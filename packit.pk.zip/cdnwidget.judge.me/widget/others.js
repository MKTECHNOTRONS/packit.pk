(function() {
    this.JST || (this.JST = {}), this.JST["templates/shopify_v2/ugc_media_grid_thumbnail"] = function(obj) {
        var __p = [];
        with(obj || {}) {
            __p.push("");
            var preloadThumbnail = "undefined" != typeof preload && preload === !0,
                wrapperClass = preloadThumbnail ? "jdgm-ugc-media__thumbnail-wrapper jdgm--loading" : "jdgm-ugc-media__thumbnail-wrapper";
            __p.push("\n\n<div class='jdgm-ugc-media__thumbnail-link' data-media-type='", ("" + object.media_type.toLowerCase()).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'>\n  <div class='", ("" + wrapperClass).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'>\n    <img class='jdgm-ugc-media__thumbnail' alt='User picture'\n        "), preloadThumbnail ? __p.push("\n          data-src='", ("" + object.thumbnail_url).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'\n        ") : __p.push("\n          src='", ("" + object.thumbnail_url).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'\n        "), __p.push("\n        "), "VIDEO" == object.media_type ? __p.push("\n          data-iframe-src='", ("" + object.media_url).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'\n        ") : __p.push("\n          data-mfp-src='", ("" + object.media_url).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'\n        "), __p.push("\n        data-object-id='", ("" + object.id || object.uuid).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'\n        data-media-type='", ("" + object.media_type.toLowerCase()).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "' />\n    "), "VIDEO" != object.media_type && (__p.push("\n    <div class='jdgm-ugc-media__actions'>\n      <div class='jdgm-ugc-media__icon-instagram'></div>\n      "), object.products.length > 0 && __p.push("\n        <a class='jdgm-ugc-media__primary-btn' data-url='", ("" + object.products[0].url + "?ref=judge.me&jdgm_referral_location=ugc_media_grid").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'>\n          ", ("" + jdgmSettings.widget_ugc_primary_button_text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "\n        </a>\n      "), __p.push("\n    </div>\n    ")), __p.push("\n  </div>\n</div>\n")
        }
        return __p.join("")
    }
}).call(this),
    function() {
        this.JST || (this.JST = {}), this.JST["templates/shopify_v3/full_review_modal"] = function(obj) {
            var __p = [];
            with(obj || {}) {
                for (__p.push("<div class='jdgm-full-rev' data-verified-buyer='", review.verified_buyer, "' data-review-id='", review.uuid, "'\n    data-product-title='", review.product_title, "' data-product-url='", review.product_url, "'>\n\n  <div class='jdgm-full-rev__header'>\n    <div class='jdgm-full-rev__rating_and_timestamp_wrapper'>\n      <span class='jdgm-full-rev__rating' data-score='", review.rating, "' tabindex='0' aria-label='", review.rating, " star review' role='img'>\n        "), i = 1; i <= 5; i++) __p.push("\n          "), status = i <= review.rating ? "on" : "off", __p.push("\n          "), "off" == status && (__p.push("\n            "), status = i - .5 <= review.rating ? "half" : "off", __p.push("\n          ")), __p.push("\n          <span class='jdgm-star jdgm--", status, "'></span>\n        ");
                __p.push("\n      </span>\n      <span class='jdgm-full-rev__timestamp' data-content='", review.user_friendly_created_at, "'>\n        ", review.user_friendly_created_at, "\n      </span>\n    </div>\n\n    <div class='jdgm-full-rev__profile-wrapper'>\n      "), review.avatar_image_url ? __p.push("\n        <div class='jdgm-full-rev__icon jdgm--loading'>\n          <img data-src='", review.avatar_image_url.normal, "'\n            data-src-retina='", review.avatar_image_url.retina, "'\n            class='jdgm-full-rev__avatar-image'\n            alt='Reviewer avatar' />\n        </div>\n      ") : review.gravatar_hash ? __p.push("\n        <div class='jdgm-full-rev__icon' data-gravatar-hash='", review.gravatar_hash, "' >\n        </div>\n      ") : __p.push("\n        <div class='jdgm-full-rev__icon'>\n        </div>\n      "), __p.push("\n\n      <div class='jdgm-full-rev__reviewer-and-location-wrapper'>\n        <div class='jdgm-full-rev__reviewer-wrapper'>\n          <span class='jdgm-full-rev__reviewer-name'>\n            ", review.public_reviewer_name, "\n          </span>\n          "), review.verified_buyer && __p.push("\n            <span class='jdgm-rev__buyer-badge'></span>\n          "), __p.push("\n        </div>\n\n        <div class='jdgm-full-rev__location-wrapper'>\n          "), jdgmSettings.widget_review_location_show && review.location && __p.push("\n            <span class='jdgm-full-rev__location' >\n              ", review.location, "\n            </span>\n          "), __p.push("\n          "), jdgmSettings.widget_show_country_flag && review.country_code_show_flag && __p.push("\n            <img class='jdgm-full-rev__location-country-flag-img' data-country-code='", review.country_code_show_flag, "' />\n          "), __p.push("\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class='jdgm-full-rev__content'>\n    <b class='jdgm-full-rev__title'>", review.title, "</b>\n    <div class='jdgm-full-rev__body'>", review.body_html, "</div>\n\n    "), review.cf_answers && (__p.push("\n      <div class='jdgm-full-rev__custom-form'>\n        "), jdgm.asyncEach(review.cf_answers, function(e) {
                    if (__p.push("\n          <div class='jdgm-full-rev__cf-ans'>\n            <div class='jdgm-full-rev__cf-ans__title'>", e.question_title, ":</div>\n            "), "scale" == e.question_type) {
                        for (__p.push("\n              <div class='jdgm-full-rev__scale-wrapper' data-value='", e.value, "'>\n                <div class='jdgm-full-rev__scale-range'>\n                  "), numberOfFilledBars = e.value.split("/")[0], __p.push("\n                  "), totalNumberOfBars = e.value.split("/")[1], __p.push("\n                  "), i = 1; i <= totalNumberOfBars; i++) __p.push("\n                    "), i <= numberOfFilledBars ? __p.push('\n                      <a href="#" rel="nofollow" class="jdgm-cf-bar jdgm--filled"></a>\n                    ') : __p.push('\n                      <a href="#" rel="nofollow" class="jdgm-cf-bar jdgm--empty"></a>\n                    '), __p.push("\n                  ");
                        __p.push("\n                </div>\n                <div class='jdgm-full-rev__scale-first'>", e.lower_value, "</div>\n                <div class='jdgm-full-rev__scale-last'>", e.top_value, "</div>\n              </div>\n            ")
                    } else "slider" == e.question_type ? __p.push("\n              <div class='jdgm-full-rev__slider-wrapper'>\n                <div class='jdgm-full-rev__slider-range'>\n                  <div class='jdgm-full-rev__slider-pointer' style='left: ", e.value, "%'></div>\n                </div>\n                <div class='jdgm-full-rev__slider-first'>", e.lower_value, "</div>\n                <div class='jdgm-full-rev__slider-last'>", e.top_value, "</div>\n              </div>\n            ") : __p.push("\n              <span class='jdgm-full-rev__cf-ans__value'>", e.value, "</span>\n            ");
                    __p.push("\n          </div>\n        ")
                }), __p.push("\n      </div>\n    ")), __p.push("\n\n    "), review.pictures_urls && (__p.push("\n      <div class='jdgm-full-rev__pics'>\n        "), jdgm.asyncEach(review.pictures_urls, function(e, t) {
                    __p.push("\n          <a class='jdgm-full-rev__pic-link jdgm--loading' target='_blank' rel='nofollow'\n              href='", e.original, "' data-mfp-src='", e.huge, "' aria-label='Link to user picture ", t, "'>\n            <img class='jdgm-full-rev__pic-img' alt='User picture' data-src='", e.compact, "'>\n          </a>\n        ")
                }), __p.push("\n      </div>\n    ")), __p.push("\n\n    "), (review.video_external_ids || review.media_platform_hosted_video_infos) && (__p.push("\n      <div class='jdgm-full-rev__vids'>\n        "), jdgm.asyncEach(review.video_external_ids, function(e) {
                    __p.push("\n          <div class='jdgm-vid-player' data-external-id=", e, ">\n            <div class='jdgm-vid-player__wrapper jdgm--loading'>\n            </div>\n          </div>\n        ")
                }), __p.push("\n        "), jdgm.asyncEach(review.media_platform_hosted_video_infos, function(e) {
                    __p.push("\n          "), "yt" == e.media_platform_name && __p.push("\n            <div class='jdgm-yt-video' data-id='", e.media_platform_url, "' data-class='jdgm-vid-player'>\n              <img src='https://img.youtube.com/vi/", e.media_platform_url, "/sddefault.jpg' class='jdgm-vid-player' alt='Judge.me YouTube video placeholder' />\n              <div class='jdgm-yt-video__play-btn'></div>\n            </div>\n          "), __p.push("\n        ")
                }), __p.push("\n      </div>\n    ")), __p.push("\n  </div>\n\n  "), review.reply_content && __p.push("\n    <div class='jdgm-full-rev__reply'>\n      <div class='jdgm-full-rev__replier-wrapper'>\n      </div>\n      <div class='jdgm-full-rev__reply-content'>", review.reply_content, "</div>\n    </div>\n  "), __p.push("\n\n  "), review.is_shop_review || __p.push("\n    <div class='jdgm-full-rev__product-wrapper'>\n      <a class='jdgm-full-rev__product-button' href='", review.product_url, "#judgeme_product_reviews'></a>\n    </div>\n  "), __p.push("\n</div>\n\n")
            }
            return __p.join("")
        }
    }.call(this),
    function() {
        this.JST || (this.JST = {}), this.JST["templates/shopify_v3/review_snippet_widget_card"] = function(obj) {
            var __p = [];
            with(obj || {}) {
                for (__p.push("<div\n  class='jdgm-rev-snippet-card'\n  data-review-id='", review.uuid, "'\n  aria-label='Review snippet card'\n  style='display: none;'\n>\n  <div class=\"jdgm-rev-snippet-card__rev-content-wrapper\">\n    "), review.review_image_url && __p.push("\n      <div class='jdgm-rev-snippet-card__pic-wrapper'>\n        <img\n          class='jdgm-rev-snippet-card__pic'\n          aria-label='Review picture'\n          title='Review picture'\n          alt='Review picture'\n          data-src='", review.review_image_url, "'\n        />\n      </div>\n    "), __p.push("\n    <div>\n      <div class='jdgm-rev-snippet-card__rev-header'>\n        <div\n          class='jdgm-rev-snippet-card__rev-rating'\n          data-score='", review.rating, "'\n          tabindex='0'\n          aria-label='", review.rating, " star review'\n          role='img'\n        >\n          "), i = 1; i <= 5; i++) __p.push("\n            "), status = i <= review.rating ? "on" : "off", __p.push("\n            "), "off" == status && (__p.push("\n              "), status = i - .5 <= review.rating ? "half" : "off", __p.push("\n            ")), __p.push("\n            <span class='jdgm-star jdgm--", status, "'></span>\n          ");
                __p.push("\n            </div>\n        <div\n          class='jdgm-rev-snippet-card__reviewer'\n          aria-label='Reviewer name'\n        >\n          ", review.public_reviewer_name, "\n        </div>\n      </div>\n      <div class='jdgm-rev-snippet-card__rev-content'>\n        <span\n          class='jdgm-rev-snippet-card__rev-body'\n          aria-label='Review body'\n        >\n          ", review.body_html, "\n        </span>\n      </div>\n    </div>\n  </div>\n</div>\n")
            }
            return __p.join("")
        }
    }.call(this),
    function(e) {
        var t = void 0;
        "function" == typeof t && t.amd ? t(["jquery"], e) : e("object" == typeof exports ? require("jquery") : window.jQuery || window.Zepto)
    }(function(e) {
        e = jdgm.$ || window.$;
        var t, i, r, n, a, o, s = "Close",
            d = "BeforeClose",
            l = "AfterClose",
            c = "BeforeAppend",
            u = "MarkupParse",
            m = "Open",
            g = "Change",
            p = "jm-mfp",
            f = "." + p,
            v = "jm-mfp-ready",
            _ = "jm-mfp-removing",
            h = "jm-mfp-prevent-close",
            j = function() {},
            w = !!e,
            b = e(window),
            y = function(e, i) {
                t.ev.on(p + e + f, i)
            },
            S = function(t, i, r, n) {
                var a = document.createElement("div");
                return a.className = "jm-mfp-" + t, r && (a.innerHTML = r), n ? i && i.appendChild(a) : (a = e(a), i && a.appendTo(i)), a
            },
            x = function(i, r) {
                t.ev.triggerHandler(p + i, r), t.st.callbacks && (i = i.charAt(0).toLowerCase() + i.slice(1), t.st.callbacks[i] && t.st.callbacks[i].apply(t, e.isArray(r) ? r : [r]))
            },
            C = function(i) {
                return i === o && t.currTemplate.closeBtn || (t.currTemplate.closeBtn = e(t.st.closeMarkup.replace("%title%", t.st.tClose)), o = i), t.currTemplate.closeBtn
            },
            k = function() {
                e.magnificPopup.instance || (t = new j, t.init(), e.magnificPopup.instance = t)
            },
            T = function() {
                var e = document.createElement("p").style,
                    t = ["ms", "O", "Moz", "Webkit"];
                if (void 0 !== e.transition) return !0;
                for (; t.length;)
                    if (t.pop() + "Transition" in e) return !0;
                return !1
            };
        j.prototype = {
            constructor: j,
            init: function() {
                var i = navigator.appVersion;
                t.isLowIE = t.isIE8 = document.all && !document.addEventListener, t.isAndroid = /android/gi.test(i), t.isIOS = /iphone|ipad|ipod/gi.test(i), t.supportsTransition = T(), t.probablyMobile = t.isAndroid || t.isIOS || /(Opera Mini)|Kindle|webOS|BlackBerry|(Opera Mobi)|(Windows Phone)|IEMobile/i.test(navigator.userAgent), r = e(document), t.popupsCache = {}
            },
            open: function(i) {
                var n;
                if (i.isObj === !1) {
                    t.items = i.items.toArray(), t.index = 0;
                    var o, s = i.items;
                    for (n = 0; n < s.length; n++)
                        if (o = s[n], o.parsed && (o = o.el[0]), o === i.el[0]) {
                            t.index = n;
                            break
                        }
                } else t.items = e.isArray(i.items) ? i.items : [i.items], t.index = i.index || 0;
                if (t.isOpen) return void t.updateItemHTML();
                t.types = [], a = "", i.mainEl && i.mainEl.length ? t.ev = i.mainEl.eq(0) : t.ev = r, i.key ? (t.popupsCache[i.key] || (t.popupsCache[i.key] = {}), t.currTemplate = t.popupsCache[i.key]) : t.currTemplate = {}, t.st = e.extend(!0, {}, e.magnificPopup.defaults, i), t.fixedContentPos = "auto" === t.st.fixedContentPos ? !t.probablyMobile : t.st.fixedContentPos, t.st.modal && (t.st.closeOnContentClick = !1, t.st.closeOnBgClick = !1, t.st.showCloseBtn = !1, t.st.enableEscapeKey = !1), t.bgOverlay || (t.bgOverlay = S("bg").on("click" + f, function() {
                    t.close()
                }), t.wrap = S("wrap").attr("tabindex", -1).on("click" + f, function(e) {
                    t._checkIfClose(e.target) && t.close()
                }), t.container = S("container", t.wrap)), t.contentContainer = S("content"), t.st.preloader && (t.preloader = S("preloader", t.container, t.st.tLoading));
                var d = e.magnificPopup.modules;
                for (n = 0; n < d.length; n++) {
                    var l = d[n];
                    l = l.charAt(0).toUpperCase() + l.slice(1), t["init" + l].call(t)
                }
                x("BeforeOpen"), t.st.showCloseBtn && (t.st.closeBtnInside ? (y(u, function(e, t, i, r) {
                    i.close_replaceWith = C(r.type)
                }), a += " jm-mfp-close-btn-in") : t.wrap.append(C())), t.st.alignTop && (a += " jm-mfp-align-top"), t.fixedContentPos ? t.wrap.css({
                    overflow: t.st.overflowY,
                    overflowX: "hidden",
                    overflowY: t.st.overflowY
                }) : t.wrap.css({
                    top: b.scrollTop(),
                    position: "absolute"
                }), (t.st.fixedBgPos === !1 || "auto" === t.st.fixedBgPos && !t.fixedContentPos) && t.bgOverlay.css({
                    height: r.height(),
                    position: "absolute"
                }), t.st.enableEscapeKey && r.on("keyup" + f, function(e) {
                    27 === e.keyCode && t.close()
                }), b.on("resize" + f, function() {
                    t.updateSize()
                }), t.st.closeOnContentClick || (a += " jm-mfp-auto-cursor"), a && t.wrap.addClass(a);
                var c = t.wH = b.height(),
                    g = {};
                if (t.fixedContentPos && t._hasScrollBar(c)) {
                    var p = t._getScrollbarSize();
                    p && (g.marginRight = p)
                }
                t.fixedContentPos && (t.isIE7 ? e("body, html").css("overflow", "hidden") : g.overflow = "hidden");
                var _ = t.st.mainClass;
                return t.isIE7 && (_ += " jm-mfp-ie7"), _ && t._addClassToMFP(_), t.updateItemHTML(), x("BuildControls"), e("html").css(g), t.bgOverlay.add(t.wrap).prependTo(t.st.prependTo || e(document.body)), t._lastFocusedEl = document.activeElement, setTimeout(function() {
                    t.content ? (t._addClassToMFP(v), t._setFocus()) : t.bgOverlay.addClass(v), r.on("focusin" + f, t._onFocusIn)
                }, 16), t.isOpen = !0, t.updateSize(c), x(m), i
            },
            close: function() {
                t.isOpen && (x(d), t.isOpen = !1, t.st.removalDelay && !t.isLowIE && t.supportsTransition ? (t._addClassToMFP(_), setTimeout(function() {
                    t._close()
                }, t.st.removalDelay)) : t._close())
            },
            _close: function() {
                x(s);
                var i = _ + " " + v + " ";
                if (t.bgOverlay.detach(), t.wrap.detach(), t.container.empty(), t.st.mainClass && (i += t.st.mainClass + " "), t._removeClassFromMFP(i), t.fixedContentPos) {
                    var n = {
                        marginRight: ""
                    };
                    t.isIE7 ? e("body, html").css("overflow", "") : n.overflow = "", e("html").css(n)
                }
                r.off("keyup" + f + " focusin" + f), t.ev.off(f), t.wrap.attr("class", "jm-mfp-wrap").removeAttr("style"), t.bgOverlay.attr("class", "jm-mfp-bg"), t.container.attr("class", "jm-mfp-container"), !t.st.showCloseBtn || t.st.closeBtnInside && t.currTemplate[t.currItem.type] !== !0 || t.currTemplate.closeBtn && t.currTemplate.closeBtn.detach(), t.st.autoFocusLast && t._lastFocusedEl && e(t._lastFocusedEl).focus(), t.currItem = null, t.content = null, t.currTemplate = null, t.prevHeight = 0, x(l)
            },
            updateSize: function(e) {
                if (t.isIOS) {
                    var i = document.documentElement.clientWidth / window.innerWidth,
                        r = window.innerHeight * i;
                    t.wrap.css("height", r), t.wH = r
                } else t.wH = e || b.height();
                t.fixedContentPos || t.wrap.css("height", t.wH), x("Resize")
            },
            updateItemHTML: function() {
                var i = t.items[t.index];
                t.contentContainer.detach(), t.content && t.content.detach(), i.parsed || (i = t.parseEl(t.index));
                var r = i.type;
                if (x("BeforeChange", [t.currItem ? t.currItem.type : "", r]), t.currItem = i, !t.currTemplate[r]) {
                    var a = t.st[r] ? t.st[r].markup : !1;
                    x("FirstMarkupParse", a), a ? t.currTemplate[r] = e(a) : t.currTemplate[r] = !0
                }
                n && n !== i.type && t.container.removeClass("jm-mfp-" + n + "-holder");
                var o = t["get" + r.charAt(0).toUpperCase() + r.slice(1)](i, t.currTemplate[r]);
                t.appendContent(o, r), i.preloaded = !0, x(g, i), n = i.type, t.container.prepend(t.contentContainer), x("AfterChange")
            },
            appendContent: function(e, i) {
                t.content = e, e ? t.st.showCloseBtn && t.st.closeBtnInside && t.currTemplate[i] === !0 ? t.content.find(".jm-mfp-close").length || t.content.append(C()) : t.content = e : t.content = "", x(c), t.container.addClass("jm-mfp-" + i + "-holder"), t.contentContainer.append(t.content)
            },
            parseEl: function(i) {
                var r, n = t.items[i];
                if (n.tagName ? n = {
                        el: e(n)
                    } : (r = n.type, n = {
                        data: n,
                        src: n.src
                    }), n.el) {
                    for (var a = t.types, o = 0; o < a.length; o++)
                        if (n.el.hasClass("jm-mfp-" + a[o])) {
                            r = a[o];
                            break
                        }
                    n.src = n.el.attr("data-mfp-src"), n.src || (n.src = n.el.attr("href"))
                }
                return n.type = r || t.st.type || "inline", n.index = i, n.parsed = !0, t.items[i] = n, x("ElementParse", n), t.items[i]
            },
            addGroup: function(e, i) {
                var r = function(r) {
                    r.mfpEl = this, t._openClick(r, e, i)
                };
                i || (i = {});
                var n = "click.magnificPopup";
                i.mainEl = e, i.items ? (i.isObj = !0, e.off(n).on(n, r)) : (i.isObj = !1, i.delegate ? e.off(n).on(n, i.delegate, r) : (i.items = e, e.off(n).on(n, r)))
            },
            _openClick: function(i, r, n) {
                var a = void 0 !== n.midClick ? n.midClick : e.magnificPopup.defaults.midClick;
                if (a || !(2 === i.which || i.ctrlKey || i.metaKey || i.altKey || i.shiftKey)) {
                    var o = void 0 !== n.disableOn ? n.disableOn : e.magnificPopup.defaults.disableOn;
                    if (o)
                        if (e.isFunction(o)) {
                            if (!o.call(t)) return !0
                        } else if (b.width() < o) return !0;
                    i.type && (i.preventDefault(), t.isOpen && i.stopPropagation()), n.el = e(i.mfpEl), n.delegate && (n.items = r.find(n.delegate)), t.open(n)
                }
            },
            updateStatus: function(e, r) {
                if (t.preloader) {
                    i !== e && t.container.removeClass("jm-mfp-s-" + i), r || "loading" !== e || (r = t.st.tLoading);
                    var n = {
                        status: e,
                        text: r
                    };
                    x("UpdateStatus", n), e = n.status, r = n.text, t.preloader.html(r), t.preloader.find("a").on("click", function(e) {
                        e.stopImmediatePropagation()
                    }), t.container.addClass("jm-mfp-s-" + e), i = e
                }
            },
            _checkIfClose: function(i) {
                if (!e(i).hasClass(h)) {
                    var r = t.st.closeOnContentClick,
                        n = t.st.closeOnBgClick;
                    if (r && n) return !0;
                    if (!t.content || e(i).hasClass("jm-mfp-close") || t.preloader && i === t.preloader[0]) return !0;
                    if (i === t.content[0] || e.contains(t.content[0], i)) {
                        if (r) return !0
                    } else if (n && e.contains(document, i)) return !0;
                    return !1
                }
            },
            _addClassToMFP: function(e) {
                t.bgOverlay.addClass(e), t.wrap.addClass(e)
            },
            _removeClassFromMFP: function(e) {
                this.bgOverlay.removeClass(e), t.wrap.removeClass(e)
            },
            _hasScrollBar: function(e) {
                return (t.isIE7 ? r.height() : document.body.scrollHeight) > (e || b.height())
            },
            _setFocus: function() {
                (t.st.focus ? t.content.find(t.st.focus).eq(0) : t.wrap).focus()
            },
            _onFocusIn: function(i) {
                return i.target === t.wrap[0] || e.contains(t.wrap[0], i.target) ? void 0 : (t._setFocus(), !1)
            },
            _parseMarkup: function(t, i, r) {
                var n;
                r.data && (i = e.extend(r.data, i)), x(u, [t, i, r]), e.each(i, function(i, r) {
                    if (void 0 === r || r === !1) return !0;
                    if (n = i.split("_"), n.length > 1) {
                        var a = t.find(f + "-" + n[0]);
                        if (a.length > 0) {
                            var o = n[1];
                            "replaceWith" === o ? a[0] !== r[0] && a.replaceWith(r) : "img" === o ? a.is("img") ? a.attr("src", r) : a.replaceWith(e("<img>").attr("src", r).attr("class", a.attr("class"))) : a.attr(n[1], r)
                        }
                    } else t.find(f + "-" + i).html(r)
                })
            },
            _getScrollbarSize: function() {
                if (void 0 === t.scrollbarSize) {
                    var e = document.createElement("div");
                    e.style.cssText = "width: 99px; height: 99px; overflow: scroll; position: absolute; top: -9999px;", document.body.appendChild(e), t.scrollbarSize = e.offsetWidth - e.clientWidth, document.body.removeChild(e)
                }
                return t.scrollbarSize
            }
        }, e.magnificPopup = {
            instance: null,
            proto: j.prototype,
            modules: [],
            open: function(t, i) {
                return k(), t = t ? e.extend(!0, {}, t) : {}, t.isObj = !0, t.index = i || 0, this.instance.open(t)
            },
            close: function() {
                return e.magnificPopup.instance && e.magnificPopup.instance.close()
            },
            registerModule: function(t, i) {
                i.options && (e.magnificPopup.defaults[t] = i.options), e.extend(this.proto, i.proto), this.modules.push(t)
            },
            defaults: {
                disableOn: 0,
                key: null,
                midClick: !1,
                mainClass: "",
                preloader: !0,
                focus: "",
                closeOnContentClick: !1,
                closeOnBgClick: !0,
                closeBtnInside: !0,
                showCloseBtn: !0,
                enableEscapeKey: !0,
                modal: !1,
                alignTop: !1,
                removalDelay: 0,
                prependTo: null,
                fixedContentPos: "auto",
                fixedBgPos: "auto",
                overflowY: "auto",
                closeMarkup: '<button title="%title%" type="button" class="jm-mfp-close">&#215;</button>',
                tClose: "Close (Esc)",
                tLoading: "Loading...",
                autoFocusLast: !0
            }
        }, e.fn.magnificPopup = function(i) {
            k();
            var r = e(this);
            if ("string" == typeof i)
                if ("open" === i) {
                    var n, a = w ? r.data("magnificPopup") : r[0].magnificPopup,
                        o = parseInt(arguments[1], 10) || 0;
                    a.items ? n = a.items[o] : (n = r, a.delegate && (n = n.find(a.delegate)), n = n.eq(o)), t._openClick({
                        mfpEl: n
                    }, r, a)
                } else t.isOpen && t[i].apply(t, Array.prototype.slice.call(arguments, 1));
            else i = e.extend(!0, {}, i), w ? r.data("magnificPopup", i) : r[0].magnificPopup = i, t.addGroup(r, i);
            return r
        };
        var E, I, L, M = "inline",
            P = function() {
                L && (I.after(L.addClass(E)).detach(), L = null)
            };
        e.magnificPopup.registerModule(M, {
            options: {
                hiddenClass: "hide",
                markup: "",
                tNotFound: "Content not found"
            },
            proto: {
                initInline: function() {
                    t.types.push(M), y(s + "." + M, function() {
                        P()
                    })
                },
                getInline: function(i, r) {
                    if (P(), i.src) {
                        var n = t.st.inline,
                            a = e(i.src);
                        if (a.length) {
                            var o = a[0].parentNode;
                            o && o.tagName && (I || (E = n.hiddenClass, I = S(E), E = "jm-mfp-" + E), L = a.after(I).detach().removeClass(E)), t.updateStatus("ready")
                        } else t.updateStatus("error", n.tNotFound), a = e("<div>");
                        return i.inlineElement = a, a
                    }
                    return t.updateStatus("ready"), t._parseMarkup(r, {}, i), r
                }
            }
        });
        var z, F = function(i, r) {
            if (i.data && void 0 !== i.data.title) return i.data.title;
            var n = t.st.image.titleSrc;
            if ("iframe" == r && (n = t.st.iframe.titleSrc), n) {
                if (e.isFunction(n)) return n.call(t, i);
                if (i.el) return i.el.attr(n) || ""
            }
            return ""
        };
        e.magnificPopup.registerModule("image", {
            options: {
                markup: '<div class="jm-mfp-figure"><div class="jm-mfp-close"></div><figure><div class="jm-mfp-img"></div><figcaption><div class="jm-mfp-bottom-bar"><div class="jm-mfp-title"></div><div class="jm-mfp-counter"></div></div></figcaption></figure></div>',
                cursor: "jm-mfp-zoom-out-cur",
                titleSrc: "title",
                verticalFit: !0,
                tError: '<a href="%url%">The image</a> could not be loaded.'
            },
            proto: {
                initImage: function() {
                    var i = t.st.image,
                        r = ".image";
                    t.types.push("image"), y(m + r, function() {
                        "image" === t.currItem.type && i.cursor && e(document.body).addClass(i.cursor)
                    }), y(s + r, function() {
                        i.cursor && e(document.body).removeClass(i.cursor), b.off("resize" + f)
                    }), y("Resize" + r, t.resizeImage), t.isLowIE && y("AfterChange", t.resizeImage)
                },
                resizeImage: function() {
                    var e = t.currItem;
                    if (e && e.img && t.st.image.verticalFit) {
                        var i = 0;
                        t.isLowIE && (i = parseInt(e.img.css("padding-top"), 10) + parseInt(e.img.css("padding-bottom"), 10)), e.img.css("max-height", t.wH - i)
                    }
                },
                _onImageHasSize: function(e) {
                    e.img && (e.hasSize = !0, z && clearInterval(z), e.isCheckingImgSize = !1, x("ImageHasSize", e), e.imgHidden && (t.content && t.content.removeClass("jm-mfp-loading"), e.imgHidden = !1))
                },
                findImageSize: function(e) {
                    var i = 0,
                        r = e.img[0],
                        n = function(a) {
                            z && clearInterval(z), z = setInterval(function() {
                                return r.naturalWidth > 0 ? void t._onImageHasSize(e) : (i > 200 && clearInterval(z), i++, void(3 === i ? n(10) : 40 === i ? n(50) : 100 === i && n(500)))
                            }, a)
                        };
                    n(1)
                },
                getImage: function(i, r) {
                    var n = 0,
                        a = function() {
                            i && (i.img[0].complete ? (i.img.off(".mfploader"), i === t.currItem && (t._onImageHasSize(i), t.updateStatus("ready")), i.hasSize = !0, i.loaded = !0, x("ImageLoadComplete")) : (n++, 200 > n ? setTimeout(a, 100) : o()))
                        },
                        o = function() {
                            i && (i.img.off(".mfploader"), i === t.currItem && (t._onImageHasSize(i), t.updateStatus("error", s.tError.replace("%url%", i.src))), i.hasSize = !0, i.loaded = !0, i.loadError = !0)
                        },
                        s = t.st.image,
                        d = r.find(".jm-mfp-img");
                    if (d.length) {
                        var l = document.createElement("img");
                        l.className = "jm-mfp-img", i.el && i.el.find("img").length && (l.alt = i.el.find("img").attr("alt")), i.img = e(l).on("load.mfploader", a).on("error.mfploader", o), l.src = i.src, d.is("img") && (i.img = i.img.clone()), l = i.img[0], l.naturalWidth > 0 ? i.hasSize = !0 : l.width || (i.hasSize = !1)
                    }
                    return t._parseMarkup(r, {
                        title: F(i),
                        img_replaceWith: i.img
                    }, i), t.resizeImage(), i.hasSize ? (z && clearInterval(z), i.loadError ? (r.addClass("jm-mfp-loading"), t.updateStatus("error", s.tError.replace("%url%", i.src))) : (r.removeClass("jm-mfp-loading"), t.updateStatus("ready")), r) : (t.updateStatus("loading"), i.loading = !0, i.hasSize || (i.imgHidden = !0, r.addClass("jm-mfp-loading"), t.findImageSize(i)), r)
                }
            }
        });
        var R, A = function() {
            return void 0 === R && (R = void 0 !== document.createElement("p").style.MozTransform), R
        };
        e.magnificPopup.registerModule("zoom", {
            options: {
                enabled: !1,
                easing: "ease-in-out",
                duration: 300,
                opener: function(e) {
                    return e.is("img") ? e : e.find("img")
                }
            },
            proto: {
                initZoom: function() {
                    var e, i = t.st.zoom,
                        r = ".zoom";
                    if (i.enabled && t.supportsTransition) {
                        var n, a, o = i.duration,
                            l = function(e) {
                                var t = e.clone().removeAttr("style").removeAttr("class").addClass("jm-mfp-animated-image"),
                                    r = "all " + i.duration / 1e3 + "s " + i.easing,
                                    n = {
                                        position: "fixed",
                                        zIndex: 9999,
                                        left: 0,
                                        top: 0,
                                        "-webkit-backface-visibility": "hidden"
                                    },
                                    a = "transition";
                                return n["-webkit-" + a] = n["-moz-" + a] = n["-o-" + a] = n[a] = r, t.css(n), t
                            },
                            c = function() {
                                t.content.css("visibility", "visible")
                            };
                        y("BuildControls" + r, function() {
                            if (t._allowZoom()) {
                                if (clearTimeout(n), t.content.css("visibility", "hidden"), e = t._getItemToZoom(), !e) return void c();
                                a = l(e), a.css(t._getOffset()), t.wrap.append(a), n = setTimeout(function() {
                                    a.css(t._getOffset(!0)), n = setTimeout(function() {
                                        c(), setTimeout(function() {
                                            a.remove(), e = a = null, x("ZoomAnimationEnded")
                                        }, 16)
                                    }, o)
                                }, 16)
                            }
                        }), y(d + r, function() {
                            if (t._allowZoom()) {
                                if (clearTimeout(n), t.st.removalDelay = o, !e) {
                                    if (e = t._getItemToZoom(), !e) return;
                                    a = l(e)
                                }
                                a.css(t._getOffset(!0)), t.wrap.append(a), t.content.css("visibility", "hidden"), setTimeout(function() {
                                    a.css(t._getOffset())
                                }, 16)
                            }
                        }), y(s + r, function() {
                            t._allowZoom() && (c(), a && a.remove(), e = null)
                        })
                    }
                },
                _allowZoom: function() {
                    return "image" === t.currItem.type
                },
                _getItemToZoom: function() {
                    return t.currItem.hasSize ? t.currItem.img : !1
                },
                _getOffset: function(i) {
                    var r;
                    r = i ? t.currItem.img : t.st.zoom.opener(t.currItem.el || t.currItem);
                    var n = r.offset(),
                        a = parseInt(r.css("padding-top"), 10),
                        o = parseInt(r.css("padding-bottom"), 10);
                    n.top -= e(window).scrollTop() - a;
                    var s = {
                        width: r.width(),
                        height: (w ? r.innerHeight() : r[0].offsetHeight) - o - a
                    };
                    return A() ? s["-moz-transform"] = s.transform = "translate(" + n.left + "px," + n.top + "px)" : (s.left = n.left, s.top = n.top), s
                }
            }
        });
        var W = "iframe",
            O = "//about:blank",
            D = function(e) {
                if (t.currTemplate[W]) {
                    var i = t.currTemplate[W].find("iframe");
                    i.length && (e || (i[0].src = O), t.isIE8 && i.css("display", e ? "block" : "none"))
                }
            };
        e.magnificPopup.registerModule(W, {
            options: {
                markup: '<div class="mfp-iframe-scaler"><div class="mfp-close"></div><iframe class="mfp-iframe" src="//about:blank" frameborder="0" allowfullscreen></iframe></div>',
                srcAction: "iframe_src",
                posterAction: "iframe_poster",
                titleSrc: "title",
                patterns: {
                    youtube: {
                        index: "youtube.com",
                        id: "v=",
                        src: "//www.youtube.com/embed/%id%"
                    },
                    vimeo: {
                        index: "vimeo.com/",
                        id: "/",
                        src: "//player.vimeo.com/video/%id%"
                    },
                    cloudflare: {
                        index: "cloudflarestream.com/",
                        id: "/",
                        src: "//iframe.videodelivery.net/%id%"
                    }
                }
            },
            proto: {
                initIframe: function() {
                    t.types.push(W), y("BeforeChange", function(e, t, i) {
                        t !== i && (t === W ? D() : i === W && D(!0))
                    }), y(s + "." + W, function() {
                        D()
                    })
                },
                getIframe: function(i, r) {
                    var n = i.el.attr("data-iframe-src"),
                        a = t.st.iframe;
                    e.each(a.patterns, function() {
                        return n.indexOf(this.index) > -1 ? (this.id && (n = "string" == typeof this.id ? n.substr(n.lastIndexOf(this.id) + this.id.length, n.length) : this.id.call(this, n)), n = this.src.replace("%id%", n), !1) : void 0
                    });
                    var o = {};
                    return a.srcAction && (o[a.srcAction] = n), a.posterAction && (o[a.posterAction] = i.el.attr("src")), a.titleSrc && (o.title = F(i, "iframe")), t._parseMarkup(r, o, i), t.updateStatus("ready"), r
                }
            }
        });
        var B = function(e) {
                var i = t.items.length;
                return e > i - 1 ? e - i : 0 > e ? i + e : e
            },
            N = function(e, t, i) {
                return e.replace(/%curr%/gi, t + 1).replace(/%total%/gi, i)
            };
        e.magnificPopup.registerModule("gallery", {
            options: {
                enabled: !1,
                arrowMarkup: '<button title="%title%" type="button" class="jm-mfp-arrow jm-mfp-arrow-%dir%"></button>',
                preload: [0, 2],
                navigateByImgClick: !0,
                arrows: !0,
                tPrev: "Previous (Left arrow key)",
                tNext: "Next (Right arrow key)",
                tCounter: "%curr% of %total%"
            },
            proto: {
                initGallery: function() {
                    var i = t.st.gallery,
                        n = ".jm-mfp-gallery";
                    return t.direction = !0, i && i.enabled ? (a += " jm-mfp-gallery", y(m + n, function() {
                        i.navigateByImgClick && t.wrap.on("click" + n, ".jm-mfp-img", function() {
                            return t.items.length > 1 ? (t.next(), !1) : void 0
                        }), r.on("keydown" + n, function(e) {
                            37 === e.keyCode ? t.prev() : 39 === e.keyCode && t.next()
                        })
                    }), y("UpdateStatus" + n, function(e, i) {
                        i.text && (i.text = N(i.text, t.currItem.index, t.items.length))
                    }), y(u + n, function(e, r, n, a) {
                        var o = t.items.length;
                        n.counter = o > 1 ? N(i.tCounter, a.index, o) : ""
                    }), y("BuildControls" + n, function() {
                        if (t.items.length > 1 && i.arrows && !t.arrowLeft) {
                            var r = i.arrowMarkup,
                                n = t.arrowLeft = e(r.replace(/%title%/gi, i.tPrev).replace(/%dir%/gi, "left")).addClass(h),
                                a = t.arrowRight = e(r.replace(/%title%/gi, i.tNext).replace(/%dir%/gi, "right")).addClass(h);
                            n.click(function() {
                                t.prev()
                            }), a.click(function() {
                                t.next()
                            }), t.container.append(n.add(a))
                        }
                    }), y(g + n, function() {
                        t._preloadTimeout && clearTimeout(t._preloadTimeout), t._preloadTimeout = setTimeout(function() {
                            t.preloadNearbyImages(), t._preloadTimeout = null
                        }, 16)
                    }), void y(s + n, function() {
                        r.off(n), t.wrap.off("click" + n), t.arrowRight = t.arrowLeft = null
                    })) : !1
                },
                next: function() {
                    t.direction = !0, t.index = B(t.index + 1), t.updateItemHTML()
                },
                prev: function() {
                    t.direction = !1, t.index = B(t.index - 1), t.updateItemHTML()
                },
                goTo: function(e) {
                    t.direction = e >= t.index, t.index = e, t.updateItemHTML()
                },
                preloadNearbyImages: function() {
                    var e, i = t.st.gallery.preload,
                        r = Math.min(i[0], t.items.length),
                        n = Math.min(i[1], t.items.length);
                    for (e = 1; e <= (t.direction ? n : r); e++) t._preloadItem(t.index + e);
                    for (e = 1; e <= (t.direction ? r : n); e++) t._preloadItem(t.index - e)
                },
                _preloadItem: function(i) {
                    if (i = B(i), !t.items[i].preloaded) {
                        var r = t.items[i];
                        r.parsed || (r = t.parseEl(i)), x("LazyLoad", r), "image" === r.type && (r.img = e('<img class="jm-mfp-img" />').on("load.mfploader", function() {
                            r.hasSize = !0
                        }).on("error.mfploader", function() {
                            r.hasSize = !0, r.loadError = !0, x("LazyLoadError", r)
                        }).attr("src", r.src)), r.preloaded = !0
                    }
                }
            }
        });
        var $ = "retina";
        e.magnificPopup.registerModule($, {
            options: {
                replaceSrc: function(e) {
                    return e.src.replace(/\.\w+$/, function(e) {
                        return "@2x" + e
                    })
                },
                ratio: 1
            },
            proto: {
                initRetina: function() {
                    if (window.devicePixelRatio > 1) {
                        var e = t.st.retina,
                            i = e.ratio;
                        i = isNaN(i) ? i() : i, i > 1 && (y("ImageHasSize." + $, function(e, t) {
                            t.img.css({
                                "max-width": t.img[0].naturalWidth / i,
                                width: "100%"
                            })
                        }), y("ElementParse." + $, function(t, r) {
                            r.src = e.replaceSrc(r, i)
                        }))
                    }
                }
            }
        }), k()
    }),
    function(e) {
        "function" == typeof define && define.amd ? define(e) : "object" == typeof exports ? module.exports = e() : e()
    }(function() {
        var e = "undefined" != typeof window ? window : this;
        e.jdgm = e.jdgm || {};
        var t = e.jdgm.Glider = function(t, i) {
                var r = this;
                if (t._glider) return t._glider;
                if (r.ele = t, r.ele.classList.add("jdgm-glider"), r.ele._glider = r, r.opt = Object.assign({}, {
                        slidesToScroll: 1,
                        slidesToShow: 1,
                        resizeLock: !0,
                        duration: .5,
                        easing: function(e, t, i, r, n) {
                            return r * (t /= n) * t + i
                        }
                    }, i), r.animate_id = r.page = r.slide = 0, r.arrows = {}, r._opt = r.opt, r.opt.skipTrack) r.track = r.ele.children[0];
                else
                    for (r.track = document.createElement("div"), r.ele.appendChild(r.track); 1 !== r.ele.children.length;) r.track.appendChild(r.ele.children[0]);
                r.track.classList.add("jdgm-glider-track"), r.init(), r.resize = r.init.bind(r, !0), r.event(r.ele, "add", {
                    scroll: r.updateControls.bind(r)
                }), r.event(e, "add", {
                    resize: r.resize
                })
            },
            i = t.prototype;
        return i.init = function(e, t) {
            var i = this,
                r = 0,
                n = 0;
            i.slides = i.track.children, [].forEach.call(i.slides, function(e, t) {
                e.classList.add("jdgm-glider-slide"), e.setAttribute("data-gslide", t)
            }), i.containerWidth = i.ele.clientWidth;
            var a = i.settingsBreakpoint();
            if (t || (t = a), "auto" === i.opt.slidesToShow || "undefined" != typeof i.opt._autoSlide) {
                var o = i.containerWidth / i.opt.itemWidth;
                i.opt._autoSlide = i.opt.slidesToShow = i.opt.exactWidth ? o : Math.max(1, Math.floor(o))
            }
            "auto" === i.opt.slidesToScroll && (i.opt.slidesToScroll = Math.floor(i.opt.slidesToShow)), i.itemWidth = i.opt.exactWidth ? i.opt.itemWidth : i.containerWidth / i.opt.slidesToShow, [].forEach.call(i.slides, function(e) {
                e.style.height = "auto", e.style.width = i.itemWidth + "px", r += i.itemWidth, n = Math.max(e.offsetHeight, n);
            }), i.track.style.width = r + "px", i.trackWidth = r, i.isDrag = !1, i.preventClick = !1, i.move = !1, i.opt.resizeLock && i.scrollTo(i.slide * i.itemWidth, 0), (a || t) && (i.bindArrows(), i.buildDots(), i.bindDrag()), i.updateControls(), i.emit(e ? "refresh" : "loaded")
        }, i.bindDrag = function() {
            var e = this;
            e.mouse = e.mouse || e.handleMouse.bind(e);
            var t = function() {
                e.mouseDown = void 0, e.ele.classList.remove("drag"), e.isDrag && (e.preventClick = !0), e.isDrag = !1
            };
            const i = function() {
                e.move = !0
            };
            var r = {
                mouseup: t,
                mouseleave: t,
                mousedown: function(t) {
                    t.preventDefault(), t.stopPropagation(), e.mouseDown = t.clientX, e.ele.classList.add("drag"), e.move = !1, setTimeout(i, 300)
                },
                touchstart: function(t) {
                    e.ele.classList.add("drag"), e.move = !1, setTimeout(i, 300)
                },
                mousemove: e.mouse,
                click: function(t) {
                    e.preventClick && e.move && (t.preventDefault(), t.stopPropagation()), e.preventClick = !1, e.move = !1
                }
            };
            e.ele.classList.toggle("draggable", e.opt.draggable === !0), e.event(e.ele, "remove", r), e.opt.draggable && e.event(e.ele, "add", r)
        }, i.buildDots = function() {
            var e = this;
            if (!e.opt.dots) return void(e.dots && (e.dots.innerHTML = ""));
            if ("string" == typeof e.opt.dots ? e.dots = document.querySelector(e.opt.dots) : e.dots = e.opt.dots, e.dots) {
                e.dots.innerHTML = "", e.dots.setAttribute("role", "tablist"), e.dots.classList.add("jdgm-glider-dots");
                for (var t = 0; t < Math.ceil(e.slides.length / e.opt.slidesToShow); ++t) {
                    var i = document.createElement("button");
                    i.dataset.index = t, i.setAttribute("aria-label", "Page " + (t + 1)), i.setAttribute("role", "tab"), i.className = "glider-dot " + (t ? "" : "active"), e.event(i, "add", {
                        click: e.scrollItem.bind(e, t, !0)
                    }), e.dots.appendChild(i)
                }
            }
        }, i.bindArrows = function() {
            var e = this;
            return e.opt.arrows ? void["prev", "next"].forEach(function(t) {
                var i = e.opt.arrows[t];
                i && ("string" == typeof i && (i = document.querySelector(i)), i && (i._func = i._func || e.scrollItem.bind(e, t), e.event(i, "remove", {
                    click: i._func
                }), e.event(i, "add", {
                    click: i._func
                }), e.arrows[t] = i))
            }) : void Object.keys(e.arrows).forEach(function(t) {
                var i = e.arrows[t];
                e.event(i, "remove", {
                    click: i._func
                })
            })
        }, i.updateControls = function(e) {
            var t = this;
            e && !t.opt.scrollPropagate && e.stopPropagation();
            var i = t.containerWidth >= t.trackWidth;
            t.opt.rewind || (t.arrows.prev && (t.arrows.prev.classList.toggle("disabled", t.ele.scrollLeft <= 0 || i), t.arrows.prev.setAttribute("aria-disabled", t.arrows.prev.classList.contains("disabled"))), t.arrows.next && (t.arrows.next.classList.toggle("disabled", Math.ceil(t.ele.scrollLeft + t.containerWidth) >= Math.floor(t.trackWidth) || i), t.arrows.next.setAttribute("aria-disabled", t.arrows.next.classList.contains("disabled")))), t.slide = Math.round(t.ele.scrollLeft / t.itemWidth), t.page = Math.round(t.ele.scrollLeft / t.containerWidth);
            var r = t.slide + Math.floor(Math.floor(t.opt.slidesToShow) / 2),
                n = Math.floor(t.opt.slidesToShow) % 2 ? 0 : r + 1;
            1 === Math.floor(t.opt.slidesToShow) && (n = 0), t.ele.scrollLeft + t.containerWidth >= Math.floor(t.trackWidth) && (t.page = t.dots ? t.dots.children.length - 1 : 0), [].forEach.call(t.slides, function(e, i) {
                var a = e.classList,
                    o = a.contains("visible"),
                    s = t.ele.scrollLeft,
                    d = t.ele.scrollLeft + t.containerWidth,
                    l = t.itemWidth * i,
                    c = l + t.itemWidth;
                [].forEach.call(a, function(e) {
                    /^left|right/.test(e) && a.remove(e)
                }), a.toggle("active", t.slide === i), r === i || n && n === i ? a.add("jdgm-center") : (a.remove("jdgm-center"), a.add([r > i ? "jdgm-left" : "jdgm-right", Math.abs(i - (r > i ? r : n || r))].join("-")));
                var u = Math.ceil(l) >= Math.floor(s) && Math.floor(c) <= Math.ceil(d);
                a.toggle("visible", u), u !== o && t.emit("slide-" + (u ? "visible" : "hidden"), {
                    slide: i
                })
            }), t.dots && [].forEach.call(t.dots.children, function(e, i) {
                e.classList.toggle("active", t.page === i)
            }), e && t.opt.scrollLock && (clearTimeout(t.scrollLock), t.scrollLock = setTimeout(function() {
                clearTimeout(t.scrollLock), Math.abs(t.ele.scrollLeft / t.itemWidth - t.slide) > .02 && (t.mouseDown || t.trackWidth > t.containerWidth + t.ele.scrollLeft && t.scrollItem(t.getCurrentSlide()))
            }, t.opt.scrollLockDelay || 250))
        }, i.getCurrentSlide = function() {
            var e = this;
            return e.round(e.ele.scrollLeft / e.itemWidth)
        }, i.scrollItem = function(e, t, i) {
            i && i.preventDefault();
            var r = this,
                n = e;
            ++r.animate_id;
            var a, o = r.slide;
            if (t === !0) e = Math.round(e * r.containerWidth / r.itemWidth), a = e * r.itemWidth;
            else {
                if ("string" == typeof e) {
                    var s = "prev" === e;
                    if (e = r.opt.slidesToScroll % 1 || r.opt.slidesToShow % 1 ? r.getCurrentSlide() : r.slide, s ? e -= r.opt.slidesToScroll : e += r.opt.slidesToScroll, r.opt.rewind) {
                        var d = r.ele.scrollLeft;
                        e = s && !d ? r.slides.length : !s && d + r.containerWidth >= Math.floor(r.trackWidth) ? 0 : e
                    }
                }
                e = Math.max(Math.min(e, r.slides.length), 0), r.slide = e, a = r.itemWidth * e
            }
            return r.emit("scroll-item", {
                prevSlide: o,
                slide: e
            }), r.scrollTo(a, r.opt.duration * Math.abs(r.ele.scrollLeft - a), function() {
                r.updateControls(), r.emit("animated", {
                    value: n,
                    type: "string" == typeof n ? "arrow" : t ? "dot" : "slide"
                })
            }), !1
        }, i.settingsBreakpoint = function() {
            var t = this,
                i = t._opt.responsive;
            if (i) {
                i.sort(function(e, t) {
                    return t.breakpoint - e.breakpoint
                });
                for (var r = 0; r < i.length; ++r) {
                    var n = i[r];
                    if (e.innerWidth >= n.breakpoint) return t.breakpoint !== n.breakpoint ? (t.opt = Object.assign({}, t._opt, n.settings), t.breakpoint = n.breakpoint, !0) : !1
                }
            }
            var a = 0 !== t.breakpoint;
            return t.opt = Object.assign({}, t._opt), t.breakpoint = 0, a
        }, i.scrollTo = function(t, i, r) {
            var n = this,
                a = (new Date).getTime(),
                o = n.animate_id,
                s = function() {
                    var d = (new Date).getTime() - a;
                    n.ele.scrollLeft = n.ele.scrollLeft + (t - n.ele.scrollLeft) * n.opt.easing(0, d, 0, 1, i), i > d && o === n.animate_id ? e.requestAnimationFrame(s) : (n.ele.scrollLeft = t, r && r.call(n))
                };
            e.requestAnimationFrame(s)
        }, i.removeItem = function(e) {
            var t = this;
            t.slides.length && (t.track.removeChild(t.slides[e]), t.refresh(!0), t.emit("remove"))
        }, i.addItem = function(e, t) {
            var i = this;
            t ? i.track.prepend(e) : (t = !1, i.track.append(e)), i.refresh(!0), i.emit("add")
        }, i.handleMouse = function(e) {
            var t = this;
            t.mouseDown && (t.isDrag = !0, t.ele.scrollLeft += (t.mouseDown - e.clientX) * (t.opt.dragVelocity || 3.3), t.mouseDown = e.clientX)
        }, i.round = function(e) {
            var t = this,
                i = t.opt.slidesToScroll % 1 || 1,
                r = 1 / i;
            return Math.round(e * r) / r
        }, i.refresh = function(e) {
            var t = this;
            t.init(!0, e)
        }, i.setOption = function(e, t) {
            var i = this;
            i.breakpoint && !t ? i._opt.responsive.forEach(function(t) {
                t.breakpoint === i.breakpoint && (t.settings = Object.assign({}, t.settings, e))
            }) : i._opt = Object.assign({}, i._opt, e), i.breakpoint = 0, i.settingsBreakpoint()
        }, i.destroy = function() {
            var t = this,
                i = t.ele.cloneNode(!0),
                r = function(e) {
                    e.removeAttribute("style"), [].forEach.call(e.classList, function(t) {
                        /^glider/.test(t) && e.classList.remove(t)
                    })
                };
            i.children[0].outerHTML = i.children[0].innerHTML, r(i), [].forEach.call(i.getElementsByTagName("*"), r), t.ele.parentNode.replaceChild(i, t.ele), t.event(e, "remove", {
                resize: t.resize
            }), t.emit("destroy")
        }, i.emit = function(t, i) {
            var r = this,
                n = new e.CustomEvent("glider-" + t, {
                    bubbles: !r.opt.eventPropagate,
                    detail: i
                });
            r.ele.dispatchEvent(n)
        }, i.event = function(e, t, i) {
            var r = e[t + "EventListener"].bind(e);
            Object.keys(i).forEach(function(e) {
                r(e, i[e])
            })
        }, t
    }),
    function() {
        jdgm.$(function(e) {
            var t, i;
            return t = "jdgm.doneSetup", i = document.createEvent("Event"), i.initEvent(t, !0, !0), document.dispatchEvent(i), jdgm._doneSetup = !0
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, i, r, n, a, o, s, d, l, c, u, m, g, p, f, v, _, h, j, w, b, y, S, x, C, k, T, E, I, L, M;
            return o = ".jdgm-carousel", r = ".jdgm-carousel-item", i = ".jdgm-carousel-item__review", n = ".jdgm-carousel__item-wrapper", t = ".jdgm-carousel-item__product-image", a = ".jdgm-carousel-number-of-reviews", M = 0, _ = function(e, t) {
                return (e % t + t) % t
            }, w = function(e) {
                return j(e), b(e), setTimeout(function() {
                    return y(e), jdgmSettings.widget_show_verified_branding ? S(e) : void 0
                }, jdgmSettings.carouselHeightLimitDelay), e.addClass("jdgm-carousel--done")
            }, j = function(e) {
                return L(e), e.data("current-slide", 0).data("slides-count", e.find(r).length), e.attr("data-arrows-on-sides", jdgmSettings.featured_carousel_arrows_on_the_sides)
            }, L = function(e) {
                var t, i;
                return t = e.data("vertical-slide") ? "outerHeight" : "outerWidth", i = parseInt(e.find(r)[t](!0)), M = Math.round(e.find(n)[t]() / i), e.data("slide-dimension", i).data("slides-per-view", 1)
            }, T = 0, E = 0, C = 0, k = 0, v = 20, p = function(e) {
                var t, i;
                return t = C - T, i = k - E, Math.abs(t) <= v || Math.abs(t) <= Math.abs(i) ? void 0 : t > 0 ? jdgm.performSliding(e, -1, !0) : jdgm.performSliding(e, 1, !0)
            }, b = function(e) {
                return e.find(".jdgm-carousel__right-arrow").on("click", function() {
                    return jdgm.slideNext(e)
                }), e.find(".jdgm-carousel__left-arrow").on("click", function() {
                    return jdgm.slidePrev(e)
                }), e.on("mouseover", function() {
                    return e.data("hovering", !0)
                }), e.on("mouseout", function() {
                    return e.data("hovering", !1)
                }), e.data("vertical-slide") ? void 0 : (e[0].addEventListener("touchstart", function(t) {
                    e.data("hovering", !0), T = t.changedTouches[0].screenX, E = t.changedTouches[0].screenY
                }, {
                    passive: !0
                }), e[0].addEventListener("touchend", function(t) {
                    C = t.changedTouches[0].screenX, k = t.changedTouches[0].screenY, p(e), e.data("hovering", !1)
                }, {
                    passive: !0
                }))
            }, y = jdgmSettings.carouselSetUpHeightLimit || function(t) {
                var r, n, a;
                return n = t.find(i).height(), a = t.find(".jdgm-carousel-item__review-rating").outerHeight(!0), r = n - a, jdgm.asyncEach(t.find(i), function(t) {
                    var i, n, a;
                    return i = e(t), n = i.find(".jdgm-carousel-item__review-title"), a = n.height(), a >= r ? n.addClass("jdgm-ellipsis") : c(n, a, 2), c(i.find(".jdgm-carousel-item__review-body"), r - n.height())
                }, 100)
            }, c = function(t, i, r) {
                var n, a, o, s, d;
                return null == r && (r = null), d = "undefined" != typeof t[0].style.webkitLineClamp, d ? (a = parseInt(t.css("lineHeight").replace("px", "")) || 20, s = i / a, s = s % 1 >= .9 ? Math.ceil(s) : Math.floor(s), r = r || Math.max(s, 1), n = t.find("p"), n.length > 1 && (o = n.map(function(t, i) {
                    return e(i).html()
                }), t.html("<p>" + o.toArray().join("<br>") + "</p>")), t.addClass("jdgm-line-clamp"), t.css("line-clamp", r + "").css("-webkit-line-clamp", r + "")) : t.css("height", i).css("overflow", "auto")
            }, S = function(e) {
                var t, i;
                if (jdgm.WIDGET_REBRANDING_ENABLED) return t = e.closest(".jdgm-carousel-wrapper"), t.attr("data-theme", jdgmSettings.featured_carousel_theme), i = t.find(a), i.css("display", ""), i.addClass("jdgm-carousel-number-of-reviews--verified"), i.append(jdgm._templateVerifiedCheckmark())
            }, m = function(e) {
                var t, i;
                return t = e.find(r), i = t.css("font-size"), e.find(n).css("font-size", 0), t.css("font-size", i)
            }, jdgm.performSliding = function(e, i, r) {
                var a, o, s, d, l, c;
                return null == r && (r = !1), !e.data("hovering") || r ? (e.data("current-slide") && e.data("slides-count") && e.data("slides-per-view") || j(e), a = e.data("current-slide"), c = e.data("slides-per-view"), a === e.data("slides-count") - M && i > 0 && (c = M, i = M), i + a + c > e.data("slides-count") ? (l = e.data("slides-count") - c - a, s = a + l, 0 === l && (s = 0)) : 0 > i + a ? (s = 0, 0 === a && (s = e.data("slides-count") - M)) : (o = e.data("slides-count") - c + 1, s = _(a + i, o)), d = s * e.data("slide-dimension"), e.data("vertical-slide") ? (e.find(n).css("transform", "translate3d(0px, " + -d + "px, 0px)"), jdgm.setupLazyLoadPicture(e.find(t), 0)) : e.find(n).css("transform", "translate3d(" + -d + "px, 0px, 0px)"), e.data("current-slide", s)) : void 0
            }, jdgm.slideNext = function(e) {
                return jdgm.performSliding(e, 1 * e.data("slides-per-view"), !0)
            }, jdgm.slidePrev = function(e) {
                return jdgm.performSliding(e, -1 * e.data("slides-per-view"), !0)
            }, jdgm.updateCarousel = function(e) {
                return L(e), jdgm.performSliding(e, 0)
            }, jdgm.autoSlideCarousel = function(e) {
                var t, i;
                return i = 1e3 * (jdgmSettings.featured_carousel_autoslide_interval || jdgmSettings.autoSlideInterval), t = setInterval(function() {
                    return jdgm.performSliding(e, 1)
                }, i), e.data("auto-slider", t)
            }, f = function() {
                return e(".jdgm-carousel-wrapper, .jdgm-carousel-title, .jdgm-all-reviews-rating-wrapper, .jdgm-carousel").addClass("jdgm-hidden")
            }, I = function() {
                var t, i, r;
                return jdgmSettings.featured_carousel_title && e(".jdgm-carousel-title").text(jdgmSettings.featured_carousel_title), t = e(".jdgm-carousel-number-of-reviews"), (i = t.data("number-of-reviews")) ? (r = jdgmSettings.featured_carousel_count_text.replace("{{ n }}", i), "gallery" === jdgmSettings.featured_carousel_theme ? g(t, r) : h(t, r)) : void 0
            }, g = function(t, i) {
                var r, n;
                return e(".jdgm-carousel-wrapper .jdgm-all-reviews-rating").addClass("jdgm-hidden"), t.text(i), jdgmSettings.featured_carousel_add_link_to_all_reviews_page ? (r = e(".jdgm-carousel__more-reviews-button-container"), n = ['<a class="jdgm-carousel__more-reviews-button" href="' + jdgmSettings.featured_carousel_url + '">', jdgmSettings.featured_carousel_more_reviews_button_text, "</a>"].join(""), r.html(n), jdgm.isVersion3 || (r.find(".jdgm-carousel__more-reviews-button").css("background-color", jdgmSettings.widget_primary_color), e(o).find(".jdgm-carousel-item__reviewer-name").css("color", jdgmSettings.widget_primary_color)), r.toggleClass("jdgm-hidden", !1)) : void 0
            }, h = function(e, t) {
                return jdgmSettings.featured_carousel_url.length && jdgmSettings.featured_carousel_add_link_to_all_reviews_page ? e.html('<a href="' + jdgmSettings.featured_carousel_url + '">' + t + "</a>") : !jdgmSettings.featured_carousel_add_link_to_all_reviews_page && jdgmSettings.can_be_branded && jdgmSettings.shop_use_review_site ? e.html('<a target="_blank" href="' + jdgmSettings.branding_url + '">' + t + "</a>") : e.text(t)
            }, x = function(t) {
                var i;
                return i = [], jdgm.asyncEach(t.find(r), function(t) {
                    return i.push(e(t).data("review-id"))
                }), i.length ? (l(t, i), jdgm.ScrollEvent.attach(function() {
                    return l(t, i)
                }, "checkToFetchFullReviewsForModals")) : void 0
            }, l = function(e, t) {
                return jdgm.isInViewport(e.closest(":visible")[0], .1) ? u(e, t) : void 0
            }, u = function(t, i) {
                return jdgm.ScrollEvent.dettach("checkToFetchFullReviewsForModals"), e.ajax({
                    url: jdgm.API_HOST + "/reviews/reviews_for_carousel_popups",
                    method: "GET",
                    data: e.extend(jdgm.shopParams(), {
                        reviews_uuids: i
                    }),
                    success: function(e) {
                        var i, r, n;
                        return i = t.find(".jdgm-carousel__modals-wrapper"), i.length <= 0 && (t.find(".jdgm-carousel__item-container").append('<div class="jdgm-carousel__modals-wrapper"></div>'), i = t.find(".jdgm-carousel__modals-wrapper")), !i[0].childElementCount && e.data.length ? (n = e.data.map(function(e) {
                            return JST["templates/shopify_v3/full_review_modal"]({
                                review: e
                            })
                        }), i.append(n), r = "jdgm-carousel-item__full-review-link", s(t, r), jdgm.initializeFullReviewModals(t, r, "carousel-gallery-theme")) : void 0
                    },
                    error: function() {}
                })
            }, s = function(t, i) {
                return t.data("unique-string", Date.now().toString(36) + "-" + jdgm.random(1e6).toString(36)), jdgm.asyncEach(t.find(r), function(r) {
                    var n, a;
                    return n = e(r), a = "#" + n.data("review-id") + "-" + t.data("unique-string"), n.append("<a class='" + i + "' href='" + a + "' role='button'></a>")
                })
            }, d = function(i) {
                var r, n, a, o;
                return o = i.data("widget-locale"), jdgmSettings.widget_multilingual_sorting_enabled && jdgmSettings.enable_multi_locales_translations && (null != o ? o.length : void 0) > 0 && (a = jdgm.normalizeLanguage(document.documentElement.lang), n = jdgm.normalizeLanguage(o), a !== n) ? (r = e.extend(jdgm.shopParams(), {
                    primary_language: a
                }), e.ajax({
                    url: jdgm.API_HOST + "/reviews/reviews_for_carousel",
                    method: "GET",
                    data: r,
                    success: function(r) {
                        var n, a;
                        return (null != r ? r.html : void 0) && (a = i.data("current-slide"), n = i.data("auto-slider"), n && clearInterval(n), i.closest(".jdgm-carousel-wrapper").find(".jdgm-verified-wrapper").remove(), i.html(e(r.html).html()), i.removeClass("jdgm-carousel--done"), w(i), jdgm.setupLazyLoadPicture(i.find(t)), !jdgmSettings.carouselNoAutoSlide && jdgmSettings.featured_carousel_autoslide_interval > 0) ? jdgm.autoSlideCarousel(i) : void 0
                    }
                })) : void 0
            }, jdgm.initializeCarousel = function() {
                return jdgm.asyncEach(e(o), function(i) {
                    var n, a;
                    return n = e(i), d(n), w(n), a = n.find(r), jdgm.customizeCarouselTimestamp(a), !jdgmSettings.carouselNoAutoSlide && jdgmSettings.featured_carousel_autoslide_interval > 0 && jdgm.autoSlideCarousel(n), m(n), 0 === a.length && f(), jdgm.setupLazyLoadPicture(n.find(t)), "gallery" === jdgmSettings.featured_carousel_theme && jdgm.isVersion3 ? x(n) : void 0
                }), I()
            }, setTimeout(jdgm.initializeCarousel, 0), e(window).on("resize", function(t) {
                return jdgm.asyncEach(e(o), function(t) {
                    return jdgm.updateCarousel(e(t))
                })
            })
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, i, r, n, a, o, s, d, l, c, u, m, g, p, f, v, _, h, j, w, b, y, S;
            return t = "1528", n = "https://judgeme-public-images.imgix.net/judgeme/flags", a = 16, i = 240, r = 360, o = function(t) {
                return jdgm.asyncEach(t.find(".jdgm-full-rev"), function(i) {
                    var r;
                    return r = e(i), r.prop("id", r.data("review-id") + "-" + t.data("unique-string"))
                })
            }, c = function(t, i, r) {
                return t.length && !t.data("init-modals") ? (e(t).data("init-modals", !0), t.find("." + i).magnificPopup({
                    type: "inline",
                    mainClass: "jdgm-full-rev-modal " + r,
                    closeBtnInside: !0,
                    midClick: !0,
                    callbacks: {
                        open: function() {
                            var t;
                            return e("body").addClass("jm-mfp-is-open"), t = e(this.content), t.show(), d(t), u(t), v(t)
                        },
                        close: function() {
                            return e("body").removeClass("jm-mfp-is-open")
                        }
                    }
                })) : void 0
            }, d = function(e) {
                return e.data("customize-review") ? void 0 : (e.data("customize-review", !0), jdgm.customizeCarouselTimestamp(e, null, ".jdgm-full-rev__timestamp"), h(e.find(".jdgm-full-rev__avatar-image")), _(e), f(e), s(e), y(e), S(e), jdgm._insertIframesToYoutubeContainers(e.find(".jdgm-yt-video"), !0), b(e), w(e))
            }, h = function(t) {
                return t.unveil(200, function() {
                    return e(this).parent(".jdgm-full-rev__icon").removeClass("jdgm--loading").addClass("jdgm-full-rev__avatar")
                }), setTimeout(function() {
                    return jdgm.ScrollEvent.trigger("unveil")
                })
            }, _ = function(t) {
                var i;
                return i = t.find(".jdgm-full-rev__icon[data-gravatar-hash]"), i.each(function(t, i) {
                    return l(e(i))
                })
            }, l = function(i) {
                var r, n, a, o;
                return (r = i.data("gravatar-hash")) ? (o = "https://secure.gravatar.com/avatar/" + r + ".png?default=mp&filetype=png&rating=pg&secure=true", n = o + "&size=48", a = o + "&size=96", e.ajax({
                    url: a,
                    type: "HEAD",
                    crossDomain: !0,
                    success: function(r, o, s) {
                        var d;
                        if (s.getResponseHeader("content-length") !== t) return d = e("<img data-src='" + n + "' data-src-retina='" + a + "' class='jdgm-full-rev__avatar-image' alt='Reviewer avatar' />"), i.html(d), i.addClass("jdgm--loading"), h(d)
                    },
                    error: function() {},
                    complete: function() {
                        return i.removeAttr("data-gravatar-hash"), jdgm.triggerEvent("doneFetchGravatar", {
                            $gravatarIcon: i
                        })
                    }
                })) : void 0
            }, f = function(e) {
                var t, i, r, a;
                if (t = e.find(".jdgm-full-rev__location-country-flag-img"), jdgmSettings.widget_show_country_flag && t.length) {
                    if (i = t.attr("data-country-code"), !i) return;
                    return r = i.toUpperCase(), a = n + "/" + r + ".svg", t.addClass("jdgm--loading"), t.attr("data-src", a), t.attr("alt", r), j(t)
                }
            }, s = function(t) {
                var i, r, n, a;
                return a = t.find(".jdgm-full-rev__custom-form"), a.length && a.children().length && (a.append('<div class="jdgm-full-rev__cf-ans--type jdgm-full-rev__cf-ans--text-type"></div>'), a.append('<div class="jdgm-full-rev__cf-ans--type jdgm-full-rev__cf-ans--graphic-type"></div>'), n = a.find(".jdgm-full-rev__cf-ans--text-type"), r = a.find(".jdgm-full-rev__cf-ans--graphic-type"), i = a.find(".jdgm-full-rev__cf-ans"), jdgm.asyncEach(i, function(t) {
                    var i;
                    return i = e(t), i.find(".jdgm-full-rev__scale-wrapper").length || i.find(".jdgm-full-rev__slider-wrapper").length ? r.append(t) : n.append(t)
                }), "horizontal" === jdgmSettings.custom_forms_style) ? a.addClass("custom-form--horizontal-style") : void 0
            }, y = function(t) {
                var i;
                return i = t.find(".jdgm-vid-player"), e.each(i, function(t, i) {
                    var r, n;
                    return r = e(i), (n = r.data("external-id")) ? n.length > a ? m(r, n) : g(r, n) : void 0
                })
            }, m = function(e, t) {
                var n, a, o, s, d;
                if (t && (n = e.height() || i, o = e.closest(".jdgm-rev__vids").width() || r, d = Math.min(1.5 * n, o), s = jdgmSettings.mute_video_by_default ? "muted='true'" : "", a = "<iframe src='https://iframe.videodelivery.net/" + t + "?" + s + "' title='Review video' height='" + n + "px' width='" + d + "px' allow='fullscreen'></iframe>", !e.find(".jdgm-vid-player__wrapper > iframe").length)) return e.find(".jdgm-vid-player__wrapper").html(a).removeClass("jdgm--loading")
            }, g = function(t, i) {
                var r;
                if (i) return r = t.find(".jdgm-vid-player__wrapper"), e.ajax({
                    url: "https://vimeo.com/api/oembed.json",
                    data: {
                        url: "https://vimeo.com/" + i,
                        maxheight: t.height(),
                        title: !1,
                        muted: jdgmSettings.mute_video_by_default,
                        byline: !jdgmSettings.remove_judgeme_branding,
                        portrait: !jdgmSettings.remove_judgeme_branding
                    },
                    success: function(e) {
                        return r.html(e.html)
                    },
                    error: function(e) {
                        return t.remove(), console.log("Video is processing. It will be available shortly. Please refresh the page after a few seconds.")
                    },
                    complete: function() {
                        return r.removeClass("jdgm--loading")
                    }
                })
            }, S = function(t) {
                return jdgm.asyncEach(t.find("img[data-src]:not([src])"), function(t) {
                    var i, r;
                    return i = e(t), i.attr("src", i.data("src")), r = i.parent(), r.removeClass("jdgm--loading")
                })
            }, j = function(t) {
                return t.unveil(200, function() {
                    return e(this).removeClass("jdgm--loading")
                }), setTimeout(function() {
                    return jdgm.ScrollEvent.trigger("unveil")
                })
            }, b = function(e) {
                var t;
                return t = jdgmSettings.widget_replied_text.replace("{{ shop_name }}", '<b class="jdgm-full-rev__replier"></b>'), e.find(".jdgm-full-rev__replier-wrapper").html(t)
            }, w = function(e) {
                var t;
                return t = e.find(".jdgm-full-rev__product-button"), t.text(jdgmSettings.featured_carousel_view_product_button_text)
            }, u = function(t) {
                return jdgm.asyncEach(t.find(".jdgm-full-rev__pic-link"), function(t) {
                    var i, r;
                    return r = e(t), r.attr("data-mfp-src", null), i = r.clone(), r.after(i), r.remove()
                })
            }, v = function(t) {
                var i, r, n;
                return r = t.closest(".jm-mfp-wrap"), i = t.closest(".jm-mfp-content"), n = ['<div class="jdgm-full-rev-modal__pic-actions">', '<a href="#" rel="prev" class="jdgm-full-rev-modal__back jdgm-full-rev-modal__back-icon"></a>', '<a href="#" rel="prev" class="jdgm-full-rev-modal__back">Back</a>', "</div>"].join(""), t.off("click", ".jdgm-full-rev__pic-link"), t.on("click", ".jdgm-full-rev__pic-link", function(a) {
                    var o, s, d;
                    return a.preventDefault(), i.data("offset-top", i.offset().top), t.hide(), i.find(".jdgm-full-rev-modal__pic").remove(), d = '<div class="jdgm-full-rev-modal__pic-slider-wrapper"><div class="jdgm-full-rev-modal__pic-slider">', jdgm.asyncEach(e(this).closest(".jdgm-full-rev__pics").find(".jdgm-full-rev__pic-link"), function(t) {
                        return d += ['<div class="jdgm-full-rev__pic">', '<img class="jdgm-full-rev__pic-img" alt="User picture" src="' + e(t).attr("href") + '" />', "</div>"].join("")
                    }), d += "</div>", d += '<button aria-label="Previous" class="jdgm-full-rev-modal__pic-slider-prev"></button>', d += '<button aria-label="Next" class="jdgm-full-rev-modal__pic-slider-next"></button></div>', i.append('<div class="jdgm-full-rev-modal__pic">' + n + d + "</div>"), s = new jdgm.Glider(i.find(".jdgm-full-rev-modal__pic-slider")[0], {
                        scrollLock: !0,
                        draggable: !0,
                        arrows: {
                            prev: ".jdgm-full-rev-modal__pic .jdgm-full-rev-modal__pic-slider-prev",
                            next: ".jdgm-full-rev-modal__pic .jdgm-full-rev-modal__pic-slider-next"
                        }
                    }), o = e(this).index() * i.find(".jdgm-full-rev-modal__pic-slider").width(), setTimeout(function() {
                        return s.scrollTo(o, 400), p(i)
                    }, 0), i.on("glider-slide-visible", ".jdgm-full-rev-modal__pic-slider", function(e) {
                        return p(i)
                    }), i.on("click", ".jdgm-full-rev-modal__pic", function(e) {
                        return e.preventDefault(), e.stopPropagation()
                    }), i.on("click", ".jdgm-full-rev-modal__back", function(e) {
                        var n;
                        return e.preventDefault(), t.show(), i.find(".jdgm-full-rev-modal__pic").remove(), n = r.offset().top + 48 - i.data("offset-top"), r.animate({
                            scrollTop: n
                        }, 0)
                    })
                })
            }, p = function(e) {
                var t;
                return t = e.find(".jdgm-full-rev__pic.visible .jdgm-full-rev__pic-img").height(), 0 === t ? setTimeout(function() {
                    return p(e)
                }, 100) : (e.find(".jdgm-full-rev-modal__pic-slider-wrapper").height(t), e.find(".jdgm-glider-track").height(t))
            }, jdgm.initializeFullReviewModals = function(e, t, i) {
                return o(e), c(e, t, i)
            }
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, i, r, n, a, o;
            return a = 430, n = 260, r = e(".jdgm-carousel__rev-sum-short"), i = e(".jdgm-carousel__rev-sum-full"), t = e(".jdgm-carousel__rev-sum-read-more"), (o = function() {
                var o;
                return o = function(e, n, a) {
                    return r.toggle(e), i.toggle(n), t.toggle(a)
                }, e(window).width() <= a ? i.text().length > n && o(!0, !1, !0) : o(!1, !0, !1), t.on("click", function() {
                    return o(!1, !0, !1)
                })
            })()
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, i, r, n, a, o, s, d, l, c, u, m, g, p, f, v, _, h;
            return i = "https://judgeme-public-images.imgix.net/judgeme/logos", t = e(".jdgm-revs-tab__wrapper"), u = jdgmSettings.widget_first_sub_tab || "product-reviews", jdgm.showReviewsTab = function() {
                return t.length > 0 && (t.addClass("jdgm-show"), jdgm.ScrollEvent.trigger("unveil"), e("body").addClass("jdgm-lock-scroll"), jdgm.triggerEvent("doneShowReviewsTab", {
                    $tabModal: t
                }), "carousel" === jdgmSettings.widget_theme) ? window.dispatchEvent(new Event("resize")) : void 0
            }, jdgm.hideReviewsTab = function() {
                return t.removeClass("jdgm-show"), e("body").removeClass("jdgm-lock-scroll")
            }, g = function(e) {
                return e.find(".jdgm-rev").length <= 0 ? !1 : (m(e), e.show(), !0)
            }, p = function(e) {
                return e.find(".jdgm-revs-tab__main").prepend(e.find(".jdgm-revs-tab__header").detach())
            }, _ = function() {
                return e(document).keydown(function(t) {
                    return 27 !== t.keyCode || e.magnificPopup.instance.isOpen ? void 0 : jdgm.hideReviewsTab()
                })
            }, v = function(e) {
                var t;
                return t = e.find(".jdgm-close-ico"), t.attr("role", "button"), t.on("click", judgeme.hideReviewsTab), e.find(".jdgm-mask").on("click", jdgm.hideReviewsTab)
            }, m = function(e) {
                var t, r;
                return r = e.find(".jdgm-revs-tab-btn"), r.attr("data-style", jdgmSettings.floating_tab_tab_style), jdgm.hasBgColor(r) || (r.css("background-color", jdgmSettings.linkColor), r.css("color", jdgmSettings.bgColor)), "text" === jdgmSettings.floating_tab_tab_style && ("0px" === r.css("padding") && r.css("padding", "8px 16px"), jdgmSettings.floating_tab_button_name && r.text(jdgmSettings.floating_tab_button_name)), "stars" === jdgmSettings.floating_tab_tab_style && (r.html(a(e)), t = r.find(".jdgm-favicon"), jdgmSettings.can_be_branded ? jdgm._loadSvg(t, i, i, t.data("monochromatic")) : t.remove(), jdgm.buildStarsFor(r.find(".jdgm-stars"))), r.on("click", jdgm.showReviewsTab)
            }, a = function(e) {
                var t, i, r, n, a, o;
                return t = "#339999" === jdgmSettings.floating_tab_button_color, jdgm.WIDGET_REBRANDING_ENABLED ? (t = "#108474" === jdgmSettings.floating_tab_button_color, i = "/verified-checkmark.svg") : i = t ? "/favicon.svg" : "/favicon-monochromatic.svg", r = Number(e.find(".jdgm-all-reviews-rating").data("score")), n = isNaN(r) ? 0 : r, a = Math.floor(10 * n) / 10, o = ['<div class="jdgm-favicon" data-monochromatic="' + !t + '" data-url="' + i + '"></div>', '<div class="jdgm-stars" data-score="' + n + '"></div>', '<div class="jdgm-rating">' + a + "</div>", "<style>.jdgm-revs-tab .jdgm-stars .jdgm-star { color: " + jdgmSettings.floating_tab_button_color + "; pointer-events: none; }</style>"], t || (o = o.concat(["<style>.jdgm-svg__mono svg path { fill: " + jdgmSettings.floating_tab_button_color + "; }</style>"])), o.join("")
            }, f = function(e) {
                var t, i, r, n;
                return t = e.find(".jdgm-revs-tab__content-header"), n = t.data("number-of-shop-reviews") || 0, r = t.data("number-of-product-reviews"), "shop-reviews" === u && 0 >= r || "product-reviews" === u && 0 >= n ? void 0 : (i = jdgm._renderAllRevsSubtab(n, r), jdgm.isVersion3 && "leex" === jdgmSettings.widget_theme ? e.find(".jdgm-rev-widg__actions").prepend(i) : i.insertAfter(t), i.data("open-tab-callback", o))
            }, o = function(e, t) {
                return u !== e ? (u = e, jdgm._loadReviewsForFRT(t, u)) : void 0
            }, jdgm._loadReviewsForFRT = function(t, i, a) {
                return null == i && (i = u), null == a && (a = !0), r(t), a && jdgm.triggerEvent("beforeFetchingReviews"), e.ajax({
                    url: t.find(".jdgm-paginate").data("url"),
                    data: e.extend(jdgm.ajaxParamsFor(t), {
                        review_type: i
                    }),
                    success: function(e) {
                        return function(e) {
                            return n(t, e)
                        }
                    }(this)
                })
            }, r = function(e) {
                return e.find(".jdgm-revs-tab__spinner").show(), e.find(".jdgm-revs-tab__reviews").hide(), e.find(".jdgm-paginate").hide()
            }, n = function(e, t, i) {
                return null == i && (i = !1), d(e, t), s(e, t), i ? e.find(".jdgm-revs-tab__reviews").show(400, function() {
                    return l(e)
                }) : e.find(".jdgm-revs-tab__reviews").slideDown(), e.find(".jdgm-paginate").show()
            }, l = function(e) {
                var t, i;
                return t = e.find(".jdgm-revs-tab__content"), 0 === t.length && (t = e), t.scrollTop(0), i = e.find(".jdgm-revs-tab__content-body").offset().top - t.offset().top, t.animate({
                    scrollTop: i
                })
            }, d = function(t, i) {
                var r, n, a, o, s;
                return r = e(i.html), o = r.find(".jdgm-revs-tab__content-body").html(), n = t.find(".jdgm-revs-tab__content"), 0 === n.length ? t.find(".jdgm-revs-tab__content-body").html(o) : (a = n.find(".jdgm-revs-tab__content-body"), a.length > 0 ? a.html(o) : (s = r.find(".jdgm-revs-tab__content").html(), n.html(s)))
            }, s = function(e, t) {
                return e.find(".jdgm-revs-tab__spinner").hide(), jdgm.customizeReviews(), jdgm.setupMediaGallery && jdgm.setupMediaGallery(e.find(".jdgm-revs-tab__reviews")), c(e, t)
            }, c = function(t, i) {
                var r, n, a;
                return r = e(i.html).find(".jdgm-revs-tab__content-header"), a = r.data("number-of-shop-reviews") || 0, n = r.data("number-of-product-reviews"), t.find(".jdgm-subtab__name[data-tabname=product-reviews] .jdgm-subtab__count").text(n), t.find(".jdgm-subtab__name[data-tabname=shop-reviews] .jdgm-subtab__count").text(a)
            }, jdgm._setupLoadReviewsEventsForFRT = function(t) {
                var i, a, o, d, l;
                return i = function() {
                    return r(t)
                }, a = function() {
                    return jdgm.isWidgetLoadMore() ? (t.find(".jdgm-paginate").hide(), t.find(".jdgm-revs-tab__spinner").show()) : r(t)
                }, l = function(e) {
                    return n(t, e, !0)
                }, o = function(e) {
                    return jdgm.isWidgetLoadMore() ? (jdgm._appendPaginateResultToBody(e, t, ".jdgm-rev", ".jdgm-revs-tab__reviews"), s(t, e)) : n(t, e, !0)
                }, d = function() {
                    return e.extend(jdgm.ajaxParamsFor(t), {
                        review_type: t.data("review-type") || u
                    })
                }, jdgm.setupPaginate(t, a, o, d), jdgm._setupSortAndFilterFor(t, i, l, d), jdgm.setupSearch(t, i, l, d)
            }, h = function(e) {
                return g(e) ? (p(e), f(e), _(), v(e), jdgm._setupLoadReviewsEventsForFRT(e), jdgm.ScrollEvent.scrollInsideContainer(".jdgm-revs-tab__content")) : void 0
            }, jdgm.asyncEach(e(".jdgm-revs-tab"), function(t) {
                return h(e(t))
            })
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, i, r, n, a, o, s, d, l, c, u, m, g, p;
            return i = "{{ shop.metafields.judgeme.all_reviews_rating | round: 1 }}", a = "{{ shop.metafields.judgeme.all_reviews_rating|round:1 }}", t = "{{ shop.metafields.judgeme.all_reviews_count }}", n = "{{ shop.metafields.judgeme.shop_reviews_rating | round: 1 }}", o = "{{ shop.metafields.judgeme.shop_reviews_rating|round:1 }}", r = "{{ shop.metafields.judgeme.shop_reviews_count }}", p = function() {
                return jdgm.asyncEach(e(".jdgm-all-reviews-text"), function(t) {
                    var i;
                    return i = e(t), i.addClass("jdgm-all-reviews-text--style-" + jdgmSettings.all_reviews_text_style), l(i.find(".jdgm-all-reviews-rating")), "branded" === jdgmSettings.all_reviews_text_style && (i.find(".jdgm-all-reviews-text__text").after(d(i, !1)), jdgm.WIDGET_REBRANDING_ENABLED ? jdgm._renderVerifiedJudgeme(i, jdgmSettings.all_reviews_text_color, !1, !1) : jdgmSettings.all_reviews_text_show_jm_brand && jdgm._renderVerifiedByJudgeme(i, !1, !1, !1)), m(i), g(i)
                })
            }, l = function(e) {
                return "text" === jdgmSettings.all_reviews_text_style && jdgmSettings.show_stars_for_all_reviews_text_badge || "branded" === jdgmSettings.all_reviews_text_style ? jdgm.buildStarsFor(e) : e.remove()
            }, d = function(e) {
                var t, i;
                if (!(jdgm.WIDGET_REBRANDING_ENABLED && e.find(".jdgm-all-reviews-rating__score").length > 0)) return s(e.find(".jdgm-all-reviews-rating")), t = jdgm.WIDGET_REBRANDING_ENABLED ? jdgmSettings.widget_show_verified_branding : jdgmSettings.all_reviews_text_show_jm_brand, t && (i = c()), [i, "<style>", ".jdgm-all-reviews-text .jdgm-all-reviews-rating:before { background-color: " + jdgmSettings.all_reviews_text_color + "; }", ".jdgm-all-reviews-text .jdgm-all-reviews-rating,", ".jdgm-all-reviews-text .jdgm-all-reviews-rating .jdgm-star,", ".jdgm-all-reviews-text .jdgm-all-reviews-text__text { color: " + jdgmSettings.all_reviews_text_color + "; }", "</style>", u()].join("")
            }, u = function() {
                return jdgmSettings.all_reviews_text_custom_css ? ["<style>", ".jdgm-all-reviews-text { " + jdgmSettings.all_reviews_text_custom_css + " }", "</style>"].join("") : ""
            }, s = function(e) {
                var t;
                return e.find(".jdgm-star").wrapAll('<span class="jdgm-all-reviews-rating__stars"></span>'), t = parseFloat(e.data("score")).toPrecision(2), e.prepend("<span class='jdgm-all-reviews-rating__score'>" + t + "</span>")
            }, c = function() {
                return ['<span class="jdgm-verified-by">', '<span class="jdgm-verified-by__text"></span>', '<span class="jdgm-verified-by__image"></span>', "<style>", ".jdgm-all-reviews-text .jdgm-verified-by { color: " + jdgmSettings.all_reviews_text_color + "; }", "</style>", "</span>"].join("")
            }, m = function(e) {
                var s, d, l;
                switch (s = e.find(".jdgm-all-reviews-text__text"), jdgmSettings.all_reviews_text_style) {
                    case "branded":
                        d = jdgmSettings.all_reviews_text_badge_text_branded_style;
                        break;
                    case "text":
                        d = jdgmSettings.all_reviews_text_badge_text
                }
                return d.length <= 0 || s.data("locale") === jdgmSettings.locale ? void 0 : (l = d.length > 1 ? d.replaceAll(a, parseFloat(s.data("score")).toPrecision(2)).replaceAll(i, parseFloat(s.data("score")).toPrecision(2)).replaceAll(t, s.data("number-of-reviews")).replaceAll(o, parseFloat(s.data("shop-rating")).toPrecision(2)).replaceAll(n, parseFloat(s.data("shop-rating")).toPrecision(2)).replaceAll(r, s.data("shop-count")) : s[0].innerHTML, s.text(l))
            }, g = function(e) {
                var t;
                return t = e.find(".jdgm-all-reviews-text__text"), jdgmSettings.all_reviews_text_badge_url.length > 0 && jdgmSettings.is_all_reviews_text_badge_a_link ? t.html("<a href=" + jdgmSettings.all_reviews_text_badge_url + ">" + t.text() + "</a>") : jdgmSettings.shop_use_review_site ? t.html("<a target='_blank' href='" + jdgmSettings.branding_url + "'>" + t.text() + "</a>") : void 0
            }, p()
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, i, r, n, a, o, s, d;
            return t = "https://judgeme-public-images.imgix.net/judgeme/verified-badge-v2/verified-badge.svg?auto=format", i = "https://s3.amazonaws.com/me.judge.public-static-assets/general/verified-badge", d = function() {
                return jdgm.asyncEach(e(".jdgm-widget.jdgm-verified-badge"), function(o) {
                    var s, d, l, c, u, m;
                    return s = e(o), c = s.find(".jdgm-verified-badge__total").text(), 20 > c ? s.remove() : (s.addClass("jdgm-verified-badge--style-" + jdgmSettings.verified_count_badge_style), d = s.find(".jdgm-verified-badge__image"), "vintage" === jdgmSettings.verified_count_badge_style ? (d.append("<img src='" + i + d.attr("data-url") + "'>"), s.css("display", "inline-block")) : "branded" === jdgmSettings.verified_count_badge_style && (a(s), (m = ["monochromatic_version", "custom"].includes(jdgmSettings.verified_count_badge_color_style)) ? l = "/verified-badge-mono.svg" : "judgeme_brand_color" === jdgmSettings.verified_count_badge_color_style && (l = "/verified-badge.svg"),
                        u = jdgm.WIDGET_REBRANDING_ENABLED ? !0 : jdgmSettings.verified_count_badge_show_jm_brand, d.attr("data-url", l), jdgm._loadSvg(d, t, t, m), s.append(r(s, m, u)), u && (jdgm._renderVerifiedByJudgeme(s, m, !1, !1, jdgm.WIDGET_REBRANDING_ENABLED), s.addClass("jdgm-verified-badge--style-branded-" + jdgmSettings.verified_count_badge_orientation)), s.css("display", "flex")), n(s))
                })
            }, a = function(e) {
                return e.find(".jdgm-verified-badge__text").remove(), e.find(".jdgm-verified-badge__stars").remove()
            }, r = function(e, t, i) {
                var r, n;
                if (!(jdgm.WIDGET_REBRANDING_ENABLED && e.find(".jdgm-verified-by").length > 0)) return i && (r = jdgm.WIDGET_REBRANDING_ENABLED ? o() : s(), t && (n = [".jdgm-widget.jdgm-verified-badge .jdgm-verified-by .jdgm-svg__mono svg path { fill: " + jdgmSettings.verified_count_badge_color + "; }"].join(""))), [r, "<style>", ".jdgm-widget.jdgm-verified-badge .jdgm-verified-badge__image svg circle { stroke: " + jdgmSettings.verified_count_badge_color + "; } ", ".jdgm-widget.jdgm-verified-badge .jdgm-verified-badge__image svg path { fill: " + jdgmSettings.verified_count_badge_color + "; } ", ".jdgm-verified-count-badget, .jdgm-widget.jdgm-verified-badge { color: " + jdgmSettings.verified_count_badge_color + "; }", n, "</style>"].join("")
            }, s = function() {
                return ['<span class="jdgm-verified-by">', '<span class="jdgm-verified-by__text">by</span>', '<span class="jdgm-verified-by__image"></span>', "</span>"].join("")
            }, o = function() {
                return ['<span class="jdgm-verified-by jdgm-verified-by--rebranding">', '<span class="jdgm-verified-by__text jdgm-verified-by__text--rebranding">by</span>', '<span class="jdgm-verified-by__image"></span>', "</span>"].join("")
            }, n = function(e) {
                var t;
                return t = e.closest(".jdgm-verified-count-badget"), t.length <= 0 && (e.wrap('<a class="jdgm-verified-count-badget" href=""></a>'), t = e.closest(".jdgm-verified-count-badget")), !jdgmSettings.is_verified_count_badge_a_link && jdgmSettings.can_be_branded && jdgmSettings.shop_use_review_site ? (t.attr("href", jdgmSettings.branding_url), t.attr("target", "_blank")) : t.attr("href", jdgmSettings.verified_count_badge_url)
            }, d()
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t;
            return (t = function() {
                return jdgm.asyncEach(e(".jdgm-all-reviews-rating"), function(t) {
                    var i;
                    return i = e(t), i.closest(".jdgm-widget.jdgm-all-reviews-text").length <= 0 ? jdgm.buildStarsFor(i) : void 0
                })
            })()
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, i, r, n;
            return i = e("html"), n = function() {
                return jdgm.ScrollEvent.attach(jdgm._insertIframesToYoutubeContainers)
            }, jdgm._insertIframesToYoutubeContainers = function(t, n) {
                return null == n && (n = !1), t || (t = e(".jdgm-yt-video")), t.not(".done-setup").each(function() {
                    var t;
                    return t = e(this), n || i.scrollTop() >= t.offset().top - 1e3 ? r(t) : void 0
                })
            }, r = function(t) {
                var i, r, n, a, o;
                return n = t.data("id"), n && (r = t.data("class"), a = t.data("title"), o = "https://www.youtube.com/embed/" + n + "?rel=0&showinfo=0&autoplay=0&cc_load_policy=1", jdgmSettings.mute_video_by_default && (o += "&mute=1"), i = e('<iframe frameborder="0" allow="autoplay; fullscreen" allowfullscreen>'), i.attr("src", o), i.addClass(r), i.attr("title", a), t.html(i)), t.addClass("done-setup")
            }, n(), t = e(), jdgm._safeRun(function() {
                return jdgm._insertIframesToYoutubeContainers(t)
            }), jdgm._safeRun(function() {
                return r(t)
            })
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, i, r, n;
            return t = "ugc-media", i = {
                mediaGridWrapper: ".jdgm-ugc-media-wrapper",
                mediaGrid: ".jdgm-ugc-media",
                mediaThumbnail: ".jdgm-ugc-media__thumbnail"
            }, n = function(e) {
                return jdgm._transformJsonData(e)
            }, jdgm._transformJsonData = function(n, a) {
                var o, s, d;
                return null == a && (a = null), s = n.data(t), s || (s = {
                    objects: {},
                    perPage: n.data("per-page"),
                    page: 1,
                    fetching: !1,
                    canNotFetch: !1
                }), a ? (s.page = a.page, d = a.posts) : (o = n.find(".jdgm-ugc-media-data"), d = o.data("json"), o.remove()), d.forEach(function(e) {
                    var t;
                    return e && (t = e.id || e.uuid) ? (s.objects[t] = e, n.append(JST["templates/shopify_v2/ugc_media_grid_thumbnail"]({
                        object: e,
                        preload: !0
                    }))) : void 0
                }), 0 === Object.keys(s.objects).length ? n.parent().remove() : (e(i.mediaGridWrapper).css("max-width", jdgmSettings.widget_ugc_max_width + "px"), jdgm.setupLazyLoadPicture(n.find(i.mediaThumbnail)), s.canNotFetch = Object.keys(d).length < s.perPage, n.data(t, s), s.canNotFetch && (e(i.mediaGrid + "__load-more-btn").remove(), e(i.mediaGrid + "-wrapper").attr("data-cannot-fetch", !0)), n.data("append-controls") ? void 0 : r(n))
            }, r = function(e) {
                return (jdgmSettings.widget_ugc_title || jdgmSettings.widget_ugc_subtitle) && e.before("<div class='jdgm-ugc-media-title'><h3>" + jdgmSettings.widget_ugc_title + "</h3>" + jdgmSettings.widget_ugc_subtitle + "</div>"), e.data(t).canNotFetch || e.after("<a class='jdgm-ugc-media__secondary-btn jdgm-ugc-media__load-more-btn'>" + jdgmSettings.widget_ugc_secondary_button_text + "</a>"), e.data("append-controls", !0)
            }, e.each(e(i.mediaGrid), function(i, r) {
                var a;
                return a = e(r), a.data("loaded") ? void 0 : (a.attr("data-loaded", !0), a.attr("data-id", t + "-" + i), n(a))
            })
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, i, r, n, a, o, s, d, l, c, u, m, g, p, f, v, _, h, j, w, b, y, S, x, C, k;
            return m = 500, c = 1e3 * jdgmSettings.popup_widget_first_review_delay - m, s = 1e3 * jdgmSettings.popup_widget_duration, p = 1e3 * jdgmSettings.popup_widget_interval, t = 600, u = 0, k = e(".jdgm-popup-widget__cards-container").data("position") || jdgmSettings.popup_widget_position, f = window.innerWidth <= 767, i = {
                left: "unset",
                right: "unset",
                bottom: "unset",
                opacity: "toggle"
            }, _ = function(e) {
                var t, i, r;
                return t = e.find(".jdgm-popup-card__pic"), i = e.find(".jdgm-popup-card__rev-prod-wrapper"), 0 === t.length ? j(i) : (r = t.attr("data-src")) ? (t[0].onerror = function() {
                    return j(i), t.closest(".jdgm-popup-card__pic-wrapper").remove()
                }, t.attr("src", r)) : void 0
            }, j = function(e) {
                return e.css("width", "100%"), e.css("max-width", "360px")
            }, b = function(i) {
                return i.find(".jdgm-popup-card__close-btn").on("click", function(r) {
                    return r.preventDefault(), e(this).prop("disabled") || (e(this).prop("disabled", !0), i.data("cycle-completed")) ? void 0 : i.fadeOut(t, function() {
                        return a(i, !0)
                    })
                })
            }, w = function() {
                return f ? (i.left = "unset", i.right = "unset", i.bottom = "+24") : (i.bottom = "unset", k.includes("left") ? (i.left = "+40", i.right = "unset") : k.includes("right") ? (i.left = "unset", i.right = "+40") : void 0)
            }, S = function() {
                var t;
                return t = e(".jdgm-popup-card").eq(u), f ? (t.css("left", "unset"), t.css("right", "unset"), t.css("bottom", "24px")) : (t.css("bottom", "unset"), k.includes("left") ? t.css("left", "40px") : k.includes("right") ? t.css("right", "40px") : void 0)
            }, x = function() {
                var r;
                return r = 0 === u ? c : p, setTimeout(function() {
                    var r;
                    return r = e(".jdgm-popup-card").eq(u), r.addClass("active-popup-card"), r.animate(i, t, function() {
                        return r.data("cycle-completed") ? void 0 : C(r)
                    })
                }, r)
            }, C = function(e) {
                return setTimeout(function() {
                    return e.length <= 0 || e.data("cycle-completed") ? void 0 : e.fadeOut(t, function() {
                        return a(e)
                    })
                }, s)
            }, a = function(t, i) {
                if (i) return d();
                if (!(t.length <= 0 || t.data("cycle-completed"))) return t.data("cycle-completed", !0), t.removeClass("active-popup-card"), u++, u < e(".jdgm-popup-card").length ? x() : void 0
            }, d = function() {
                var t;
                return t = 864e5, localStorage.setItem("popup-widget-manually-closed", Date.now() + t), jdgm.asyncEach(e(".jdgm-popup-card"), function(t) {
                    return e(t).data("cycle-completed", !0), e(t).removeClass("active-popup-card")
                })
            }, l = function(t) {
                var i;
                return i = e(".jdgm-popup-widget"), e.ajax({
                    url: jdgm.API_HOST + "/reviews/reviews_for_popup_widget_modals",
                    method: "GET",
                    data: e.extend(jdgm.shopParams(), {
                        reviews_uuids: t
                    }),
                    success: function(e) {
                        var t, n, a;
                        return i.append('<div class="jdgm-popup-widget__modals-container"></div>'), t = i.find(".jdgm-popup-widget__modals-container"), !t[0].childElementCount && e.data.length ? (a = e.data.map(function(e) {
                            return JST["templates/shopify_v3/full_review_modal"]({
                                review: e
                            })
                        }), t.append(a), n = "jdgm-popup-card__full-rev-link", r(i, n), jdgm.initializeFullReviewModals(i, n, "popup-widget")) : void 0
                    },
                    error: function() {}
                })
            }, r = function(t, i) {
                return t.data("unique-string", Date.now().toString(36) + "-" + jdgm.random(1e6).toString(36)), jdgm.asyncEach(t.find(".jdgm-popup-card"), function(r) {
                    var n, a;
                    return n = e(r), a = "#" + n.data("review-id") + "-" + t.data("unique-string"), n.append("<a class='" + i + "' href='" + a + "' role='button'></a>")
                })
            }, g = function() {
                var t, i;
                return clearTimeout(y), t = e(".jdgm-popup-card"), t.length <= 0 ? void 0 : (i = [], jdgm.asyncEach(t, function(t) {
                    var r;
                    return r = e(t), _(r), b(r), i.push(r.data("review-id"))
                }), w(), x(), jdgm.isVersion3 ? l(i) : void 0)
            }, v = function(e) {
                var t, i, r, n;
                switch (r = window.location.pathname, t = r.split("/")[1], i = /^[a-z]{2}(-[a-z]{2})?$/i, i.test(t) && (r = r.replace("/" + t, "")), n = /^\/collections\/[^\/]+\/products\/[^\/]+$/, e) {
                    case "product":
                        return r.startsWith("/products/") || r.startsWith("/product/") || n.test(r);
                    case "collection":
                        return r.startsWith("/collections/") && !n.test(r);
                    case "home":
                        return "/" === r || "" === r;
                    case "cart":
                        return "/cart" === r
                }
            }, o = parseInt(localStorage.getItem("popup-widget-manually-closed"), 10), n = {
                home: jdgmSettings.popup_widget_show_on_home_page && v("home"),
                product: jdgmSettings.popup_widget_show_on_product_page && v("product"),
                collection: jdgmSettings.popup_widget_show_on_collection_page && v("collection"),
                cart: jdgmSettings.popup_widget_show_on_cart_page && v("cart")
            }, o && !(o < Date.now()) || f && jdgmSettings.popup_widget_hide_on_mobile || !Object.values(n).includes(!0) ? e(".jdgm-popup-widget").remove() : (y = setTimeout(function() {
                return g()
            }, m), h = window.innerWidth, e(window).on("resize", function(e) {
                var t;
                return t = window.innerWidth, (767 >= h && t > 767 || h > 767 && 767 >= t) && (f = 767 >= t, S(), w()), h = t
            }))
        })
    }.call(this),
    function() {
        var e;
        window.jdgmReviewSnippet = window.jdgmReviewSnippet || {}, e = function() {
            function e(e) {
                this.$ = e, this.reviews = []
            }
            var t, i, r, n, a, o;
            return r = 5e3, t = 3e3, o = ".jdgm-rev-snippet-card", a = ".jdgm-rev-snippet-widget__prev-btn", n = ".jdgm-rev-snippet-widget__next-btn", i = 0, e.prototype.initialize = function() {
                return this.$wrapper = this.$(".jdgm-review-snippet-widget-wrapper"), this.$wrapper.length > 0 ? this.fetchReviews().then(function(e) {
                    return function() {
                        var t;
                        return e.$widget = e.$(".jdgm-review-snippet-widget"), e.reviews.length > 0 ? (e.initializeWidget(), t = window.innerWidth, e.$(window).on("resize", function() {
                            var i;
                            return i = window.innerWidth, e.windowChanged = t !== i, e.windowChanged && (e.cardWidth = e.$wrapper.outerWidth(), e.setupCardsContainer()), t = i
                        })) : e.$widget.remove()
                    }
                }(this)) : void 0
            }, e.prototype.initializeWidget = function() {
                return this.currentIndex = i, this.$widget.length > 0 ? (this.$cardsContainer = this.$widget.find(".jdgm-rev-snippet-widget__cards-container"), this.$cardsContainer[0].childElementCount && !this.windowChanged || !this.reviews.length ? void 0 : (this.injectCards(), this.setupCardsContainer(), this.showCard(this.currentIndex), this.startAutoRotation(), this.setupEventListeners(), this.updateNavigationButtons(), this.setupModals(), this.$(this.document).trigger("jdgm.doneRenderReviewSnippet", {
                    $reviewWidget: this.$widget
                }))) : void 0
            }, e.prototype.fetchReviews = function() {
                return new Promise(function(e) {
                    return function(t, i) {
                        var r;
                        return r = e.$wrapper.data("id"), e.$.ajax({
                            url: jdgm.API_HOST + "/reviews/reviews_for_review_snippet_widget",
                            method: "GET",
                            data: e.$.extend(jdgm.shopParams(), {
                                product_id: r
                            }),
                            success: function(i) {
                                return e.reviews = i.data, t()
                            },
                            error: function(e) {
                                return console.error("Unable to fetch reviews. Please try again later."), i(e)
                            }
                        })
                    }
                }(this))
            }, e.prototype.injectCards = function() {
                var e;
                return e = this.reviews.map(function(e) {
                    return function(e) {
                        return JST["templates/shopify_v3/review_snippet_widget_card"]({
                            review: e
                        })
                    }
                }(this)), this.$cardsContainer.append(e), this.$cards = this.$cardsContainer.find(o), this.$cards.each(function(e) {
                    return function(t, i) {
                        return e.loadPicture(e.$(i).find(".jdgm-rev-snippet-card__pic-wrapper img"))
                    }
                }(this)), this.totalCards = this.$cards.length, this.cardWidth = this.$wrapper.outerWidth(), this.$cards.is(":visible") ? void 0 : this.$cards.fadeIn()
            }, e.prototype.cleanupWidget = function() {
                var e;
                return this.stopAutoRotation(), null != (e = this.$widget) && e.off(), this.$cards = null, this.currentIndex = i
            }, e.prototype.setupCardsContainer = function() {
                var e;
                return e = this.cardWidth * this.totalCards, this.$cardsContainer.css({
                    transition: "transform 0.5s ease",
                    width: e + "px"
                })
            }, e.prototype.showCard = function(e) {
                return e = Math.max(0, Math.min(e, this.totalCards - 1)), this.$cardsContainer.css("transform", "translateX(-" + e * this.cardWidth + "px)"), this.currentIndex = e, this.updateNavigationButtons()
            }, e.prototype.startAutoRotation = function() {
                return this.intervalId = setInterval(function(e) {
                    return function() {
                        return e.showNextCard()
                    }
                }(this), r)
            }, e.prototype.stopAutoRotation = function() {
                return clearInterval(this.intervalId)
            }, e.prototype.resumeAutoRotation = function() {
                return this.stopAutoRotation(), this.intervalId = setTimeout(function(e) {
                    return function() {
                        return e.startAutoRotation()
                    }
                }(this), t)
            }, e.prototype.updateNavigationButtons = function() {
                return this.$widget.find(a).toggle(this.currentIndex > 0), this.$widget.find(n).toggle(this.currentIndex < this.totalCards - 1)
            }, e.prototype.showPreviousCard = function() {
                var e;
                return e = (this.currentIndex - 1 + this.totalCards) % this.totalCards, this.showCard(e), this.resumeAutoRotation()
            }, e.prototype.showNextCard = function() {
                var e;
                return e = (this.currentIndex + 1) % this.totalCards, this.showCard(e), this.resumeAutoRotation()
            }, e.prototype.setupEventListeners = function() {
                return this.$widget.on("click", a, function(e) {
                    return function(t) {
                        return t.preventDefault(), e.showPreviousCard()
                    }
                }(this)), this.$widget.on("click", n, function(e) {
                    return function(t) {
                        return t.preventDefault(), e.showNextCard()
                    }
                }(this))
            }, e.prototype.setupModals = function() {
                var e;
                return e = this.reviews.map(function(e) {
                    return e.uuid
                }), this.fetchFullReviewsForModals(e, this.$widget)
            }, e.prototype.fetchFullReviewsForModals = function(e, t) {
                return this.$.ajax({
                    url: jdgm.API_HOST + "/reviews/reviews_for_popup_widget_modals",
                    method: "GET",
                    data: this.$.extend(jdgm.shopParams(), {
                        reviews_uuids: e
                    }),
                    success: function(e) {
                        return function(i) {
                            var r, n, a, o;
                            return n = e.$(".jdgm-review-snippet__modals-wrapper"), n.length > 0 ? r = n : (t.append('<div class="jdgm-review-snippet__modals-wrapper" style="display: none;"></div>'), r = t.find(".jdgm-review-snippet__modals-wrapper")), !r[0].childElementCount && i.data.length ? (o = i.data.map(function(e) {
                                return JST["templates/shopify_v3/full_review_modal"]({
                                    review: e
                                })
                            }), r.append(o), a = "jdgm-rev-snippet-card__full-review-link", e.appendFullReviewLink(t, a), jdgm.initializeFullReviewModals(t, a, "rev-snippet-widget")) : void 0
                        }
                    }(this),
                    error: function() {}
                })
            }, e.prototype.appendFullReviewLink = function(e, t) {
                return e.data("unique-string", Date.now().toString(36) + "-" + jdgm.random(1e6).toString(36)), jdgm.asyncEach(e.find(o), function(i) {
                    return function(r) {
                        var n, a;
                        return n = i.$(r), a = "#" + n.data("review-id") + "-" + e.data("unique-string"), n.append("<a class='" + t + "' href='" + a + "' role='button'></a>")
                    }
                }(this))
            }, e.prototype.loadPicture = function(e) {
                var t;
                if ((null != e ? e.length : void 0) > 0) return t = e.attr("data-src"), t ? (e.on("error", function() {
                    return e.closest(".jdgm-rev-snippet-card__pic-wrapper").remove()
                }), e.attr("src", t)) : void 0
            }, e
        }(), document.addEventListener("jdgm.doneSetup", function() {
            var t;
            return t = new e(jdgm.$), t.initialize()
        }, !1)
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, i, r, n, a, o, s;
            return i = jdgm.CDN_HOST + "widget/form.js", t = ["judgeme_token", "judgeme_review_uuid", "judgeme_dynamic_form", "judgeme_follow_up_token", "judgeme_upload_pictures"], o = function() {
                return jdgm.loadScript(i), jdgm.loadCSS(jdgm.widgetPath("form.css"))
            }, a = function() {
                return jdgm.loadScript.requestedUrls.indexOf(i) >= 0
            }, s = function() {
                var e, i;
                return e = window.location, i = "#judgeme" === e.hash || "#judgeme_product_reviews" === e.hash, t.forEach(function(t) {
                    return i || (i = e.search.indexOf(t) >= 0)
                }), i
            }, r = function() {
                return e(document).on("click", ".jdgm-write-rev-link, .jdgm-ask-question-btn", function(e) {
                    return a() ? void 0 : (o(), !1)
                })
            }, n = function() {
                var t;
                return a() ? void jdgm.ScrollEvent.dettach("checkToLoadFormJsFile") : (t = !1, jdgm.asyncEach(e(".jdgm-write-rev-link, .jdgm-ask-question-btn"), function(i) {
                    return t ? void 0 : jdgm.isInViewport(e(i).closest(":visible")[0]) ? (t = !0, o()) : void 0
                }))
            }, s() ? o() : (r(), n(), jdgm.ScrollEvent.attach(n, "checkToLoadFormJsFile"))
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, i, r, n, a, o;
            return i = ".jdgm-yt-video, .jdgm-rev__pic-link, .jdgm-rev__pic-img, .jdgm-vid-player, .jdgm-medal__image, .jdgm-gallery, .jdgm-ugc-media", t = jdgm.widgetPath("media.css"), o = function() {
                return jdgm.loadCSS(t, function() {
                    return jdgm.triggerEvent("doneLoadingMediaCss")
                }), jdgm.loadScript(jdgm.CDN_HOST + "widget/media.js")
            }, e(i).length > 0 && o(), r = e(".jdgm-gallery-data").data("json"), n = jdgmSettings.widget_show_photo_gallery && r && r.length > 0, a = "carousel" === jdgmSettings.widget_theme, (a || n) && o(), e(document).on("jdgm.beforeFetchingReviews", function(e, t) {
                return o()
            }), e(document).on("click", ".jdgm-ugc-media__thumbnail-link, .jdgm-ugc-media__load-more-btn", function(t) {
                return e(this).attr("data-execute-after-load", !0), o()
            })
        })
    }.call(this);