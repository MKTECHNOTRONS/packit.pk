! function(e, t) {
    "use strict";
    "object" == typeof module && "object" == typeof module.exports ? module.exports = e.document ? t(e, !0) : function(e) {
        if (!e.document) throw new Error("jQuery requires a window with a document");
        return t(e)
    } : t(e)
}("undefined" != typeof window ? window : this, function(e, t) {
    "use strict";

    function n(e, t, n) {}

    function r(e) {
        return null == e ? e + "" : "object" == typeof e || "function" == typeof e ? pe[ge.call(e)] || "object" : typeof e
    }

    function i(e) {
        var t = !!e && "length" in e && e.length,
            n = r(e);
        return we(e) || ye(e) ? !1 : "array" === n || 0 === t || "number" == typeof t && t > 0 && t - 1 in e
    }

    function o(e, t) {
        return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase()
    }

    function a(e, t, n) {
        return we(t) ? je.grep(e, function(e, r) {
            return !!t.call(e, r, e) !== n
        }) : t.nodeType ? je.grep(e, function(e) {
            return e === t !== n
        }) : "string" != typeof t ? je.grep(e, function(e) {
            return fe.call(t, e) > -1 !== n
        }) : je.filter(t, e, n)
    }

    function s(e, t) {
        for (;
            (e = e[t]) && 1 !== e.nodeType;);
        return e
    }

    function u(e) {
        var t = {};
        return je.each(e.match(He) || [], function(e, n) {
            t[n] = !0
        }), t
    }

    function l(e) {
        return e
    }

    function d(e) {
        throw e
    }

    function c(e, t, n, r) {
        var i;
        try {
            e && we(i = e.promise) ? i.call(e).done(t).fail(n) : e && we(i = e.then) ? i.call(e, t, n) : t.apply(void 0, [e].slice(r))
        } catch (e) {
            n.apply(void 0, [e])
        }
    }

    function f() {
        be.removeEventListener("DOMContentLoaded", f), e.removeEventListener("load", f), je.ready()
    }

    function p(e, t) {
        return t.toUpperCase()
    }

    function g(e) {
        return e.replace(Ie, "ms-").replace(Me, p)
    }

    function h() {
        this.expando = je.expando + h.uid++
    }

    function m(e) {
        return "true" === e ? !0 : "false" === e ? !1 : "null" === e ? null : e === +e + "" ? +e : $e.test(e) ? JSON.parse(e) : e
    }

    function _(e, t, n) {
        var r;
        if (void 0 === n && 1 === e.nodeType)
            if (r = "data-" + t.replace(ze, "-$&").toLowerCase(), n = e.getAttribute(r), "string" == typeof n) {
                try {
                    n = m(n)
                } catch (i) {}
                Be.set(e, t, n)
            } else n = void 0;
        return n
    }

    function v(e, t, n, r) {
        var i, o, a = 20,
            s = r ? function() {
                return r.cur()
            } : function() {
                return je.css(e, t, "")
            },
            u = s(),
            l = n && n[3] || (je.cssNumber[t] ? "" : "px"),
            d = e.nodeType && (je.cssNumber[t] || "px" !== l && +u) && Ve.exec(je.css(e, t));
        if (d && d[3] !== l) {
            for (u /= 2, l = l || d[3], d = +u || 1; a--;) je.style(e, t, d + l), (1 - o) * (1 - (o = s() / u || .5)) <= 0 && (a = 0), d /= o;
            d = 2 * d, je.style(e, t, d + l), n = n || []
        }
        return n && (d = +d || +u || 0, i = n[1] ? d + (n[1] + 1) * n[2] : +n[2], r && (r.unit = l, r.start = d, r.end = i)), i
    }

    function w(e) {
        var t, n = e.ownerDocument,
            r = e.nodeName,
            i = Ke[r];
        return i ? i : (t = n.body.appendChild(n.createElement(r)), i = je.css(t, "display"), t.parentNode.removeChild(t), "none" === i && (i = "block"), Ke[r] = i, i)
    }

    function y(e, t) {
        for (var n, r, i = [], o = 0, a = e.length; a > o; o++) r = e[o], r.style && (n = r.style.display, t ? ("none" === n && (i[o] = We.get(r, "display") || null, i[o] || (r.style.display = "")), "" === r.style.display && Ye(r) && (i[o] = w(r))) : "none" !== n && (i[o] = "none", We.set(r, "display", n)));
        for (o = 0; a > o; o++) null != i[o] && (e[o].style.display = i[o]);
        return e
    }

    function b(e, t) {
        var n;
        return n = "undefined" != typeof e.getElementsByTagName ? e.getElementsByTagName(t || "*") : "undefined" != typeof e.querySelectorAll ? e.querySelectorAll(t || "*") : [], void 0 === t || t && o(e, t) ? je.merge([e], n) : n
    }

    function x(e, t) {
        for (var n = 0, r = e.length; r > n; n++) We.set(e[n], "globalEval", !t || We.get(t[n], "globalEval"))
    }

    function j(e, t, n, i, o) {
        for (var a, s, u, l, d, c, f = t.createDocumentFragment(), p = [], g = 0, h = e.length; h > g; g++)
            if (a = e[g], a || 0 === a)
                if ("object" === r(a)) je.merge(p, a.nodeType ? [a] : a);
                else if (rt.test(a)) {
            for (s = s || f.appendChild(t.createElement("div")), u = (et.exec(a) || ["", ""])[1].toLowerCase(), l = nt[u] || nt._default, s.innerHTML = l[1] + je.htmlPrefilter(a) + l[2], c = l[0]; c--;) s = s.lastChild;
            je.merge(p, s.childNodes), s = f.firstChild, s.textContent = ""
        } else p.push(t.createTextNode(a));
        for (f.textContent = "", g = 0; a = p[g++];)
            if (i && je.inArray(a, i) > -1) o && o.push(a);
            else if (d = Je(a), s = b(f.appendChild(a), "script"), d && x(s), n)
            for (c = 0; a = s[c++];) tt.test(a.type || "") && n.push(a);
        return f
    }

    function T() {
        return !0
    }

    function C() {
        return !1
    }

    function S(e, t) {
        return e === k() == ("focus" === t)
    }

    function k() {
        try {
            return be.activeElement
        } catch (e) {}
    }

    function E(e, t, n, r, i, o) {
        var a, s;
        if ("object" == typeof t) {
            "string" != typeof n && (r = r || n, n = void 0);
            for (s in t) E(e, s, n, r, t[s], o);
            return e
        }
        if (null == r && null == i ? (i = n, r = n = void 0) : null == i && ("string" == typeof n ? (i = r, r = void 0) : (i = r, r = n, n = void 0)), i === !1) i = C;
        else if (!i) return e;
        return 1 === o && (a = i, i = function(e) {
            return je().off(e), a.apply(this, arguments)
        }, i.guid = a.guid || (a.guid = je.guid++)), e.each(function() {
            je.event.add(this, t, i, r, n)
        })
    }

    function A(e, t, n) {
        return n ? (We.set(e, t, !1), void je.event.add(e, t, {
            namespace: !1,
            handler: function(e) {
                var r, i, o = We.get(this, t);
                if (1 & e.isTrigger && this[t]) {
                    if (o.length)(je.event.special[t] || {}).delegateType && e.stopPropagation();
                    else if (o = le.call(arguments), We.set(this, t, o), r = n(this, t), this[t](), i = We.get(this, t), o !== i || r ? We.set(this, t, !1) : i = {}, o !== i) return e.stopImmediatePropagation(), e.preventDefault(), i && i.value
                } else o.length && (We.set(this, t, {
                    value: je.event.trigger(je.extend(o[0], je.Event.prototype), o.slice(1), this)
                }), e.stopImmediatePropagation())
            }
        })) : void(void 0 === We.get(e, t) && je.event.add(e, t, T))
    }

    function D(e, t) {
        return o(e, "table") && o(11 !== t.nodeType ? t : t.firstChild, "tr") ? je(e).children("tbody")[0] || e : e
    }

    function N(e) {
        return e.type = (null !== e.getAttribute("type")) + "/" + e.type, e
    }

    function q(e) {
        return "true/" === (e.type || "").slice(0, 5) ? e.type = e.type.slice(5) : e.removeAttribute("type"), e
    }

    function L(e, t) {
        var n, r, i, o, a, s, u;
        if (1 === t.nodeType) {
            if (We.hasData(e) && (o = We.get(e), u = o.events)) {
                We.remove(t, "handle events");
                for (i in u)
                    for (n = 0, r = u[i].length; r > n; n++) je.event.add(t, i, u[i][n])
            }
            Be.hasData(e) && (a = Be.access(e), s = je.extend({}, a), Be.set(t, s))
        }
    }

    function H(e, t) {
        var n = t.nodeName.toLowerCase();
        "input" === n && Ze.test(e.type) ? t.checked = e.checked : ("input" === n || "textarea" === n) && (t.defaultValue = e.defaultValue)
    }

    function P(e, t, r, i) {
        t = de(t);
        var o, a, s, u, l, d, c = 0,
            f = e.length,
            p = f - 1,
            g = t[0],
            h = we(g);
        if (h || f > 1 && "string" == typeof g && !ve.checkClone && at.test(g)) return e.each(function(n) {
            var o = e.eq(n);
            h && (t[0] = g.call(this, n, o.html())), P(o, t, r, i)
        });
        if (f && (o = j(t, e[0].ownerDocument, !1, e, i), a = o.firstChild, 1 === o.childNodes.length && (o = a), a || i)) {
            for (s = je.map(b(o, "script"), N), u = s.length; f > c; c++) l = o, c !== p && (l = je.clone(l, !0, !0), u && je.merge(s, b(l, "script"))), r.call(e[c], l, c);
            if (u)
                for (d = s[s.length - 1].ownerDocument, je.map(s, q), c = 0; u > c; c++) l = s[c], tt.test(l.type || "") && !We.access(l, "globalEval") && je.contains(d, l) && (l.src && "module" !== (l.type || "").toLowerCase() ? je._evalUrl && !l.noModule && je._evalUrl(l.src, {
                    nonce: l.nonce || l.getAttribute("nonce")
                }, d) : n(l.textContent.replace(st, ""), l, d))
        }
        return e
    }

    function R(e, t, n) {
        for (var r, i = t ? je.filter(t, e) : e, o = 0; null != (r = i[o]); o++) n || 1 !== r.nodeType || je.cleanData(b(r)), r.parentNode && (n && Je(r) && x(b(r, "script")), r.parentNode.removeChild(r));
        return e
    }

    function O(e, t, n) {
        var r, i, o, a, s = e.style;
        return n = n || lt(e), n && (a = n.getPropertyValue(t) || n[t], "" !== a || Je(e) || (a = je.style(e, t)), !ve.pixelBoxStyles() && ut.test(a) && ct.test(t) && (r = s.width, i = s.minWidth, o = s.maxWidth, s.minWidth = s.maxWidth = s.width = a, a = n.width, s.width = r, s.minWidth = i, s.maxWidth = o)), void 0 !== a ? a + "" : a
    }

    function I(e, t) {
        return {
            get: function() {
                return e() ? void delete this.get : (this.get = t).apply(this, arguments)
            }
        }
    }

    function M(e) {
        for (var t = e[0].toUpperCase() + e.slice(1), n = ft.length; n--;)
            if (e = ft[n] + t, e in pt) return e
    }

    function F(e) {
        var t = je.cssProps[e] || gt[e];
        return t ? t : e in pt ? e : gt[e] = M(e) || e
    }

    function W(e, t, n) {
        var r = Ve.exec(t);
        return r ? Math.max(0, r[2] - (n || 0)) + (r[3] || "px") : t
    }

    function B(e, t, n, r, i, o) {
        var a = "width" === t ? 1 : 0,
            s = 0,
            u = 0;
        if (n === (r ? "border" : "content")) return 0;
        for (; 4 > a; a += 2) "margin" === n && (u += je.css(e, n + Xe[a], !0, i)), r ? ("content" === n && (u -= je.css(e, "padding" + Xe[a], !0, i)), "margin" !== n && (u -= je.css(e, "border" + Xe[a] + "Width", !0, i))) : (u += je.css(e, "padding" + Xe[a], !0, i), "padding" !== n ? u += je.css(e, "border" + Xe[a] + "Width", !0, i) : s += je.css(e, "border" + Xe[a] + "Width", !0, i));
        return !r && o >= 0 && (u += Math.max(0, Math.ceil(e["offset" + t[0].toUpperCase() + t.slice(1)] - o - u - s - .5)) || 0), u
    }

    function $(e, t, n) {
        var r = lt(e),
            i = !ve.boxSizingReliable() || n,
            a = i && "border-box" === je.css(e, "boxSizing", !1, r),
            s = a,
            u = O(e, t, r),
            l = "offset" + t[0].toUpperCase() + t.slice(1);
        if (ut.test(u)) {
            if (!n) return u;
            u = "auto"
        }
        return (!ve.boxSizingReliable() && a || !ve.reliableTrDimensions() && o(e, "tr") || "auto" === u || !parseFloat(u) && "inline" === je.css(e, "display", !1, r)) && e.getClientRects().length && (a = "border-box" === je.css(e, "boxSizing", !1, r), s = l in e, s && (u = e[l])), u = parseFloat(u) || 0, u + B(e, t, n || (a ? "border" : "content"), s, r, u) + "px"
    }

    function z(e, t, n, r, i) {
        return new z.prototype.init(e, t, n, r, i)
    }

    function U() {
        yt && (be.hidden === !1 && e.requestAnimationFrame ? e.requestAnimationFrame(U) : e.setTimeout(U, je.fx.interval), je.fx.tick())
    }

    function V() {
        return e.setTimeout(function() {
            wt = void 0
        }), wt = Date.now()
    }

    function X(e, t) {
        var n, r = 0,
            i = {
                height: e
            };
        for (t = t ? 1 : 0; 4 > r; r += 2 - t) n = Xe[r], i["margin" + n] = i["padding" + n] = e;
        return t && (i.opacity = i.width = e), i
    }

    function G(e, t, n) {
        for (var r, i = (Y.tweeners[t] || []).concat(Y.tweeners["*"]), o = 0, a = i.length; a > o; o++)
            if (r = i[o].call(n, t, e)) return r
    }

    function J(e, t, n) {
        var r, i, o, a, s, u, l, d, c = "width" in t || "height" in t,
            f = this,
            p = {},
            g = e.style,
            h = e.nodeType && Ye(e),
            m = We.get(e, "fxshow");
        n.queue || (a = je._queueHooks(e, "fx"), null == a.unqueued && (a.unqueued = 0, s = a.empty.fire, a.empty.fire = function() {
            a.unqueued || s()
        }), a.unqueued++, f.always(function() {
            f.always(function() {
                a.unqueued--, je.queue(e, "fx").length || a.empty.fire()
            })
        }));
        for (r in t)
            if (i = t[r], bt.test(i)) {
                if (delete t[r], o = o || "toggle" === i, i === (h ? "hide" : "show")) {
                    if ("show" !== i || !m || void 0 === m[r]) continue;
                    h = !0
                }
                p[r] = m && m[r] || je.style(e, r)
            }
        if (u = !je.isEmptyObject(t), u || !je.isEmptyObject(p)) {
            c && 1 === e.nodeType && (n.overflow = [g.overflow, g.overflowX, g.overflowY], l = m && m.display, null == l && (l = We.get(e, "display")), d = je.css(e, "display"), "none" === d && (l ? d = l : (y([e], !0), l = e.style.display || l, d = je.css(e, "display"), y([e]))), ("inline" === d || "inline-block" === d && null != l) && "none" === je.css(e, "float") && (u || (f.done(function() {
                g.display = l
            }), null == l && (d = g.display, l = "none" === d ? "" : d)), g.display = "inline-block")), n.overflow && (g.overflow = "hidden", f.always(function() {
                g.overflow = n.overflow[0], g.overflowX = n.overflow[1], g.overflowY = n.overflow[2]
            })), u = !1;
            for (r in p) u || (m ? "hidden" in m && (h = m.hidden) : m = We.access(e, "fxshow", {
                display: l
            }), o && (m.hidden = !h), h && y([e], !0), f.done(function() {
                h || y([e]), We.remove(e, "fxshow");
                for (r in p) je.style(e, r, p[r])
            })), u = G(h ? m[r] : 0, r, f), r in m || (m[r] = u.start, h && (u.end = u.start, u.start = 0))
        }
    }

    function Q(e, t) {
        var n, r, i, o, a;
        for (n in e)
            if (r = g(n), i = t[r], o = e[n], Array.isArray(o) && (i = o[1], o = e[n] = o[0]), n !== r && (e[r] = o, delete e[n]), a = je.cssHooks[r], a && "expand" in a) {
                o = a.expand(o), delete e[r];
                for (n in o) n in e || (e[n] = o[n], t[n] = i)
            } else t[r] = i
    }

    function Y(e, t, n) {
        var r, i, o = 0,
            a = Y.prefilters.length,
            s = je.Deferred().always(function() {
                delete u.elem
            }),
            u = function() {
                if (i) return !1;
                for (var t = wt || V(), n = Math.max(0, l.startTime + l.duration - t), r = n / l.duration || 0, o = 1 - r, a = 0, u = l.tweens.length; u > a; a++) l.tweens[a].run(o);
                return s.notifyWith(e, [l, o, n]), 1 > o && u ? n : (u || s.notifyWith(e, [l, 1, 0]), s.resolveWith(e, [l]), !1)
            },
            l = s.promise({
                elem: e,
                props: je.extend({}, t),
                opts: je.extend(!0, {
                    specialEasing: {},
                    easing: je.easing._default
                }, n),
                originalProperties: t,
                originalOptions: n,
                startTime: wt || V(),
                duration: n.duration,
                tweens: [],
                createTween: function(t, n) {
                    var r = je.Tween(e, l.opts, t, n, l.opts.specialEasing[t] || l.opts.easing);
                    return l.tweens.push(r), r
                },
                stop: function(t) {
                    var n = 0,
                        r = t ? l.tweens.length : 0;
                    if (i) return this;
                    for (i = !0; r > n; n++) l.tweens[n].run(1);
                    return t ? (s.notifyWith(e, [l, 1, 0]), s.resolveWith(e, [l, t])) : s.rejectWith(e, [l, t]), this
                }
            }),
            d = l.props;
        for (Q(d, l.opts.specialEasing); a > o; o++)
            if (r = Y.prefilters[o].call(l, e, d, l.opts)) return we(r.stop) && (je._queueHooks(l.elem, l.opts.queue).stop = r.stop.bind(r)), r;
        return je.map(d, G, l), we(l.opts.start) && l.opts.start.call(e, l), l.progress(l.opts.progress).done(l.opts.done, l.opts.complete).fail(l.opts.fail).always(l.opts.always), je.fx.timer(je.extend(u, {
            elem: e,
            anim: l,
            queue: l.opts.queue
        })), l
    }

    function K(e) {
        var t = e.match(He) || [];
        return t.join(" ")
    }

    function Z(e) {
        return e.getAttribute && e.getAttribute("class") || ""
    }

    function ee(e) {
        return Array.isArray(e) ? e : "string" == typeof e ? e.match(He) || [] : []
    }

    function te(e, t, n, i) {
        var o;
        if (Array.isArray(t)) je.each(t, function(t, r) {
            n || Lt.test(e) ? i(e, r) : te(e + "[" + ("object" == typeof r && null != r ? t : "") + "]", r, n, i)
        });
        else if (n || "object" !== r(t)) i(e, t);
        else
            for (o in t) te(e + "[" + o + "]", t[o], n, i)
    }

    function ne(e) {
        return function(t, n) {
            "string" != typeof t && (n = t, t = "*");
            var r, i = 0,
                o = t.toLowerCase().match(He) || [];
            if (we(n))
                for (; r = o[i++];) "+" === r[0] ? (r = r.slice(1) || "*", (e[r] = e[r] || []).unshift(n)) : (e[r] = e[r] || []).push(n)
        }
    }

    function re(e, t, n, r) {
        function i(s) {
            var u;
            return o[s] = !0, je.each(e[s] || [], function(e, s) {
                var l = s(t, n, r);
                return "string" != typeof l || a || o[l] ? a ? !(u = l) : void 0 : (t.dataTypes.unshift(l), i(l), !1)
            }), u
        }
        var o = {},
            a = e === Ut;
        return i(t.dataTypes[0]) || !o["*"] && i("*")
    }

    function ie(e, t) {
        var n, r, i = je.ajaxSettings.flatOptions || {};
        for (n in t) void 0 !== t[n] && ((i[n] ? e : r || (r = {}))[n] = t[n]);
        return r && je.extend(!0, e, r), e
    }

    function oe(e, t, n) {
        for (var r, i, o, a, s = e.contents, u = e.dataTypes;
            "*" === u[0];) u.shift(), void 0 === r && (r = e.mimeType || t.getResponseHeader("Content-Type"));
        if (r)
            for (i in s)
                if (s[i] && s[i].test(r)) {
                    u.unshift(i);
                    break
                }
        if (u[0] in n) o = u[0];
        else {
            for (i in n) {
                if (!u[0] || e.converters[i + " " + u[0]]) {
                    o = i;
                    break
                }
                a || (a = i)
            }
            o = o || a
        }
        return o ? (o !== u[0] && u.unshift(o), n[o]) : void 0
    }

    function ae(e, t, n, r) {
        var i, o, a, s, u, l = {},
            d = e.dataTypes.slice();
        if (d[1])
            for (a in e.converters) l[a.toLowerCase()] = e.converters[a];
        for (o = d.shift(); o;)
            if (e.responseFields[o] && (n[e.responseFields[o]] = t), !u && r && e.dataFilter && (t = e.dataFilter(t, e.dataType)), u = o, o = d.shift())
                if ("*" === o) o = u;
                else if ("*" !== u && u !== o) {
            if (a = l[u + " " + o] || l["* " + o], !a)
                for (i in l)
                    if (s = i.split(" "), s[1] === o && (a = l[u + " " + s[0]] || l["* " + s[0]])) {
                        a === !0 ? a = l[i] : l[i] !== !0 && (o = s[0], d.unshift(s[1]));
                        break
                    }
            if (a !== !0)
                if (a && e["throws"]) t = a(t);
                else try {
                    t = a(t)
                } catch (c) {
                    return {
                        state: "parsererror",
                        error: a ? c : "No conversion from " + u + " to " + o
                    }
                }
        }
        return {
            state: "success",
            data: t
        }
    }
    var se = [],
        ue = Object.getPrototypeOf,
        le = se.slice,
        de = se.flat ? function(e) {
            return se.flat.call(e)
        } : function(e) {
            return se.concat.apply([], e)
        },
        ce = se.push,
        fe = se.indexOf,
        pe = {},
        ge = pe.toString,
        he = pe.hasOwnProperty,
        me = he.toString,
        _e = me.call(Object),
        ve = {},
        we = function(e) {
            return "function" == typeof e && "number" != typeof e.nodeType && "function" != typeof e.item
        },
        ye = function(e) {
            return null != e && e === e.window
        },
        be = e.document,
        xe = "3.6.0",
        je = function(e, t) {
            return new je.fn.init(e, t)
        };
    je.fn = je.prototype = {
        jquery: xe,
        constructor: je,
        length: 0,
        toArray: function() {
            return le.call(this)
        },
        get: function(e) {
            return null == e ? le.call(this) : 0 > e ? this[e + this.length] : this[e]
        },
        pushStack: function(e) {
            var t = je.merge(this.constructor(), e);
            return t.prevObject = this, t
        },
        each: function(e) {
            return je.each(this, e)
        },
        map: function(e) {
            return this.pushStack(je.map(this, function(t, n) {
                return e.call(t, n, t)
            }))
        },
        slice: function() {
            return this.pushStack(le.apply(this, arguments))
        },
        first: function() {
            return this.eq(0)
        },
        last: function() {
            return this.eq(-1)
        },
        even: function() {
            return this.pushStack(je.grep(this, function(e, t) {
                return (t + 1) % 2
            }))
        },
        odd: function() {
            return this.pushStack(je.grep(this, function(e, t) {
                return t % 2
            }))
        },
        eq: function(e) {
            var t = this.length,
                n = +e + (0 > e ? t : 0);
            return this.pushStack(n >= 0 && t > n ? [this[n]] : [])
        },
        end: function() {
            return this.prevObject || this.constructor()
        },
        push: ce,
        sort: se.sort,
        splice: se.splice
    }, je.extend = je.fn.extend = function() {
        var e, t, n, r, i, o, a = arguments[0] || {},
            s = 1,
            u = arguments.length,
            l = !1;
        for ("boolean" == typeof a && (l = a, a = arguments[s] || {}, s++), "object" == typeof a || we(a) || (a = {}), s === u && (a = this, s--); u > s; s++)
            if (null != (e = arguments[s]))
                for (t in e) r = e[t], "__proto__" !== t && a !== r && (l && r && (je.isPlainObject(r) || (i = Array.isArray(r))) ? (n = a[t], o = i && !Array.isArray(n) ? [] : i || je.isPlainObject(n) ? n : {}, i = !1, a[t] = je.extend(l, o, r)) : void 0 !== r && (a[t] = r));
        return a
    }, je.extend({
        expando: "jQuery" + (xe + Math.random()).replace(/\D/g, ""),
        isReady: !0,
        error: function(e) {
            throw new Error(e)
        },
        noop: function() {},
        isPlainObject: function(e) {
            var t, n;
            return e && "[object Object]" === ge.call(e) ? (t = ue(e)) ? (n = he.call(t, "constructor") && t.constructor, "function" == typeof n && me.call(n) === _e) : !0 : !1
        },
        isEmptyObject: function(e) {
            var t;
            for (t in e) return !1;
            return !0
        },
        globalEval: function(e, t, n) {},
        each: function(e, t) {
            var n, r = 0;
            if (i(e))
                for (n = e.length; n > r && t.call(e[r], r, e[r]) !== !1; r++);
            else
                for (r in e)
                    if (t.call(e[r], r, e[r]) === !1) break;
            return e
        },
        makeArray: function(e, t) {
            var n = t || [];
            return null != e && (i(Object(e)) ? je.merge(n, "string" == typeof e ? [e] : e) : ce.call(n, e)), n
        },
        inArray: function(e, t, n) {
            return null == t ? -1 : fe.call(t, e, n)
        },
        merge: function(e, t) {
            for (var n = +t.length, r = 0, i = e.length; n > r; r++) e[i++] = t[r];
            return e.length = i, e
        },
        grep: function(e, t, n) {
            for (var r, i = [], o = 0, a = e.length, s = !n; a > o; o++) r = !t(e[o], o), r !== s && i.push(e[o]);
            return i
        },
        map: function(e, t, n) {
            var r, o, a = 0,
                s = [];
            if (i(e))
                for (r = e.length; r > a; a++) o = t(e[a], a, n), null != o && s.push(o);
            else
                for (a in e) o = t(e[a], a, n), null != o && s.push(o);
            return de(s)
        },
        guid: 1,
        support: ve
    }), "function" == typeof Symbol && (je.fn[Symbol.iterator] = se[Symbol.iterator]), je.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "), function(e, t) {
        pe["[object " + t + "]"] = t.toLowerCase()
    });
    var Te = function(e) {
        function t(e, t, n, r) {
            var i, o, a, s, u, l, c, p = t && t.ownerDocument,
                g = t ? t.nodeType : 9;
            if (n = n || [], "string" != typeof e || !e || 1 !== g && 9 !== g && 11 !== g) return n;
            if (!r && (N(t), t = t || q, H)) {
                if (11 !== g && (u = ve.exec(e)))
                    if (i = u[1]) {
                        if (9 === g) {
                            if (!(a = t.getElementById(i))) return n;
                            if (a.id === i) return n.push(a), n
                        } else if (p && (a = p.getElementById(i)) && I(t, a) && a.id === i) return n.push(a), n
                    } else {
                        if (u[2]) return K.apply(n, t.getElementsByTagName(e)), n;
                        if ((i = u[3]) && b.getElementsByClassName && t.getElementsByClassName) return K.apply(n, t.getElementsByClassName(i)), n
                    }
                if (b.qsa && !V[e + " "] && (!P || !P.test(e)) && (1 !== g || "object" !== t.nodeName.toLowerCase())) {
                    if (c = e, p = t, 1 === g && (de.test(e) || le.test(e))) {
                        for (p = we.test(e) && d(t.parentNode) || t, p === t && b.scope || ((s = t.getAttribute("id")) ? s = s.replace(xe, je) : t.setAttribute("id", s = M)), l = C(e), o = l.length; o--;) l[o] = (s ? "#" + s : ":scope") + " " + f(l[o]);
                        c = l.join(",")
                    }
                    try {
                        return K.apply(n, p.querySelectorAll(c)), n
                    } catch (h) {
                        V(e, !0)
                    } finally {
                        s === M && t.removeAttribute("id")
                    }
                }
            }
            return k(e.replace(se, "$1"), t, n, r)
        }

        function n() {
            function e(n, r) {
                return t.push(n + " ") > x.cacheLength && delete e[t.shift()], e[n + " "] = r
            }
            var t = [];
            return e
        }

        function r(e) {
            return e[M] = !0, e
        }

        function i(e) {
            var t = q.createElement("fieldset");
            try {
                return !!e(t)
            } catch (n) {
                return !1
            } finally {
                t.parentNode && t.parentNode.removeChild(t), t = null
            }
        }

        function o(e, t) {
            for (var n = e.split("|"), r = n.length; r--;) x.attrHandle[n[r]] = t
        }

        function a(e) {
            return function(t) {
                var n = t.nodeName.toLowerCase();
                return "input" === n && t.type === e
            }
        }

        function s(e) {
            return function(t) {
                var n = t.nodeName.toLowerCase();
                return ("input" === n || "button" === n) && t.type === e
            }
        }

        function u(e) {
            return function(t) {
                return "form" in t ? t.parentNode && t.disabled === !1 ? "label" in t ? "label" in t.parentNode ? t.parentNode.disabled === e : t.disabled === e : t.isDisabled === e || t.isDisabled !== !e && Ce(t) === e : t.disabled === e : "label" in t ? t.disabled === e : !1
            }
        }

        function l(e) {
            return r(function(t) {
                return t = +t, r(function(n, r) {
                    for (var i, o = e([], n.length, t), a = o.length; a--;) n[i = o[a]] && (n[i] = !(r[i] = n[i]))
                })
            })
        }

        function d(e) {
            return e && "undefined" != typeof e.getElementsByTagName && e
        }

        function c() {}

        function f(e) {
            for (var t = 0, n = e.length, r = ""; n > t; t++) r += e[t].value;
            return r
        }

        function p(e, t, n) {
            var r = t.dir,
                i = t.next,
                o = i || r,
                a = n && "parentNode" === o,
                s = B++;
            return t.first ? function(t, n, i) {
                for (; t = t[r];)
                    if (1 === t.nodeType || a) return e(t, n, i);
                return !1
            } : function(t, n, u) {
                var l, d, c, f = [W, s];
                if (u) {
                    for (; t = t[r];)
                        if ((1 === t.nodeType || a) && e(t, n, u)) return !0
                } else
                    for (; t = t[r];)
                        if (1 === t.nodeType || a)
                            if (c = t[M] || (t[M] = {}), d = c[t.uniqueID] || (c[t.uniqueID] = {}), i && i === t.nodeName.toLowerCase()) t = t[r] || t;
                            else {
                                if ((l = d[o]) && l[0] === W && l[1] === s) return f[2] = l[2];
                                if (d[o] = f, f[2] = e(t, n, u)) return !0
                            } return !1
            }
        }

        function g(e) {
            return e.length > 1 ? function(t, n, r) {
                for (var i = e.length; i--;)
                    if (!e[i](t, n, r)) return !1;
                return !0
            } : e[0]
        }

        function h(e, n, r) {
            for (var i = 0, o = n.length; o > i; i++) t(e, n[i], r);
            return r
        }

        function m(e, t, n, r, i) {
            for (var o, a = [], s = 0, u = e.length, l = null != t; u > s; s++)(o = e[s]) && (!n || n(o, r, i)) && (a.push(o), l && t.push(s));
            return a
        }

        function _(e, t, n, i, o, a) {
            return i && !i[M] && (i = _(i)), o && !o[M] && (o = _(o, a)), r(function(r, a, s, u) {
                var l, d, c, f = [],
                    p = [],
                    g = a.length,
                    _ = r || h(t || "*", s.nodeType ? [s] : s, []),
                    v = !e || !r && t ? _ : m(_, f, e, s, u),
                    w = n ? o || (r ? e : g || i) ? [] : a : v;
                if (n && n(v, w, s, u), i)
                    for (l = m(w, p), i(l, [], s, u), d = l.length; d--;)(c = l[d]) && (w[p[d]] = !(v[p[d]] = c));
                if (r) {
                    if (o || e) {
                        if (o) {
                            for (l = [], d = w.length; d--;)(c = w[d]) && l.push(v[d] = c);
                            o(null, w = [], l, u)
                        }
                        for (d = w.length; d--;)(c = w[d]) && (l = o ? ee(r, c) : f[d]) > -1 && (r[l] = !(a[l] = c))
                    }
                } else w = m(w === a ? w.splice(g, w.length) : w), o ? o(null, a, w, u) : K.apply(a, w)
            })
        }

        function v(e) {
            for (var t, n, r, i = e.length, o = x.relative[e[0].type], a = o || x.relative[" "], s = o ? 1 : 0, u = p(function(e) {
                    return e === t
                }, a, !0), l = p(function(e) {
                    return ee(t, e) > -1
                }, a, !0), d = [function(e, n, r) {
                    var i = !o && (r || n !== E) || ((t = n).nodeType ? u(e, n, r) : l(e, n, r));
                    return t = null, i
                }]; i > s; s++)
                if (n = x.relative[e[s].type]) d = [p(g(d), n)];
                else {
                    if (n = x.filter[e[s].type].apply(null, e[s].matches), n[M]) {
                        for (r = ++s; i > r && !x.relative[e[r].type]; r++);
                        return _(s > 1 && g(d), s > 1 && f(e.slice(0, s - 1).concat({
                            value: " " === e[s - 2].type ? "*" : ""
                        })).replace(se, "$1"), n, r > s && v(e.slice(s, r)), i > r && v(e = e.slice(r)), i > r && f(e))
                    }
                    d.push(n)
                }
            return g(d)
        }

        function w(e, n) {
            var i = n.length > 0,
                o = e.length > 0,
                a = function(r, a, s, u, l) {
                    var d, c, f, p = 0,
                        g = "0",
                        h = r && [],
                        _ = [],
                        v = E,
                        w = r || o && x.find.TAG("*", l),
                        y = W += null == v ? 1 : Math.random() || .1,
                        b = w.length;
                    for (l && (E = a == q || a || l); g !== b && null != (d = w[g]); g++) {
                        if (o && d) {
                            for (c = 0, a || d.ownerDocument == q || (N(d), s = !H); f = e[c++];)
                                if (f(d, a || q, s)) {
                                    u.push(d);
                                    break
                                }
                            l && (W = y)
                        }
                        i && ((d = !f && d) && p--, r && h.push(d))
                    }
                    if (p += g, i && g !== p) {
                        for (c = 0; f = n[c++];) f(h, _, a, s);
                        if (r) {
                            if (p > 0)
                                for (; g--;) h[g] || _[g] || (_[g] = Q.call(u));
                            _ = m(_)
                        }
                        K.apply(u, _), l && !r && _.length > 0 && p + n.length > 1 && t.uniqueSort(u)
                    }
                    return l && (W = y, E = v), h
                };
            return i ? r(a) : a
        }
        var y, b, x, j, T, C, S, k, E, A, D, N, q, L, H, P, R, O, I, M = "sizzle" + 1 * new Date,
            F = e.document,
            W = 0,
            B = 0,
            $ = n(),
            z = n(),
            U = n(),
            V = n(),
            X = function(e, t) {
                return e === t && (D = !0), 0
            },
            G = {}.hasOwnProperty,
            J = [],
            Q = J.pop,
            Y = J.push,
            K = J.push,
            Z = J.slice,
            ee = function(e, t) {
                for (var n = 0, r = e.length; r > n; n++)
                    if (e[n] === t) return n;
                return -1
            },
            te = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
            ne = "[\\x20\\t\\r\\n\\f]",
            re = "(?:\\\\[\\da-fA-F]{1,6}" + ne + "?|\\\\[^\\r\\n\\f]|[\\w-]|[^\x00-\\x7f])+",
            ie = "\\[" + ne + "*(" + re + ")(?:" + ne + "*([*^$|!~]?=)" + ne + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + re + "))|)" + ne + "*\\]",
            oe = ":(" + re + ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" + ie + ")*)|.*)\\)|)",
            ae = new RegExp(ne + "+", "g"),
            se = new RegExp("^" + ne + "+|((?:^|[^\\\\])(?:\\\\.)*)" + ne + "+$", "g"),
            ue = new RegExp("^" + ne + "*," + ne + "*"),
            le = new RegExp("^" + ne + "*([>+~]|" + ne + ")" + ne + "*"),
            de = new RegExp(ne + "|>"),
            ce = new RegExp(oe),
            fe = new RegExp("^" + re + "$"),
            pe = {
                ID: new RegExp("^#(" + re + ")"),
                CLASS: new RegExp("^\\.(" + re + ")"),
                TAG: new RegExp("^(" + re + "|[*])"),
                ATTR: new RegExp("^" + ie),
                PSEUDO: new RegExp("^" + oe),
                CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + ne + "*(even|odd|(([+-]|)(\\d*)n|)" + ne + "*(?:([+-]|)" + ne + "*(\\d+)|))" + ne + "*\\)|)", "i"),
                bool: new RegExp("^(?:" + te + ")$", "i"),
                needsContext: new RegExp("^" + ne + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + ne + "*((?:-\\d)?\\d*)" + ne + "*\\)|)(?=[^-]|$)", "i")
            },
            ge = /HTML$/i,
            he = /^(?:input|select|textarea|button)$/i,
            me = /^h\d$/i,
            _e = /^[^{]+\{\s*\[native \w/,
            ve = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
            we = /[+~]/,
            ye = new RegExp("\\\\[\\da-fA-F]{1,6}" + ne + "?|\\\\([^\\r\\n\\f])", "g"),
            be = function(e, t) {
                var n = "0x" + e.slice(1) - 65536;
                return t ? t : 0 > n ? String.fromCharCode(n + 65536) : String.fromCharCode(n >> 10 | 55296, 1023 & n | 56320)
            },
            xe = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\0-\x1f\x7f-\uFFFF\w-]/g,
            je = function(e, t) {
                return t ? "\x00" === e ? "\ufffd" : e.slice(0, -1) + "\\" + e.charCodeAt(e.length - 1).toString(16) + " " : "\\" + e
            },
            Te = function() {
                N()
            },
            Ce = p(function(e) {
                return e.disabled === !0 && "fieldset" === e.nodeName.toLowerCase()
            }, {
                dir: "parentNode",
                next: "legend"
            });
        try {
            K.apply(J = Z.call(F.childNodes), F.childNodes), J[F.childNodes.length].nodeType
        } catch (Se) {
            K = {
                apply: J.length ? function(e, t) {
                    Y.apply(e, Z.call(t))
                } : function(e, t) {
                    for (var n = e.length, r = 0; e[n++] = t[r++];);
                    e.length = n - 1
                }
            }
        }
        b = t.support = {}, T = t.isXML = function(e) {
            var t = e && e.namespaceURI,
                n = e && (e.ownerDocument || e).documentElement;
            return !ge.test(t || n && n.nodeName || "HTML")
        }, N = t.setDocument = function(e) {
            var t, n, r = e ? e.ownerDocument || e : F;
            return r != q && 9 === r.nodeType && r.documentElement ? (q = r, L = q.documentElement, H = !T(q), F != q && (n = q.defaultView) && n.top !== n && (n.addEventListener ? n.addEventListener("unload", Te, !1) : n.attachEvent && n.attachEvent("onunload", Te)), b.scope = i(function(e) {
                return L.appendChild(e).appendChild(q.createElement("div")), "undefined" != typeof e.querySelectorAll && !e.querySelectorAll(":scope fieldset div").length
            }), b.attributes = i(function(e) {
                return e.className = "i", !e.getAttribute("className")
            }), b.getElementsByTagName = i(function(e) {
                return e.appendChild(q.createComment("")), !e.getElementsByTagName("*").length
            }), b.getElementsByClassName = _e.test(q.getElementsByClassName), b.getById = i(function(e) {
                return L.appendChild(e).id = M, !q.getElementsByName || !q.getElementsByName(M).length
            }), b.getById ? (x.filter.ID = function(e) {
                var t = e.replace(ye, be);
                return function(e) {
                    return e.getAttribute("id") === t
                }
            }, x.find.ID = function(e, t) {
                if ("undefined" != typeof t.getElementById && H) {
                    var n = t.getElementById(e);
                    return n ? [n] : []
                }
            }) : x.filter.ID = function(e) {
                var t = e.replace(ye, be);
                return function(e) {
                    var n = "undefined" != typeof e.getAttributeNode && e.getAttributeNode("id");
                    return n && n.value === t
                }
            }, x.find.TAG = b.getElementsByTagName ? function(e, t) {
                return "undefined" != typeof t.getElementsByTagName ? t.getElementsByTagName(e) : b.qsa ? t.querySelectorAll(e) : void 0
            } : function(e, t) {
                var n, r = [],
                    i = 0,
                    o = t.getElementsByTagName(e);
                if ("*" === e) {
                    for (; n = o[i++];) 1 === n.nodeType && r.push(n);
                    return r
                }
                return o
            }, x.find.CLASS = b.getElementsByClassName && function(e, t) {
                return "undefined" != typeof t.getElementsByClassName && H ? t.getElementsByClassName(e) : void 0
            }, R = [], P = [], (b.qsa = _e.test(q.querySelectorAll)) && (i(function(e) {
                var t;
                L.appendChild(e).innerHTML = "<a id='" + M + "'></a><select id='" + M + "-\r\\' msallowcapture=''><option selected=''></option></select>", e.querySelectorAll("[msallowcapture^='']").length && P.push("[*^$]=" + ne + "*(?:''|\"\")"), e.querySelectorAll("[selected]").length || P.push("\\[" + ne + "*(?:value|" + te + ")"), e.querySelectorAll("[id~=" + M + "-]").length || P.push("~="), t = q.createElement("input"), t.setAttribute("name", ""), e.appendChild(t), e.querySelectorAll("[name='']").length || P.push("\\[" + ne + "*name" + ne + "*=" + ne + "*(?:''|\"\")"), e.querySelectorAll(":checked").length || P.push(":checked"), e.querySelectorAll("a#" + M + "+*").length || P.push(".#.+[+~]"), e.querySelectorAll("\\\f"), P.push("[\\r\\n\\f]")
            }), i(function(e) {
                e.innerHTML = "<a href='' disabled='disabled'></a><select disabled='disabled'><option/></select>";
                var t = q.createElement("input");
                t.setAttribute("type", "hidden"), e.appendChild(t).setAttribute("name", "D"), e.querySelectorAll("[name=d]").length && P.push("name" + ne + "*[*^$|!~]?="), 2 !== e.querySelectorAll(":enabled").length && P.push(":enabled", ":disabled"), L.appendChild(e).disabled = !0, 2 !== e.querySelectorAll(":disabled").length && P.push(":enabled", ":disabled"), e.querySelectorAll("*,:x"), P.push(",.*:")
            })), (b.matchesSelector = _e.test(O = L.matches || L.webkitMatchesSelector || L.mozMatchesSelector || L.oMatchesSelector || L.msMatchesSelector)) && i(function(e) {
                b.disconnectedMatch = O.call(e, "*"), O.call(e, "[s!='']:x"), R.push("!=", oe)
            }), P = P.length && new RegExp(P.join("|")), R = R.length && new RegExp(R.join("|")), t = _e.test(L.compareDocumentPosition), I = t || _e.test(L.contains) ? function(e, t) {
                var n = 9 === e.nodeType ? e.documentElement : e,
                    r = t && t.parentNode;
                return e === r || !(!r || 1 !== r.nodeType || !(n.contains ? n.contains(r) : e.compareDocumentPosition && 16 & e.compareDocumentPosition(r)))
            } : function(e, t) {
                if (t)
                    for (; t = t.parentNode;)
                        if (t === e) return !0;
                return !1
            }, X = t ? function(e, t) {
                if (e === t) return D = !0, 0;
                var n = !e.compareDocumentPosition - !t.compareDocumentPosition;
                return n ? n : (n = (e.ownerDocument || e) == (t.ownerDocument || t) ? e.compareDocumentPosition(t) : 1, 1 & n || !b.sortDetached && t.compareDocumentPosition(e) === n ? e == q || e.ownerDocument == F && I(F, e) ? -1 : t == q || t.ownerDocument == F && I(F, t) ? 1 : A ? ee(A, e) - ee(A, t) : 0 : 4 & n ? -1 : 1)
            } : function(e, t) {
                return 0
            }, q) : q
        }, t.matches = function(e, n) {
            return t(e, null, null, n)
        }, t.matchesSelector = function(e, n) {
            if (N(e), b.matchesSelector && H && !V[n + " "] && (!R || !R.test(n)) && (!P || !P.test(n))) try {
                var r = O.call(e, n);
                if (r || b.disconnectedMatch || e.document && 11 !== e.document.nodeType) return r
            } catch (i) {
                V(n, !0)
            }
            return t(n, q, null, [e]).length > 0
        }, t.contains = function(e, t) {
            return (e.ownerDocument || e) != q && N(e), I(e, t)
        }, t.attr = function(e, t) {
            (e.ownerDocument || e) != q && N(e);
            var n = x.attrHandle[t.toLowerCase()],
                r = n && G.call(x.attrHandle, t.toLowerCase()) ? n(e, t, !H) : void 0;
            return void 0 !== r ? r : b.attributes || !H ? e.getAttribute(t) : (r = e.getAttributeNode(t)) && r.specified ? r.value : null
        }, t.escape = function(e) {
            return (e + "").replace(xe, je)
        }, t.error = function(e) {
            throw new Error("Syntax error, unrecognized expression: " + e)
        }, t.uniqueSort = function(e) {
            var t, n = [],
                r = 0,
                i = 0;
            if (D = !b.detectDuplicates, A = !b.sortStable && e.slice(0), e.sort(X), D) {
                for (; t = e[i++];) t === e[i] && (r = n.push(i));
                for (; r--;) e.splice(n[r], 1)
            }
            return A = null, e
        }, j = t.getText = function(e) {
            var t, n = "",
                r = 0,
                i = e.nodeType;
            if (i) {
                if (1 === i || 9 === i || 11 === i) {
                    if ("string" == typeof e.textContent) return e.textContent;
                    for (e = e.firstChild; e; e = e.nextSibling) n += j(e)
                } else if (3 === i || 4 === i) return e.nodeValue
            } else
                for (; t = e[r++];) n += j(t);
            return n
        }, x = t.selectors = {
            cacheLength: 50,
            createPseudo: r,
            match: pe,
            attrHandle: {},
            find: {},
            relative: {
                ">": {
                    dir: "parentNode",
                    first: !0
                },
                " ": {
                    dir: "parentNode"
                },
                "+": {
                    dir: "previousSibling",
                    first: !0
                },
                "~": {
                    dir: "previousSibling"
                }
            },
            preFilter: {
                ATTR: function(e) {
                    return e[1] = e[1].replace(ye, be), e[3] = (e[3] || e[4] || e[5] || "").replace(ye, be), "~=" === e[2] && (e[3] = " " + e[3] + " "), e.slice(0, 4)
                },
                CHILD: function(e) {
                    return e[1] = e[1].toLowerCase(), "nth" === e[1].slice(0, 3) ? (e[3] || t.error(e[0]), e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * ("even" === e[3] || "odd" === e[3])), e[5] = +(e[7] + e[8] || "odd" === e[3])) : e[3] && t.error(e[0]), e
                },
                PSEUDO: function(e) {
                    var t, n = !e[6] && e[2];
                    return pe.CHILD.test(e[0]) ? null : (e[3] ? e[2] = e[4] || e[5] || "" : n && ce.test(n) && (t = C(n, !0)) && (t = n.indexOf(")", n.length - t) - n.length) && (e[0] = e[0].slice(0, t), e[2] = n.slice(0, t)), e.slice(0, 3))
                }
            },
            filter: {
                TAG: function(e) {
                    var t = e.replace(ye, be).toLowerCase();
                    return "*" === e ? function() {
                        return !0
                    } : function(e) {
                        return e.nodeName && e.nodeName.toLowerCase() === t
                    }
                },
                CLASS: function(e) {
                    var t = $[e + " "];
                    return t || (t = new RegExp("(^|" + ne + ")" + e + "(" + ne + "|$)")) && $(e, function(e) {
                        return t.test("string" == typeof e.className && e.className || "undefined" != typeof e.getAttribute && e.getAttribute("class") || "")
                    })
                },
                ATTR: function(e, n, r) {
                    return function(i) {
                        var o = t.attr(i, e);
                        return null == o ? "!=" === n : n ? (o += "", "=" === n ? o === r : "!=" === n ? o !== r : "^=" === n ? r && 0 === o.indexOf(r) : "*=" === n ? r && o.indexOf(r) > -1 : "$=" === n ? r && o.slice(-r.length) === r : "~=" === n ? (" " + o.replace(ae, " ") + " ").indexOf(r) > -1 : "|=" === n ? o === r || o.slice(0, r.length + 1) === r + "-" : !1) : !0
                    }
                },
                CHILD: function(e, t, n, r, i) {
                    var o = "nth" !== e.slice(0, 3),
                        a = "last" !== e.slice(-4),
                        s = "of-type" === t;
                    return 1 === r && 0 === i ? function(e) {
                        return !!e.parentNode
                    } : function(t, n, u) {
                        var l, d, c, f, p, g, h = o !== a ? "nextSibling" : "previousSibling",
                            m = t.parentNode,
                            _ = s && t.nodeName.toLowerCase(),
                            v = !u && !s,
                            w = !1;
                        if (m) {
                            if (o) {
                                for (; h;) {
                                    for (f = t; f = f[h];)
                                        if (s ? f.nodeName.toLowerCase() === _ : 1 === f.nodeType) return !1;
                                    g = h = "only" === e && !g && "nextSibling"
                                }
                                return !0
                            }
                            if (g = [a ? m.firstChild : m.lastChild], a && v) {
                                for (f = m, c = f[M] || (f[M] = {}), d = c[f.uniqueID] || (c[f.uniqueID] = {}), l = d[e] || [], p = l[0] === W && l[1], w = p && l[2], f = p && m.childNodes[p]; f = ++p && f && f[h] || (w = p = 0) || g.pop();)
                                    if (1 === f.nodeType && ++w && f === t) {
                                        d[e] = [W, p, w];
                                        break
                                    }
                            } else if (v && (f = t, c = f[M] || (f[M] = {}), d = c[f.uniqueID] || (c[f.uniqueID] = {}), l = d[e] || [], p = l[0] === W && l[1], w = p), w === !1)
                                for (;
                                    (f = ++p && f && f[h] || (w = p = 0) || g.pop()) && ((s ? f.nodeName.toLowerCase() !== _ : 1 !== f.nodeType) || !++w || (v && (c = f[M] || (f[M] = {}), d = c[f.uniqueID] || (c[f.uniqueID] = {}), d[e] = [W, w]), f !== t)););
                            return w -= i, w === r || w % r === 0 && w / r >= 0
                        }
                    }
                },
                PSEUDO: function(e, n) {
                    var i, o = x.pseudos[e] || x.setFilters[e.toLowerCase()] || t.error("unsupported pseudo: " + e);
                    return o[M] ? o(n) : o.length > 1 ? (i = [e, e, "", n], x.setFilters.hasOwnProperty(e.toLowerCase()) ? r(function(e, t) {
                        for (var r, i = o(e, n), a = i.length; a--;) r = ee(e, i[a]), e[r] = !(t[r] = i[a])
                    }) : function(e) {
                        return o(e, 0, i)
                    }) : o
                }
            },
            pseudos: {
                not: r(function(e) {
                    var t = [],
                        n = [],
                        i = S(e.replace(se, "$1"));
                    return i[M] ? r(function(e, t, n, r) {
                        for (var o, a = i(e, null, r, []), s = e.length; s--;)(o = a[s]) && (e[s] = !(t[s] = o))
                    }) : function(e, r, o) {
                        return t[0] = e, i(t, null, o, n), t[0] = null, !n.pop()
                    }
                }),
                has: r(function(e) {
                    return function(n) {
                        return t(e, n).length > 0
                    }
                }),
                contains: r(function(e) {
                    return e = e.replace(ye, be),
                        function(t) {
                            return (t.textContent || j(t)).indexOf(e) > -1
                        }
                }),
                lang: r(function(e) {
                    return fe.test(e || "") || t.error("unsupported lang: " + e), e = e.replace(ye, be).toLowerCase(),
                        function(t) {
                            var n;
                            do
                                if (n = H ? t.lang : t.getAttribute("xml:lang") || t.getAttribute("lang")) return n = n.toLowerCase(), n === e || 0 === n.indexOf(e + "-"); while ((t = t.parentNode) && 1 === t.nodeType);
                            return !1
                        }
                }),
                target: function(t) {
                    var n = e.location && e.location.hash;
                    return n && n.slice(1) === t.id
                },
                root: function(e) {
                    return e === L
                },
                focus: function(e) {
                    return e === q.activeElement && (!q.hasFocus || q.hasFocus()) && !!(e.type || e.href || ~e.tabIndex)
                },
                enabled: u(!1),
                disabled: u(!0),
                checked: function(e) {
                    var t = e.nodeName.toLowerCase();
                    return "input" === t && !!e.checked || "option" === t && !!e.selected
                },
                selected: function(e) {
                    return e.parentNode && e.parentNode.selectedIndex,
                        e.selected === !0
                },
                empty: function(e) {
                    for (e = e.firstChild; e; e = e.nextSibling)
                        if (e.nodeType < 6) return !1;
                    return !0
                },
                parent: function(e) {
                    return !x.pseudos.empty(e)
                },
                header: function(e) {
                    return me.test(e.nodeName)
                },
                input: function(e) {
                    return he.test(e.nodeName)
                },
                button: function(e) {
                    var t = e.nodeName.toLowerCase();
                    return "input" === t && "button" === e.type || "button" === t
                },
                text: function(e) {
                    var t;
                    return "input" === e.nodeName.toLowerCase() && "text" === e.type && (null == (t = e.getAttribute("type")) || "text" === t.toLowerCase())
                },
                first: l(function() {
                    return [0]
                }),
                last: l(function(e, t) {
                    return [t - 1]
                }),
                eq: l(function(e, t, n) {
                    return [0 > n ? n + t : n]
                }),
                even: l(function(e, t) {
                    for (var n = 0; t > n; n += 2) e.push(n);
                    return e
                }),
                odd: l(function(e, t) {
                    for (var n = 1; t > n; n += 2) e.push(n);
                    return e
                }),
                lt: l(function(e, t, n) {
                    for (var r = 0 > n ? n + t : n > t ? t : n; --r >= 0;) e.push(r);
                    return e
                }),
                gt: l(function(e, t, n) {
                    for (var r = 0 > n ? n + t : n; ++r < t;) e.push(r);
                    return e
                })
            }
        }, x.pseudos.nth = x.pseudos.eq;
        for (y in {
                radio: !0,
                checkbox: !0,
                file: !0,
                password: !0,
                image: !0
            }) x.pseudos[y] = a(y);
        for (y in {
                submit: !0,
                reset: !0
            }) x.pseudos[y] = s(y);
        return c.prototype = x.filters = x.pseudos, x.setFilters = new c, C = t.tokenize = function(e, n) {
            var r, i, o, a, s, u, l, d = z[e + " "];
            if (d) return n ? 0 : d.slice(0);
            for (s = e, u = [], l = x.preFilter; s;) {
                (!r || (i = ue.exec(s))) && (i && (s = s.slice(i[0].length) || s), u.push(o = [])), r = !1, (i = le.exec(s)) && (r = i.shift(), o.push({
                    value: r,
                    type: i[0].replace(se, " ")
                }), s = s.slice(r.length));
                for (a in x.filter) !(i = pe[a].exec(s)) || l[a] && !(i = l[a](i)) || (r = i.shift(), o.push({
                    value: r,
                    type: a,
                    matches: i
                }), s = s.slice(r.length));
                if (!r) break
            }
            return n ? s.length : s ? t.error(e) : z(e, u).slice(0)
        }, S = t.compile = function(e, t) {
            var n, r = [],
                i = [],
                o = U[e + " "];
            if (!o) {
                for (t || (t = C(e)), n = t.length; n--;) o = v(t[n]), o[M] ? r.push(o) : i.push(o);
                o = U(e, w(i, r)), o.selector = e
            }
            return o
        }, k = t.select = function(e, t, n, r) {
            var i, o, a, s, u, l = "function" == typeof e && e,
                c = !r && C(e = l.selector || e);
            if (n = n || [], 1 === c.length) {
                if (o = c[0] = c[0].slice(0), o.length > 2 && "ID" === (a = o[0]).type && 9 === t.nodeType && H && x.relative[o[1].type]) {
                    if (t = (x.find.ID(a.matches[0].replace(ye, be), t) || [])[0], !t) return n;
                    l && (t = t.parentNode), e = e.slice(o.shift().value.length)
                }
                for (i = pe.needsContext.test(e) ? 0 : o.length; i-- && (a = o[i], !x.relative[s = a.type]);)
                    if ((u = x.find[s]) && (r = u(a.matches[0].replace(ye, be), we.test(o[0].type) && d(t.parentNode) || t))) {
                        if (o.splice(i, 1), e = r.length && f(o), !e) return K.apply(n, r), n;
                        break
                    }
            }
            return (l || S(e, c))(r, t, !H, n, !t || we.test(e) && d(t.parentNode) || t), n
        }, b.sortStable = M.split("").sort(X).join("") === M, b.detectDuplicates = !!D, N(), b.sortDetached = i(function(e) {
            return 1 & e.compareDocumentPosition(q.createElement("fieldset"))
        }), i(function(e) {
            return e.innerHTML = "<a href='#'></a>", "#" === e.firstChild.getAttribute("href")
        }) || o("type|href|height|width", function(e, t, n) {
            return n ? void 0 : e.getAttribute(t, "type" === t.toLowerCase() ? 1 : 2)
        }), b.attributes && i(function(e) {
            return e.innerHTML = "<input/>", e.firstChild.setAttribute("value", ""), "" === e.firstChild.getAttribute("value")
        }) || o("value", function(e, t, n) {
            return n || "input" !== e.nodeName.toLowerCase() ? void 0 : e.defaultValue
        }), i(function(e) {
            return null == e.getAttribute("disabled")
        }) || o(te, function(e, t, n) {
            var r;
            return n ? void 0 : e[t] === !0 ? t.toLowerCase() : (r = e.getAttributeNode(t)) && r.specified ? r.value : null
        }), t
    }(e);
    je.find = Te, je.expr = Te.selectors, je.expr[":"] = je.expr.pseudos, je.uniqueSort = je.unique = Te.uniqueSort, je.text = Te.getText, je.isXMLDoc = Te.isXML, je.contains = Te.contains, je.escapeSelector = Te.escape;
    var Ce = function(e, t, n) {
            for (var r = [], i = void 0 !== n;
                (e = e[t]) && 9 !== e.nodeType;)
                if (1 === e.nodeType) {
                    if (i && je(e).is(n)) break;
                    r.push(e)
                }
            return r
        },
        Se = function(e, t) {
            for (var n = []; e; e = e.nextSibling) 1 === e.nodeType && e !== t && n.push(e);
            return n
        },
        ke = je.expr.match.needsContext,
        Ee = /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i;
    je.filter = function(e, t, n) {
        var r = t[0];
        return n && (e = ":not(" + e + ")"), 1 === t.length && 1 === r.nodeType ? je.find.matchesSelector(r, e) ? [r] : [] : je.find.matches(e, je.grep(t, function(e) {
            return 1 === e.nodeType
        }))
    }, je.fn.extend({
        find: function(e) {
            var t, n, r = this.length,
                i = this;
            if ("string" != typeof e) return this.pushStack(je(e).filter(function() {
                for (t = 0; r > t; t++)
                    if (je.contains(i[t], this)) return !0
            }));
            for (n = this.pushStack([]), t = 0; r > t; t++) je.find(e, i[t], n);
            return r > 1 ? je.uniqueSort(n) : n
        },
        filter: function(e) {
            return this.pushStack(a(this, e || [], !1))
        },
        not: function(e) {
            return this.pushStack(a(this, e || [], !0))
        },
        is: function(e) {
            return !!a(this, "string" == typeof e && ke.test(e) ? je(e) : e || [], !1).length
        }
    });
    var Ae, De = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/,
        Ne = je.fn.init = function(e, t, n) {
            var r, i;
            if (!e) return this;
            if (n = n || Ae, "string" == typeof e) {
                if (r = "<" === e[0] && ">" === e[e.length - 1] && e.length >= 3 ? [null, e, null] : De.exec(e), !r || !r[1] && t) return !t || t.jquery ? (t || n).find(e) : this.constructor(t).find(e);
                if (r[1]) {
                    if (t = t instanceof je ? t[0] : t, je.merge(this, je.parseHTML(r[1], t && t.nodeType ? t.ownerDocument || t : be, !0)), Ee.test(r[1]) && je.isPlainObject(t))
                        for (r in t) we(this[r]) ? this[r](t[r]) : this.attr(r, t[r]);
                    return this
                }
                return i = be.getElementById(r[2]), i && (this[0] = i, this.length = 1), this
            }
            return e.nodeType ? (this[0] = e, this.length = 1, this) : we(e) ? void 0 !== n.ready ? n.ready(e) : e(je) : je.makeArray(e, this)
        };
    Ne.prototype = je.fn, Ae = je(be);
    var qe = /^(?:parents|prev(?:Until|All))/,
        Le = {
            children: !0,
            contents: !0,
            next: !0,
            prev: !0
        };
    je.fn.extend({
        has: function(e) {
            var t = je(e, this),
                n = t.length;
            return this.filter(function() {
                for (var e = 0; n > e; e++)
                    if (je.contains(this, t[e])) return !0
            })
        },
        closest: function(e, t) {
            var n, r = 0,
                i = this.length,
                o = [],
                a = "string" != typeof e && je(e);
            if (!ke.test(e))
                for (; i > r; r++)
                    for (n = this[r]; n && n !== t; n = n.parentNode)
                        if (n.nodeType < 11 && (a ? a.index(n) > -1 : 1 === n.nodeType && je.find.matchesSelector(n, e))) {
                            o.push(n);
                            break
                        }
            return this.pushStack(o.length > 1 ? je.uniqueSort(o) : o)
        },
        index: function(e) {
            return e ? "string" == typeof e ? fe.call(je(e), this[0]) : fe.call(this, e.jquery ? e[0] : e) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
        },
        add: function(e, t) {
            return this.pushStack(je.uniqueSort(je.merge(this.get(), je(e, t))))
        },
        addBack: function(e) {
            return this.add(null == e ? this.prevObject : this.prevObject.filter(e))
        }
    }), je.each({
        parent: function(e) {
            var t = e.parentNode;
            return t && 11 !== t.nodeType ? t : null
        },
        parents: function(e) {
            return Ce(e, "parentNode")
        },
        parentsUntil: function(e, t, n) {
            return Ce(e, "parentNode", n)
        },
        next: function(e) {
            return s(e, "nextSibling")
        },
        prev: function(e) {
            return s(e, "previousSibling")
        },
        nextAll: function(e) {
            return Ce(e, "nextSibling")
        },
        prevAll: function(e) {
            return Ce(e, "previousSibling")
        },
        nextUntil: function(e, t, n) {
            return Ce(e, "nextSibling", n)
        },
        prevUntil: function(e, t, n) {
            return Ce(e, "previousSibling", n)
        },
        siblings: function(e) {
            return Se((e.parentNode || {}).firstChild, e)
        },
        children: function(e) {
            return Se(e.firstChild)
        },
        contents: function(e) {
            return null != e.contentDocument && ue(e.contentDocument) ? e.contentDocument : (o(e, "template") && (e = e.content || e), je.merge([], e.childNodes))
        }
    }, function(e, t) {
        je.fn[e] = function(n, r) {
            var i = je.map(this, t, n);
            return "Until" !== e.slice(-5) && (r = n), r && "string" == typeof r && (i = je.filter(r, i)), this.length > 1 && (Le[e] || je.uniqueSort(i), qe.test(e) && i.reverse()), this.pushStack(i)
        }
    });
    var He = /[^\x20\t\r\n\f]+/g;
    je.Callbacks = function(e) {
        e = "string" == typeof e ? u(e) : je.extend({}, e);
        var t, n, i, o, a = [],
            s = [],
            l = -1,
            d = function() {
                for (o = o || e.once, i = t = !0; s.length; l = -1)
                    for (n = s.shift(); ++l < a.length;) a[l].apply(n[0], n[1]) === !1 && e.stopOnFalse && (l = a.length, n = !1);
                e.memory || (n = !1), t = !1, o && (a = n ? [] : "")
            },
            c = {
                add: function() {
                    return a && (n && !t && (l = a.length - 1, s.push(n)), function i(t) {
                        je.each(t, function(t, n) {
                            we(n) ? e.unique && c.has(n) || a.push(n) : n && n.length && "string" !== r(n) && i(n)
                        })
                    }(arguments), n && !t && d()), this
                },
                remove: function() {
                    return je.each(arguments, function(e, t) {
                        for (var n;
                            (n = je.inArray(t, a, n)) > -1;) a.splice(n, 1), l >= n && l--
                    }), this
                },
                has: function(e) {
                    return e ? je.inArray(e, a) > -1 : a.length > 0
                },
                empty: function() {
                    return a && (a = []), this
                },
                disable: function() {
                    return o = s = [], a = n = "", this
                },
                disabled: function() {
                    return !a
                },
                lock: function() {
                    return o = s = [], n || t || (a = n = ""), this
                },
                locked: function() {
                    return !!o
                },
                fireWith: function(e, n) {
                    return o || (n = n || [], n = [e, n.slice ? n.slice() : n], s.push(n), t || d()), this
                },
                fire: function() {
                    return c.fireWith(this, arguments), this
                },
                fired: function() {
                    return !!i
                }
            };
        return c
    }, je.extend({
        Deferred: function(t) {
            var n = [
                    ["notify", "progress", je.Callbacks("memory"), je.Callbacks("memory"), 2],
                    ["resolve", "done", je.Callbacks("once memory"), je.Callbacks("once memory"), 0, "resolved"],
                    ["reject", "fail", je.Callbacks("once memory"), je.Callbacks("once memory"), 1, "rejected"]
                ],
                r = "pending",
                i = {
                    state: function() {
                        return r
                    },
                    always: function() {
                        return o.done(arguments).fail(arguments), this
                    },
                    "catch": function(e) {
                        return i.then(null, e)
                    },
                    pipe: function() {
                        var e = arguments;
                        return je.Deferred(function(t) {
                            je.each(n, function(n, r) {
                                var i = we(e[r[4]]) && e[r[4]];
                                o[r[1]](function() {
                                    var e = i && i.apply(this, arguments);
                                    e && we(e.promise) ? e.promise().progress(t.notify).done(t.resolve).fail(t.reject) : t[r[0] + "With"](this, i ? [e] : arguments)
                                })
                            }), e = null
                        }).promise()
                    },
                    then: function(t, r, i) {
                        function o(t, n, r, i) {
                            return function() {
                                var s = this,
                                    u = arguments,
                                    c = function() {
                                        var e, c;
                                        if (!(a > t)) {
                                            if (e = r.apply(s, u), e === n.promise()) throw new TypeError("Thenable self-resolution");
                                            c = e && ("object" == typeof e || "function" == typeof e) && e.then, we(c) ? i ? c.call(e, o(a, n, l, i), o(a, n, d, i)) : (a++, c.call(e, o(a, n, l, i), o(a, n, d, i), o(a, n, l, n.notifyWith))) : (r !== l && (s = void 0, u = [e]), (i || n.resolveWith)(s, u))
                                        }
                                    },
                                    f = i ? c : function() {
                                        try {
                                            c()
                                        } catch (e) {
                                            je.Deferred.exceptionHook && je.Deferred.exceptionHook(e, f.stackTrace), t + 1 >= a && (r !== d && (s = void 0, u = [e]), n.rejectWith(s, u))
                                        }
                                    };
                                t ? f() : (je.Deferred.getStackHook && (f.stackTrace = je.Deferred.getStackHook()), e.setTimeout(f))
                            }
                        }
                        var a = 0;
                        return je.Deferred(function(e) {
                            n[0][3].add(o(0, e, we(i) ? i : l, e.notifyWith)), n[1][3].add(o(0, e, we(t) ? t : l)), n[2][3].add(o(0, e, we(r) ? r : d))
                        }).promise()
                    },
                    promise: function(e) {
                        return null != e ? je.extend(e, i) : i
                    }
                },
                o = {};
            return je.each(n, function(e, t) {
                var a = t[2],
                    s = t[5];
                i[t[1]] = a.add, s && a.add(function() {
                    r = s
                }, n[3 - e][2].disable, n[3 - e][3].disable, n[0][2].lock, n[0][3].lock), a.add(t[3].fire), o[t[0]] = function() {
                    return o[t[0] + "With"](this === o ? void 0 : this, arguments), this
                }, o[t[0] + "With"] = a.fireWith
            }), i.promise(o), t && t.call(o, o), o
        },
        when: function(e) {
            var t = arguments.length,
                n = t,
                r = Array(n),
                i = le.call(arguments),
                o = je.Deferred(),
                a = function(e) {
                    return function(n) {
                        r[e] = this, i[e] = arguments.length > 1 ? le.call(arguments) : n, --t || o.resolveWith(r, i)
                    }
                };
            if (1 >= t && (c(e, o.done(a(n)).resolve, o.reject, !t), "pending" === o.state() || we(i[n] && i[n].then))) return o.then();
            for (; n--;) c(i[n], a(n), o.reject);
            return o.promise()
        }
    });
    var Pe = /^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/;
    je.Deferred.exceptionHook = function(t, n) {
        e.console && e.console.warn && t && Pe.test(t.name) && e.console.warn("jQuery.Deferred exception: " + t.message, t.stack, n)
    }, je.readyException = function(t) {
        e.setTimeout(function() {
            throw t
        })
    };
    var Re = je.Deferred();
    je.fn.ready = function(e) {
        return Re.then(e)["catch"](function(e) {
            je.readyException(e)
        }), this
    }, je.extend({
        isReady: !1,
        readyWait: 1,
        ready: function(e) {
            (e === !0 ? --je.readyWait : je.isReady) || (je.isReady = !0, e !== !0 && --je.readyWait > 0 || Re.resolveWith(be, [je]))
        }
    }), je.ready.then = Re.then, "complete" === be.readyState || "loading" !== be.readyState && !be.documentElement.doScroll ? e.setTimeout(je.ready) : (be.addEventListener("DOMContentLoaded", f), e.addEventListener("load", f));
    var Oe = function(e, t, n, i, o, a, s) {
            var u = 0,
                l = e.length,
                d = null == n;
            if ("object" === r(n)) {
                o = !0;
                for (u in n) Oe(e, t, u, n[u], !0, a, s)
            } else if (void 0 !== i && (o = !0, we(i) || (s = !0), d && (s ? (t.call(e, i), t = null) : (d = t, t = function(e, t, n) {
                    return d.call(je(e), n)
                })), t))
                for (; l > u; u++) t(e[u], n, s ? i : i.call(e[u], u, t(e[u], n)));
            return o ? e : d ? t.call(e) : l ? t(e[0], n) : a
        },
        Ie = /^-ms-/,
        Me = /-([a-z])/g,
        Fe = function(e) {
            return 1 === e.nodeType || 9 === e.nodeType || !+e.nodeType
        };
    h.uid = 1, h.prototype = {
        cache: function(e) {
            var t = e[this.expando];
            return t || (t = {}, Fe(e) && (e.nodeType ? e[this.expando] = t : Object.defineProperty(e, this.expando, {
                value: t,
                configurable: !0
            }))), t
        },
        set: function(e, t, n) {
            var r, i = this.cache(e);
            if ("string" == typeof t) i[g(t)] = n;
            else
                for (r in t) i[g(r)] = t[r];
            return i
        },
        get: function(e, t) {
            return void 0 === t ? this.cache(e) : e[this.expando] && e[this.expando][g(t)]
        },
        access: function(e, t, n) {
            return void 0 === t || t && "string" == typeof t && void 0 === n ? this.get(e, t) : (this.set(e, t, n), void 0 !== n ? n : t)
        },
        remove: function(e, t) {
            var n, r = e[this.expando];
            if (void 0 !== r) {
                if (void 0 !== t) {
                    Array.isArray(t) ? t = t.map(g) : (t = g(t), t = t in r ? [t] : t.match(He) || []), n = t.length;
                    for (; n--;) delete r[t[n]]
                }(void 0 === t || je.isEmptyObject(r)) && (e.nodeType ? e[this.expando] = void 0 : delete e[this.expando])
            }
        },
        hasData: function(e) {
            var t = e[this.expando];
            return void 0 !== t && !je.isEmptyObject(t)
        }
    };
    var We = new h,
        Be = new h,
        $e = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
        ze = /[A-Z]/g;
    je.extend({
        hasData: function(e) {
            return Be.hasData(e) || We.hasData(e)
        },
        data: function(e, t, n) {
            return Be.access(e, t, n)
        },
        removeData: function(e, t) {
            Be.remove(e, t)
        },
        _data: function(e, t, n) {
            return We.access(e, t, n)
        },
        _removeData: function(e, t) {
            We.remove(e, t)
        }
    }), je.fn.extend({
        data: function(e, t) {
            var n, r, i, o = this[0],
                a = o && o.attributes;
            if (void 0 === e) {
                if (this.length && (i = Be.get(o), 1 === o.nodeType && !We.get(o, "hasDataAttrs"))) {
                    for (n = a.length; n--;) a[n] && (r = a[n].name, 0 === r.indexOf("data-") && (r = g(r.slice(5)), _(o, r, i[r])));
                    We.set(o, "hasDataAttrs", !0)
                }
                return i
            }
            return "object" == typeof e ? this.each(function() {
                Be.set(this, e)
            }) : Oe(this, function(t) {
                var n;
                if (o && void 0 === t) {
                    if (n = Be.get(o, e), void 0 !== n) return n;
                    if (n = _(o, e), void 0 !== n) return n
                } else this.each(function() {
                    Be.set(this, e, t)
                })
            }, null, t, arguments.length > 1, null, !0)
        },
        removeData: function(e) {
            return this.each(function() {
                Be.remove(this, e)
            })
        }
    }), je.extend({
        queue: function(e, t, n) {
            var r;
            return e ? (t = (t || "fx") + "queue", r = We.get(e, t), n && (!r || Array.isArray(n) ? r = We.access(e, t, je.makeArray(n)) : r.push(n)), r || []) : void 0
        },
        dequeue: function(e, t) {
            t = t || "fx";
            var n = je.queue(e, t),
                r = n.length,
                i = n.shift(),
                o = je._queueHooks(e, t),
                a = function() {
                    je.dequeue(e, t)
                };
            "inprogress" === i && (i = n.shift(), r--), i && ("fx" === t && n.unshift("inprogress"), delete o.stop, i.call(e, a, o)), !r && o && o.empty.fire()
        },
        _queueHooks: function(e, t) {
            var n = t + "queueHooks";
            return We.get(e, n) || We.access(e, n, {
                empty: je.Callbacks("once memory").add(function() {
                    We.remove(e, [t + "queue", n])
                })
            })
        }
    }), je.fn.extend({
        queue: function(e, t) {
            var n = 2;
            return "string" != typeof e && (t = e, e = "fx", n--), arguments.length < n ? je.queue(this[0], e) : void 0 === t ? this : this.each(function() {
                var n = je.queue(this, e, t);
                je._queueHooks(this, e), "fx" === e && "inprogress" !== n[0] && je.dequeue(this, e)
            })
        },
        dequeue: function(e) {
            return this.each(function() {
                je.dequeue(this, e)
            })
        },
        clearQueue: function(e) {
            return this.queue(e || "fx", [])
        },
        promise: function(e, t) {
            var n, r = 1,
                i = je.Deferred(),
                o = this,
                a = this.length,
                s = function() {
                    --r || i.resolveWith(o, [o])
                };
            for ("string" != typeof e && (t = e, e = void 0), e = e || "fx"; a--;) n = We.get(o[a], e + "queueHooks"), n && n.empty && (r++, n.empty.add(s));
            return s(), i.promise(t)
        }
    });
    var Ue = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
        Ve = new RegExp("^(?:([+-])=|)(" + Ue + ")([a-z%]*)$", "i"),
        Xe = ["Top", "Right", "Bottom", "Left"],
        Ge = be.documentElement,
        Je = function(e) {
            return je.contains(e.ownerDocument, e)
        },
        Qe = {
            composed: !0
        };
    Ge.getRootNode && (Je = function(e) {
        return je.contains(e.ownerDocument, e) || e.getRootNode(Qe) === e.ownerDocument
    });
    var Ye = function(e, t) {
            return e = t || e, "none" === e.style.display || "" === e.style.display && Je(e) && "none" === je.css(e, "display")
        },
        Ke = {};
    je.fn.extend({
        show: function() {
            return y(this, !0)
        },
        hide: function() {
            return y(this)
        },
        toggle: function(e) {
            return "boolean" == typeof e ? e ? this.show() : this.hide() : this.each(function() {
                Ye(this) ? je(this).show() : je(this).hide()
            })
        }
    });
    var Ze = /^(?:checkbox|radio)$/i,
        et = /<([a-z][^\/\0>\x20\t\r\n\f]*)/i,
        tt = /^$|^module$|\/(?:java|ecma)script/i;
    ! function() {
        var e = be.createDocumentFragment(),
            t = e.appendChild(be.createElement("div")),
            n = be.createElement("input");
        n.setAttribute("type", "radio"), n.setAttribute("checked", "checked"), n.setAttribute("name", "t"), t.appendChild(n), ve.checkClone = t.cloneNode(!0).cloneNode(!0).lastChild.checked, t.innerHTML = "<textarea>x</textarea>", ve.noCloneChecked = !!t.cloneNode(!0).lastChild.defaultValue, t.innerHTML = "<option></option>", ve.option = !!t.lastChild
    }();
    var nt = {
        thead: [1, "<table>", "</table>"],
        col: [2, "<table><colgroup>", "</colgroup></table>"],
        tr: [2, "<table><tbody>", "</tbody></table>"],
        td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
        _default: [0, "", ""]
    };
    nt.tbody = nt.tfoot = nt.colgroup = nt.caption = nt.thead, nt.th = nt.td, ve.option || (nt.optgroup = nt.option = [1, "<select multiple='multiple'>", "</select>"]);
    var rt = /<|&#?\w+;/,
        it = /^([^.]*)(?:\.(.+)|)/;
    je.event = {
        global: {},
        add: function(e, t, n, r, i) {
            var o, a, s, u, l, d, c, f, p, g, h, m = We.get(e);
            if (Fe(e))
                for (n.handler && (o = n, n = o.handler, i = o.selector), i && je.find.matchesSelector(Ge, i), n.guid || (n.guid = je.guid++), (u = m.events) || (u = m.events = Object.create(null)), (a = m.handle) || (a = m.handle = function(t) {
                        return "undefined" != typeof je && je.event.triggered !== t.type ? je.event.dispatch.apply(e, arguments) : void 0
                    }), t = (t || "").match(He) || [""], l = t.length; l--;) s = it.exec(t[l]) || [], p = h = s[1], g = (s[2] || "").split(".").sort(), p && (c = je.event.special[p] || {}, p = (i ? c.delegateType : c.bindType) || p, c = je.event.special[p] || {}, d = je.extend({
                    type: p,
                    origType: h,
                    data: r,
                    handler: n,
                    guid: n.guid,
                    selector: i,
                    needsContext: i && je.expr.match.needsContext.test(i),
                    namespace: g.join(".")
                }, o), (f = u[p]) || (f = u[p] = [], f.delegateCount = 0, c.setup && c.setup.call(e, r, g, a) !== !1 || e.addEventListener && e.addEventListener(p, a)), c.add && (c.add.call(e, d), d.handler.guid || (d.handler.guid = n.guid)), i ? f.splice(f.delegateCount++, 0, d) : f.push(d), je.event.global[p] = !0)
        },
        remove: function(e, t, n, r, i) {
            var o, a, s, u, l, d, c, f, p, g, h, m = We.hasData(e) && We.get(e);
            if (m && (u = m.events)) {
                for (t = (t || "").match(He) || [""], l = t.length; l--;)
                    if (s = it.exec(t[l]) || [], p = h = s[1], g = (s[2] || "").split(".").sort(), p) {
                        for (c = je.event.special[p] || {}, p = (r ? c.delegateType : c.bindType) || p, f = u[p] || [], s = s[2] && new RegExp("(^|\\.)" + g.join("\\.(?:.*\\.|)") + "(\\.|$)"), a = o = f.length; o--;) d = f[o], !i && h !== d.origType || n && n.guid !== d.guid || s && !s.test(d.namespace) || r && r !== d.selector && ("**" !== r || !d.selector) || (f.splice(o, 1), d.selector && f.delegateCount--, c.remove && c.remove.call(e, d));
                        a && !f.length && (c.teardown && c.teardown.call(e, g, m.handle) !== !1 || je.removeEvent(e, p, m.handle), delete u[p])
                    } else
                        for (p in u) je.event.remove(e, p + t[l], n, r, !0);
                je.isEmptyObject(u) && We.remove(e, "handle events")
            }
        },
        dispatch: function(e) {
            var t, n, r, i, o, a, s = new Array(arguments.length),
                u = je.event.fix(e),
                l = (We.get(this, "events") || Object.create(null))[u.type] || [],
                d = je.event.special[u.type] || {};
            for (s[0] = u, t = 1; t < arguments.length; t++) s[t] = arguments[t];
            if (u.delegateTarget = this, !d.preDispatch || d.preDispatch.call(this, u) !== !1) {
                for (a = je.event.handlers.call(this, u, l), t = 0;
                    (i = a[t++]) && !u.isPropagationStopped();)
                    for (u.currentTarget = i.elem, n = 0;
                        (o = i.handlers[n++]) && !u.isImmediatePropagationStopped();)(!u.rnamespace || o.namespace === !1 || u.rnamespace.test(o.namespace)) && (u.handleObj = o, u.data = o.data, r = ((je.event.special[o.origType] || {}).handle || o.handler).apply(i.elem, s), void 0 !== r && (u.result = r) === !1 && (u.preventDefault(), u.stopPropagation()));
                return d.postDispatch && d.postDispatch.call(this, u), u.result
            }
        },
        handlers: function(e, t) {
            var n, r, i, o, a, s = [],
                u = t.delegateCount,
                l = e.target;
            if (u && l.nodeType && !("click" === e.type && e.button >= 1))
                for (; l !== this; l = l.parentNode || this)
                    if (1 === l.nodeType && ("click" !== e.type || l.disabled !== !0)) {
                        for (o = [], a = {}, n = 0; u > n; n++) r = t[n], i = r.selector + " ", void 0 === a[i] && (a[i] = r.needsContext ? je(i, this).index(l) > -1 : je.find(i, this, null, [l]).length), a[i] && o.push(r);
                        o.length && s.push({
                            elem: l,
                            handlers: o
                        })
                    }
            return l = this, u < t.length && s.push({
                elem: l,
                handlers: t.slice(u)
            }), s
        },
        addProp: function(e, t) {
            Object.defineProperty(je.Event.prototype, e, {
                enumerable: !0,
                configurable: !0,
                get: we(t) ? function() {
                    return this.originalEvent ? t(this.originalEvent) : void 0
                } : function() {
                    return this.originalEvent ? this.originalEvent[e] : void 0
                },
                set: function(t) {
                    Object.defineProperty(this, e, {
                        enumerable: !0,
                        configurable: !0,
                        writable: !0,
                        value: t
                    })
                }
            })
        },
        fix: function(e) {
            return e[je.expando] ? e : new je.Event(e)
        },
        special: {
            load: {
                noBubble: !0
            },
            click: {
                setup: function(e) {
                    var t = this || e;
                    return Ze.test(t.type) && t.click && o(t, "input") && A(t, "click", T), !1
                },
                trigger: function(e) {
                    var t = this || e;
                    return Ze.test(t.type) && t.click && o(t, "input") && A(t, "click"), !0
                },
                _default: function(e) {
                    var t = e.target;
                    return Ze.test(t.type) && t.click && o(t, "input") && We.get(t, "click") || o(t, "a")
                }
            },
            beforeunload: {
                postDispatch: function(e) {
                    void 0 !== e.result && e.originalEvent && (e.originalEvent.returnValue = e.result)
                }
            }
        }
    }, je.removeEvent = function(e, t, n) {
        e.removeEventListener && e.removeEventListener(t, n)
    }, je.Event = function(e, t) {
        return this instanceof je.Event ? (e && e.type ? (this.originalEvent = e, this.type = e.type, this.isDefaultPrevented = e.defaultPrevented || void 0 === e.defaultPrevented && e.returnValue === !1 ? T : C, this.target = e.target && 3 === e.target.nodeType ? e.target.parentNode : e.target, this.currentTarget = e.currentTarget, this.relatedTarget = e.relatedTarget) : this.type = e, t && je.extend(this, t), this.timeStamp = e && e.timeStamp || Date.now(), void(this[je.expando] = !0)) : new je.Event(e, t)
    }, je.Event.prototype = {
        constructor: je.Event,
        isDefaultPrevented: C,
        isPropagationStopped: C,
        isImmediatePropagationStopped: C,
        isSimulated: !1,
        preventDefault: function() {
            var e = this.originalEvent;
            this.isDefaultPrevented = T, e && !this.isSimulated && e.preventDefault()
        },
        stopPropagation: function() {
            var e = this.originalEvent;
            this.isPropagationStopped = T, e && !this.isSimulated && e.stopPropagation()
        },
        stopImmediatePropagation: function() {
            var e = this.originalEvent;
            this.isImmediatePropagationStopped = T, e && !this.isSimulated && e.stopImmediatePropagation(), this.stopPropagation()
        }
    }, je.each({
        altKey: !0,
        bubbles: !0,
        cancelable: !0,
        changedTouches: !0,
        ctrlKey: !0,
        detail: !0,
        eventPhase: !0,
        metaKey: !0,
        pageX: !0,
        pageY: !0,
        shiftKey: !0,
        view: !0,
        "char": !0,
        code: !0,
        charCode: !0,
        key: !0,
        keyCode: !0,
        button: !0,
        buttons: !0,
        clientX: !0,
        clientY: !0,
        offsetX: !0,
        offsetY: !0,
        pointerId: !0,
        pointerType: !0,
        screenX: !0,
        screenY: !0,
        targetTouches: !0,
        toElement: !0,
        touches: !0,
        which: !0
    }, je.event.addProp), je.each({
        focus: "focusin",
        blur: "focusout"
    }, function(e, t) {
        je.event.special[e] = {
            setup: function() {
                return A(this, e, S), !1
            },
            trigger: function() {
                return A(this, e), !0
            },
            _default: function() {
                return !0
            },
            delegateType: t
        }
    }), je.each({
        mouseenter: "mouseover",
        mouseleave: "mouseout",
        pointerenter: "pointerover",
        pointerleave: "pointerout"
    }, function(e, t) {
        je.event.special[e] = {
            delegateType: t,
            bindType: t,
            handle: function(e) {
                var n, r = this,
                    i = e.relatedTarget,
                    o = e.handleObj;
                return (!i || i !== r && !je.contains(r, i)) && (e.type = o.origType, n = o.handler.apply(this, arguments), e.type = t), n
            }
        }
    }), je.fn.extend({
        on: function(e, t, n, r) {
            return E(this, e, t, n, r)
        },
        one: function(e, t, n, r) {
            return E(this, e, t, n, r, 1)
        },
        off: function(e, t, n) {
            var r, i;
            if (e && e.preventDefault && e.handleObj) return r = e.handleObj, je(e.delegateTarget).off(r.namespace ? r.origType + "." + r.namespace : r.origType, r.selector, r.handler), this;
            if ("object" == typeof e) {
                for (i in e) this.off(i, t, e[i]);
                return this
            }
            return (t === !1 || "function" == typeof t) && (n = t, t = void 0), n === !1 && (n = C), this.each(function() {
                je.event.remove(this, e, n, t)
            })
        }
    });
    var ot = /<script|<style|<link/i,
        at = /checked\s*(?:[^=]|=\s*.checked.)/i,
        st = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g;
    je.extend({
        htmlPrefilter: function(e) {
            return e
        },
        clone: function(e, t, n) {
            var r, i, o, a, s = e.cloneNode(!0),
                u = Je(e);
            if (!(ve.noCloneChecked || 1 !== e.nodeType && 11 !== e.nodeType || je.isXMLDoc(e)))
                for (a = b(s), o = b(e), r = 0, i = o.length; i > r; r++) H(o[r], a[r]);
            if (t)
                if (n)
                    for (o = o || b(e), a = a || b(s), r = 0, i = o.length; i > r; r++) L(o[r], a[r]);
                else L(e, s);
            return a = b(s, "script"), a.length > 0 && x(a, !u && b(e, "script")), s
        },
        cleanData: function(e) {
            for (var t, n, r, i = je.event.special, o = 0; void 0 !== (n = e[o]); o++)
                if (Fe(n)) {
                    if (t = n[We.expando]) {
                        if (t.events)
                            for (r in t.events) i[r] ? je.event.remove(n, r) : je.removeEvent(n, r, t.handle);
                        n[We.expando] = void 0
                    }
                    n[Be.expando] && (n[Be.expando] = void 0)
                }
        }
    }), je.fn.extend({
        detach: function(e) {
            return R(this, e, !0)
        },
        remove: function(e) {
            return R(this, e)
        },
        text: function(e) {
            return Oe(this, function(e) {
                return void 0 === e ? je.text(this) : this.empty().each(function() {
                    (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) && (this.textContent = e)
                })
            }, null, e, arguments.length)
        },
        append: function() {
            return P(this, arguments, function(e) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var t = D(this, e);
                    t.appendChild(e)
                }
            })
        },
        prepend: function() {
            return P(this, arguments, function(e) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var t = D(this, e);
                    t.insertBefore(e, t.firstChild)
                }
            })
        },
        before: function() {
            return P(this, arguments, function(e) {
                this.parentNode && this.parentNode.insertBefore(e, this)
            })
        },
        after: function() {
            return P(this, arguments, function(e) {
                this.parentNode && this.parentNode.insertBefore(e, this.nextSibling)
            })
        },
        empty: function() {
            for (var e, t = 0; null != (e = this[t]); t++) 1 === e.nodeType && (je.cleanData(b(e, !1)), e.textContent = "");
            return this
        },
        clone: function(e, t) {
            return e = null == e ? !1 : e, t = null == t ? e : t, this.map(function() {
                return je.clone(this, e, t)
            })
        },
        html: function(e) {
            return Oe(this, function(e) {
                var t = this[0] || {},
                    n = 0,
                    r = this.length;
                if (void 0 === e && 1 === t.nodeType) return t.innerHTML;
                if ("string" == typeof e && !ot.test(e) && !nt[(et.exec(e) || ["", ""])[1].toLowerCase()]) {
                    e = je.htmlPrefilter(e);
                    try {
                        for (; r > n; n++) t = this[n] || {}, 1 === t.nodeType && (je.cleanData(b(t, !1)), t.innerHTML = e);
                        t = 0
                    } catch (i) {}
                }
                t && this.empty().append(e)
            }, null, e, arguments.length)
        },
        replaceWith: function() {
            var e = [];
            return P(this, arguments, function(t) {
                var n = this.parentNode;
                je.inArray(this, e) < 0 && (je.cleanData(b(this)), n && n.replaceChild(t, this))
            }, e)
        }
    }), je.each({
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith"
    }, function(e, t) {
        je.fn[e] = function(e) {
            for (var n, r = [], i = je(e), o = i.length - 1, a = 0; o >= a; a++) n = a === o ? this : this.clone(!0), je(i[a])[t](n), ce.apply(r, n.get());
            return this.pushStack(r)
        }
    });
    var ut = new RegExp("^(" + Ue + ")(?!px)[a-z%]+$", "i"),
        lt = function(t) {
            var n = t.ownerDocument.defaultView;
            return n && n.opener || (n = e), n.getComputedStyle(t)
        },
        dt = function(e, t, n) {
            var r, i, o = {};
            for (i in t) o[i] = e.style[i], e.style[i] = t[i];
            r = n.call(e);
            for (i in t) e.style[i] = o[i];
            return r
        },
        ct = new RegExp(Xe.join("|"), "i");
    ! function() {
        function t() {
            if (d) {
                l.style.cssText = "position:absolute;left:-11111px;width:60px;margin-top:1px;padding:0;border:0", d.style.cssText = "position:relative;display:block;box-sizing:border-box;overflow:scroll;margin:auto;border:1px;padding:1px;width:60%;top:1%", Ge.appendChild(l).appendChild(d);
                var t = e.getComputedStyle(d);
                r = "1%" !== t.top, u = 12 === n(t.marginLeft), d.style.right = "60%", a = 36 === n(t.right), i = 36 === n(t.width), d.style.position = "absolute", o = 12 === n(d.offsetWidth / 3), Ge.removeChild(l), d = null
            }
        }

        function n(e) {
            return Math.round(parseFloat(e))
        }
        var r, i, o, a, s, u, l = be.createElement("div"),
            d = be.createElement("div");
        d.style && (d.style.backgroundClip = "content-box", d.cloneNode(!0).style.backgroundClip = "", ve.clearCloneStyle = "content-box" === d.style.backgroundClip, je.extend(ve, {
            boxSizingReliable: function() {
                return t(), i
            },
            pixelBoxStyles: function() {
                return t(), a
            },
            pixelPosition: function() {
                return t(), r
            },
            reliableMarginLeft: function() {
                return t(), u
            },
            scrollboxSize: function() {
                return t(), o
            },
            reliableTrDimensions: function() {
                var t, n, r, i;
                return null == s && (t = be.createElement("table"), n = be.createElement("tr"), r = be.createElement("div"), t.style.cssText = "position:absolute;left:-11111px;border-collapse:separate", n.style.cssText = "border:1px solid", n.style.height = "1px", r.style.height = "9px", r.style.display = "block", Ge.appendChild(t).appendChild(n).appendChild(r), i = e.getComputedStyle(n), s = parseInt(i.height, 10) + parseInt(i.borderTopWidth, 10) + parseInt(i.borderBottomWidth, 10) === n.offsetHeight, Ge.removeChild(t)), s
            }
        }))
    }();
    var ft = ["Webkit", "Moz", "ms"],
        pt = be.createElement("div").style,
        gt = {},
        ht = /^(none|table(?!-c[ea]).+)/,
        mt = /^--/,
        _t = {
            position: "absolute",
            visibility: "hidden",
            display: "block"
        },
        vt = {
            letterSpacing: "0",
            fontWeight: "400"
        };
    je.extend({
        cssHooks: {
            opacity: {
                get: function(e, t) {
                    if (t) {
                        var n = O(e, "opacity");
                        return "" === n ? "1" : n
                    }
                }
            }
        },
        cssNumber: {
            animationIterationCount: !0,
            columnCount: !0,
            fillOpacity: !0,
            flexGrow: !0,
            flexShrink: !0,
            fontWeight: !0,
            gridArea: !0,
            gridColumn: !0,
            gridColumnEnd: !0,
            gridColumnStart: !0,
            gridRow: !0,
            gridRowEnd: !0,
            gridRowStart: !0,
            lineHeight: !0,
            opacity: !0,
            order: !0,
            orphans: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0
        },
        cssProps: {},
        style: function(e, t, n, r) {
            if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) {
                var i, o, a, s = g(t),
                    u = mt.test(t),
                    l = e.style;
                return u || (t = F(s)), a = je.cssHooks[t] || je.cssHooks[s], void 0 === n ? a && "get" in a && void 0 !== (i = a.get(e, !1, r)) ? i : l[t] : (o = typeof n, "string" === o && (i = Ve.exec(n)) && i[1] && (n = v(e, t, i), o = "number"), null != n && n === n && ("number" !== o || u || (n += i && i[3] || (je.cssNumber[s] ? "" : "px")), ve.clearCloneStyle || "" !== n || 0 !== t.indexOf("background") || (l[t] = "inherit"), a && "set" in a && void 0 === (n = a.set(e, n, r)) || (u ? l.setProperty(t, n) : l[t] = n)), void 0)
            }
        },
        css: function(e, t, n, r) {
            var i, o, a, s = g(t),
                u = mt.test(t);
            return u || (t = F(s)), a = je.cssHooks[t] || je.cssHooks[s], a && "get" in a && (i = a.get(e, !0, n)), void 0 === i && (i = O(e, t, r)), "normal" === i && t in vt && (i = vt[t]), "" === n || n ? (o = parseFloat(i), n === !0 || isFinite(o) ? o || 0 : i) : i
        }
    }), je.each(["height", "width"], function(e, t) {
        je.cssHooks[t] = {
            get: function(e, n, r) {
                return n ? !ht.test(je.css(e, "display")) || e.getClientRects().length && e.getBoundingClientRect().width ? $(e, t, r) : dt(e, _t, function() {
                    return $(e, t, r)
                }) : void 0
            },
            set: function(e, n, r) {
                var i, o = lt(e),
                    a = !ve.scrollboxSize() && "absolute" === o.position,
                    s = a || r,
                    u = s && "border-box" === je.css(e, "boxSizing", !1, o),
                    l = r ? B(e, t, r, u, o) : 0;
                return u && a && (l -= Math.ceil(e["offset" + t[0].toUpperCase() + t.slice(1)] - parseFloat(o[t]) - B(e, t, "border", !1, o) - .5)), l && (i = Ve.exec(n)) && "px" !== (i[3] || "px") && (e.style[t] = n, n = je.css(e, t)), W(e, n, l)
            }
        }
    }), je.cssHooks.marginLeft = I(ve.reliableMarginLeft, function(e, t) {
        return t ? (parseFloat(O(e, "marginLeft")) || e.getBoundingClientRect().left - dt(e, {
            marginLeft: 0
        }, function() {
            return e.getBoundingClientRect().left
        })) + "px" : void 0
    }), je.each({
        margin: "",
        padding: "",
        border: "Width"
    }, function(e, t) {
        je.cssHooks[e + t] = {
            expand: function(n) {
                for (var r = 0, i = {}, o = "string" == typeof n ? n.split(" ") : [n]; 4 > r; r++) i[e + Xe[r] + t] = o[r] || o[r - 2] || o[0];
                return i
            }
        }, "margin" !== e && (je.cssHooks[e + t].set = W)
    }), je.fn.extend({
        css: function(e, t) {
            return Oe(this, function(e, t, n) {
                var r, i, o = {},
                    a = 0;
                if (Array.isArray(t)) {
                    for (r = lt(e), i = t.length; i > a; a++) o[t[a]] = je.css(e, t[a], !1, r);
                    return o
                }
                return void 0 !== n ? je.style(e, t, n) : je.css(e, t)
            }, e, t, arguments.length > 1)
        }
    }), je.Tween = z, z.prototype = {
        constructor: z,
        init: function(e, t, n, r, i, o) {
            this.elem = e, this.prop = n, this.easing = i || je.easing._default, this.options = t, this.start = this.now = this.cur(), this.end = r, this.unit = o || (je.cssNumber[n] ? "" : "px")
        },
        cur: function() {
            var e = z.propHooks[this.prop];
            return e && e.get ? e.get(this) : z.propHooks._default.get(this)
        },
        run: function(e) {
            var t, n = z.propHooks[this.prop];
            return this.options.duration ? this.pos = t = je.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration) : this.pos = t = e, this.now = (this.end - this.start) * t + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), n && n.set ? n.set(this) : z.propHooks._default.set(this), this
        }
    }, z.prototype.init.prototype = z.prototype, z.propHooks = {
        _default: {
            get: function(e) {
                var t;
                return 1 !== e.elem.nodeType || null != e.elem[e.prop] && null == e.elem.style[e.prop] ? e.elem[e.prop] : (t = je.css(e.elem, e.prop, ""), t && "auto" !== t ? t : 0)
            },
            set: function(e) {
                je.fx.step[e.prop] ? je.fx.step[e.prop](e) : 1 !== e.elem.nodeType || !je.cssHooks[e.prop] && null == e.elem.style[F(e.prop)] ? e.elem[e.prop] = e.now : je.style(e.elem, e.prop, e.now + e.unit)
            }
        }
    }, z.propHooks.scrollTop = z.propHooks.scrollLeft = {
        set: function(e) {
            e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now)
        }
    }, je.easing = {
        linear: function(e) {
            return e
        },
        swing: function(e) {
            return .5 - Math.cos(e * Math.PI) / 2
        },
        _default: "swing"
    }, je.fx = z.prototype.init, je.fx.step = {};
    var wt, yt, bt = /^(?:toggle|show|hide)$/,
        xt = /queueHooks$/;
    je.Animation = je.extend(Y, {
            tweeners: {
                "*": [function(e, t) {
                    var n = this.createTween(e, t);
                    return v(n.elem, e, Ve.exec(t), n), n
                }]
            },
            tweener: function(e, t) {
                we(e) ? (t = e, e = ["*"]) : e = e.match(He);
                for (var n, r = 0, i = e.length; i > r; r++) n = e[r], Y.tweeners[n] = Y.tweeners[n] || [], Y.tweeners[n].unshift(t)
            },
            prefilters: [J],
            prefilter: function(e, t) {
                t ? Y.prefilters.unshift(e) : Y.prefilters.push(e)
            }
        }), je.speed = function(e, t, n) {
            var r = e && "object" == typeof e ? je.extend({}, e) : {
                complete: n || !n && t || we(e) && e,
                duration: e,
                easing: n && t || t && !we(t) && t
            };
            return je.fx.off ? r.duration = 0 : "number" != typeof r.duration && (r.duration in je.fx.speeds ? r.duration = je.fx.speeds[r.duration] : r.duration = je.fx.speeds._default), (null == r.queue || r.queue === !0) && (r.queue = "fx"), r.old = r.complete, r.complete = function() {
                we(r.old) && r.old.call(this), r.queue && je.dequeue(this, r.queue)
            }, r
        }, je.fn.extend({
            fadeTo: function(e, t, n, r) {
                return this.filter(Ye).css("opacity", 0).show().end().animate({
                    opacity: t
                }, e, n, r)
            },
            animate: function(e, t, n, r) {
                var i = je.isEmptyObject(e),
                    o = je.speed(t, n, r),
                    a = function() {
                        var t = Y(this, je.extend({}, e), o);
                        (i || We.get(this, "finish")) && t.stop(!0)
                    };
                return a.finish = a, i || o.queue === !1 ? this.each(a) : this.queue(o.queue, a)
            },
            stop: function(e, t, n) {
                var r = function(e) {
                    var t = e.stop;
                    delete e.stop, t(n)
                };
                return "string" != typeof e && (n = t, t = e, e = void 0), t && this.queue(e || "fx", []), this.each(function() {
                    var t = !0,
                        i = null != e && e + "queueHooks",
                        o = je.timers,
                        a = We.get(this);
                    if (i) a[i] && a[i].stop && r(a[i]);
                    else
                        for (i in a) a[i] && a[i].stop && xt.test(i) && r(a[i]);
                    for (i = o.length; i--;) o[i].elem !== this || null != e && o[i].queue !== e || (o[i].anim.stop(n), t = !1, o.splice(i, 1));
                    (t || !n) && je.dequeue(this, e)
                })
            },
            finish: function(e) {
                return e !== !1 && (e = e || "fx"), this.each(function() {
                    var t, n = We.get(this),
                        r = n[e + "queue"],
                        i = n[e + "queueHooks"],
                        o = je.timers,
                        a = r ? r.length : 0;
                    for (n.finish = !0, je.queue(this, e, []),
                        i && i.stop && i.stop.call(this, !0), t = o.length; t--;) o[t].elem === this && o[t].queue === e && (o[t].anim.stop(!0), o.splice(t, 1));
                    for (t = 0; a > t; t++) r[t] && r[t].finish && r[t].finish.call(this);
                    delete n.finish
                })
            }
        }), je.each(["toggle", "show", "hide"], function(e, t) {
            var n = je.fn[t];
            je.fn[t] = function(e, r, i) {
                return null == e || "boolean" == typeof e ? n.apply(this, arguments) : this.animate(X(t, !0), e, r, i)
            }
        }), je.each({
            slideDown: X("show"),
            slideUp: X("hide"),
            slideToggle: X("toggle"),
            fadeIn: {
                opacity: "show"
            },
            fadeOut: {
                opacity: "hide"
            },
            fadeToggle: {
                opacity: "toggle"
            }
        }, function(e, t) {
            je.fn[e] = function(e, n, r) {
                return this.animate(t, e, n, r)
            }
        }), je.timers = [], je.fx.tick = function() {
            var e, t = 0,
                n = je.timers;
            for (wt = Date.now(); t < n.length; t++) e = n[t], e() || n[t] !== e || n.splice(t--, 1);
            n.length || je.fx.stop(), wt = void 0
        }, je.fx.timer = function(e) {
            je.timers.push(e), je.fx.start()
        }, je.fx.interval = 13, je.fx.start = function() {
            yt || (yt = !0, U())
        }, je.fx.stop = function() {
            yt = null
        }, je.fx.speeds = {
            slow: 600,
            fast: 200,
            _default: 400
        }, je.fn.delay = function(t, n) {
            return t = je.fx ? je.fx.speeds[t] || t : t, n = n || "fx", this.queue(n, function(n, r) {
                var i = e.setTimeout(n, t);
                r.stop = function() {
                    e.clearTimeout(i)
                }
            })
        },
        function() {
            var e = be.createElement("input"),
                t = be.createElement("select"),
                n = t.appendChild(be.createElement("option"));
            e.type = "checkbox", ve.checkOn = "" !== e.value, ve.optSelected = n.selected, e = be.createElement("input"), e.value = "t", e.type = "radio", ve.radioValue = "t" === e.value
        }();
    var jt, Tt = je.expr.attrHandle;
    je.fn.extend({
        attr: function(e, t) {
            return Oe(this, je.attr, e, t, arguments.length > 1)
        },
        removeAttr: function(e) {
            return this.each(function() {
                je.removeAttr(this, e)
            })
        }
    }), je.extend({
        attr: function(e, t, n) {
            var r, i, o = e.nodeType;
            if (3 !== o && 8 !== o && 2 !== o) return "undefined" == typeof e.getAttribute ? je.prop(e, t, n) : (1 === o && je.isXMLDoc(e) || (i = je.attrHooks[t.toLowerCase()] || (je.expr.match.bool.test(t) ? jt : void 0)), void 0 !== n ? null === n ? void je.removeAttr(e, t) : i && "set" in i && void 0 !== (r = i.set(e, n, t)) ? r : (e.setAttribute(t, n + ""), n) : i && "get" in i && null !== (r = i.get(e, t)) ? r : (r = je.find.attr(e, t), null == r ? void 0 : r))
        },
        attrHooks: {
            type: {
                set: function(e, t) {
                    if (!ve.radioValue && "radio" === t && o(e, "input")) {
                        var n = e.value;
                        return e.setAttribute("type", t), n && (e.value = n), t
                    }
                }
            }
        },
        removeAttr: function(e, t) {
            var n, r = 0,
                i = t && t.match(He);
            if (i && 1 === e.nodeType)
                for (; n = i[r++];) e.removeAttribute(n)
        }
    }), jt = {
        set: function(e, t, n) {
            return t === !1 ? je.removeAttr(e, n) : e.setAttribute(n, n), n
        }
    }, je.each(je.expr.match.bool.source.match(/\w+/g), function(e, t) {
        var n = Tt[t] || je.find.attr;
        Tt[t] = function(e, t, r) {
            var i, o, a = t.toLowerCase();
            return r || (o = Tt[a], Tt[a] = i, i = null != n(e, t, r) ? a : null, Tt[a] = o), i
        }
    });
    var Ct = /^(?:input|select|textarea|button)$/i,
        St = /^(?:a|area)$/i;
    je.fn.extend({
        prop: function(e, t) {
            return Oe(this, je.prop, e, t, arguments.length > 1)
        },
        removeProp: function(e) {
            return this.each(function() {
                delete this[je.propFix[e] || e]
            })
        }
    }), je.extend({
        prop: function(e, t, n) {
            var r, i, o = e.nodeType;
            if (3 !== o && 8 !== o && 2 !== o) return 1 === o && je.isXMLDoc(e) || (t = je.propFix[t] || t, i = je.propHooks[t]), void 0 !== n ? i && "set" in i && void 0 !== (r = i.set(e, n, t)) ? r : e[t] = n : i && "get" in i && null !== (r = i.get(e, t)) ? r : e[t]
        },
        propHooks: {
            tabIndex: {
                get: function(e) {
                    var t = je.find.attr(e, "tabindex");
                    return t ? parseInt(t, 10) : Ct.test(e.nodeName) || St.test(e.nodeName) && e.href ? 0 : -1
                }
            }
        },
        propFix: {
            "for": "htmlFor",
            "class": "className"
        }
    }), ve.optSelected || (je.propHooks.selected = {
        get: function(e) {
            var t = e.parentNode;
            return t && t.parentNode && t.parentNode.selectedIndex, null
        },
        set: function(e) {
            var t = e.parentNode;
            t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex)
        }
    }), je.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], function() {
        je.propFix[this.toLowerCase()] = this
    }), je.fn.extend({
        addClass: function(e) {
            var t, n, r, i, o, a, s, u = 0;
            if (we(e)) return this.each(function(t) {
                je(this).addClass(e.call(this, t, Z(this)))
            });
            if (t = ee(e), t.length)
                for (; n = this[u++];)
                    if (i = Z(n), r = 1 === n.nodeType && " " + K(i) + " ") {
                        for (a = 0; o = t[a++];) r.indexOf(" " + o + " ") < 0 && (r += o + " ");
                        s = K(r), i !== s && n.setAttribute("class", s)
                    }
            return this
        },
        removeClass: function(e) {
            var t, n, r, i, o, a, s, u = 0;
            if (we(e)) return this.each(function(t) {
                je(this).removeClass(e.call(this, t, Z(this)))
            });
            if (!arguments.length) return this.attr("class", "");
            if (t = ee(e), t.length)
                for (; n = this[u++];)
                    if (i = Z(n), r = 1 === n.nodeType && " " + K(i) + " ") {
                        for (a = 0; o = t[a++];)
                            for (; r.indexOf(" " + o + " ") > -1;) r = r.replace(" " + o + " ", " ");
                        s = K(r), i !== s && n.setAttribute("class", s)
                    }
            return this
        },
        toggleClass: function(e, t) {
            var n = typeof e,
                r = "string" === n || Array.isArray(e);
            return "boolean" == typeof t && r ? t ? this.addClass(e) : this.removeClass(e) : we(e) ? this.each(function(n) {
                je(this).toggleClass(e.call(this, n, Z(this), t), t)
            }) : this.each(function() {
                var t, i, o, a;
                if (r)
                    for (i = 0, o = je(this), a = ee(e); t = a[i++];) o.hasClass(t) ? o.removeClass(t) : o.addClass(t);
                else(void 0 === e || "boolean" === n) && (t = Z(this), t && We.set(this, "__className__", t), this.setAttribute && this.setAttribute("class", t || e === !1 ? "" : We.get(this, "__className__") || ""))
            })
        },
        hasClass: function(e) {
            var t, n, r = 0;
            for (t = " " + e + " "; n = this[r++];)
                if (1 === n.nodeType && (" " + K(Z(n)) + " ").indexOf(t) > -1) return !0;
            return !1
        }
    });
    var kt = /\r/g;
    je.fn.extend({
        val: function(e) {
            var t, n, r, i = this[0]; {
                if (arguments.length) return r = we(e), this.each(function(n) {
                    var i;
                    1 === this.nodeType && (i = r ? e.call(this, n, je(this).val()) : e, null == i ? i = "" : "number" == typeof i ? i += "" : Array.isArray(i) && (i = je.map(i, function(e) {
                        return null == e ? "" : e + ""
                    })), t = je.valHooks[this.type] || je.valHooks[this.nodeName.toLowerCase()], t && "set" in t && void 0 !== t.set(this, i, "value") || (this.value = i))
                });
                if (i) return t = je.valHooks[i.type] || je.valHooks[i.nodeName.toLowerCase()], t && "get" in t && void 0 !== (n = t.get(i, "value")) ? n : (n = i.value, "string" == typeof n ? n.replace(kt, "") : null == n ? "" : n)
            }
        }
    }), je.extend({
        valHooks: {
            option: {
                get: function(e) {
                    var t = je.find.attr(e, "value");
                    return null != t ? t : K(je.text(e))
                }
            },
            select: {
                get: function(e) {
                    var t, n, r, i = e.options,
                        a = e.selectedIndex,
                        s = "select-one" === e.type,
                        u = s ? null : [],
                        l = s ? a + 1 : i.length;
                    for (r = 0 > a ? l : s ? a : 0; l > r; r++)
                        if (n = i[r], (n.selected || r === a) && !n.disabled && (!n.parentNode.disabled || !o(n.parentNode, "optgroup"))) {
                            if (t = je(n).val(), s) return t;
                            u.push(t)
                        }
                    return u
                },
                set: function(e, t) {
                    for (var n, r, i = e.options, o = je.makeArray(t), a = i.length; a--;) r = i[a], (r.selected = je.inArray(je.valHooks.option.get(r), o) > -1) && (n = !0);
                    return n || (e.selectedIndex = -1), o
                }
            }
        }
    }), je.each(["radio", "checkbox"], function() {
        je.valHooks[this] = {
            set: function(e, t) {
                return Array.isArray(t) ? e.checked = je.inArray(je(e).val(), t) > -1 : void 0
            }
        }, ve.checkOn || (je.valHooks[this].get = function(e) {
            return null === e.getAttribute("value") ? "on" : e.value
        })
    }), ve.focusin = "onfocusin" in e;
    var Et = /^(?:focusinfocus|focusoutblur)$/,
        At = function(e) {
            e.stopPropagation()
        };
    je.extend(je.event, {
        trigger: function(t, n, r, i) {
            var o, a, s, u, l, d, c, f, p = [r || be],
                g = he.call(t, "type") ? t.type : t,
                h = he.call(t, "namespace") ? t.namespace.split(".") : [];
            if (a = f = s = r = r || be, 3 !== r.nodeType && 8 !== r.nodeType && !Et.test(g + je.event.triggered) && (g.indexOf(".") > -1 && (h = g.split("."), g = h.shift(), h.sort()), l = g.indexOf(":") < 0 && "on" + g, t = t[je.expando] ? t : new je.Event(g, "object" == typeof t && t), t.isTrigger = i ? 2 : 3, t.namespace = h.join("."), t.rnamespace = t.namespace ? new RegExp("(^|\\.)" + h.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, t.result = void 0, t.target || (t.target = r), n = null == n ? [t] : je.makeArray(n, [t]), c = je.event.special[g] || {}, i || !c.trigger || c.trigger.apply(r, n) !== !1)) {
                if (!i && !c.noBubble && !ye(r)) {
                    for (u = c.delegateType || g, Et.test(u + g) || (a = a.parentNode); a; a = a.parentNode) p.push(a), s = a;
                    s === (r.ownerDocument || be) && p.push(s.defaultView || s.parentWindow || e)
                }
                for (o = 0;
                    (a = p[o++]) && !t.isPropagationStopped();) f = a, t.type = o > 1 ? u : c.bindType || g, d = (We.get(a, "events") || Object.create(null))[t.type] && We.get(a, "handle"), d && d.apply(a, n), d = l && a[l], d && d.apply && Fe(a) && (t.result = d.apply(a, n), t.result === !1 && t.preventDefault());
                return t.type = g, i || t.isDefaultPrevented() || c._default && c._default.apply(p.pop(), n) !== !1 || !Fe(r) || l && we(r[g]) && !ye(r) && (s = r[l], s && (r[l] = null), je.event.triggered = g, t.isPropagationStopped() && f.addEventListener(g, At), r[g](), t.isPropagationStopped() && f.removeEventListener(g, At), je.event.triggered = void 0, s && (r[l] = s)), t.result
            }
        },
        simulate: function(e, t, n) {
            var r = je.extend(new je.Event, n, {
                type: e,
                isSimulated: !0
            });
            je.event.trigger(r, null, t)
        }
    }), je.fn.extend({
        trigger: function(e, t) {
            return this.each(function() {
                je.event.trigger(e, t, this)
            })
        },
        triggerHandler: function(e, t) {
            var n = this[0];
            return n ? je.event.trigger(e, t, n, !0) : void 0
        }
    });
    var Dt = e.location,
        Nt = {
            guid: Date.now()
        },
        qt = /\?/;
    je.parseXML = function(t) {
        var n, r;
        if (!t || "string" != typeof t) return null;
        try {
            n = (new e.DOMParser).parseFromString(t, "text/xml")
        } catch (i) {}
        return r = n && n.getElementsByTagName("parsererror")[0], (!n || r) && je.error("Invalid XML: " + (r ? je.map(r.childNodes, function(e) {
            return e.textContent
        }).join("\n") : t)), n
    };
    var Lt = /\[\]$/,
        Ht = /\r?\n/g,
        Pt = /^(?:submit|button|image|reset|file)$/i,
        Rt = /^(?:input|select|textarea|keygen)/i;
    je.param = function(e, t) {
        var n, r = [],
            i = function(e, t) {
                var n = we(t) ? t() : t;
                r[r.length] = encodeURIComponent(e) + "=" + encodeURIComponent(null == n ? "" : n)
            };
        if (null == e) return "";
        if (Array.isArray(e) || e.jquery && !je.isPlainObject(e)) je.each(e, function() {
            i(this.name, this.value)
        });
        else
            for (n in e) te(n, e[n], t, i);
        return r.join("&")
    }, je.fn.extend({
        serialize: function() {
            return je.param(this.serializeArray())
        },
        serializeArray: function() {
            return this.map(function() {
                var e = je.prop(this, "elements");
                return e ? je.makeArray(e) : this
            }).filter(function() {
                var e = this.type;
                return this.name && !je(this).is(":disabled") && Rt.test(this.nodeName) && !Pt.test(e) && (this.checked || !Ze.test(e))
            }).map(function(e, t) {
                var n = je(this).val();
                return null == n ? null : Array.isArray(n) ? je.map(n, function(e) {
                    return {
                        name: t.name,
                        value: e.replace(Ht, "\r\n")
                    }
                }) : {
                    name: t.name,
                    value: n.replace(Ht, "\r\n")
                }
            }).get()
        }
    });
    var Ot = /%20/g,
        It = /#.*$/,
        Mt = /([?&])_=[^&]*/,
        Ft = /^(.*?):[ \t]*([^\r\n]*)$/gm,
        Wt = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/,
        Bt = /^(?:GET|HEAD)$/,
        $t = /^\/\//,
        zt = {},
        Ut = {},
        Vt = "*/".concat("*"),
        Xt = be.createElement("a");
    Xt.href = Dt.href, je.extend({
        active: 0,
        lastModified: {},
        etag: {},
        ajaxSettings: {
            url: Dt.href,
            type: "GET",
            isLocal: Wt.test(Dt.protocol),
            global: !0,
            processData: !0,
            async: !0,
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            accepts: {
                "*": Vt,
                text: "text/plain",
                html: "text/html",
                xml: "application/xml, text/xml",
                json: "application/json, text/javascript"
            },
            contents: {
                xml: /\bxml\b/,
                html: /\bhtml/,
                json: /\bjson\b/
            },
            responseFields: {
                xml: "responseXML",
                text: "responseText",
                json: "responseJSON"
            },
            converters: {
                "* text": String,
                "text html": !0,
                "text json": JSON.parse,
                "text xml": je.parseXML
            },
            flatOptions: {
                url: !0,
                context: !0
            }
        },
        ajaxSetup: function(e, t) {
            return t ? ie(ie(e, je.ajaxSettings), t) : ie(je.ajaxSettings, e)
        },
        ajaxPrefilter: ne(zt),
        ajaxTransport: ne(Ut),
        ajax: function(t, n) {
            function r(t, n, r, s) {
                var l, f, p, y, b, x = n;
                d || (d = !0, u && e.clearTimeout(u), i = void 0, a = s || "", j.readyState = t > 0 ? 4 : 0, l = t >= 200 && 300 > t || 304 === t, r && (y = oe(g, j, r)), !l && je.inArray("script", g.dataTypes) > -1 && je.inArray("json", g.dataTypes) < 0 && (g.converters["text script"] = function() {}), y = ae(g, y, j, l), l ? (g.ifModified && (b = j.getResponseHeader("Last-Modified"), b && (je.lastModified[o] = b), b = j.getResponseHeader("etag"), b && (je.etag[o] = b)), 204 === t || "HEAD" === g.type ? x = "nocontent" : 304 === t ? x = "notmodified" : (x = y.state, f = y.data, p = y.error, l = !p)) : (p = x, (t || !x) && (x = "error", 0 > t && (t = 0))), j.status = t, j.statusText = (n || x) + "", l ? _.resolveWith(h, [f, x, j]) : _.rejectWith(h, [j, x, p]), j.statusCode(w), w = void 0, c && m.trigger(l ? "ajaxSuccess" : "ajaxError", [j, g, l ? f : p]), v.fireWith(h, [j, x]), c && (m.trigger("ajaxComplete", [j, g]), --je.active || je.event.trigger("ajaxStop")))
            }
            if (null != t && ("object" != typeof t || (n = t, t = void 0, null != n.url))) {
                n = n || {};
                var i, o, a, s, u, l, d, c, f, p, g = je.ajaxSetup({}, n),
                    h = g.context || g,
                    m = g.context && (h.nodeType || h.jquery) ? je(h) : je.event,
                    _ = je.Deferred(),
                    v = je.Callbacks("once memory"),
                    w = g.statusCode || {},
                    y = {},
                    b = {},
                    x = "canceled",
                    j = {
                        readyState: 0,
                        getResponseHeader: function(e) {
                            var t;
                            if (d) {
                                if (!s)
                                    for (s = {}; t = Ft.exec(a);) s[t[1].toLowerCase() + " "] = (s[t[1].toLowerCase() + " "] || []).concat(t[2]);
                                t = s[e.toLowerCase() + " "]
                            }
                            return null == t ? null : t.join(", ")
                        },
                        getAllResponseHeaders: function() {
                            return d ? a : null
                        },
                        setRequestHeader: function(e, t) {
                            return null == d && (e = b[e.toLowerCase()] = b[e.toLowerCase()] || e, y[e] = t), this
                        },
                        overrideMimeType: function(e) {
                            return null == d && (g.mimeType = e), this
                        },
                        statusCode: function(e) {
                            var t;
                            if (e)
                                if (d) j.always(e[j.status]);
                                else
                                    for (t in e) w[t] = [w[t], e[t]];
                            return this
                        },
                        abort: function(e) {
                            var t = e || x;
                            return i && i.abort(t), r(0, t), this
                        }
                    };
                if (_.promise(j), g.url = ((t || g.url || Dt.href) + "").replace($t, Dt.protocol + "//"), g.type = n.method || n.type || g.method || g.type, g.dataTypes = (g.dataType || "*").toLowerCase().match(He) || [""], null == g.crossDomain) {
                    l = be.createElement("a");
                    try {
                        l.href = g.url, l.href = l.href, g.crossDomain = Xt.protocol + "//" + Xt.host != l.protocol + "//" + l.host
                    } catch (T) {
                        g.crossDomain = !0
                    }
                }
                if (g.data && g.processData && "string" != typeof g.data && (g.data = je.param(g.data, g.traditional)), re(zt, g, n, j), d) return j;
                c = je.event && g.global, c && 0 === je.active++ && je.event.trigger("ajaxStart"), g.type = g.type.toUpperCase(), g.hasContent = !Bt.test(g.type), o = g.url.replace(It, ""), g.hasContent ? g.data && g.processData && 0 === (g.contentType || "").indexOf("application/x-www-form-urlencoded") && (g.data = g.data.replace(Ot, "+")) : (p = g.url.slice(o.length), g.data && (g.processData || "string" == typeof g.data) && (o += (qt.test(o) ? "&" : "?") + g.data, delete g.data), g.cache === !1 && (o = o.replace(Mt, "$1"), p = (qt.test(o) ? "&" : "?") + "_=" + Nt.guid++ + p), g.url = o + p), g.ifModified && (je.lastModified[o] && j.setRequestHeader("If-Modified-Since", je.lastModified[o]), je.etag[o] && j.setRequestHeader("If-None-Match", je.etag[o])), (g.data && g.hasContent && g.contentType !== !1 || n.contentType) && j.setRequestHeader("Content-Type", g.contentType), j.setRequestHeader("Accept", g.dataTypes[0] && g.accepts[g.dataTypes[0]] ? g.accepts[g.dataTypes[0]] + ("*" !== g.dataTypes[0] ? ", " + Vt + "; q=0.01" : "") : g.accepts["*"]);
                for (f in g.headers) j.setRequestHeader(f, g.headers[f]);
                if (g.beforeSend && (g.beforeSend.call(h, j, g) === !1 || d)) return j.abort();
                if (x = "abort", v.add(g.complete), j.done(g.success), j.fail(g.error), i = re(Ut, g, n, j)) {
                    if (j.readyState = 1, c && m.trigger("ajaxSend", [j, g]), d) return j;
                    g.async && g.timeout > 0 && (u = e.setTimeout(function() {
                        j.abort("timeout")
                    }, g.timeout));
                    try {
                        d = !1, i.send(y, r)
                    } catch (T) {
                        if (d) throw T;
                        r(-1, T)
                    }
                } else r(-1, "No Transport");
                return j
            }
        },
        getJSON: function(e, t, n) {
            return je.get(e, t, n, "json")
        },
        getScript: function(e, t) {
            return je.get(e, void 0, t, "script")
        }
    }), je.each(["get", "post"], function(e, t) {
        je[t] = function(e, n, r, i) {
            return we(n) && (i = i || r, r = n, n = void 0), je.ajax(je.extend({
                url: e,
                type: t,
                dataType: i,
                data: n,
                success: r
            }, je.isPlainObject(e) && e))
        }
    }), je.ajaxPrefilter(function(e) {
        var t;
        for (t in e.headers) "content-type" === t.toLowerCase() && (e.contentType = e.headers[t] || "")
    }), je._evalUrl = function(e, t, n) {}, je.fn.extend({
        wrapAll: function(e) {
            var t;
            return this[0] && (we(e) && (e = e.call(this[0])), t = je(e, this[0].ownerDocument).eq(0).clone(!0), this[0].parentNode && t.insertBefore(this[0]), t.map(function() {
                for (var e = this; e.firstElementChild;) e = e.firstElementChild;
                return e
            }).append(this)), this
        },
        wrapInner: function(e) {
            return we(e) ? this.each(function(t) {
                je(this).wrapInner(e.call(this, t))
            }) : this.each(function() {
                var t = je(this),
                    n = t.contents();
                n.length ? n.wrapAll(e) : t.append(e)
            })
        },
        wrap: function(e) {
            var t = we(e);
            return this.each(function(n) {
                je(this).wrapAll(t ? e.call(this, n) : e)
            })
        },
        unwrap: function(e) {
            return this.parent(e).not("body").each(function() {
                je(this).replaceWith(this.childNodes)
            }), this
        }
    }), je.expr.pseudos.hidden = function(e) {
        return !je.expr.pseudos.visible(e)
    }, je.expr.pseudos.visible = function(e) {
        return !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length)
    }, je.ajaxSettings.xhr = function() {
        try {
            return new e.XMLHttpRequest
        } catch (t) {}
    };
    var Gt = {
            0: 200,
            1223: 204
        },
        Jt = je.ajaxSettings.xhr();
    ve.cors = !!Jt && "withCredentials" in Jt, ve.ajax = Jt = !!Jt, je.ajaxTransport(function(t) {
        var n, r;
        return ve.cors || Jt && !t.crossDomain ? {
            send: function(i, o) {
                var a, s = t.xhr();
                if (s.open(t.type, t.url, t.async, t.username, t.password), t.xhrFields)
                    for (a in t.xhrFields) s[a] = t.xhrFields[a];
                t.mimeType && s.overrideMimeType && s.overrideMimeType(t.mimeType), t.crossDomain || i["X-Requested-With"] || (i["X-Requested-With"] = "XMLHttpRequest");
                for (a in i) s.setRequestHeader(a, i[a]);
                n = function(e) {
                    return function() {
                        n && (n = r = s.onload = s.onerror = s.onabort = s.ontimeout = s.onreadystatechange = null, "abort" === e ? s.abort() : "error" === e ? "number" != typeof s.status ? o(0, "error") : o(s.status, s.statusText) : o(Gt[s.status] || s.status, s.statusText, "text" !== (s.responseType || "text") || "string" != typeof s.responseText ? {
                            binary: s.response
                        } : {
                            text: s.responseText
                        }, s.getAllResponseHeaders()))
                    }
                }, s.onload = n(), r = s.onerror = s.ontimeout = n("error"), void 0 !== s.onabort ? s.onabort = r : s.onreadystatechange = function() {
                    4 === s.readyState && e.setTimeout(function() {
                        n && r()
                    })
                }, n = n("abort");
                try {
                    s.send(t.hasContent && t.data || null)
                } catch (u) {
                    if (n) throw u
                }
            },
            abort: function() {
                n && n()
            }
        } : void 0
    }), je.ajaxPrefilter(function(e) {
        e.crossDomain && (e.contents.script = !1)
    }), je.ajaxSetup({
        accepts: {
            script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
        },
        contents: {
            script: /\b(?:java|ecma)script\b/
        },
        converters: {
            "text script": function(e) {
                return je.globalEval(e), e
            }
        }
    }), je.ajaxPrefilter("script", function(e) {
        void 0 === e.cache && (e.cache = !1), e.crossDomain && (e.type = "GET")
    }), je.ajaxTransport("script", function(e) {
        if (e.crossDomain || e.scriptAttrs) {
            var t, n;
            return {
                send: function(r, i) {
                    t = je("<script>").attr(e.scriptAttrs || {}).prop({
                        charset: e.scriptCharset,
                        src: e.url
                    }).on("load error", n = function(e) {
                        t.remove(), n = null, e && i("error" === e.type ? 404 : 200, e.type)
                    }), be.head.appendChild(t[0])
                },
                abort: function() {
                    n && n()
                }
            }
        }
    });
    var Qt = [],
        Yt = /(=)\?(?=&|$)|\?\?/;
    je.ajaxSetup({
        jsonp: "callback",
        jsonpCallback: function() {
            var e = Qt.pop() || je.expando + "_" + Nt.guid++;
            return this[e] = !0, e
        }
    }), je.ajaxPrefilter("json jsonp", function(t, n, r) {
        var i, o, a, s = t.jsonp !== !1 && (Yt.test(t.url) ? "url" : "string" == typeof t.data && 0 === (t.contentType || "").indexOf("application/x-www-form-urlencoded") && Yt.test(t.data) && "data");
        return s || "jsonp" === t.dataTypes[0] ? (i = t.jsonpCallback = we(t.jsonpCallback) ? t.jsonpCallback() : t.jsonpCallback, s ? t[s] = t[s].replace(Yt, "$1" + i) : t.jsonp !== !1 && (t.url += (qt.test(t.url) ? "&" : "?") + t.jsonp + "=" + i), t.converters["script json"] = function() {
            return a || je.error(i + " was not called"), a[0]
        }, t.dataTypes[0] = "json", o = e[i], e[i] = function() {
            a = arguments
        }, r.always(function() {
            void 0 === o ? je(e).removeProp(i) : e[i] = o, t[i] && (t.jsonpCallback = n.jsonpCallback, Qt.push(i)), a && we(o) && o(a[0]), a = o = void 0
        }), "script") : void 0
    }), ve.createHTMLDocument = function() {
        var e = be.implementation.createHTMLDocument("").body;
        return e.innerHTML = "<form></form><form></form>", 2 === e.childNodes.length
    }(), je.parseHTML = function(e, t, n) {
        if ("string" != typeof e) return [];
        "boolean" == typeof t && (n = t, t = !1);
        var r, i, o;
        return t || (ve.createHTMLDocument ? (t = be.implementation.createHTMLDocument(""), r = t.createElement("base"), r.href = be.location.href, t.head.appendChild(r)) : t = be), i = Ee.exec(e), o = !n && [], i ? [t.createElement(i[1])] : (i = j([e], t, o), o && o.length && je(o).remove(), je.merge([], i.childNodes))
    }, je.fn.load = function(e, t, n) {
        var r, i, o, a = this,
            s = e.indexOf(" ");
        return s > -1 && (r = K(e.slice(s)), e = e.slice(0, s)), we(t) ? (n = t, t = void 0) : t && "object" == typeof t && (i = "POST"), a.length > 0 && je.ajax({
            url: e,
            type: i || "GET",
            dataType: "html",
            data: t
        }).done(function(e) {
            o = arguments, a.html(r ? je("<div>").append(je.parseHTML(e)).find(r) : e)
        }).always(n && function(e, t) {
            a.each(function() {
                n.apply(this, o || [e.responseText, t, e])
            })
        }), this
    }, je.expr.pseudos.animated = function(e) {
        return je.grep(je.timers, function(t) {
            return e === t.elem
        }).length
    }, je.offset = {
        setOffset: function(e, t, n) {
            var r, i, o, a, s, u, l, d = je.css(e, "position"),
                c = je(e),
                f = {};
            "static" === d && (e.style.position = "relative"), s = c.offset(), o = je.css(e, "top"), u = je.css(e, "left"), l = ("absolute" === d || "fixed" === d) && (o + u).indexOf("auto") > -1, l ? (r = c.position(), a = r.top, i = r.left) : (a = parseFloat(o) || 0, i = parseFloat(u) || 0), we(t) && (t = t.call(e, n, je.extend({}, s))), null != t.top && (f.top = t.top - s.top + a), null != t.left && (f.left = t.left - s.left + i), "using" in t ? t.using.call(e, f) : c.css(f)
        }
    }, je.fn.extend({
        offset: function(e) {
            if (arguments.length) return void 0 === e ? this : this.each(function(t) {
                je.offset.setOffset(this, e, t)
            });
            var t, n, r = this[0];
            if (r) return r.getClientRects().length ? (t = r.getBoundingClientRect(), n = r.ownerDocument.defaultView, {
                top: t.top + n.pageYOffset,
                left: t.left + n.pageXOffset
            }) : {
                top: 0,
                left: 0
            }
        },
        position: function() {
            if (this[0]) {
                var e, t, n, r = this[0],
                    i = {
                        top: 0,
                        left: 0
                    };
                if ("fixed" === je.css(r, "position")) t = r.getBoundingClientRect();
                else {
                    for (t = this.offset(), n = r.ownerDocument, e = r.offsetParent || n.documentElement; e && (e === n.body || e === n.documentElement) && "static" === je.css(e, "position");) e = e.parentNode;
                    e && e !== r && 1 === e.nodeType && (i = je(e).offset(), i.top += je.css(e, "borderTopWidth", !0), i.left += je.css(e, "borderLeftWidth", !0))
                }
                return {
                    top: t.top - i.top - je.css(r, "marginTop", !0),
                    left: t.left - i.left - je.css(r, "marginLeft", !0)
                }
            }
        },
        offsetParent: function() {
            return this.map(function() {
                for (var e = this.offsetParent; e && "static" === je.css(e, "position");) e = e.offsetParent;
                return e || Ge
            })
        }
    }), je.each({
        scrollLeft: "pageXOffset",
        scrollTop: "pageYOffset"
    }, function(e, t) {
        var n = "pageYOffset" === t;
        je.fn[e] = function(r) {
            return Oe(this, function(e, r, i) {
                var o;
                return ye(e) ? o = e : 9 === e.nodeType && (o = e.defaultView), void 0 === i ? o ? o[t] : e[r] : void(o ? o.scrollTo(n ? o.pageXOffset : i, n ? i : o.pageYOffset) : e[r] = i)
            }, e, r, arguments.length)
        }
    }), je.each(["top", "left"], function(e, t) {
        je.cssHooks[t] = I(ve.pixelPosition, function(e, n) {
            return n ? (n = O(e, t), ut.test(n) ? je(e).position()[t] + "px" : n) : void 0
        })
    }), je.each({
        Height: "height",
        Width: "width"
    }, function(e, t) {
        je.each({
            padding: "inner" + e,
            content: t,
            "": "outer" + e
        }, function(n, r) {
            je.fn[r] = function(i, o) {
                var a = arguments.length && (n || "boolean" != typeof i),
                    s = n || (i === !0 || o === !0 ? "margin" : "border");
                return Oe(this, function(t, n, i) {
                    var o;
                    return ye(t) ? 0 === r.indexOf("outer") ? t["inner" + e] : t.document.documentElement["client" + e] : 9 === t.nodeType ? (o = t.documentElement, Math.max(t.body["scroll" + e], o["scroll" + e], t.body["offset" + e], o["offset" + e], o["client" + e])) : void 0 === i ? je.css(t, n, s) : je.style(t, n, i, s)
                }, t, a ? i : void 0, a)
            }
        })
    }), je.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function(e, t) {
        je.fn[t] = function(e) {
            return this.on(t, e)
        }
    }), je.fn.extend({
        bind: function(e, t, n) {
            return this.on(e, null, t, n)
        },
        unbind: function(e, t) {
            return this.off(e, null, t)
        },
        delegate: function(e, t, n, r) {
            return this.on(t, e, n, r)
        },
        undelegate: function(e, t, n) {
            return 1 === arguments.length ? this.off(e, "**") : this.off(t, e || "**", n)
        },
        hover: function(e, t) {
            return this.mouseenter(e).mouseleave(t || e)
        }
    }), je.each("blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(" "), function(e, t) {
        je.fn[t] = function(e, n) {
            return arguments.length > 0 ? this.on(t, null, e, n) : this.trigger(t)
        }
    });
    var Kt = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
    je.proxy = function(e, t) {
        var n, r, i;
        return "string" == typeof t && (n = e[t], t = e, e = n), we(e) ? (r = le.call(arguments, 2), i = function() {
            return e.apply(t || this, r.concat(le.call(arguments)))
        }, i.guid = e.guid = e.guid || je.guid++, i) : void 0
    }, je.holdReady = function(e) {
        e ? je.readyWait++ : je.ready(!0)
    }, je.isArray = Array.isArray, je.parseJSON = JSON.parse, je.nodeName = o, je.isFunction = we, je.isWindow = ye, je.camelCase = g, je.type = r, je.now = Date.now, je.isNumeric = function(e) {
        var t = je.type(e);
        return ("number" === t || "string" === t) && !isNaN(e - parseFloat(e))
    }, je.trim = function(e) {
        return null == e ? "" : (e + "").replace(Kt, "")
    }, "function" == typeof define && define.amd && define("jquery", [], function() {
        return je
    });
    var Zt = e.jQuery,
        en = e.$;
    return je.noConflict = function(t) {
        return e.$ === je && (e.$ = en), t && e.jQuery === je && (e.jQuery = Zt), je
    }, "undefined" == typeof t && (jdgm.jQuery = jdgm.$ = je), je
}), jdgm.$.fn.unveil = function(e, t) {
        function n() {
            var e = l.filter(function() {
                var e = i(this);
                if (!e.is(":hidden")) {
                    var t = o.scrollTop(),
                        n = t + o.height(),
                        r = e.offset().top,
                        s = r + e.height();
                    return s >= t - a && n + a >= r
                }
            });
            r = e.trigger("unveil"), l = l.not(r)
        }
        var r, i = jdgm.$,
            o = i(window),
            a = e || 0,
            s = window.devicePixelRatio > 1,
            u = s ? "data-src-retina" : "data-src",
            l = this;
        return this.one("unveil", function() {
            var e = this.getAttribute(u);
            e = e || this.getAttribute("data-src"), e && (this.setAttribute("src", e), "function" == typeof t && t.call(this))
        }), o.on("resize.unveil lookup.unveil", n), jdgm.ScrollEvent.attach(n, "unveil"), n(), this
    },
    function(e, t) {
        function n(e, t, n) {
            return !1
        }

        function r(t, n, a, s, u) {
            var l = !1,
                d = "a, table, thead, tbody, tfoot, tr, col, colgroup, object, embed, param, ol, ul, dl, blockquote, select, optgroup, option, textarea, script, style",
                c = "script, .dotdotdot-keep";
            return t.contents().detach().each(function() {
                var f = this,
                    p = e(f);
                if ("undefined" == typeof f) return !0;
                if (p.is(c)) t.append(p);
                else {
                    if (l) return !0;
                    t.append(p), !u || p.is(s.after) || p.find(s.after).length || t[t.is(d) ? "after" : "append"](u), o(a, s) && (l = 3 == f.nodeType ? i(p, n, a, s, u) : r(p, n, a, s, u)), l || u && u.detach()
                }
            }), n.addClass("is-truncated"), l
        }

        function i(t, n, r, i, l) {
            var c = t[0];
            if (!c) return !1;
            var f = u(c),
                p = -1 !== f.indexOf(" ") ? " " : "\u3000",
                g = "letter" == i.wrap ? "" : p,
                h = f.split(g),
                m = -1,
                _ = -1,
                v = 0,
                w = h.length - 1;
            for (i.fallbackToLetter && 0 == v && 0 == w && (g = "", h = f.split(g), w = h.length - 1); w >= v && (0 != v || 0 != w);) {
                var y = Math.floor((v + w) / 2);
                if (y == _) break;
                _ = y, s(c, h.slice(0, _ + 1).join(g) + i.ellipsis), r.children().each(function() {
                    e(this).toggle().toggle()
                }), o(r, i) ? (w = _, i.fallbackToLetter && 0 == v && 0 == w && (g = "", h = h[0].split(g), m = -1, _ = -1, v = 0, w = h.length - 1)) : (m = _, v = _)
            }
            if (-1 == m || 1 == h.length && 0 == h[0].length) {
                var b = t.parent();
                t.detach();
                var x = l && l.closest(b).length ? l.length : 0;
                b.contents().length > x ? c = d(b.contents().eq(-1 - x), n) : (c = d(b, n, !0), x || b.detach()), c && (f = a(u(c), i), s(c, f), x && l && e(c).parent().append(l))
            } else f = a(h.slice(0, m + 1).join(g), i), s(c, f);
            return !0
        }

        function o(e, t) {
            return e.innerHeight() > t.maxHeight
        }

        function a(t, n) {
            for (; e.inArray(t.slice(-1), n.lastCharacter.remove) > -1;) t = t.slice(0, -1);
            return e.inArray(t.slice(-1), n.lastCharacter.noEllipsis) < 0 && (t += n.ellipsis), t
        }

        function s(e, t) {
            e.innerText ? e.innerText = t : e.nodeValue ? e.nodeValue = t : e.textContent && (e.textContent = t)
        }

        function u(e) {
            return e.innerText ? e.innerText : e.nodeValue ? e.nodeValue : e.textContent ? e.textContent : ""
        }

        function l(e) {
            do e = e.previousSibling; while (e && 1 !== e.nodeType && 3 !== e.nodeType);
            return e
        }

        function d(t, n, r) {
            var i, o = t && t[0];
            if (o) {
                if (!r) {
                    if (3 === o.nodeType) return o;
                    if (e.trim(t.text())) return d(t.contents().last(), n)
                }
                for (i = l(o); !i;) {
                    if (t = t.parent(), t.is(n) || !t.length) return !1;
                    i = l(t[0])
                }
                if (i) return d(e(i), n)
            }
            return !1
        }

        function c(t, n) {
            return t ? "string" == typeof t ? (t = e(t, n), t.length ? t : !1) : t.jquery ? t : !1 : !1
        }

        function f(e) {
            for (var t = e.innerHeight(), n = ["paddingTop", "paddingBottom"], r = 0, i = n.length; i > r; r++) {
                var o = parseInt(e.css(n[r]), 10);
                isNaN(o) && (o = 0), t -= o
            }
            return t
        }
        if (!e.fn.dotdotdot) {
            e.fn.dotdotdot = function(t) {
                if (0 == this.length) return e.fn.dotdotdot.debug('No element found for "' + this.selector + '".'), this;
                if (this.length > 1) return this.each(function() {
                    e(this).dotdotdot(t)
                });
                var i = this;
                i.data("dotdotdot") && i.trigger("destroy.dot"), i.data("dotdotdot-style", i.attr("style") || ""), i.css("word-wrap", "break-word"), "nowrap" === i.css("white-space") && i.css("white-space", "normal"), i.bind_events = function() {
                    return i.bind("update.dot", function(t, d) {
                        switch (i.removeClass("is-truncated"), t.preventDefault(), t.stopPropagation(), typeof s.height) {
                            case "number":
                                s.maxHeight = s.height;
                                break;
                            case "function":
                                s.maxHeight = s.height.call(i[0]);
                                break;
                            default:
                                s.maxHeight = f(i)
                        }
                        s.maxHeight += s.tolerance, "undefined" != typeof d && (("string" == typeof d || "nodeType" in d && 1 === d.nodeType) && (d = e("<div />").append(d).contents()), d instanceof e && (a = d)), l = i.wrapInner('<div class="dotdotdot" />').children(), l.contents().detach().end().append(a.clone(!0)).find("br").replaceWith("  <br />  ").end().css({
                            height: "auto",
                            width: "auto",
                            border: "none",
                            padding: 0,
                            margin: 0
                        });
                        var c = !1,
                            p = !1;
                        return u.afterElement && (c = u.afterElement.clone(!0), c.show(), u.afterElement.detach()), o(l, s) && (p = "children" == s.wrap ? n(l, s, c) : r(l, i, l, s, c)), l.replaceWith(l.contents()), l = null, e.isFunction(s.callback) && s.callback.call(i[0], p, a), u.isTruncated = p, p
                    }).bind("originalContent.dot", function(e, t) {
                        return e.preventDefault(), e.stopPropagation(), "function" == typeof t && t.call(i[0], a), a
                    }).bind("destroy.dot", function(e) {
                        e.preventDefault(), e.stopPropagation(), i.unbind_events().contents().detach().end().append(a).attr("style", i.data("dotdotdot-style") || "").data("dotdotdot", !1)
                    }), i
                }, i.unbind_events = function() {
                    return i.unbind(".dot"), i
                }, i.watch = function() {}, i.unwatch = function() {};
                var a = i.contents(),
                    s = e.extend(!0, {}, e.fn.dotdotdot.defaults, t),
                    u = {},
                    l = null;
                return s.lastCharacter.remove instanceof Array || (s.lastCharacter.remove = e.fn.dotdotdot.defaultArrays.lastCharacter.remove), s.lastCharacter.noEllipsis instanceof Array || (s.lastCharacter.noEllipsis = e.fn.dotdotdot.defaultArrays.lastCharacter.noEllipsis), u.afterElement = c(s.after, i), u.isTruncated = !1, u.dotId = p++, i.data("dotdotdot", !0).bind_events().trigger("update.dot"), s.watch && i.watch(), i
            }, e.fn.dotdotdot.defaults = {
                ellipsis: "... ",
                wrap: "word",
                fallbackToLetter: !0,
                lastCharacter: {},
                tolerance: 0,
                callback: null,
                after: null,
                height: null,
                watch: !1,
                windowResizeFix: !0
            }, e.fn.dotdotdot.defaultArrays = {
                lastCharacter: {
                    remove: [" ", "\u3000", ",", ";", ".", "!", "?"],
                    noEllipsis: []
                }
            }, e.fn.dotdotdot.debug = function(e) {};
            var p = 1,
                g = e.fn.html;
            e.fn.html = function(n) {
                return n != t && !e.isFunction(n) && this.data("dotdotdot") ? this.trigger("update", [n]) : g.apply(this, arguments)
            };
            var h = e.fn.text;
            e.fn.text = function(n) {
                return n != t && !e.isFunction(n) && this.data("dotdotdot") ? (n = e("<div />").text(n).html(), this.trigger("update", [n])) : h.apply(this, arguments)
            }
        }
    }(jdgm.$ || jQuery),
    function() {
        jdgm.$(function(e) {
            var t, n, r;
            return r = jdgm._safeRun, n = function() {
                return {}
            }, t = e(), r(function() {
                return ["serialize", "val", "fadeTo", "hasClass", "has", "text", "index", "add", "addBack", "not", "is", "closest", "hide", "toggle", "slice", "first", "last", "even", "odd", "promise", "position", "off", "prepend", "before", "after", "clone", "replaceWith", "appendTo", "wrapAll", "wrapInner", "wrap", "unwrap", "removeClass"].forEach(function(e) {
                    return t[e]()
                }), e.event.remove(t), e.event.dispatch(t), e.clone(document.createElement("div")), t.appendTo(document.createElement("div"))
            }), r(function() {
                var t;
                return t = e("<form><input name=warmup></form>"), ["stop", "finish", "serializeArray", "parent", "parents", "parentsUntil", "next", "prev", "nextAll", "prevAll", "nextUntil", "prevUntil", "siblings", "children", "contents", "serializeJSON", "innerWidth"].forEach(function(e) {
                    return t[e]()
                }), ["attr", "prop", "removeProp", "removeData", "val"].forEach(function(e) {
                    return t[e]("")
                }), t.removeAttr("", "").animate({
                    width: "1px",
                    height: "1px"
                }), t.toggleClass("jdgm-hidden").trigger("click"), t.scrollTop({}), e.offset.setOffset(t[0], {}), e(".jdgm-random-link").offset()
            }), r(function() {
                return ["when", "parseXML", "ajax", "get", "proxy", "trim"].forEach(function(t) {
                    return e[t]()
                }), ["hasData", "data", "removeData", "_data", "_removeData"].forEach(function(n) {
                    return e[n](t, "")
                })
            }), r(function() {
                return e.Animation.tweener("x"), e.valHooks.select.get({
                    options: ""
                }), e.valHooks.select.set({
                    options: ""
                }), e.fn.load(""), e.isNumeric({}), e.event.special.blur.trigger()
            }), r(function() {
                var t, n;
                return t = e(".jdgm-widget span"), t.filter("[a]"), t.filter(".btn"), n = ["contains(x)", "lang(en)", "checked", "empty", "text", "even", "odd", "lt", "gt", "target", "root", "button", "input", "focus", "first-child", "selected", "not(i)", "parent", "header", "enabled", "disabled"], jdgm.asyncEach(n, function(e) {
                    return t.filter(":" + e)
                }), e.param(n), e.param({
                    a: {
                        b: n
                    }
                }), e.unique(n)
            }), r(function() {
                return e("<img>").unveil().trigger("unveil")
            }), r(function() {
                return e.urlParam(""), jdgm.uniq([]), jdgm.compact([]), jdgm.compactHash({
                    a: null
                }), jdgm.random(), jdgm.shopifyDomain(), jdgm.shopDomain(), jdgm.shopParams(), jdgm.truncate(""), jdgm.times(1, n), jdgm.escapeHTML(""), jdgm.urlParamsAsHash(""), jdgm.isInViewport(document.createElement("i")), jdgm.ScrollEvent.attach(n, "warmup"), jdgm.ScrollEvent.dettach("warmup"), jdgm.ScrollEvent.trigger("warmup"), jdgm.buildStarsFor(e("<i score=5></i>"))
            })
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            return e(".jdgm-prev-badge").closest(".judgeme-preview-badge").addClass("jdgm-widget jdgm-preview-badge jdgm--from-v1"), e(".jdgm-rev-widg").closest("#judgeme_product_reviews:not(.jdgm-widget.jdgm-review-widget)").addClass("jdgm-widget jdgm-review-widget jdgm--from-v1"), e(".ui-tabs.ui-widget [id=judgeme_product_reviews]:not(.jdgm-widget.jdgm-review-widget)").each(function(t, n) {
                var r;
                return r = e(n), r.find(".jdgm-rev-widg, .judgeme-reviews").length <= 0 ? r.addClass("jdgm-widget jdgm-review-widget jdgm--from-v1") : void 0
            })
        })
    }.call(this),
    function() {
        window.InstantClick && InstantClick.on("change", function(e) {
            return jdgm._doneSetup = null
        })
    }.call(this),
    function() {
        var e;
        e = {
            pagination: 5,
            disable_web_reviews: !1,
            badge_no_review_text: "No reviews",
            badge_n_reviews_text: "{{ n }} review/reviews",
            badge_star_color: "",
            hide_badge_preview_if_no_reviews: !1,
            badge_hide_text: !1,
            enforce_center_preview_badge: !1,
            widget_title: "Customer Reviews",
            widget_open_form_text: "Write a review",
            widget_close_form_text: "Cancel review",
            widget_refresh_page_text: "Refresh page",
            widget_summary_text: "Based on {{ number_of_reviews }} review/reviews",
            widget_no_review_text: "Be the first to write a review",
            widget_name_field_text: "Name",
            widget_verified_name_field_text: "Verified Name (public)",
            widget_name_placeholder_text: "Enter your name (public)",
            widget_required_field_error_text: "This field is required.",
            widget_email_field_text: "Email",
            widget_verified_email_field_text: "Verified Email (private, can not be edited)",
            widget_email_placeholder_text: "Enter your email (private)",
            widget_email_field_error_text: "Please enter a valid email address.",
            widget_rating_field_text: "Rating",
            widget_review_title_field_text: "Review Title",
            widget_review_title_placeholder_text: "Give your review a title",
            widget_review_body_field_text: "Review",
            widget_review_body_placeholder_text: "Write your comments here",
            widget_pictures_field_text: "Picture/Video (optional)",
            widget_submit_review_text: "Submit Review",
            widget_submit_verified_review_text: "Submit Verified Review",
            widget_submit_success_msg_with_auto_publish: 'Thank you! Please refresh the page in a few moments to see your review. You can remove or edit your review by logging into <a href="https://judge.me/login" target="_blank" rel="nofollow noopener">Judge.me</a>',
            widget_submit_success_msg_no_auto_publish: 'Thank you! Your review will be published as soon as it is approved by the shop admin. You can remove or edit your review by logging into <a href="https://judge.me/login" target="_blank" rel="nofollow noopener">Judge.me</a>',
            widget_show_default_reviews_out_of_total_text: "Showing {{ n_reviews_shown }} out of {{ n_reviews }} reviews.",
            widget_show_all_link_text: "Show all",
            widget_show_less_link_text: "Show less",
            widget_author_said_text: "{{ reviewer_name }} said:",
            widget_days_text: "{{ n }} days ago",
            widget_weeks_text: "{{ n }} week/weeks ago",
            widget_months_text: "{{ n }} month/months ago",
            widget_years_text: "{{ n }} year/years ago",
            widget_yesterday_text: "yesterday",
            widget_today_text: "today",
            widget_replied_text: ">> {{ shop_name }} replied:",
            widget_read_more_text: "Read more",
            widget_reviewer_name_as_initial: "",
            widget_rating_filter_color: "#fbcd0a",
            widget_rating_filter_see_all_text: "See all reviews",
            widget_sorting_most_recent_text: "Most Recent",
            widget_sorting_highest_rating_text: "Highest Rating",
            widget_sorting_lowest_rating_text: "Lowest Rating",
            widget_sorting_with_pictures_text: "Only Pictures",
            widget_sorting_most_helpful_text: "Most Helpful",
            widget_open_question_form_text: "Ask a question",
            widget_reviews_subtab_text: "Reviews",
            widget_questions_subtab_text: "Questions",
            widget_question_label_text: "Question",
            widget_answer_label_text: "Answer",
            widget_question_placeholder_text: "Write your question here",
            widget_submit_question_text: "Submit Question",
            widget_question_submit_success_text: "Thank you for your question! We will notify you once it gets answered.",
            widget_star_color: "",
            verified_badge_text: "Verified",
            verified_badge_bg_color: "",
            verified_badge_text_color: "",
            verified_badge_placement: "left-of-reviewer-name",
            widget_review_max_height: "",
            widget_hide_border: !1,
            widget_social_share: !1,
            widget_thumb: !1,
            widget_review_location_show: !1,
            widget_location_format: "",
            all_reviews_include_out_of_store_products: !0,
            all_reviews_out_of_store_text: "(out of store)",
            all_reviews_pagination: 100,
            all_reviews_product_name_prefix_text: "about",
            all_reviews_product_variant_label_text: "Variant: ",
            enable_review_pictures: !1,
            enable_question_anwser: !1,
            widget_theme: "default",
            review_date_format: "mm/dd/yyyy",
            default_sort_method: "most-recent",
            widget_product_reviews_subtab_text: "Product Reviews",
            widget_shop_reviews_subtab_text: "Shop Reviews",
            widget_write_a_store_review_text: "Write a Store Review",
            widget_other_languages_heading: "Reviews in Other Languages",
            show_product_url_for_grouped_product: !1,
            widget_sorting_pictures_first_text: "Pictures First",
            show_pictures_on_all_rev_page_mobile: !1,
            show_pictures_on_all_rev_page_desktop: !1,
            floating_tab_hide_mobile_install_preference: !1,
            floating_tab_button_name: "\u2605 Reviews",
            floating_tab_title: "Let customers speak for us",
            floating_tab_button_color: "",
            floating_tab_button_background_color: "",
            floating_tab_url: "",
            floating_tab_url_enabled: !1,
            floating_tab_tab_style: "text",
            all_reviews_text_badge_text: "Customers rate us {{ shop.metafields.judgeme.all_reviews_rating | round: 1 }}/5 based on {{ shop.metafields.judgeme.all_reviews_count }} reviews.",
            all_reviews_text_badge_text_branded_style: "{{ shop.metafields.judgeme.all_reviews_rating | round: 1 }} out of 5 stars based on {{ shop.metafields.judgeme.all_reviews_count }} reviews",
            is_all_reviews_text_badge_a_link: !1,
            show_stars_for_all_reviews_text_badge: !1,
            all_reviews_text_badge_url: "",
            all_reviews_text_style: "text",
            all_reviews_text_color_style: "judgeme_brand_color",
            all_reviews_text_color: "#108474",
            all_reviews_text_show_jm_brand: !0,
            featured_carousel_show_header: !0,
            featured_carousel_title: "Let customers speak for us",
            featured_carousel_count_text: "from {{ n }} reviews",
            featured_carousel_add_link_to_all_reviews_page: !1,
            featured_carousel_url: "",
            featured_carousel_show_images: !0,
            featured_carousel_autoslide_interval: 5,
            featured_carousel_arrows_on_the_sides: !1,
            featured_carousel_height: 250,
            featured_carousel_width: 80,
            featured_carousel_image_size: 0,
            featured_carousel_image_height: 250,
            featured_carousel_arrow_color: "#eeeeee",
            verified_count_badge_style: "vintage",
            verified_count_badge_orientation: "horizontal",
            verified_count_badge_color_style: "judgeme_brand_color",
            verified_count_badge_color: "#108474",
            is_verified_count_badge_a_link: !1,
            verified_count_badge_url: "",
            verified_count_badge_show_jm_brand: !0,
            widget_rating_preset_default: 5,
            widget_first_sub_tab: "product-reviews",
            widget_show_histogram: !0,
            widget_histogram_use_custom_color: !1,
            widget_pagination_use_custom_color: !1,
            widget_star_use_custom_color: !1,
            widget_verified_badge_use_custom_color: !1,
            widget_write_review_use_custom_color: !1,
            picture_reminder_submit_button: "Upload Pictures",
            enable_review_videos: !1,
            mute_video_by_default: !1,
            widget_sorting_videos_first_text: "Videos First",
            widget_review_pending_text: "Pending",
            featured_carousel_items_for_large_screen: 3,
            social_share_options_order: "Facebook,Twitter",
            remove_microdata_snippet: !1,
            disable_json_ld: !1,
            enable_json_ld_products: !1,
            preview_badge_show_question_text: !1,
            preview_badge_no_question_text: "No questions",
            preview_badge_n_question_text: "{{ number_of_questions }} question/questions",
            qa_badge_show_icon: !1,
            qa_badge_icon_color: null,
            qa_badge_position: "same-row",
            remove_judgeme_branding: !1,
            widget_add_search_bar: !1,
            widget_search_bar_placeholder: "Search reviews",
            widget_sorting_verified_only_text: "Verified only",
            featured_carousel_theme: "default",
            featured_carousel_show_rating: !0,
            featured_carousel_show_title: !0,
            featured_carousel_show_body: !0,
            featured_carousel_show_date: !1,
            featured_carousel_show_reviewer: !0,
            featured_carousel_show_product: !1,
            featured_carousel_header_background_color: "#108474",
            featured_carousel_header_text_color: "#ffffff",
            featured_carousel_name_product_separator: "reviewed",
            featured_carousel_full_star_background: "#108474",
            featured_carousel_empty_star_background: "#dadada",
            featured_carousel_vertical_theme_background: "#f9fafb",
            featured_carousel_verified_badge_enable: !1,
            featured_carousel_verified_badge_color: "#108474",
            featured_carousel_border_style: "round",
            featured_carousel_review_line_length_limit: 3,
            featured_carousel_more_reviews_button_text: "Read more reviews",
            featured_carousel_view_product_button_text: "View product",
            all_reviews_page_load_reviews_on: "scroll",
            all_reviews_page_load_more_text: "Load More Reviews",
            disable_fb_tab_reviews: !1,
            enable_ajax_cdn_cache: !1,
            widget_advanced_speed_features: null,
            widget_public_name_text: "displayed publicly like",
            default_reviewer_name: "John Smith",
            default_reviewer_name_has_non_latin: !0,
            widget_reviewer_anonymous: "Anonymous",
            medals_widget_title: "Judge.me Review Medals",
            medals_widget_background_color: "#f9fafb",
            medals_widget_position: "footer_all_pages",
            medals_widget_border_color: "#f9fafb",
            medals_widget_verified_text_position: "left",
            medals_widget_use_monochromatic_version: !1,
            medals_widget_elements_color: "#108474",
            show_reviewer_avatar: !0,
            widget_invalid_yt_video_url_error_text: "Not a YouTube video URL",
            widget_max_length_field_error_text: "Please enter no more than {0} characters.",
            widget_show_country_flag: !1,
            widget_show_collected_via_shop_app: !0,
            widget_verified_by_shop_badge_style: "light",
            widget_verified_by_shop_text: "Verified by Shop",
            widget_show_photo_gallery: !1,
            widget_load_with_code_splitting: !1,
            widget_ugc_install_preference: !1,
            widget_ugc_title: "Made by us, Shared by you",
            widget_ugc_subtitle: "Tag us to see your picture featured in our page",
            widget_ugc_arrows_color: "#ffffff",
            widget_ugc_primary_button_text: "Buy Now",
            widget_ugc_primary_button_background_color: "#108474",
            widget_ugc_primary_button_text_color: "#ffffff",
            widget_ugc_primary_button_border_width: "0",
            widget_ugc_primary_button_border_style: "none",
            widget_ugc_primary_button_border_color: "#108474",
            widget_ugc_primary_button_border_radius: "25",
            widget_ugc_secondary_button_text: "Load More",
            widget_ugc_secondary_button_background_color: "#ffffff",
            widget_ugc_secondary_button_text_color: "#108474",
            widget_ugc_secondary_button_border_width: "2",
            widget_ugc_secondary_button_border_style: "solid",
            widget_ugc_secondary_button_border_color: "#108474",
            widget_ugc_secondary_button_border_radius: "25",
            widget_ugc_reviews_button_text: "View Reviews",
            widget_ugc_reviews_button_background_color: "#ffffff",
            widget_ugc_reviews_button_text_color: "#108474",
            widget_ugc_reviews_button_border_width: "2",
            widget_ugc_reviews_button_border_style: "solid",
            widget_ugc_reviews_button_border_color: "#108474",
            widget_ugc_reviews_button_border_radius: "25",
            widget_ugc_reviews_button_link_to: "judgeme-reviews-page",
            widget_ugc_show_post_date: !0,
            widget_ugc_max_width: "800",
            widget_rating_metafield_value_type: !0,
            widget_primary_color: "#108474",
            widget_enable_secondary_color: !1,
            widget_secondary_color: "#edf5f5",
            widget_summary_average_rating_text: "{{ average_rating }} out of 5",
            widget_media_grid_title: "Customer photos & videos",
            widget_media_grid_see_more_text: "See more",
            widget_round_style: !1,
            widget_show_product_medals: !0,
            widget_verified_by_judgeme_text: "Verified by Judge.me",
            widget_show_store_medals: !0,
            widget_verified_by_judgeme_text_in_store_medals: "Verified by Judge.me",
            widget_media_field_exceed_quantity_message: "Sorry, we can only accept {{ max_media }} for one review.",
            widget_media_field_exceed_limit_message: "{{ file_name }} is too large, please select a {{ media_type }} less than {{ size_limit }}MB.",
            widget_review_submitted_text: "Review Submitted!",
            widget_question_submitted_text: "Question Submitted!",
            widget_close_form_text_question: "Cancel",
            widget_write_your_answer_here_text: "Write your answer here",
            widget_enabled_branded_link: !0,
            widget_show_collected_by_judgeme: !1,
            widget_reviewer_name_color: "",
            widget_write_review_text_color: "",
            widget_write_review_bg_color: "",
            widget_collected_by_judgeme_text: "collected by Judge.me",
            widget_pagination_type: "standard",
            widget_load_more_text: "Load More",
            widget_load_more_color: "#108474",
            widget_full_review_text: "Full Review",
            widget_read_more_reviews_text: "Read More Reviews",
            widget_read_questions_text: "Read Questions",
            widget_questions_and_answers_text: "Questions & Answers",
            widget_verified_by_text: "Verified by",
            widget_verified_text: "Verified",
            widget_number_of_reviews_text: "{{ number_of_reviews }} reviews",
            widget_back_button_text: "Back",
            widget_next_button_text: "Next",
            widget_custom_forms_filter_button: "Filters",
            custom_forms_style: "horizontal",
            widget_show_review_information: !1,
            how_reviews_are_collected: "How reviews are collected?",
            widget_show_review_keywords: !1,
            widget_gdpr_statement: "How we use your data: We\u2019ll only contact you about the review you left, and only if necessary. By submitting your review, you agree to Judge.me\u2019s <a href='https://judge.me/terms' target='_blank' rel='nofollow noopener'>terms</a>, <a href='https://judge.me/privacy' target='_blank' rel='nofollow noopener'>privacy</a> and <a href='https://judge.me/content-policy' target='_blank' rel='nofollow noopener'>content</a> policies.",
            widget_multilingual_sorting_enabled: !1,
            popup_widget_review_selection: "automatically_with_pictures",
            popup_widget_round_border_style: !0,
            popup_widget_show_title: !0,
            popup_widget_show_body: !0,
            popup_widget_show_reviewer: !1,
            popup_widget_show_product: !0,
            popup_widget_show_pictures: !0,
            popup_widget_use_review_picture: !0,
            popup_widget_show_on_home_page: !0,
            popup_widget_show_on_product_page: !0,
            popup_widget_show_on_collection_page: !0,
            popup_widget_show_on_cart_page: !0,
            popup_widget_position: "bottom_left",
            popup_widget_first_review_delay: 5,
            popup_widget_duration: 5,
            popup_widget_interval: 5,
            popup_widget_review_count: 5,
            popup_widget_hide_on_mobile: !0,
            review_snippet_widget_round_border_style: !0,
            review_snippet_widget_card_color: "#FFFFFF",
            review_snippet_widget_slider_arrows_background_color: "#FFFFFF",
            review_snippet_widget_slider_arrows_color: "#000000",
            review_snippet_widget_star_color: "#108474",
            preview_badge_collection_page_install_status: !1,
            widget_review_custom_css: "",
            preview_badge_custom_css: "",
            preview_badge_stars_count: "5-stars",
            featured_carousel_custom_css: "",
            floating_tab_custom_css: "",
            all_reviews_widget_custom_css: "",
            medals_widget_custom_css: "",
            verified_badge_custom_css: "",
            all_reviews_text_custom_css: "",
            checkout_comment_extension_title_on_product_page: "Customer Comments",
            checkout_comment_extension_num_latest_comment_show: 5,
            checkout_comment_extension_format: "name_and_timestamp",
            checkout_comment_customer_name: "last_initial",
            checkout_comment_comment_notification: !0,
            preview_badge_collection_page_install_preference: !1,
            preview_badge_home_page_install_preference: !1,
            preview_badge_product_page_install_preference: !1,
            review_widget_install_preference: "",
            review_carousel_install_preference: !1,
            floating_reviews_tab_install_preference: "none",
            verified_reviews_count_badge_install_preference: !1,
            all_reviews_text_install_preference: !1,
            review_widget_best_location: !1,
            judgeme_medals_install_preference: !1,
            platform: "shopify",
            branding_url: "https://judge.me/reviews",
            branding_text: "Powered by Judge.me",
            widget_show_verified_branding: !0,
            locale: "en"
        }, jdgm.$(function(t) {
            var n, r, i, o, a;
            return n = {
                cbFormAdded: t.noop,
                cbRevSubmitSuccess: t.noop,
                openForm: null,
                closeForm: null,
                submitBtnClassname: null,
                cancelBtnClassname: null,
                scrollTopOffset: 30,
                scrollTo: t.noop,
                openReviewTab: null,
                revTabSelector: null,
                preloadPictures: !1,
                jldDisable: !1,
                jldCanonicalUrl: null,
                jldProductTitle: null,
                removeMicrodata: !1,
                autoSlideInterval: 5,
                carouselNoAutoSlide: !1,
                carouselHeightLimitDelay: 0,
                smallReviewWidget: !1,
                leexPicWidth: 360,
                productUrlBuilder: null,
                ajaxCdnCacheTtl: 1200,
                leexDesktopPreload: 6,
                leexMobilePreload: 1
            }, i = function() {
                var e;
                return e = t("<a class='jdgm-random-link jdgm-hidden' href='#' rel='nofollow' style='display: none;'>Judge.me</a>"), t("body").append(e), "rgb(0, 0, 238)" === window.getComputedStyle(e[0]).color ? (jdgmSettings.linkColor = "#fbcd0a", jdgmSettings.buttonColor = "currentColor") : (jdgmSettings.linkColor = e.css("color"), jdgmSettings.buttonColor = e.css("color")), jdgmSettings.bgColor = e.css("backgroundColor"), jdgm.hasBgColor(e) ? void 0 : jdgmSettings.bgColor = "#ffffff"
            }, a = function() {
                var e, n;
                return n = ".jdgm-settings-style, .jdgm-miracle-styles", e = /<span[^<]+>|<\/span>/g, t.each(t(n), function(n, r) {
                    var i, o;
                    return i = t(r), o = i.html(), o = o.replaceAll(e, ""), i.html(o)
                })
            }, o = function() {
                var e, t, n;
                t = [];
                for (e in jdgmSettings) n = jdgmSettings[e], "string" == typeof n ? t.push(jdgmSettings[e] = r(n)) : t.push(void 0);
                return t
            }, r = function(e) {
                var t, n, r, i, o, a, s;
                if (o = e, s = /<span class='notranslate'>([^<]+)<\/span>/g, i = o.match(s), i && i.length > 0)
                    for (t = 0, n = i.length; n > t; t++) r = i[t], a = s.exec(r), s.lastIndex = 0, a && (o = o.replace(r, a[1]));
                return o
            }, i(), a(), o(), jdgm.originalSettings = jdgmSettings, window.jdgmSettings = t.extend({}, e, n, jdgmSettings, window.judgemeOpts)
        })
    }.call(this),
    function() {
        var e, t, n;
        e = jdgm.$, t = function() {
            return (new Date).getTime()
        }, jdgm.DONE_SETUP_CLASS = "jdgm--done-setup", jdgm.DONE_SETUP_WIDGET_CLASS = "jdgm--done-setup-widget", jdgm.REVIEWS_NEEDING_SETUP_SELECTOR = ".jdgm-rev:not(." + jdgm.DONE_SETUP_CLASS + ")", jdgm.HTTPS_HOST = "https://judge.me", jdgm.API_HOST = "https://api.judge.me", jdgm.WIDGET_TRACKING_API_HOST = "https://tracking.aws.judge.me", jdgm.CDN_HOST = jdgm.CDN_HOST || "https://cdnwidget.judge.me/", jdgm.SPECIAL_CDN_HOST = "cdn.judge.me", jdgm.SPECIAL_CDN_HOST_HTTPS = "https://" + jdgm.SPECIAL_CDN_HOST, jdgm.JM_PUBLIC_IMAGE_URL = "https://judgeme-public-images.imgix.net/judgeme/", jdgm.LANGUAGES_WITH_UNSUPPORTED_REGIONS = {
            "pt-br": "pt",
            "pt-pt": "pt",
            "zh-ch": "zh",
            "zh-tw": "zh"
        }, e.urlParam = function(e) {
            var t;
            return t = new RegExp("[\\?&]" + e + "=([^&#]*)").exec(window.location.href), t ? t[1] || void 0 : void 0
        }, e.fn.serializeJSON = function() {
            var t, n;
            return n = {}, t = e(this), t.find("input, select").each(function() {
                var t;
                if (t = void 0, this.name) {
                    if ("radio" === this.type) {
                        if (n[this.name]) return;
                        return n[this.name] = this.checked ? this.value : ""
                    }
                    return "checkbox" !== this.type ? (t = n[this.name], n[this.name] = "string" == typeof t ? [t, this.value] : e.isArray(t) ? e.merge(t, [this.value]) : this.value) : (t = n[this.name], this.checked ? n[this.name] = "string" == typeof t ? [t, this.value] : e.isArray(t) ? e.merge(t, [this.value]) : this.value : t ? void 0 : n[this.name] = "")
                }
            }), n
        }, jdgm.asyncEach = function(e, n, r, i, o) {
            var a, s;
            return null == r && (r = 200), null == i && (i = window), null == o && (o = 1), a = function() {
                var u;
                for (u = t(); s < e.length && t() - u <= r;) n.call(i, e[s], s, e), ++s;
                return s < e.length ? setTimeout(a, o) : void 0
            }, s = 0, a()
        }, jdgm.uniq = function(t) {
            return e.grep(t, function(n, r) {
                return r === e.inArray(n, t)
            })
        }, jdgm.random = function(e) {
            return Math.floor(Math.random() * e + 1)
        }, jdgm.shopifyDomain = function() {
            return window.Shopify ? Shopify.shop : void 0
        }, jdgm.shopDomain = function() {
            return jdgm.SHOP_DOMAIN || jdgm.shopifyDomain() || document.domain
        }, jdgm.shopParams = function() {
            return {
                url: jdgm.shopDomain(),
                shop_domain: jdgm.shopDomain(),
                platform: jdgmSettings.platform
            }
        }, jdgm.truncate = function(e, t) {
            return e.length <= t ? e : e.substring(0, t - 3) + "..."
        }, jdgm.hasBgColor = function(e) {
            var t;
            return t = e.css("background-color"), "rgba(0, 0, 0, 0)" !== t && "transparent" !== t
        }, jdgm.scrollTo = function(t, n) {
            return n = n || 0, jdgmSettings.scrollTo(t, n) !== !1 ? e("html,body").animate({
                scrollTop: t.offset().top - n
            }) : void 0
        }, jdgm.triggerEvent = function(t, n) {
            return e(document).trigger("jdgm." + t, n)
        }, jdgm.triggerVanillaEvent = function(e, t) {
            var n;
            return n = new CustomEvent("jdgm." + e, {
                detail: t
            }), document.dispatchEvent(n)
        }, jdgm.setupLazyLoadPicture = function(t, n) {
            return null == n && (n = 200), t.unveil(n, function() {
                var t;
                return t = e(this).parent(".jdgm--loading"), t ? t.removeClass("jdgm--loading") : void 0
            }), setTimeout(function() {
                return jdgm.ScrollEvent.trigger("unveil")
            })
        }, jdgm._loadSvg = function(t, n, r, i, o) {
            var a, s;
            return null == i && (i = !1), null == o && (o = !1), i ? e.ajax({
                url: "" + r + t.data("url") + "?auto=format",
                success: function(n) {
                    var r, i, o;
                    return r = e("<span class='jdgm-svg__mono' role='img'><span>"), r.attr("aria-label", t.data("alt")), void 0 === e(n.documentElement).attr("viewBox") && (o = e(n.documentElement).attr("width"), i = e(n.documentElement).attr("height"), e(n.documentElement).attr("viewBox", "0 0 " + o + " " + i)), r.html((new XMLSerializer).serializeToString(n.documentElement)), t.html(r), t.parent().removeClass("jdgm--loading")
                }
            }) : (a = e("<img />"), a.attr("alt", t.data("alt")), s = "" + n + t.data("url") + "?auto=format", o ? a.attr("data-src", s) : a.attr("src", s), t.html(a), t.parent().removeClass("jdgm--loading"))
        }, jdgm.compact = function(e) {
            return e.filter(Boolean)
        }, jdgm.compactHash = function(e) {
            return Object.keys(e).forEach(function(t) {
                return null === e[t] || void 0 === e[t] ? delete e[t] : void 0
            }), e
        }, jdgm.times = function(e, t) {
            var n, r, i, o;
            for (o = [], n = r = 0, i = e; i >= 0 ? i > r : r > i; n = i >= 0 ? ++r : --r) o.push(t(n));
            return o
        }, n = document.createElement("textarea"), jdgm.escapeHTML = function(e) {
            return n.textContent = e, n.innerHTML
        }, jdgm.urlParamsAsHash = function(e) {
            var t, n, r, i, o;
            if (null == e && (e = null), e) i = e.split("?")[1], r = i ? i.split("&") : [];
            else {
                if (location.search.length <= 0) return {};
                r = location.search.substring(1).split("&")
            }
            for (o = {}, t = 0; t < r.length;) n = r[t].split("="), o[decodeURIComponent(n[0])] = decodeURIComponent(n[1]), t++;
            return o
        }, jdgm.isWidgetLoadMore = function() {
            return "load_more" === jdgmSettings.widget_pagination_type
        }, jdgm.isInViewport = function(e, t) {
            var n, r;
            return null == t && (t = 1), null === e.offsetParent ? !1 : (r = e.getBoundingClientRect(), n = r.bottom - r.height * (1 - t), r.top >= 0 && r.left >= 0 && n <= (window.innerHeight || document.documentElement.clientHeight) && r.right <= (window.innerWidth || document.documentElement.clientWidth))
        }, jdgm._htmlFor = function(e, t) {
            return JST["templates/shopify_v2/" + e](t)
        }, jdgm._safeRun = function(e, t) {
            return null == t && (t = 99), setTimeout(function() {
                try {
                    return e()
                } catch (t) {}
            }, t)
        }, jdgm.normalizeLanguage = function(e) {
            var t;
            return e ? (t = e.toLowerCase(), jdgm.LANGUAGES_WITH_UNSUPPORTED_REGIONS[t] || t) : e
        }
    }.call(this),
    function() {
        var e, t, n, r, i;
        e = jdgm.$, r = !1, t = [], n = {}, jdgm.ScrollEvent = {
            attach: function(e, r) {
                return r ? (n[r] = n[r] || [], n[r].push(e)) : t.push(e)
            },
            dettach: function(e) {
                return delete n[e]
            },
            trigger: function(e) {
                var t;
                return t = n[e], i(t)
            },
            scrollInsideContainer: function(t) {
                return e(t).on("scroll", function() {
                    return r = !0
                })
            }
        }, i = function(t) {
            return e.each(t, function(t, n) {
                return e.isFunction(n) ? n() : void 0
            })
        }, e(window).on("scroll", function() {
            return r = !0
        }), setInterval(function() {
            return r ? (r = !1, i(t), e.each(n, function(e, t) {
                return i(t)
            })) : void 0
        }, 250)
    }.call(this),
    function() {
        var e, t, n, r;
        e = jdgm.$, jdgm.buildStarsFor = function(e, t) {
            return e.find(".jdgm-star").length > 0 ? void 0 : (t = t || e.data("score"), e.html(n(t)))
        }, r = function(e) {
            return Math.round(2 * e) / 2
        }, t = function(e) {
            return "<span class='jdgm-star jdgm--" + e + "'></span>"
        }, n = function(e) {
            var n, i, o, a, s, u;
            for (u = r(parseFloat(e)), n = Math.floor(u), i = u % 1 === .5, s = 5, a = "", o = 0; n > o;) a += t("on"), s--, o++;
            for (i && (a += t("half"), s--), o = 0; s > o;) a += t("off"), o++;
            return a
        }
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, n;
            return t = [".jdgm-histogram__row", ".jdgm-paginate__page", ".jdgm-prev-badge", ".jdgm-subtab__name", ".jdgm-rev__thumb-btn", ".jdgm-rev__share-btn", ".jdgm-carousel__left-arrow", ".jdgm-carousel__right-arrow", ".jdgm-form .jdgm-star", ".jdgm-revs-tab-btn", ".jdgm-form-dynamic__back", ".jdgm-form-dynamic__next", ".jdgm-form-dynamic .jdgm-star", ".jdgm-rev__body-read-more"].join(", "), n = function(e) {
                return [32, 13].includes(e.keyCode) ? e.currentTarget.click() : void 0
            }, e(document).on("keyup", t, n)
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, n, r, i, o, a, s, u, l, d, c, f, p, g, h, m, _, v, w;
            return t = 1e3, a = {
                "jdgm-preview-badge": "preview_badge",
                "jdgm-review-widget": "review_widget",
                "jdgm-medals-wrapper": "medals",
                "jdgm-verified-badge": "verified_badge",
                "jdgm-ugc-media-wrapper": "ugc_media",
                "jdgm-revs-tab": "reviews_tab",
                "jdgm-revs-tab__main": "reviews_tab",
                "jdgm-carousel": "carousel",
                "jdgm-all-reviews-widget": "all_reviews_page",
                "jdgm-all-reviews-text": "all_reviews_text",
                "jdgm-comment-widget": "checkout_comment",
                "jdgm-popup-widget": "popup_widget",
                "jdgm-review-snippet-widget": "review_snippet_widget"
            }, n = [".jdgm-review-widget", ".jdgm-carousel", ".jdgm-comment-widget", ".jdgm-widget.jdgm-medals-wrapper", ".jdgm-verified-badge", ".jdgm-ugc-media-wrapper", ".jdgm-all-reviews-widget", ".jdgm-revs-tab", ".jdgm-revs-tab__main", ".jdgm-popup-widget", ".jdgm-review-snippet-widget", ".jdgm-preview-badge"], s = {
                preview_badge: "data-id",
                review_widget: "data-id",
                checkout_comment: "data-id"
            }, o = .01, jdgm._widgetEvents = [], w = null, r = 2e3, i = 20, jdgm._recordWidgetClick = function(e) {
                return _(e, "clicks")
            }, h = function() {
                var t;
                return t = e(".jdgm-widget:not([data-widget-name]):not(.jdgm-hidden)"), jdgm.asyncEach(t, function(t) {
                    return l(e(t))
                }), v(t), g(t)
            }, v = function(t) {
                return jdgm.asyncEach(t, function(t) {
                    return _(e(t), "impressions")
                })
            }, g = function(t) {
                var n, r, i;
                return n = function(t, n) {
                    return t.forEach(function(t) {
                        var r;
                        return t.intersectionRatio > 0 && !t.target.dataset["views-tracked"] ? (r = e(t.target), _(r, "views"), jdgm.triggerVanillaEvent("widgetViewed", {
                            $widget: r
                        }), n.unobserve(t.target)) : void 0
                    })
                }, r = new IntersectionObserver(n, {
                    threshold: 0
                }), jdgm.asyncEach(t, function(e) {
                    return r.observe(e)
                }), i = document.querySelector(".jdgm-revs-tab__main"), i ? r.observe(i) : void 0
            }, p = function() {
                return e(document).on("click", ".jdgm-widget[data-widget-name]", function(t) {
                    var n;
                    return n = e(t.currentTarget), jdgm._recordWidgetClick(n), jdgm.triggerVanillaEvent("widgetClicked", {
                        $widget: n
                    })
                })
            }, l = function(t) {
                var n, r;
                return t.length <= 0 ? null : (n = t[0], r = null, e.each(t[0].classList, function(e, t) {
                    return a[t] ? (r = a[t], !1) : void 0
                }), r || (r = n.classList[1] || "unknown"), t.attr("data-widget-name", r), r)
            }, m = function() {
                return {
                    shop_domain: jdgm.shopDomain(),
                    platform: jdgmSettings.platform
                }
            }, _ = function(e, t) {
                var n, r, i, a;
                if (!e[0].dataset[t + "Tracked"]) return a = e.data("widget-name"), n = {
                    name: a,
                    event_key: t
                }, i = d(e, a), i && (n.external_product_id = i), r = u(a), r && (n.location = r), "preview_badge" === a && Math.random() > o ? void(e[0].dataset[t + "Tracked"] = !0) : (jdgm._widgetEvents.push(n), c(), e[0].dataset[t + "Tracked"] = !0)
            }, d = function(e, t) {
                var n, r;
                return r = s[t], r && (n = e.attr(r)), n
            }, u = function(e) {
                var t;
                return t = window.location.pathname, "preview_badge" !== e ? null : t.startsWith("/products/") || t.startsWith("/collections/") && t.indexOf("/products/") > -1 ? "product" : t.startsWith("/collections/") ? "collection" : "/cart" === t ? "cart" : "/" === t ? "home" : null
            }, c = function() {
                return w || (w = setTimeout(f, r))
            }, f = function() {
                var t, n;
                if (!(jdgm._widgetEvents.length <= 0)) return n = jdgm._widgetEvents.splice(0, i), t = e.extend(m(), {
                    events: n
                }), e.ajax({
                    url: jdgm.WIDGET_TRACKING_API_HOST + "/widgets/track_bulk_events?_events_count=" + n.length,
                    method: "POST",
                    data: t
                }), w = null, jdgm._widgetEvents.length > 0 ? c() : void 0
            }, setTimeout(function() {
                return l(e(".jdgm-revs-tab__main")), h(), p()
            }, t), setInterval(h, 1e4)
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, n, r, i, o, a, s;
            return n = 1e3, r = "jdgm_widget_interactions", t = {}, s = function() {
                return document.addEventListener("jdgm.widgetViewed", function(e) {
                    return i(e.detail.$widget, "viewed")
                }), document.addEventListener("jdgm.widgetClicked", function(e) {
                    return i(e.detail.$widget, "clicked")
                })
            }, i = function(e, n) {
                var r;
                return !e.hasClass("jdgm-review-widget") && !e.hasClass("jdgm-preview-badge") || (r = e.data("id"), t[r + "-" + n]) ? void 0 : (t[r + "-" + n] = !0, a(r, n, e.data("widget-name")))
            }, a = function(e, t, n) {
                var i, o, a, s;
                return a = localStorage.getItem(r) || "{}", o = JSON.parse(a), s = n + "--" + t, o[e] = o[e] || {}, (i = o[e])[s] || (i[s] = 0), o[e][s] += 1, localStorage.setItem(r, JSON.stringify(o))
            }, o = function() {
                try {
                    return window.Shopify && window.Shopify.customerPrivacy ? window.Shopify.customerPrivacy.analyticsProcessingAllowed() : !1
                } catch (e) {
                    return console.warn("Something went wrong with Shopify.customerPrivacy API"), !1
                }
            }, window.Shopify && window.Shopify.loadFeatures ? window.Shopify.loadFeatures([{
                name: "consent-tracking-api",
                version: "0.1"
            }], function(e) {
                return e ? console.warn("Cannot load consent-tracking-api via Shopify.loadFeatures API") : o() ? setTimeout(s, n) : void 0
            }) : void 0
        })
    }.call(this);