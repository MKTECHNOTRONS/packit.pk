! function(e) {
    var t = void 0;
    "function" == typeof t && t.amd ? t(["jquery"], e) : e("object" == typeof exports ? require("jquery") : window.jQuery || window.Zepto)
}(function(e) {
    e = jdgm.$ || window.$;
    var t, a, r, n, i, o, l = "Close",
        s = "BeforeClose",
        d = "AfterClose",
        p = "BeforeAppend",
        c = "MarkupParse",
        m = "Open",
        u = "Change",
        g = "jm-mfp",
        _ = "." + g,
        f = "jm-mfp-ready",
        v = "jm-mfp-removing",
        h = "jm-mfp-prevent-close",
        j = function() {},
        w = !!e,
        y = e(window),
        b = function(e, a) {
            t.ev.on(g + e + _, a)
        },
        x = function(t, a, r, n) {
            var i = document.createElement("div");
            return i.className = "jm-mfp-" + t, r && (i.innerHTML = r), n ? a && a.appendChild(i) : (i = e(i), a && i.appendTo(a)), i
        },
        C = function(a, r) {
            t.ev.triggerHandler(g + a, r), t.st.callbacks && (a = a.charAt(0).toLowerCase() + a.slice(1), t.st.callbacks[a] && t.st.callbacks[a].apply(t, e.isArray(r) ? r : [r]))
        },
        k = function(a) {
            return a === o && t.currTemplate.closeBtn || (t.currTemplate.closeBtn = e(t.st.closeMarkup.replace("%title%", t.st.tClose)), o = a), t.currTemplate.closeBtn
        },
        T = function() {
            e.magnificPopup.instance || (t = new j, t.init(), e.magnificPopup.instance = t)
        },
        S = function() {
            var e = document.createElement("p").style,
                t = ["ms", "O", "Moz", "Webkit"];
            if (void 0 !== e.transition) return !0;
            for (; t.length;)
                if (t.pop() + "Transition" in e) return !0;
            return !1
        };
    j.prototype = {
        constructor: j,
        init: function() {
            var a = navigator.appVersion;
            t.isLowIE = t.isIE8 = document.all && !document.addEventListener, t.isAndroid = /android/gi.test(a), t.isIOS = /iphone|ipad|ipod/gi.test(a), t.supportsTransition = S(), t.probablyMobile = t.isAndroid || t.isIOS || /(Opera Mini)|Kindle|webOS|BlackBerry|(Opera Mobi)|(Windows Phone)|IEMobile/i.test(navigator.userAgent), r = e(document), t.popupsCache = {}
        },
        open: function(a) {
            var n;
            if (a.isObj === !1) {
                t.items = a.items.toArray(), t.index = 0;
                var o, l = a.items;
                for (n = 0; n < l.length; n++)
                    if (o = l[n], o.parsed && (o = o.el[0]), o === a.el[0]) {
                        t.index = n;
                        break
                    }
            } else t.items = e.isArray(a.items) ? a.items : [a.items], t.index = a.index || 0;
            if (t.isOpen) return void t.updateItemHTML();
            t.types = [], i = "", a.mainEl && a.mainEl.length ? t.ev = a.mainEl.eq(0) : t.ev = r, a.key ? (t.popupsCache[a.key] || (t.popupsCache[a.key] = {}), t.currTemplate = t.popupsCache[a.key]) : t.currTemplate = {}, t.st = e.extend(!0, {}, e.magnificPopup.defaults, a), t.fixedContentPos = "auto" === t.st.fixedContentPos ? !t.probablyMobile : t.st.fixedContentPos, t.st.modal && (t.st.closeOnContentClick = !1, t.st.closeOnBgClick = !1, t.st.showCloseBtn = !1, t.st.enableEscapeKey = !1), t.bgOverlay || (t.bgOverlay = x("bg").on("click" + _, function() {
                t.close()
            }), t.wrap = x("wrap").attr("tabindex", -1).on("click" + _, function(e) {
                t._checkIfClose(e.target) && t.close()
            }), t.container = x("container", t.wrap)), t.contentContainer = x("content"), t.st.preloader && (t.preloader = x("preloader", t.container, t.st.tLoading));
            var s = e.magnificPopup.modules;
            for (n = 0; n < s.length; n++) {
                var d = s[n];
                d = d.charAt(0).toUpperCase() + d.slice(1), t["init" + d].call(t)
            }
            C("BeforeOpen"), t.st.showCloseBtn && (t.st.closeBtnInside ? (b(c, function(e, t, a, r) {
                a.close_replaceWith = k(r.type)
            }), i += " jm-mfp-close-btn-in") : t.wrap.append(k())), t.st.alignTop && (i += " jm-mfp-align-top"), t.fixedContentPos ? t.wrap.css({
                overflow: t.st.overflowY,
                overflowX: "hidden",
                overflowY: t.st.overflowY
            }) : t.wrap.css({
                top: y.scrollTop(),
                position: "absolute"
            }), (t.st.fixedBgPos === !1 || "auto" === t.st.fixedBgPos && !t.fixedContentPos) && t.bgOverlay.css({
                height: r.height(),
                position: "absolute"
            }), t.st.enableEscapeKey && r.on("keyup" + _, function(e) {
                27 === e.keyCode && t.close()
            }), y.on("resize" + _, function() {
                t.updateSize()
            }), t.st.closeOnContentClick || (i += " jm-mfp-auto-cursor"), i && t.wrap.addClass(i);
            var p = t.wH = y.height(),
                u = {};
            if (t.fixedContentPos && t._hasScrollBar(p)) {
                var g = t._getScrollbarSize();
                g && (u.marginRight = g)
            }
            t.fixedContentPos && (t.isIE7 ? e("body, html").css("overflow", "hidden") : u.overflow = "hidden");
            var v = t.st.mainClass;
            return t.isIE7 && (v += " jm-mfp-ie7"), v && t._addClassToMFP(v), t.updateItemHTML(), C("BuildControls"), e("html").css(u), t.bgOverlay.add(t.wrap).prependTo(t.st.prependTo || e(document.body)), t._lastFocusedEl = document.activeElement, setTimeout(function() {
                t.content ? (t._addClassToMFP(f), t._setFocus()) : t.bgOverlay.addClass(f), r.on("focusin" + _, t._onFocusIn)
            }, 16), t.isOpen = !0, t.updateSize(p), C(m), a
        },
        close: function() {
            t.isOpen && (C(s), t.isOpen = !1, t.st.removalDelay && !t.isLowIE && t.supportsTransition ? (t._addClassToMFP(v), setTimeout(function() {
                t._close()
            }, t.st.removalDelay)) : t._close())
        },
        _close: function() {
            C(l);
            var a = v + " " + f + " ";
            if (t.bgOverlay.detach(), t.wrap.detach(), t.container.empty(), t.st.mainClass && (a += t.st.mainClass + " "), t._removeClassFromMFP(a), t.fixedContentPos) {
                var n = {
                    marginRight: ""
                };
                t.isIE7 ? e("body, html").css("overflow", "") : n.overflow = "", e("html").css(n)
            }
            r.off("keyup" + _ + " focusin" + _), t.ev.off(_), t.wrap.attr("class", "jm-mfp-wrap").removeAttr("style"), t.bgOverlay.attr("class", "jm-mfp-bg"), t.container.attr("class", "jm-mfp-container"), !t.st.showCloseBtn || t.st.closeBtnInside && t.currTemplate[t.currItem.type] !== !0 || t.currTemplate.closeBtn && t.currTemplate.closeBtn.detach(), t.st.autoFocusLast && t._lastFocusedEl && e(t._lastFocusedEl).focus(), t.currItem = null, t.content = null, t.currTemplate = null, t.prevHeight = 0, C(d)
        },
        updateSize: function(e) {
            if (t.isIOS) {
                var a = document.documentElement.clientWidth / window.innerWidth,
                    r = window.innerHeight * a;
                t.wrap.css("height", r), t.wH = r
            } else t.wH = e || y.height();
            t.fixedContentPos || t.wrap.css("height", t.wH), C("Resize")
        },
        updateItemHTML: function() {
            var a = t.items[t.index];
            t.contentContainer.detach(), t.content && t.content.detach(), a.parsed || (a = t.parseEl(t.index));
            var r = a.type;
            if (C("BeforeChange", [t.currItem ? t.currItem.type : "", r]), t.currItem = a, !t.currTemplate[r]) {
                var i = t.st[r] ? t.st[r].markup : !1;
                C("FirstMarkupParse", i), i ? t.currTemplate[r] = e(i) : t.currTemplate[r] = !0
            }
            n && n !== a.type && t.container.removeClass("jm-mfp-" + n + "-holder");
            var o = t["get" + r.charAt(0).toUpperCase() + r.slice(1)](a, t.currTemplate[r]);
            t.appendContent(o, r), a.preloaded = !0, C(u, a), n = a.type, t.container.prepend(t.contentContainer), C("AfterChange")
        },
        appendContent: function(e, a) {
            t.content = e, e ? t.st.showCloseBtn && t.st.closeBtnInside && t.currTemplate[a] === !0 ? t.content.find(".jm-mfp-close").length || t.content.append(k()) : t.content = e : t.content = "", C(p), t.container.addClass("jm-mfp-" + a + "-holder"), t.contentContainer.append(t.content)
        },
        parseEl: function(a) {
            var r, n = t.items[a];
            if (n.tagName ? n = {
                    el: e(n)
                } : (r = n.type, n = {
                    data: n,
                    src: n.src
                }), n.el) {
                for (var i = t.types, o = 0; o < i.length; o++)
                    if (n.el.hasClass("jm-mfp-" + i[o])) {
                        r = i[o];
                        break
                    }
                n.src = n.el.attr("data-mfp-src"), n.src || (n.src = n.el.attr("href"))
            }
            return n.type = r || t.st.type || "inline", n.index = a, n.parsed = !0, t.items[a] = n, C("ElementParse", n), t.items[a]
        },
        addGroup: function(e, a) {
            var r = function(r) {
                r.mfpEl = this, t._openClick(r, e, a)
            };
            a || (a = {});
            var n = "click.magnificPopup";
            a.mainEl = e, a.items ? (a.isObj = !0, e.off(n).on(n, r)) : (a.isObj = !1, a.delegate ? e.off(n).on(n, a.delegate, r) : (a.items = e, e.off(n).on(n, r)))
        },
        _openClick: function(a, r, n) {
            var i = void 0 !== n.midClick ? n.midClick : e.magnificPopup.defaults.midClick;
            if (i || !(2 === a.which || a.ctrlKey || a.metaKey || a.altKey || a.shiftKey)) {
                var o = void 0 !== n.disableOn ? n.disableOn : e.magnificPopup.defaults.disableOn;
                if (o)
                    if (e.isFunction(o)) {
                        if (!o.call(t)) return !0
                    } else if (y.width() < o) return !0;
                a.type && (a.preventDefault(), t.isOpen && a.stopPropagation()), n.el = e(a.mfpEl), n.delegate && (n.items = r.find(n.delegate)), t.open(n)
            }
        },
        updateStatus: function(e, r) {
            if (t.preloader) {
                a !== e && t.container.removeClass("jm-mfp-s-" + a), r || "loading" !== e || (r = t.st.tLoading);
                var n = {
                    status: e,
                    text: r
                };
                C("UpdateStatus", n), e = n.status, r = n.text, t.preloader.html(r), t.preloader.find("a").on("click", function(e) {
                    e.stopImmediatePropagation()
                }), t.container.addClass("jm-mfp-s-" + e), a = e
            }
        },
        _checkIfClose: function(a) {
            if (!e(a).hasClass(h)) {
                var r = t.st.closeOnContentClick,
                    n = t.st.closeOnBgClick;
                if (r && n) return !0;
                if (!t.content || e(a).hasClass("jm-mfp-close") || t.preloader && a === t.preloader[0]) return !0;
                if (a === t.content[0] || e.contains(t.content[0], a)) {
                    if (r) return !0
                } else if (n && e.contains(document, a)) return !0;
                return !1
            }
        },
        _addClassToMFP: function(e) {
            t.bgOverlay.addClass(e), t.wrap.addClass(e)
        },
        _removeClassFromMFP: function(e) {
            this.bgOverlay.removeClass(e), t.wrap.removeClass(e)
        },
        _hasScrollBar: function(e) {
            return (t.isIE7 ? r.height() : document.body.scrollHeight) > (e || y.height())
        },
        _setFocus: function() {
            (t.st.focus ? t.content.find(t.st.focus).eq(0) : t.wrap).focus()
        },
        _onFocusIn: function(a) {
            return a.target === t.wrap[0] || e.contains(t.wrap[0], a.target) ? void 0 : (t._setFocus(), !1)
        },
        _parseMarkup: function(t, a, r) {
            var n;
            r.data && (a = e.extend(r.data, a)), C(c, [t, a, r]), e.each(a, function(a, r) {
                if (void 0 === r || r === !1) return !0;
                if (n = a.split("_"), n.length > 1) {
                    var i = t.find(_ + "-" + n[0]);
                    if (i.length > 0) {
                        var o = n[1];
                        "replaceWith" === o ? i[0] !== r[0] && i.replaceWith(r) : "img" === o ? i.is("img") ? i.attr("src", r) : i.replaceWith(e("<img>").attr("src", r).attr("class", i.attr("class"))) : i.attr(n[1], r)
                    }
                } else t.find(_ + "-" + a).html(r)
            })
        },
        _getScrollbarSize: function() {
            if (void 0 === t.scrollbarSize) {
                var e = document.createElement("div");
                e.style.cssText = "width: 99px; height: 99px; overflow: scroll; position: absolute; top: -9999px;", document.body.appendChild(e), t.scrollbarSize = e.offsetWidth - e.clientWidth, document.body.removeChild(e)
            }
            return t.scrollbarSize
        }
    }, e.magnificPopup = {
        instance: null,
        proto: j.prototype,
        modules: [],
        open: function(t, a) {
            return T(), t = t ? e.extend(!0, {}, t) : {}, t.isObj = !0, t.index = a || 0, this.instance.open(t)
        },
        close: function() {
            return e.magnificPopup.instance && e.magnificPopup.instance.close()
        },
        registerModule: function(t, a) {
            a.options && (e.magnificPopup.defaults[t] = a.options), e.extend(this.proto, a.proto), this.modules.push(t)
        },
        defaults: {
            disableOn: 0,
            key: null,
            midClick: !1,
            mainClass: "",
            preloader: !0,
            focus: "",
            closeOnContentClick: !1,
            closeOnBgClick: !0,
            closeBtnInside: !0,
            showCloseBtn: !0,
            enableEscapeKey: !0,
            modal: !1,
            alignTop: !1,
            removalDelay: 0,
            prependTo: null,
            fixedContentPos: "auto",
            fixedBgPos: "auto",
            overflowY: "auto",
            closeMarkup: '<button title="%title%" type="button" class="jm-mfp-close">&#215;</button>',
            tClose: "Close (Esc)",
            tLoading: "Loading...",
            autoFocusLast: !0
        }
    }, e.fn.magnificPopup = function(a) {
        T();
        var r = e(this);
        if ("string" == typeof a)
            if ("open" === a) {
                var n, i = w ? r.data("magnificPopup") : r[0].magnificPopup,
                    o = parseInt(arguments[1], 10) || 0;
                i.items ? n = i.items[o] : (n = r, i.delegate && (n = n.find(i.delegate)), n = n.eq(o)), t._openClick({
                    mfpEl: n
                }, r, i)
            } else t.isOpen && t[a].apply(t, Array.prototype.slice.call(arguments, 1));
        else a = e.extend(!0, {}, a), w ? r.data("magnificPopup", a) : r[0].magnificPopup = a, t.addGroup(r, a);
        return r
    };
    var P, I, E, F = "inline",
        L = function() {
            E && (I.after(E.addClass(P)).detach(), E = null)
        };
    e.magnificPopup.registerModule(F, {
        options: {
            hiddenClass: "hide",
            markup: "",
            tNotFound: "Content not found"
        },
        proto: {
            initInline: function() {
                t.types.push(F), b(l + "." + F, function() {
                    L()
                })
            },
            getInline: function(a, r) {
                if (L(), a.src) {
                    var n = t.st.inline,
                        i = e(a.src);
                    if (i.length) {
                        var o = i[0].parentNode;
                        o && o.tagName && (I || (P = n.hiddenClass, I = x(P), P = "jm-mfp-" + P), E = i.after(I).detach().removeClass(P)), t.updateStatus("ready")
                    } else t.updateStatus("error", n.tNotFound), i = e("<div>");
                    return a.inlineElement = i, i
                }
                return t.updateStatus("ready"), t._parseMarkup(r, {}, a), r
            }
        }
    });
    var R, O = function(a, r) {
        if (a.data && void 0 !== a.data.title) return a.data.title;
        var n = t.st.image.titleSrc;
        if ("iframe" == r && (n = t.st.iframe.titleSrc), n) {
            if (e.isFunction(n)) return n.call(t, a);
            if (a.el) return a.el.attr(n) || ""
        }
        return ""
    };
    e.magnificPopup.registerModule("image", {
        options: {
            markup: '<div class="jm-mfp-figure"><div class="jm-mfp-close"></div><figure><div class="jm-mfp-img"></div><figcaption><div class="jm-mfp-bottom-bar"><div class="jm-mfp-title"></div><div class="jm-mfp-counter"></div></div></figcaption></figure></div>',
            cursor: "jm-mfp-zoom-out-cur",
            titleSrc: "title",
            verticalFit: !0,
            tError: '<a href="%url%">The image</a> could not be loaded.'
        },
        proto: {
            initImage: function() {
                var a = t.st.image,
                    r = ".image";
                t.types.push("image"), b(m + r, function() {
                    "image" === t.currItem.type && a.cursor && e(document.body).addClass(a.cursor)
                }), b(l + r, function() {
                    a.cursor && e(document.body).removeClass(a.cursor), y.off("resize" + _)
                }), b("Resize" + r, t.resizeImage), t.isLowIE && b("AfterChange", t.resizeImage)
            },
            resizeImage: function() {
                var e = t.currItem;
                if (e && e.img && t.st.image.verticalFit) {
                    var a = 0;
                    t.isLowIE && (a = parseInt(e.img.css("padding-top"), 10) + parseInt(e.img.css("padding-bottom"), 10)), e.img.css("max-height", t.wH - a)
                }
            },
            _onImageHasSize: function(e) {
                e.img && (e.hasSize = !0, R && clearInterval(R), e.isCheckingImgSize = !1, C("ImageHasSize", e), e.imgHidden && (t.content && t.content.removeClass("jm-mfp-loading"), e.imgHidden = !1))
            },
            findImageSize: function(e) {
                var a = 0,
                    r = e.img[0],
                    n = function(i) {
                        R && clearInterval(R), R = setInterval(function() {
                            return r.naturalWidth > 0 ? void t._onImageHasSize(e) : (a > 200 && clearInterval(R), a++, void(3 === a ? n(10) : 40 === a ? n(50) : 100 === a && n(500)))
                        }, i)
                    };
                n(1)
            },
            getImage: function(a, r) {
                var n = 0,
                    i = function() {
                        a && (a.img[0].complete ? (a.img.off(".mfploader"), a === t.currItem && (t._onImageHasSize(a), t.updateStatus("ready")), a.hasSize = !0, a.loaded = !0, C("ImageLoadComplete")) : (n++, 200 > n ? setTimeout(i, 100) : o()))
                    },
                    o = function() {
                        a && (a.img.off(".mfploader"), a === t.currItem && (t._onImageHasSize(a), t.updateStatus("error", l.tError.replace("%url%", a.src))), a.hasSize = !0, a.loaded = !0, a.loadError = !0)
                    },
                    l = t.st.image,
                    s = r.find(".jm-mfp-img");
                if (s.length) {
                    var d = document.createElement("img");
                    d.className = "jm-mfp-img", a.el && a.el.find("img").length && (d.alt = a.el.find("img").attr("alt")), a.img = e(d).on("load.mfploader", i).on("error.mfploader", o), d.src = a.src, s.is("img") && (a.img = a.img.clone()), d = a.img[0], d.naturalWidth > 0 ? a.hasSize = !0 : d.width || (a.hasSize = !1)
                }
                return t._parseMarkup(r, {
                    title: O(a),
                    img_replaceWith: a.img
                }, a), t.resizeImage(), a.hasSize ? (R && clearInterval(R), a.loadError ? (r.addClass("jm-mfp-loading"), t.updateStatus("error", l.tError.replace("%url%", a.src))) : (r.removeClass("jm-mfp-loading"), t.updateStatus("ready")), r) : (t.updateStatus("loading"), a.loading = !0, a.hasSize || (a.imgHidden = !0, r.addClass("jm-mfp-loading"), t.findImageSize(a)), r)
            }
        }
    });
    var B, A = function() {
        return void 0 === B && (B = void 0 !== document.createElement("p").style.MozTransform), B
    };
    e.magnificPopup.registerModule("zoom", {
        options: {
            enabled: !1,
            easing: "ease-in-out",
            duration: 300,
            opener: function(e) {
                return e.is("img") ? e : e.find("img")
            }
        },
        proto: {
            initZoom: function() {
                var e, a = t.st.zoom,
                    r = ".zoom";
                if (a.enabled && t.supportsTransition) {
                    var n, i, o = a.duration,
                        d = function(e) {
                            var t = e.clone().removeAttr("style").removeAttr("class").addClass("jm-mfp-animated-image"),
                                r = "all " + a.duration / 1e3 + "s " + a.easing,
                                n = {
                                    position: "fixed",
                                    zIndex: 9999,
                                    left: 0,
                                    top: 0,
                                    "-webkit-backface-visibility": "hidden"
                                },
                                i = "transition";
                            return n["-webkit-" + i] = n["-moz-" + i] = n["-o-" + i] = n[i] = r, t.css(n), t
                        },
                        p = function() {
                            t.content.css("visibility", "visible")
                        };
                    b("BuildControls" + r, function() {
                        if (t._allowZoom()) {
                            if (clearTimeout(n), t.content.css("visibility", "hidden"), e = t._getItemToZoom(), !e) return void p();
                            i = d(e), i.css(t._getOffset()), t.wrap.append(i), n = setTimeout(function() {
                                i.css(t._getOffset(!0)), n = setTimeout(function() {
                                    p(), setTimeout(function() {
                                        i.remove(), e = i = null, C("ZoomAnimationEnded")
                                    }, 16)
                                }, o)
                            }, 16)
                        }
                    }), b(s + r, function() {
                        if (t._allowZoom()) {
                            if (clearTimeout(n), t.st.removalDelay = o, !e) {
                                if (e = t._getItemToZoom(), !e) return;
                                i = d(e)
                            }
                            i.css(t._getOffset(!0)), t.wrap.append(i), t.content.css("visibility", "hidden"), setTimeout(function() {
                                i.css(t._getOffset())
                            }, 16)
                        }
                    }), b(l + r, function() {
                        t._allowZoom() && (p(), i && i.remove(), e = null)
                    })
                }
            },
            _allowZoom: function() {
                return "image" === t.currItem.type
            },
            _getItemToZoom: function() {
                return t.currItem.hasSize ? t.currItem.img : !1
            },
            _getOffset: function(a) {
                var r;
                r = a ? t.currItem.img : t.st.zoom.opener(t.currItem.el || t.currItem);
                var n = r.offset(),
                    i = parseInt(r.css("padding-top"), 10),
                    o = parseInt(r.css("padding-bottom"), 10);
                n.top -= e(window).scrollTop() - i;
                var l = {
                    width: r.width(),
                    height: (w ? r.innerHeight() : r[0].offsetHeight) - o - i
                };
                return A() ? l["-moz-transform"] = l.transform = "translate(" + n.left + "px," + n.top + "px)" : (l.left = n.left, l.top = n.top), l
            }
        }
    });
    var G = "iframe",
        z = "//about:blank",
        M = function(e) {
            if (t.currTemplate[G]) {
                var a = t.currTemplate[G].find("iframe");
                a.length && (e || (a[0].src = z), t.isIE8 && a.css("display", e ? "block" : "none"))
            }
        };
    e.magnificPopup.registerModule(G, {
        options: {
            markup: '<div class="mfp-iframe-scaler"><div class="mfp-close"></div><iframe class="mfp-iframe" src="//about:blank" frameborder="0" allowfullscreen></iframe></div>',
            srcAction: "iframe_src",
            posterAction: "iframe_poster",
            titleSrc: "title",
            patterns: {
                youtube: {
                    index: "youtube.com",
                    id: "v=",
                    src: "//www.youtube.com/embed/%id%"
                },
                vimeo: {
                    index: "vimeo.com/",
                    id: "/",
                    src: "//player.vimeo.com/video/%id%"
                },
                cloudflare: {
                    index: "cloudflarestream.com/",
                    id: "/",
                    src: "//iframe.videodelivery.net/%id%"
                }
            }
        },
        proto: {
            initIframe: function() {
                t.types.push(G), b("BeforeChange", function(e, t, a) {
                    t !== a && (t === G ? M() : a === G && M(!0))
                }), b(l + "." + G, function() {
                    M()
                })
            },
            getIframe: function(a, r) {
                var n = a.el.attr("data-iframe-src"),
                    i = t.st.iframe;
                e.each(i.patterns, function() {
                    return n.indexOf(this.index) > -1 ? (this.id && (n = "string" == typeof this.id ? n.substr(n.lastIndexOf(this.id) + this.id.length, n.length) : this.id.call(this, n)), n = this.src.replace("%id%", n), !1) : void 0
                });
                var o = {};
                return i.srcAction && (o[i.srcAction] = n), i.posterAction && (o[i.posterAction] = a.el.attr("src")), i.titleSrc && (o.title = O(a, "iframe")), t._parseMarkup(r, o, a), t.updateStatus("ready"), r
            }
        }
    });
    var q = function(e) {
            var a = t.items.length;
            return e > a - 1 ? e - a : 0 > e ? a + e : e
        },
        N = function(e, t, a) {
            return e.replace(/%curr%/gi, t + 1).replace(/%total%/gi, a)
        };
    e.magnificPopup.registerModule("gallery", {
        options: {
            enabled: !1,
            arrowMarkup: '<button title="%title%" type="button" class="jm-mfp-arrow jm-mfp-arrow-%dir%"></button>',
            preload: [0, 2],
            navigateByImgClick: !0,
            arrows: !0,
            tPrev: "Previous (Left arrow key)",
            tNext: "Next (Right arrow key)",
            tCounter: "%curr% of %total%"
        },
        proto: {
            initGallery: function() {
                var a = t.st.gallery,
                    n = ".jm-mfp-gallery";
                return t.direction = !0, a && a.enabled ? (i += " jm-mfp-gallery", b(m + n, function() {
                    a.navigateByImgClick && t.wrap.on("click" + n, ".jm-mfp-img", function() {
                        return t.items.length > 1 ? (t.next(), !1) : void 0
                    }), r.on("keydown" + n, function(e) {
                        37 === e.keyCode ? t.prev() : 39 === e.keyCode && t.next()
                    })
                }), b("UpdateStatus" + n, function(e, a) {
                    a.text && (a.text = N(a.text, t.currItem.index, t.items.length))
                }), b(c + n, function(e, r, n, i) {
                    var o = t.items.length;
                    n.counter = o > 1 ? N(a.tCounter, i.index, o) : ""
                }), b("BuildControls" + n, function() {
                    if (t.items.length > 1 && a.arrows && !t.arrowLeft) {
                        var r = a.arrowMarkup,
                            n = t.arrowLeft = e(r.replace(/%title%/gi, a.tPrev).replace(/%dir%/gi, "left")).addClass(h),
                            i = t.arrowRight = e(r.replace(/%title%/gi, a.tNext).replace(/%dir%/gi, "right")).addClass(h);
                        n.click(function() {
                            t.prev()
                        }), i.click(function() {
                            t.next()
                        }), t.container.append(n.add(i))
                    }
                }), b(u + n, function() {
                    t._preloadTimeout && clearTimeout(t._preloadTimeout), t._preloadTimeout = setTimeout(function() {
                        t.preloadNearbyImages(), t._preloadTimeout = null
                    }, 16)
                }), void b(l + n, function() {
                    r.off(n), t.wrap.off("click" + n), t.arrowRight = t.arrowLeft = null
                })) : !1
            },
            next: function() {
                t.direction = !0, t.index = q(t.index + 1), t.updateItemHTML()
            },
            prev: function() {
                t.direction = !1, t.index = q(t.index - 1), t.updateItemHTML()
            },
            goTo: function(e) {
                t.direction = e >= t.index, t.index = e, t.updateItemHTML()
            },
            preloadNearbyImages: function() {
                var e, a = t.st.gallery.preload,
                    r = Math.min(a[0], t.items.length),
                    n = Math.min(a[1], t.items.length);
                for (e = 1; e <= (t.direction ? n : r); e++) t._preloadItem(t.index + e);
                for (e = 1; e <= (t.direction ? r : n); e++) t._preloadItem(t.index - e)
            },
            _preloadItem: function(a) {
                if (a = q(a), !t.items[a].preloaded) {
                    var r = t.items[a];
                    r.parsed || (r = t.parseEl(a)), C("LazyLoad", r), "image" === r.type && (r.img = e('<img class="jm-mfp-img" />').on("load.mfploader", function() {
                        r.hasSize = !0
                    }).on("error.mfploader", function() {
                        r.hasSize = !0, r.loadError = !0, C("LazyLoadError", r)
                    }).attr("src", r.src)), r.preloaded = !0
                }
            }
        }
    });
    var D = "retina";
    e.magnificPopup.registerModule(D, {
        options: {
            replaceSrc: function(e) {
                return e.src.replace(/\.\w+$/, function(e) {
                    return "@2x" + e
                })
            },
            ratio: 1
        },
        proto: {
            initRetina: function() {
                if (window.devicePixelRatio > 1) {
                    var e = t.st.retina,
                        a = e.ratio;
                    a = isNaN(a) ? a() : a, a > 1 && (b("ImageHasSize." + D, function(e, t) {
                        t.img.css({
                            "max-width": t.img[0].naturalWidth / a,
                            width: "100%"
                        })
                    }), b("ElementParse." + D, function(t, r) {
                        r.src = e.replaceSrc(r, a)
                    }))
                }
            }
        }
    }), T()
}),
function() {
    this.JST || (this.JST = {}), this.JST["templates/shopify_v2/photo_gallery_popup"] = function(obj) {
        var __p = [];
        with(obj || {}) __p.push('<div class="jm-mfp-main">\n  <div class="jm-mfp-carousel-wrapper">\n    <div class="jm-mfp-content-wrapper"></div>\n    <div class="jm-mfp-carousel"></div>\n  </div>\n  <div class="jm-mfp-review-wrapper">\n    <div class="jm-mfp-close">\xd7</div>\n    <div class="jdgm-rev"></div>\n  </div>\n</div>\n');
        return __p.join("")
    }
}.call(this),
    function() {
        this.JST || (this.JST = {}), this.JST["templates/shopify_v2/photo_gallery_thumbnail"] = function(obj) {
            var __p = [];
            with(obj || {}) {
                __p.push("");
                var imgSrc, iframeSrc, preloadThumbnail = "undefined" != typeof preload && preload === !0,
                    wrapperClass = preloadThumbnail ? "jdgm-gallery__thumbnail-wrapper jdgm--loading" : "jdgm-gallery__thumbnail-wrapper";
                __p.push("\n\n"), review.pictures_urls && (__p.push("\n  "), review.pictures_urls.forEach(function(e) {
                    __p.push("\n    "), imgSrc = e.compact, __p.push("\n    <div class='jdgm-gallery__thumbnail-link'>\n      <div class='", ("" + wrapperClass).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'>\n        <img class='jdgm-gallery__thumbnail' alt='User picture'\n            "), preloadThumbnail ? __p.push("\n              data-src='", ("" + imgSrc).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'\n            ") : __p.push("\n              src='", ("" + imgSrc).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'\n            "), __p.push("\n            data-mfp-src='", ("" + e.original).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'\n            data-review-id='", ("" + review.uuid).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "' />\n      </div>\n    </div>\n  ")
                }), __p.push("\n")), __p.push("\n\n"), review.video_external_data && (__p.push("\n  "), jdgm.$.each(review.video_external_data, function(e, t) {
                    __p.push("\n    <div class='jdgm-gallery__thumbnail-link'>\n      <div class='", ("" + wrapperClass).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "' data-media-type='video'>\n        <img class='jdgm-gallery__thumbnail' alt='User video' preload='", ("" + preloadThumbnail).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'\n            "), t.img_src && (__p.push("\n              "), preloadThumbnail ? __p.push("\n                data-src='", ("" + t.img_src).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'\n              ") : __p.push("\n                src='", ("" + t.img_src).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'\n              "), __p.push("\n            ")), __p.push("\n            data-iframe-src='", ("" + t.iframe_src).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'\n            data-external-id='", ("" + e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "' data-review-id='", ("" + review.uuid).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "' data-media-type='video' />\n      </div>\n    </div>\n  ")
                }), __p.push("\n")), __p.push("\n\n"), review.media_platform_hosted_video_infos && (__p.push("\n  "), review.media_platform_hosted_video_infos.forEach(function(e) {
                    __p.push("\n    "), "yt" == e.media_platform_name && (__p.push("\n      "), imgSrc = "https://img.youtube.com/vi/" + e.media_platform_url + "/sddefault.jpg", iframeSrc = "https://www.youtube.com/watch?v=" + e.media_platform_url, __p.push("\n      <div class='jdgm-gallery__thumbnail-link'>\n        <div class='", ("" + wrapperClass).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "' data-media-type='video'>\n          <img class='jdgm-gallery__thumbnail' alt='User video'\n              "), preloadThumbnail ? __p.push("\n                data-src='", ("" + imgSrc).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'\n              ") : __p.push("\n                src='", ("" + imgSrc).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'\n              "), __p.push("\n              data-iframe-src='", ("" + iframeSrc).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'\n              data-platform-name='", ("" + e.media_platform_name).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "' data-platform-url='", ("" + e.media_platform_url).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'\n              data-review-id='", ("" + review.uuid).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "' data-media-type='video'>\n        </div>\n      </div>\n    ")), __p.push("\n  ")
                }), __p.push("\n")), __p.push("\n")
            }
            return __p.join("")
        }
    }.call(this),
    function() {
        this.JST || (this.JST = {}), this.JST["templates/shopify_v2/review_for_photo_gallery"] = function(obj) {
            var __p = [];
            with(obj || {}) __p.push("<div class='jdgm-rev jdgm-divider-top' data-verified-buyer='", review.verified_buyer, "'>\n  <div class='jdgm-rev__header'>\n    "), jdgm.isVersion3 ? (__p.push("\n      "), review.product_title && __p.push("\n        <div class='jdgm-row-product'>\n          <span class='jdgm-rev__prod-info-wrapper'>\n            <span class='jdgm-rev__prod-link-prefix'></span>\n            <a href='", review.product_url, "#judgeme_product_reviews' target='_blank' class='jdgm-rev__prod-link'>", review.product_title, "</a>\n          </span>\n        </div>\n      "), __p.push("\n\n      <div class='jdgm-row-rating'>\n        "), review.rating && __p.push("\n          <span class='jdgm-rev__rating' data-score='", review.rating, "' aria-label='", review.rating, " star review' role='img'></span>\n        "), __p.push("\n        <span class='jdgm-rev__timestamp jdgm-spinner' data-content='", review.created_at, "'></span>\n      </div>\n\n      "), review.avatar_image_url ? __p.push("\n        <div class='jdgm-rev__icon jdgm--loading jdgm-rev__avatar'>\n          <img data-src='", review.avatar_image_url.normal, "'\n            data-src-retina='", review.avatar_image_url.retina, "'\n            class='jdgm-rev__avatar-image'\n            alt='Reviewer avatar' />\n        </div>\n      ") : review.gravatar_hash ? __p.push("\n        <div class='jdgm-rev__icon jdgm--loading jdgm-rev__avatar'>\n          <img data-src='https://secure.gravatar.com/avatar/", review.gravatar_hash, ".png?default=mp&filetype=png&rating=pg&secure=true'\n            class='jdgm-rev__avatar-image'\n            alt='Reviewer avatar' />\n        </div>\n      ") : __p.push("\n        <div class='jdgm-rev__icon'>\n        </div>\n      "), __p.push("\n\n      <div class='jdgm-row-profile'>\n        <span class='jdgm-rev__author'>", review.reviewer_name, "</span>\n        "), review.verified_buyer && __p.push("\n          <span class='jdgm-rev__buyer-badge'></span>\n        "), __p.push("\n      </div>\n      <div class='jdgm-row-extra'>\n        "), jdgmSettings.widget_review_location_show && review.location && __p.push("\n          <span class='jdgm-rev__location'>", review.location.replace(/\(|\)/g, ""), "</span>\n        "), __p.push("\n        "), jdgmSettings.widget_show_country_flag && review.country_code_show_flag && __p.push("\n          <img class='jdgm-rev__location-country-flag-img' alt='", review.country_code_show_flag, "' src='https://judgeme-public-images.imgix.net/judgeme/flags/", review.country_code_show_flag, ".svg' />\n        "), __p.push("\n      </div>\n    ")) : (__p.push("\n      "), review.avatar_image_url ? __p.push("\n        <div class='jdgm-rev__icon jdgm--loading'>\n          <img data-src='", review.avatar_image_url.normal, "'\n            data-src-retina='", review.avatar_image_url.retina, "'\n            class='jdgm-rev__avatar-image'\n            alt='Reviewer avatar' />\n        </div>\n      ") : review.gravatar_hash ? __p.push("\n        <div class='jdgm-rev__icon jdgm--loading'>\n          <img data-src='https://secure.gravatar.com/avatar/", review.gravatar_hash, ".png?default=mp&filetype=png&rating=pg&secure=true'\n            class='jdgm-rev__avatar-image'\n            alt='Reviewer avatar' />\n        </div>\n      ") : __p.push("\n        <div class='jdgm-rev__icon'>\n          ", review.reviewer_name.charAt(0), "\n        </div>\n      "), __p.push("\n      "), review.rating && __p.push("\n      <span class='jdgm-rev__rating' data-score='", review.rating, "' aria-label='", review.rating, " star review' role='img'></span>\n      "), __p.push("\n      "), jdgmSettings.review_dates && __p.push("\n        <span class='jdgm-rev__timestamp jdgm-spinner' data-content='", review.created_at, "'></span>\n        "), __p.push("\n      "), review.product_title && __p.push("\n        <span class='jdgm-rev__prod-info-wrapper'>\n          <span class='jdgm-rev__prod-link-prefix'></span>\n          <a href='", review.product_url, "#judgeme_product_reviews' target='_blank' class='jdgm-rev__prod-link'>", review.product_title, "</a>\n        </span>\n      "), __p.push("\n\n      <span class='jdgm-rev__author-wrapper'>\n        "), review.verified_buyer && __p.push("\n          <span class='jdgm-rev__buyer-badge-wrapper'>\n            <span class='jdgm-rev__buyer-badge'></span>\n          </span>\n        "), __p.push("\n        <span class='jdgm-rev__author'>", review.reviewer_name, "</span>\n        "), jdgmSettings.widget_show_country_flag && review.country_code_show_flag && __p.push("\n          <img class='jdgm-rev__location-country-flag-img' alt='", review.country_code_show_flag, "' src='https://judgeme-public-images.imgix.net/judgeme/flags/", review.country_code_show_flag, ".svg' />\n        "), __p.push("\n        "), jdgmSettings.widget_review_location_show && review.location && __p.push("\n          <span class='jdgm-rev__location'>", review.location, "</span>\n        "), __p.push("\n      </span>\n    ")), __p.push("\n  </div>\n\n  <div class='jdgm-rev__content "), review.title && __p.push("jdgm-rev__content--has-title"), __p.push("'>\n    "), jdgm.isVersion3 && (__p.push("\n      "), review.title && __p.push("\n        <div class='jdgm-rev__title'>", review.title, "</div>\n      "), __p.push("\n      <div class='jdgm-rev__body'>", review.body_html, "</div>\n    ")), __p.push("\n    "), review.cf_answers && (__p.push("\n      <div class='jdgm-rev__custom-form'>\n        "), jdgm.asyncEach(review.cf_answers, function(e) {
                if (__p.push("\n          "), jdgm.isVersion3 || "slider" != e.question_type) {
                    if (__p.push("\n            <div class='jdgm-rev__cf-ans'>\n              <b class='jdgm-rev__cf-ans__title'>", e.question_title, ":</b>\n              "), "scale" == e.question_type) {
                        for (__p.push("\n                <div class='jdgm-cf-bars-wrapper' data-value='", e.value, "'>\n                  <div class='jdgm-rev__scale-range'>\n                    "), numberOfFilledBars = e.value.split("/")[0], __p.push("\n                    "), totalNumberOfBars = e.value.split("/")[1], __p.push("\n                    "), i = 1; i <= totalNumberOfBars; i++) __p.push("\n                      "), i <= numberOfFilledBars ? __p.push('\n                        <a href="#" rel="nofollow" class="jdgm-cf-bar jdgm--filled"></a>\n                      ') : __p.push('\n                        <a href="#" rel="nofollow" class="jdgm-cf-bar jdgm--empty"></a>\n                      '), __p.push("\n                    ");
                        __p.push("\n                  </div>\n                  "), jdgm.isVersion3 && __p.push("\n                    <div class='jdgm-rev__scale-first'>", e.lower_value, "</div>\n                    <div class='jdgm-rev__scale-last'>", e.top_value, "</div>\n                  "), __p.push("\n                </div>\n              ")
                    } else jdgm.isVersion3 && "slider" == e.question_type ? __p.push("\n                <div class='jdgm-rev__slider-wrapper'>\n                  <div class='jdgm-rev__slider-range'>\n                    <div class='jdgm-rev__slider-pointer' style='left: ", e.value, "%'></div>\n                  </div>\n                  <div class='jdgm-rev__slider-first'>", e.lower_value, "</div>\n                  <div class='jdgm-rev__slider-last'>", e.top_value, "</div>\n                </div>\n              ") : (jdgm.isVersion3 || "slider" != e.question_type) && __p.push("\n                <span class='jdgm-rev__cf-ans__value'>", e.value, "</span>\n              ");
                    __p.push("\n            </div>\n          ")
                }
                __p.push("\n        ")
            }), __p.push("\n      </div>\n    ")), __p.push("\n    "), jdgm.isVersion3 || (__p.push("\n      "), review.title && __p.push("\n        <div class='jdgm-rev__title'>", review.title, "</div>\n      "), __p.push("\n      <div class='jdgm-rev__body'>", review.body_html, "</div>\n    ")), __p.push("\n  </div>\n</div>\n");
            return __p.join("")
        }
    }.call(this),
    function() {
        this.JST || (this.JST = {}), this.JST["templates/shopify_v2/photo_gallery_popup_content"] = function(obj) {
            var __p = [];
            with(obj || {}) __p.push('<div class="jm-mfp-figure">\n  <figure>\n    '), "undefined" == typeof mediaType ? __p.push('\n      <div class="jm-mfp-img"></div>\n    ') : "video" == mediaType ? __p.push('\n      <div class="jm-mfp-iframe-wrapper">\n        <iframe class="jm-mfp-iframe" src="//about:blank" frameborder="0" allowfullscreen></iframe>\n      </div>\n    ') : "video-native" == mediaType && __p.push('\n      <div class="jm-mfp-video-wrapper">\n        <video controls class="jm-mfp-iframe" poster="" src=""></video>\n      </div>\n    '), __p.push('\n  </figure>\n  <div class="jm-mfp-title"></div>\n</div>\n');
            return __p.join("")
        }
    }.call(this),
    function() {
        this.JST || (this.JST = {}), this.JST["templates/shopify_v2/photo_gallery_popup_thumbnail"] = function(obj) {
            var __p = [];
            with(obj || {}) __p.push("<div class='jdgm-gallery__thumbnail-link'>\n  <div class='jdgm-gallery__thumbnail-wrapper' data-media-type='", ("" + object.media_type.toLowerCase()).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'>\n    <img class='jdgm-gallery__thumbnail' alt='User picture'\n        src='", ("" + object.thumbnail_url).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'\n        "), "VIDEO" == object.media_type ? __p.push("\n          data-iframe-src='", ("" + object.media_url).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'\n        ") : __p.push("\n          data-mfp-src='", ("" + object.media_url).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'\n        "), __p.push("\n        data-object-id='", ("" + object.id || object.uuid).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'\n        data-media-type='", ("" + object.media_type.toLowerCase()).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "' />\n  </div>\n</div>\n");
            return __p.join("")
        }
    }.call(this),
    function() {
        this.JST || (this.JST = {}), this.JST["templates/shopify_v2/ugc_media_grid_popup"] = function(obj) {
            var __p = [];
            with(obj || {}) {
                __p.push("<div class='jdgm-rev'>\n  <div class='jdgm-rev__header'>\n    <div class='jdgm-rev__icon'>\n      "), post.avatar_image_url ? __p.push("\n        <img src='", ("" + post.avatar_image_url).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "' class='jdgm-rev__avatar-image' alt='Reviewer avatar' />\n      ") : __p.push("\n        ", ("" + post.username ? post.username.charAt(0).toUpperCase() : "A").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "\n      "), __p.push("\n    </div>\n    <div class='jdgm-rev__author-wrapper'>\n      <span class='jdgm-rev__author'>", ("" + post.username ? "@" + post.username : "Anonymous").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "</span>\n    </div>\n    "), jdgmSettings.widget_ugc_show_post_date && __p.push("\n      <div class='jdgm-rev__timestamp'>", ("" + post.timestamp).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "</div>\n    "), __p.push("\n  </div>\n  <div class='jdgm-rev__content "), post.products.length > 0 && __p.push("jdgm-rev__content--has-attachments"), __p.push("'>\n    <div class='jdgm-rev__body jdgm-rev__body--no-readmore'>\n      ");
                var _paragraphs = post.html_safe_caption.split("\n");
                __p.push("\n      ");
                for (var i = 0; i < _paragraphs.length; i++) __p.push("\n        <div>", _paragraphs[i] || "&nbsp;", "</div>\n      ");
                if (__p.push("\n    </div>\n    "), post.products.length > 0) {
                    __p.push("\n      <div class='jdgm-rev-attachments'>\n        ");
                    for (var i = 0; i < post.products.length; i++) {
                        __p.push("\n          ");
                        var product = post.products[i];
                        __p.push("\n          <div class='jdgm-rev-attachment'>\n            <div class='jdgm-rev-attachment__cover'>\n              "), product.image_url ? __p.push("\n                <img class='jdgm-rev-attachment__thumbnail' src='", ("" + product.image_url).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "' />\n              ") : __p.push("\n                <div class='jdgm-rev-attachment__thumbnail'></div>\n              "), __p.push("\n            </div>\n            <div class='jdgm-rev-attachment__content'>\n              <div class='jdgm-rev-attachment__title'>", ("" + product.title).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "</div>\n              <div class='jdgm-rev-attachment__review'>\n                <span class='jdgm-rev-attachment__review-stars' data-score='", ("" + product.widget_published_reviews_rating).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'></span>\n                <span class='jdgm-rev-attachment__review-text' data-reviews='", ("" + product.widget_published_reviews_count).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'></span>\n              </div>\n              <div class='jdgm-rev-attachment__price'>", ("" + product.price).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "</div>\n              <div class='jdgm-rev-attachment__actions'>\n                <a class='jdgm-rev-attachment__btn jdgm-ugc-media__primary-btn' data-url='", ("" + product.url + "?ref=judge.me&jdgm_referral_location=ugc_media_grid").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'>\n                  ", ("" + jdgmSettings.widget_ugc_primary_button_text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "\n                </a>\n                ");
                        var viewReviewsLink = "store-product-page" == jdgmSettings.widget_ugc_reviews_button_link_to ? product.url + "#judgeme_product_reviews" : product.judgeme_url;
                        __p.push("\n                <a class='jdgm-rev-attachment__btn jdgm-ugc-media__reviews-btn' data-url='", ("" + viewReviewsLink).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'>\n                  ", ("" + jdgmSettings.widget_ugc_reviews_button_text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "\n                </a>\n              </div>\n            </div>\n          </div>\n        ")
                    }
                    __p.push("\n      </div>\n    ")
                }
                __p.push("\n  </div>\n</div>\n")
            }
            return __p.join("")
        }
    }.call(this), jdgm.$(function(e) {
        jdgm.templates = jdgm.templates || {}, jdgm.templates.photoGalleryPopup = JST["templates/shopify_v2/photo_gallery_popup"], jdgm.templates.photoGalleryThumbnail = JST["templates/shopify_v2/photo_gallery_thumbnail"], jdgm.templates.reviewForPhotoGallery = JST["templates/shopify_v2/review_for_photo_gallery"], jdgm.templates.photoGalleryPopupContent = JST["templates/shopify_v2/photo_gallery_popup_content"], jdgm.templates.photoGalleryPopupThumbnail = JST["templates/shopify_v2/photo_gallery_popup_thumbnail"], jdgm.templates.ugcMediaGridPopup = JST["templates/shopify_v2/ugc_media_grid_popup"]
    }),
    function() {
        jdgm.$(function(e) {
            var t, a;
            return a = jdgm._safeRun, t = function() {
                return {}
            }, a(function() {
                return jdgm._htmlFor("photo_gallery_thumbnail", {
                    review: {
                        pictures_urls: [""],
                        video_external_data: [{}],
                        media_platform_hosted_video_infos: [{}],
                        preload: !1
                    }
                })
            }), a(function() {
                return jdgm._htmlFor("review_for_photo_gallery", {
                    review: {}
                })
            }), a(function() {
                return jdgm._htmlFor("photo_gallery_popup")
            }), a(function() {
                return jdgm._htmlFor("photo_gallery_popup_thumbnail", {
                    object: {}
                })
            }), a(function() {
                return jdgm._htmlFor("ugc_media_grid_popup", {
                    post: {}
                })
            }), a(function() {
                return jdgm._htmlFor("ugc_media_grid_thumbnail", {
                    object: {},
                    preload: !0
                })
            }), 0 === e(".jdgm-widget [data-execute-after-load=true]").length ? (a(function() {
                return jdgm.$.magnificPopup.open()
            }), a(function() {
                return jdgm.$.magnificPopup.close()
            })) : void 0
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, a, r, n, i, o, l, s, d, p, c, m, u, g, _, f;
            return a = /(\/.+)(&#39;)(.+\/)/, r = 16, jdgm.preloadedUrls = [], jdgm.preload = function() {
                var e, t;
                for (e = 0, t = []; e < arguments.length;)(new Image).src = arguments[e], jdgm.preloadedUrls.push(arguments[e]), t.push(e++);
                return t
            }, jdgm.setupPictures = jdgm.setupMediaGallery = function(t) {
                return t.find(".jdgm-rev__pic-img").each(function() {
                    return m(e(this))
                }), jdgm.setupLazyLoadPicture(t.find(".jdgm-rev__pic-img")), jdgm.eachWidgetWithReviews(function(e) {
                    return c(e.find(".jdgm-rev__pic-link:not([data-popup=false])"))
                }), jdgm.triggerEvent("doneSetupPictures", {
                    $reviews: t
                }), jdgm._shouldSetUpVideo ? jdgm._setupVideoPlayers(t.find(".jdgm-vid-player")) : void 0
            }, jdgm._setupVideoPlayers = function(t) {
                return e.each(t, function(t, a) {
                    var n, i;
                    return n = e(a), (i = n.data("external-id")) ? i.length > r ? l(n, i) : s(n, i) : void 0
                }), jdgm.triggerEvent("doneSetupVideos", {
                    $reviews: t.closest(".jdgm-rev")
                })
            }, m = function(e) {
                var t, r;
                return r = e.attr("data-src"), a.test(r) ? (r = r.replace(a, "$1'$3"), e.attr({
                    src: r,
                    "data-src": r
                }), t = e.closest(".jdgm-rev__pic-link"), t.attr({
                    href: t.attr("href").replace(a, "$1'$3"),
                    "data-mfp-src": t.attr("data-mfp-src").replace(a, "$1'$3")
                })) : void 0
            }, f = function(e) {
                return jdgm._shouldSetUpVideo || jdgm._setupVideoPlayers(e.find(".jdgm-vid-player")), jdgm._shouldSetUpVideo = !0
            }, p = function(t) {
                return jdgm.ScrollEvent.attach(function() {
                    return f(t), jdgm.ScrollEvent.dettach("deferredLoadingVideos")
                }, "deferredLoadingVideos"), e(document).one("mousemove", function(e) {
                    return f(t)
                })
            }, l = function(e, t) {
                var a, r, n, i, o;
                if (t && (a = e.height() || 240, n = e.closest(".jdgm-rev__vids").width() || 360, o = Math.min(1.5 * a, n), i = jdgmSettings.mute_video_by_default ? "muted='true'" : "", r = "<iframe src='https://iframe.videodelivery.net/" + t + "?" + i + "' title='Review video' height='" + a + "px' width='" + o + "px' allow='fullscreen'></iframe>", !(e.find(".jdgm-vid-player__wrapper > iframe").length > 0))) return e.find(".jdgm-vid-player__wrapper").html(r).removeClass("jdgm--loading")
            }, s = function(t, a) {
                var r;
                if (a) return r = t.find(".jdgm-vid-player__wrapper"), e.ajax({
                    url: "https://vimeo.com/api/oembed.json",
                    data: {
                        url: "https://vimeo.com/" + a,
                        maxheight: t.height(),
                        title: !1,
                        muted: jdgmSettings.mute_video_by_default,
                        byline: !jdgmSettings.remove_judgeme_branding,
                        portrait: !jdgmSettings.remove_judgeme_branding
                    },
                    success: function(e) {
                        return r.html(e.html)
                    },
                    error: function(e) {
                        return t.remove(), console.log("Video is processing. It will be available shortly. Please refresh the page after a few seconds.")
                    },
                    complete: function() {
                        return r.removeClass("jdgm--loading")
                    }
                })
            }, _ = 0, g = 0, n = !1, i = function() {
                _ > g && e.magnificPopup.instance.next(), g > _ && e.magnificPopup.instance.prev()
            }, u = function() {
                var t;
                return n ? void 0 : (n = !0, t = document.getElementsByClassName("jm-mfp-gallery"), e.each(t, function(e, t) {
                    return t.addEventListener("touchstart", function(e) {
                        _ = e.changedTouches[0].screenX
                    }, {
                        passive: !0
                    }), t.addEventListener("touchend", function(e) {
                        g = e.changedTouches[0].screenX, i()
                    }, {
                        passive: !0
                    })
                }))
            }, d = 0, o = function(t) {
                var a;
                return null == t && (t = !0), a = e("body"), t ? (d = window.pageYOffset, a.css("overflow", "hidden"), a.css("position", "fixed"), a.css("top", "-" + d + "px"), a.css("width", "100%")) : (a.css("overflow", ""), a.css("position", ""), a.css("top", ""), a.css("width", ""), window.scrollTo(0, d))
            }, c = function(t) {
                var a;
                return jdgmSettings.remove_judgeme_branding || !jdgmSettings.can_be_branded, a = "", t.magnificPopup({
                    type: "image",
                    image: {
                        cursor: null
                    },
                    tLoading: "",
                    gallery: {
                        enabled: !0,
                        preload: [1, 10],
                        tCounter: a + " <span class='jm-mfp-counter__number'>%curr% / %total%</span>"
                    },
                    zoom: {
                        enabled: !0,
                        duration: 200
                    },
                    callbacks: {
                        open: function() {
                            return e("body").addClass("jm-mfp-is-open"), o(!0), u()
                        },
                        close: function() {
                            return e("body").removeClass("jm-mfp-is-open"), o(!1)
                        }
                    }
                })
            }, jdgm.setupMediaGallery(e(".jdgm-rev")), p(e(".jdgm-rev")), t = e(), jdgm._safeRun(function() {
                return jdgm.preload()
            }), jdgm._safeRun(function() {
                return jdgm._setupVideoPlayers(t)
            }), jdgm._safeRun(function() {
                return l(t)
            }), jdgm._safeRun(function() {
                return s(t)
            }), jdgm._safeRun(function() {
                return rotateImage(t)
            })
        }), jdgm.$(window).on("load", function() {
            return jdgmSettings.preloadPictures && !jdgmSettings.lazyloadCardImages ? jdgm.$(".jdgm-rev__pic-link").slice(0, 10).each(function(e, t) {
                return jdgm.preload(jdgm.$(t).data("mfp-src"))
            }) : void 0
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, a, r, n;
            return a = e("html"), n = function() {
                return jdgm.ScrollEvent.attach(jdgm._insertIframesToYoutubeContainers)
            }, jdgm._insertIframesToYoutubeContainers = function(t, n) {
                return null == n && (n = !1), t || (t = e(".jdgm-yt-video")), t.not(".done-setup").each(function() {
                    var t;
                    return t = e(this), n || a.scrollTop() >= t.offset().top - 1e3 ? r(t) : void 0
                })
            }, r = function(t) {
                var a, r, n, i, o;
                return n = t.data("id"), n && (r = t.data("class"), i = t.data("title"), o = "https://www.youtube.com/embed/" + n + "?rel=0&showinfo=0&autoplay=0&cc_load_policy=1", jdgmSettings.mute_video_by_default && (o += "&mute=1"), a = e('<iframe frameborder="0" allow="autoplay; fullscreen" allowfullscreen>'), a.attr("src", o), a.addClass(r), a.attr("title", i), t.html(a)), t.addClass("done-setup")
            }, n(), t = e(), jdgm._safeRun(function() {
                return jdgm._insertIframesToYoutubeContainers(t)
            }), jdgm._safeRun(function() {
                return r(t)
            })
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, a, r, n, i, o, l, s, d, p, c, m, u, g, _, f, v;
            return a = jdgm.JM_PUBLIC_IMAGE_URL + "medals-v2/", r = jdgm.JM_PUBLIC_IMAGE_URL + "medals-v2-2025-rebranding/", i = jdgm.JM_PUBLIC_IMAGE_URL + "medals-mono/", o = jdgm.JM_PUBLIC_IMAGE_URL + "medals-mono-2025-rebranding/", n = 96, v = function() {
                var t;
                return t = e(".jdgm-medals"), u(t) ? void 0 : (jdgm.asyncEach(t, function(t) {
                    var a, r, n;
                    return a = e(t), p(a), r = a.closest(".jdgm-widget"), r.hasClass("jdgm-medals-wrapper") ? (jdgm.WIDGET_REBRANDING_ENABLED && r.addClass("jdgm-medals-wrapper--rebranding"), g(r), n = r.closest(":visible").width(), 680 > n ? m(r) : void 0) : l(r, a)
                }), setTimeout(function() {
                    return e(".jdgm-medals-wrapper").removeClass("jdgm-hidden")
                }, 300))
            }, p = function(t) {
                return jdgm.asyncEach(t.find(".jdgm-medal__image"), function(n) {
                    var l;
                    return l = e(n), jdgm.WIDGET_REBRANDING_ENABLED ? jdgm._loadSvg(l, r, o, jdgmSettings.medals_widget_use_monochromatic_version) : jdgm._loadSvg(l, a, i, jdgmSettings.medals_widget_use_monochromatic_version), jdgmSettings.can_be_branded ? l.parent().attr("target", "_blank").attr("href", t.data("link")) : void 0
                }), jdgmSettings.medals_widget_use_monochromatic_version && e(".jdgm-medals-style").length <= 0 ? t.before(c()) : void 0
            }, c = function(e) {
                var t, a;
                return a = jdgmSettings.medals_widget_elements_color, t = jdgmSettings.medals_widget_background_color, ['<style class="jdgm-medals-style">', ".jdgm-medals-wrapper.jdgm-widget { background-color: " + t + " !important; color: " + a + " !important; }", ".jdgm-medals-wrapper .jdgm-verified-wrapper { border-color: " + a + " !important; }", ".jdgm-medal__value, .jdgm-medals-wrapper .jdgm-star { color: " + a + " !important; }", ".jdgm-medals-wrapper .jdgm-svg__mono svg path, .jdgm-medals-wrapper .jdgm-svg__mono svg circle { fill: " + a + "; }", "</style>"].join("")
            }, g = function(e) {
                return e.hasClass("jdgm-medals-wrapper") ? (jdgm.WIDGET_REBRANDING_ENABLED && _(e), jdgm._renderVerifiedByJudgeme(e, jdgmSettings.medals_widget_use_monochromatic_version, !0, !1, jdgm.WIDGET_REBRANDING_ENABLED)) : void 0
            }, m = function(e) {
                var t, a, r, i;
                return e.addClass("jdgm-medals-wrapper--small"), e.find(".jdgm-medals").before(e.find(".jdgm-rating").detach()), e.find(".jdgm-medals").after(e.find(".jdgm-verified-by").detach()), a = e.find(".jdgm-medal-wrapper"), i = a.length, t = e.find(".jdgm-medals__container"), t.width(n * i), i > 3 ? (r = e.find(".jdgm-medals"), r.data("current-slide", 1).data("total-slides", i - 2), setInterval(function() {
                    return f(r)
                }, 3e3)) : void 0
            }, f = function(e) {
                var t, a;
                return t = e.data("current-slide"), a = (t - 1) * n, e.animate({
                    scrollLeft: a
                }, 400), t === e.data("total-slides") && (t = 0), e.data("current-slide", t + 1)
            }, _ = function(t) {
                var a, r, n;
                return r = e('<div class="jdgm-medals-separator"> </div>'), n = t.find(".jdgm-verified-wrapper"), a = t.find(".jdgm-medals"), n.index() < a.index() ? n.after(r) : a.after(r)
            }, l = function(e, t) {
                var a, r;
                return a = d(e), jdgmSettings.can_be_branded && (r = jdgmSettings.widget_verified_by_judgeme_text_in_store_medals, e.hasClass("jdgm-review-widget") && (r = jdgmSettings.widget_verified_by_judgeme_text), jdgm.WIDGET_REBRANDING_ENABLED && (r = jdgmSettings.widget_verified_text), s(t, t.data("link"), r, jdgm.WIDGET_REBRANDING_ENABLED)), a.append(t.closest(".jdgm-medals-wrapper").detach())
            }, d = function(t) {
                var a;
                return a = t.find(".jdgm-row-media"), 0 === a.length && (a = e("<div>", {
                    "class": "jdgm-row-media"
                }), t.find(".jdgm-form-wrapper").length > 0 ? t.find(".jdgm-form-wrapper").after(a) : t.find(".jdgm-row-stars").after(a)), a
            }, s = function(t, a, r, n) {
                var i, o;
                if (null == n && (n = !1), !n || jdgmSettings.widget_show_verified_branding) {
                    if (o = "<a class='jdgm-link " + (n ? "jdgm-link--rebranding" : "") + "' href='" + a + "' target='_blank'>" + r + "</a>", n) {
                        if (t.find(".jdgm-verified-link-wrapper").length > 0) return;
                        t.addClass("jdgm-medals--rebranding"), i = e("<div class='jdgm-verified-link-wrapper'></div>"), i.append(o), i.append(jdgm._templateVerifiedCheckmark()), t.append(i)
                    } else t.append(o);
                    return t.find(".jdgm-medal").prop("href", a)
                }
            }, u = function(t) {
                var a, r;
                return r = !1, a = t.find(".jdgm-medals__title-wrapper"), a.length > 0 ? (jdgmSettings.medals_widget_title && e(".jdgm-medals__title").text(jdgmSettings.medals_widget_title), jdgm.setupLazyLoadPicture(e(".jdgm-medal__image")), !0) : r
            }, e(document).on("jdgm.doneLoadingMediaCss", function(t, a) {
                return e(".jdgm-medals-wrapper").removeClass("jdgm-hidden")
            }), v(), t = e(), jdgm._safeRun(function() {
                return u(t)
            }), jdgm._safeRun(function() {
                return p(t)
            }), jdgm._safeRun(function() {
                return g(t)
            }), jdgm._safeRun(function() {
                return m(t)
            }), jdgm._safeRun(function() {
                return f(t)
            }), jdgm._safeRun(function() {
                return l(t)
            })
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, a, r, n, i, o, l, s, d, p, c, m, u, g, _, f, v, h, j, w, y, b, x, C, k;
            return r = "gallery-data", i = {
                widget: ".jdgm-widget",
                gallery: ".jdgm-gallery",
                galleryThumbnail: ".jdgm-gallery__thumbnail",
                galleryThumbnailLink: ".jdgm-gallery__thumbnail-link",
                galleryPopup: ".jdgm-gallery-popup",
                galleryPopupData: ".jdgm-gallery--" + r
            }, n = {
                closeOnBgClick: !1,
                image: {
                    cursor: null,
                    markup: jdgm.templates.photoGalleryPopupContent(),
                    titleSrc: function(e) {
                        return j(e)
                    }
                },
                iframe: {
                    markup: jdgm.templates.photoGalleryPopupContent({
                        mediaType: "video"
                    }),
                    titleSrc: function(e) {
                        return j(e)
                    }
                },
                tLoading: "",
                gallery: {
                    enabled: !0
                },
                callbacks: {
                    open: function() {
                        return setTimeout(function(e) {
                            return function() {
                                return d(), s()
                            }
                        }(this), 0), e("body").addClass("jm-mfp-is-open")
                    },
                    close: function() {
                        return e("body").removeClass("jm-mfp-is-open")
                    },
                    elementParse: function(t) {
                        var a;
                        return a = e(t.el[0]), "video" === a.data("media-type") ? t.type = "iframe" : t.type = "image"
                    },
                    change: function(e) {
                        return setTimeout(function(e) {
                            return function() {
                                return c(), l(), k(), e.index >= e.items.length - 4 ? m() : void 0
                            }
                        }(this), 0)
                    }
                }
            }, d = function() {
                var t;
                return t = e(e.magnificPopup.instance.wrap), t.attr("id", i.galleryPopup.substring(1) + "--" + e.magnificPopup.instance.st.key), t.find(".jm-mfp-container").append(jdgm.templates.photoGalleryPopup())
            }, c = function() {
                var t, a, r, n;
                return n = e(e.magnificPopup.instance.wrap), a = n.find(".jm-mfp-main"), a.length > 0 ? (t = n.find(".jm-mfp-container > .jm-mfp-content"), r = t.find(".jdgm-rev").detach(), t = t.detach(), a.find(".jm-mfp-content-wrapper").prepend(t), a.find(".jdgm-rev").replaceWith(r), jdgm.customizeTimestamp(n), jdgm.setupLazyLoadPicture(n.find(".jdgm-rev__avatar-image")), jdgm.buildStarsFor(n.find(".jdgm-rev__rating"))) : void 0
            }, j = function(e) {
                var t, a, n;
                return t = e.el.closest(i.gallery).data("id"), a = u(t).data(r), a && (n = a.reviews[e.el.data("review-id")]) ? jdgm.templates.reviewForPhotoGallery({
                    review: n
                }) : void 0
            }, t = null, l = function() {
                var a;
                return a = e(e.magnificPopup.instance.wrap), t || (t = a.find(".jm-mfp-arrow").clone()), a.find(".jm-mfp-arrow").remove(), t ? a.find(".jm-mfp-figure figure").append(t) : void 0
            }, s = function() {
                var t, a, n;
                return n = e(e.magnificPopup.instance.wrap), t = u(e.magnificPopup.instance.st.key), a = e("<div>", {
                    "class": i.gallery.substring(1),
                    "data-id": e.magnificPopup.instance.st.key
                }), e.each(t.data(r).reviews, function(e, t) {
                    return a.append(jdgm.templates.photoGalleryThumbnail({
                        review: t
                    }))
                }), n.find(".jm-mfp-carousel").html(a), e.magnificPopup.instance.items = a.find(i.galleryThumbnail).toArray()
            }, k = function() {
                var t, a, r, n, o;
                return o = e.magnificPopup.instance.currItem.el, r = e(e.magnificPopup.instance.wrap), a = r.find(i.galleryThumbnail + "[data-review-id='" + o.attr("data-review-id") + "'][src='" + o.attr("src") + "']"), a.length <= 0 ? void 0 : (n = i.galleryThumbnailLink + "--current", e(n).removeClass(n.substring(1)), a.closest(i.galleryThumbnailLink).addClass(n.substring(1)), t = r.find(i.gallery), t.scrollLeft(a.outerWidth() * (e.magnificPopup.instance.index + 3) - t.width()))
            }, m = function() {
                var t, a, n, o;
                return t = u(e.magnificPopup.instance.st.key), n = t.data(r), !n || n.fetching || n.canNotFetch ? void 0 : (n.fetching = !0, t.data(r, n), a = t.closest(i.widget), o = e.extend(jdgm.ajaxParamsFor(a), {
                    review_type: "all-reviews",
                    sort_by: "with_media",
                    per_page: n.perPage,
                    page: n.page + 1
                }), e.ajax({
                    method: "GET",
                    url: jdgm.API_HOST + "/" + n.url,
                    data: o,
                    success: function(e) {
                        return x(e.html)
                    },
                    complete: function() {
                        return n = t.data(r), n.fetching = !1, t.data(r, n), k()
                    }
                }))
            }, x = function(t) {
                var a, n, i, o, l, d;
                return i = e(e.magnificPopup.instance.wrap), a = u(e.magnificPopup.instance.st.key), d = a.data(r), t.length <= 0 ? (d.canNotFetch = !0, void a.data(r, d)) : (l = [], o = e.parseHTML(t), n = e(o[0]).hasClass("jdgm-rev") ? e(o) : e(o).find(".jdgm-rev"), e.each(n, function(e, t) {
                    var r;
                    return r = v(t), d.reviews[r.uuid] ? void 0 : (r = g(a, r), l.push(r))
                }), 0 === l.length ? d.canNotFetch = !0 : (d.page += 1, l.forEach(function(e) {
                    return d.reviews[e.uuid] = e
                })), a.data(r, d), s())
            }, v = function(t) {
                var a, r, n, i, o, l, s;
                return a = e(t), i = [], e.each(a.find(".jdgm-rev__pic-link:not(.jdgm-rev__product-picture)"), function(t, a) {
                    var r;
                    return r = e(a), i.push({
                        compact: r.find("img.jdgm-rev__pic-img").data("src"),
                        huge: r.data("mfp-src"),
                        original: r.attr("href")
                    })
                }), o = [], e.each(a.find(".jdgm-rev__vids > .jdgm-vid-player"), function(t, a) {
                    var r;
                    return r = e(a), o.push(r.data("external-id"))
                }), l = [], e.each(a.find("jdgm-rev__vids > .jdgm-yt-video"), function(t, a) {
                    var r;
                    return r = e(a), l.push({
                        media_platform_name: "yt",
                        media_platform_url: r.data("id")
                    })
                }), a.find(".jdgm-rev__avatar-image").length > 0 && (r = {
                    normal: a.find(".jdgm-rev__avatar-image").data("src"),
                    retina: a.find(".jdgm-rev__avatar-image").data("src-retina")
                }), n = [], e.each(a.find(".jdgm-rev__cf-ans"), function(t, a) {
                    var r;
                    return r = e(a), n.push(p(r))
                }), s = {
                    uuid: a.data("review-id"),
                    rating: a.find(".jdgm-rev__rating").data("score"),
                    created_at: a.find(".jdgm-rev__timestamp").data("content"),
                    reviewer_name: a.find(".jdgm-rev__author").text(),
                    title: a.find(".jdgm-rev__title").html(),
                    body_html: a.find(".jdgm-rev__body").html(),
                    avatar_image_url: r,
                    gravatar_hash: a.find(".jdgm-rev__icon").data("gravatar-hash"),
                    verified_buyer: a.data("verified-buyer"),
                    product_title: a.data("product-title"),
                    product_url: a.data("product-url"),
                    country_code_show_flag: a.find(".jdgm-rev__location").data("country-code"),
                    location: a.find(".jdgm-rev__location").text(),
                    pictures_urls: i,
                    video_external_ids: o,
                    media_platform_hosted_video_infos: l,
                    cf_answers: n
                }
            }, p = function(e) {
                var t, a, r, n, i, o, l, s, d, p;
                return t = e.find(".jdgm-cf-bars-wrapper"), a = e.find(".jdgm-rev__slider-wrapper"), o = e.find(".jdgm-rev__cf-ans__title").text().slice(0, -1), t.length > 0 ? (i = t.find(".jdgm-cf-bar.jdgm--filled").length, s = t.find(".jdgm-cf-bar").length, p = i + "/" + s, d = "scale", n = t.find(".jdgm-rev__scale-first").text(), l = t.find(".jdgm-rev__scale-last").text()) : a.length > 0 ? (p = a.find(".jdgm-rev__slider-pointer").attr("style").match(/\d{1,3}/g)[0], d = "slider", n = a.find(".jdgm-rev__slider-first").text(), l = a.find(".jdgm-rev__slider-last").text()) : p = e.find(".jdgm-rev__cf-ans__value").text(), r = {
                    value: p,
                    question_title: o,
                    question_type: d,
                    lower_value: n,
                    top_value: l
                }, Object.fromEntries(Object.entries(r).filter(function(e) {
                    return function(e) {
                        var t, a;
                        return t = e[0], a = e[1], void 0 !== a
                    }
                }(this)))
            }, f = function(t, a) {
                return e.magnificPopup.open(e.extend({}, n, {
                    items: t.find(i.galleryThumbnail).toArray()
                }), a)
            }, y = function(t) {
                var a;
                return a = t.data("id"), t.find(i.galleryThumbnailLink).magnificPopup(e.extend({}, n, {
                    key: a,
                    mainClass: i.galleryPopup.substring(1) + " " + i.galleryPopupData.substring(1) + " " + i.galleryPopup.substring(1) + "--" + a,
                    items: t.find(i.galleryThumbnail).toArray()
                }))
            }, w = function() {
                return e(document).on("click", i.widget + " " + i.galleryThumbnailLink + ", " + i.galleryPopupData + " " + i.galleryThumbnailLink, function(t) {
                    return t.preventDefault(), t.stopPropagation(), f(e(this).parent(), e(this).index())
                }), e(document).on("click", i.galleryPopupData + " .jm-mfp-main", function(t) {
                    return e(t.target).is("a") || t.preventDefault(), t.stopPropagation()
                }), e(document).on("click", ".jm-mfp-bg, " + i.galleryPopupData + " .jm-mfp-container, " + i.galleryPopupData + " .jm-mfp-close", function(t) {
                    return e.magnificPopup.instance.close()
                }), e(document).on("click", i.galleryPopupData + " .jm-mfp-arrow-left", function(t) {
                    return e.magnificPopup.instance.prev()
                }), e(document).on("click", i.galleryPopupData + " .jm-mfp-arrow-right", function(t) {
                    return e.magnificPopup.instance.next()
                })
            }, b = function(e) {
                return C(e), y(e)
            }, C = function(e) {
                var t, a;
                return a = {
                    reviews: {},
                    url: e.data("url"),
                    perPage: e.data("per-page"),
                    page: 1,
                    fetching: !1,
                    canNotFetch: !1
                }, t = e.find(".jdgm-gallery-data"), t.data("json").forEach(function(t) {
                    return t && t.uuid ? (t = g(e, t), a.reviews[t.uuid] = t, e.append(jdgm.templates.photoGalleryThumbnail({
                        review: t,
                        preload: !0
                    }))) : void 0
                }), t.remove(), 0 === Object.keys(a.reviews).length ? h(e) : (o(e), jdgm.setupLazyLoadPicture(e.find(i.galleryThumbnail)), a.canNotFetch = Object.keys(a.reviews).length < a.perPage, e.data(r, a))
            }, o = function(t) {
                var a, r, n;
                return jdgm.isVersion3 ? (n = t.closest(i.widget), r = n.find(".jdgm-row-media"), 0 === r.length && (r = e("<div>", {
                    "class": "jdgm-row-media"
                })), t.wrap('<div class="jdgm-gallery-wrapper"></div>'), a = t.closest(".jdgm-gallery-wrapper").detach(), a.prepend("<div class='jdgm-gallery-title'>" + jdgmSettings.widget_media_grid_title + "</div>"), r.prepend(a), n.find(".jdgm-custom-forms-avg-responses").length > 0 ? n.find(".jdgm-custom-forms-avg-responses").after(r.detach()) : n.find(".jdgm-form-wrapper").length > 0 ? n.find(".jdgm-form-wrapper").after(r.detach()) : n.find(".jdgm-row-stars").after(r.detach())) : void 0
            }, g = function(t, a) {
                var r, n, i, o, l;
                for (a.video_external_data = {}, o = a.video_external_ids, n = 0, i = o.length; i > n; n++) r = o[n], l = {
                    external_id: r
                }, r.length > 16 ? (l.img_src = "https://cloudflarestream.com/" + r + "/thumbnails/thumb_5_0.jpg", l.iframe_src = "https://iframe.videodelivery.net/" + r) : e.ajax({
                    url: "https://vimeo.com/api/oembed.json",
                    data: {
                        url: "https://vimeo.com/" + r
                    },
                    success: function(e) {
                        return _(t, e, a)
                    }
                }), a.video_external_data[r] = l;
                return a
            }, _ = function(e, t, a) {
                var n, o;
                return o = e.data(r), o.reviews[a.uuid].video_external_data[t.video_id].img_src = t.thumbnail_url, o.reviews[a.uuid].video_external_data[t.video_id].iframe_src = "https://player.vimeo.com" + t.uri, e.data(r, o), n = e.find(i.galleryThumbnail + "[data-external-id=" + t.video_id + "]"), n.attr("src", t.thumbnail_url), n.attr("data-src", t.thumbnail_url), n.attr("data-iframe-src", "https://player.vimeo.com" + t.uri), n.parent().removeClass("jdgm--loading")
            }, u = function(t) {
                return e(i.widget + " " + i.gallery + "[data-id=" + t + "]")
            }, h = function(t) {
                return null == t && (t = null), null === t && (t = e(i.widget + " " + i.gallery)), t.closest(i.widget).attr("data-display-media", "false"), t.remove()
            }, jdgmSettings.widget_show_photo_gallery ? (e.each(e(i.widget + " " + i.gallery), function(t, a) {
                var n;
                return n = e(a), n.data("loaded") ? void 0 : (n.attr("data-loaded", !0), n.attr("data-id", r + "-" + t), b(n))
            }), e(i.widget + " " + i.gallery).data("setup-event") || (e(i.widget + " " + i.gallery).attr("data-setup-event", !0), w())) : h(), a = e(), jdgm._safeRun(function() {
                return C(a)
            }), jdgm._safeRun(function() {
                return y(a)
            }), jdgm._safeRun(function() {
                return _(a, {}, {})
            }), jdgm._safeRun(function() {
                return c()
            }), jdgm._safeRun(function() {
                return j(a)
            }), jdgm._safeRun(function() {
                return l()
            }), jdgm._safeRun(function() {
                return s()
            }), jdgm._safeRun(function() {
                return k()
            }), jdgm._safeRun(function() {
                return m()
            }), jdgm._safeRun(function() {
                return x("")
            }), jdgm._safeRun(function() {
                return v("")
            })
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, a, r, n, i, o, l, s, d, p, c, m, u, g, _, f, v, h, j, w;
            return n = "ugc-media", o = {
                mediaGrid: ".jdgm-ugc-media",
                mediaThumbnail: ".jdgm-ugc-media__thumbnail",
                review: ".jdgm-rev",
                reviewAttachment: ".jdgm-rev-attachment"
            }, r = "jdgm-gallery", i = {
                closeOnBgClick: !1,
                image: {
                    cursor: null,
                    markup: jdgm.templates.photoGalleryPopupContent(),
                    titleSrc: function(e) {
                        return g(e)
                    }
                },
                iframe: {
                    markup: jdgm.templates.photoGalleryPopupContent({
                        mediaType: "video-native"
                    }),
                    titleSrc: function(e) {
                        return g(e)
                    }
                },
                tLoading: "",
                gallery: {
                    enabled: !0
                },
                callbacks: {
                    open: function() {
                        return setTimeout(function(e) {
                            return function() {
                                return d(e), s(e)
                            }
                        }(this), 0), e("body").addClass("jm-mfp-is-open")
                    },
                    close: function() {
                        return e("body").removeClass("jm-mfp-is-open")
                    },
                    elementParse: function(t) {
                        var a;
                        return a = e(t.el[0]), "video" === a.data("media-type") ? t.type = "iframe" : t.type = "image"
                    },
                    change: function(e) {
                        return setTimeout(function(e) {
                            return function() {
                                return p(e), l(e), w(e), e.index >= e.items.length - 2 ? c(e.st.key, e) : void 0
                            }
                        }(this), 0)
                    }
                }
            }, d = function(t) {
                var a;
                return t.wrap ? (a = e(t.wrap), a.attr("id", "jdgm-gallery-popup--" + t.st.key), a.find(".jm-mfp-container").append(jdgm.templates.photoGalleryPopup())) : void 0
            }, s = function(t) {
                var a, i, o;
                return t.wrap ? (o = e(t.wrap), a = m(t.st.key), i = e("<div>", {
                    "class": r,
                    "data-id": t.st.key
                }), e.each(a.data(n).objects, function(e, t) {
                    return i.append(jdgm.templates.photoGalleryPopupThumbnail({
                        object: t
                    }))
                }), o.find(".jm-mfp-carousel").html(i), e.magnificPopup.instance.items = i.find("." + r + "__thumbnail").toArray()) : void 0
            }, g = function(e) {
                var t, a, r, i;
                return e.el && (r = e.el.attr("class").split("__")[0], t = e.el.closest("." + r).data("id"), i = m(t).data(n), i && (a = i.objects[e.el.data("object-id")])) ? jdgm.templates.ugcMediaGridPopup({
                    post: a
                }) : void 0
            }, p = function(t) {
                var a, r, n, i;
                return t.wrap && (i = e(t.wrap), n = i.find(".jm-mfp-main"), n.length > 0) ? (a = i.find(".jm-mfp-container > .jm-mfp-content"), r = a.find(o.review).detach(), a = a.detach(), n.find(".jm-mfp-content-wrapper").prepend(a), n.find(o.review).replaceWith(r), jdgm.asyncEach(n.find(o.reviewAttachment), function(t) {
                    var a, r, n;
                    return n = e(t), a = n.find(o.reviewAttachment + "__review-stars"), jdgm.buildStarsFor(a), r = n.find(o.reviewAttachment + "__review-text"), jdgm._customizeBadgeTexts(r, r.data("reviews"), a.data("score"))
                })) : void 0
            }, t = null, l = function(a) {
                var r;
                return a.wrap && (r = e(a.wrap), t || (t = r.find(".jm-mfp-arrow").clone()), r.find(".jm-mfp-arrow").remove(), t) ? r.find(".jm-mfp-figure figure").append(t) : void 0
            }, w = function(t) {
                var a, n, i, o, l;
                if (t.wrap) {
                    if (i = e(t.wrap), l = t.currItem.el.attr("src"), o = "." + r, n = i.find(o + "__thumbnail[src='" + l + "']"), n.length <= 0) return;
                    return e(o + "__thumbnail-link--current").removeClass(r + "__thumbnail-link--current"), n.closest(o + "__thumbnail-link").addClass(r + "__thumbnail-link--current"), a = i.find(o), a.scrollLeft(n.outerWidth() * (t.index + 3) - a.width())
                }
            }, u = function(t, a, r) {
                return e.magnificPopup.open(e.extend({}, i, {
                    items: t.find(a).toArray()
                }), r)
            }, c = function(t, a) {
                var r, i, l, d;
                return null == a && (a = null), i = m(t), l = i.data(n), !l || l.fetching || l.canNotFetch ? void 0 : (l.fetching = !0, i.data(n, l), r = e(o.mediaGrid + "__load-more-btn"), r.attr("disabled", "disabled"), d = e.extend(jdgm.ajaxParamsFor(i), {
                    per_page: l.perPage,
                    page: l.page + 1
                }), e.ajax({
                    method: "GET",
                    url: jdgm.API_HOST + "/reviews/social_posts",
                    data: d,
                    success: function(e) {
                        return jdgm._transformJsonData(i, e)
                    },
                    complete: function() {
                        return l = i.data(n), l.fetching = !1, i.data(n, l), f(), a && (s(a), w(a)), r.removeAttr("disabled")
                    }
                }))
            }, v = function(t) {
                var a;
                return a = t.data("id"), t.find(o.mediaGrid + "__thumbnail-link").magnificPopup(e.extend({}, i, {
                    key: a,
                    mainClass: "jdgm-gallery-popup jdgm-gallery-popup__" + n + " jdgm-gallery-popup--" + a,
                    items: t.find(o.mediaThumbnail).toArray()
                }))
            }, _ = function() {
                return e(document).off("click", o.mediaGrid + "__thumbnail-link"), e(document).on("click", o.mediaGrid + "__thumbnail-link", function(t) {
                    return u(e(this).parent(), o.mediaThumbnail, e(this).index() - 1)
                }), e(document).on("click", ".jdgm-gallery-popup__" + n + " .jdgm-gallery__thumbnail-link", function(t) {
                    return t.preventDefault(), t.stopPropagation(), u(e(this).parent(), "." + r + "__thumbnail", e(this).index())
                }), e(document).off("click", o.mediaGrid + "__load-more-btn"), e(document).on("click", o.mediaGrid + "__load-more-btn", function(t) {
                    var a;
                    return a = e(this).siblings(o.mediaGrid).data("id"), c(a)
                }), e(document).on("click", o.mediaGrid + "__primary-btn[data-url], " + o.mediaGrid + "__reviews-btn[data-url]", function(t) {
                    return window.open(e(t.target).data("url"), "_blank")
                }), e(document).on("click", ".jdgm-gallery-popup__" + n + " .jm-mfp-main", function(t) {
                    return e(t.target).is("a") || t.preventDefault(), t.stopPropagation()
                }), e(document).on("click", ".jm-mfp-bg, .jdgm-gallery-popup__" + n + " .jm-mfp-container, .jdgm-gallery-popup__" + n + " .jm-mfp-close", function(t) {
                    return e.magnificPopup.instance.close()
                }), e(document).on("click", ".jdgm-gallery-popup__" + n + " .jm-mfp-arrow-left", function(t) {
                    return e.magnificPopup.instance.prev()
                }), e(document).on("click", ".jdgm-gallery-popup__" + n + " .jm-mfp-arrow-right", function(t) {
                    return e.magnificPopup.instance.next()
                })
            }, m = function(t) {
                return e(o.mediaGrid + "[data-id=" + t + "]")
            }, j = function() {
                return h(o.mediaGrid + "__thumbnail-link[data-execute-after-load=true]"), h(o.mediaGrid + "__load-more-btn[data-execute-after-load=true]")
            }, h = function(t) {
                var a;
                return a = e(t), a.length > 0 ? (a.trigger("click"), a.removeAttr("data-execute-after-load")) : void 0
            }, f = function() {
                return e.each(e(o.mediaGrid), function(t, a) {
                    return v(e(a))
                })
            }, f(), e(o.mediaGrid).data("setup-event") || (e(o.mediaGrid).attr("data-setup-event", !0), _(), j()), a = e(), jdgm._safeRun(function() {
                return d({})
            }), jdgm._safeRun(function() {
                return s({})
            }), jdgm._safeRun(function() {
                return g({})
            }), jdgm._safeRun(function() {
                return p({})
            }), jdgm._safeRun(function() {
                return l({})
            }), jdgm._safeRun(function() {
                return w({})
            }), jdgm._safeRun(function() {
                return c(1)
            })
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            return jdgm.triggerEvent("doneLoadingMediaJs")
        })
    }.call(this);