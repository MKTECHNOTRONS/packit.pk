(function() {
    this.JST || (this.JST = {}), this.JST["templates/shopify_v2/widget_actions_wrapper"] = function(obj) {
        var __p = [];
        with(obj || {}) __p.push('<div class="jdgm-widget-actions-wrapper">\n  '), jdgmSettings.widget_add_search_bar && addSearch && __p.push('\n    <input type="text" name=\'', jdgmSettings.widget_search_bar_placeholder, "' class=\"jdgm-review-search\" placeholder='", jdgmSettings.widget_search_bar_placeholder, "' aria-label='", jdgmSettings.widget_search_bar_placeholder, "'>\n  "), __p.push("\n</div>\n");
        return __p.join("")
    }
}).call(this),
    function() {
        this.JST || (this.JST = {}), this.JST["templates/shopify_v2/sort_dropdown"] = function(obj) {
            var __p = [];
            with(obj || {}) __p.push("<div class='jdgm-sort-dropdown-wrapper'>\n  <select class='jdgm-sort-dropdown' aria-label='Sort dropdown'>\n    <option value='most-recent'>", jdgmSettings.widget_sorting_most_recent_text, "</option>\n    <option value='highest-rating'>", jdgmSettings.widget_sorting_highest_rating_text, "</option>\n    <option value='lowest-rating'>", jdgmSettings.widget_sorting_lowest_rating_text, "</option>\n    <option value='with-pictures'>", jdgmSettings.widget_sorting_with_pictures_text, "</option>\n    <option value='pictures-first'>", jdgmSettings.widget_sorting_pictures_first_text, "</option>\n    <option value='videos-first'>", jdgmSettings.widget_sorting_videos_first_text || "Videos first", "</option>\n    <option value='most-helpful'>", jdgmSettings.widget_sorting_most_helpful_text, "</option>\n  </select><span class='jdgm-sort-dropdown-arrow'></span>\n</div>\n");
            return __p.join("")
        }
    }.call(this),
    function() {
        this.JST || (this.JST = {}), this.JST["templates/shopify_v2/setting_css_style"] = function(obj) {
            var __p = [];
            with(obj || {}) __p.push("<style>\n.jdgm-rev__icon::after { content: '\\e001'; }\n.jdgm-rev__icon::after,\n.jdgm-rev__buyer-badge {\n  display: inline-block;\n  color: ", verifiedBadgeOpts.color, ";\n  background-color: ", verifiedBadgeOpts.bgColor, ";\n}\n.jdgm-rev__buyer-badge:before { content: '", verifiedBadgeOpts.text, "'; }\n\n.jdgm-rev-widg__title { visibility: unset; }\n.jdgm-rev-widg__summary-text { visibility: unset; }\n.jdgm-prev-badge__text { visibility: unset; }\n\n.jdgm-quest__body:before { content: '", questionLabel, ":'; }\n.jdgm-ans__body:before { content: '", answerLabel, ":'; }\n\n.jdgm-star { color: ", linkColor, "; }\n\n.jdgm-ask-question-btn,\n.jdgm-write-rev-link,\n.jdgm-all-reviews-rating-wrapper,\n.jdgm-carousel-wrapper a,\n.jdgm-rev__prod-link,\n.jdgm-all-reviews-text a,\n.jdgm-carousel-item__product,\n.jdgm-carousel-number-of-reviews,\n.jdgm-revs-tab__url { color: ", buttonColor, "; }\n\na.jdgm-write-rev-link {\n    color: ", writeReviewTextColor, ";\n    background-color: ", writeReviewBgColor, ";\n}\n\n/* Legacy selectors, to keep old CSS specificities */\n.jdgm-preview-badge .jdgm-star { color: ", linkColor, "; }\n.jdgm-histogram .jdgm-star { color: ", linkColor, "; }\n</style>\n");
            return __p.join("")
        }
    }.call(this),
    function() {
        this.JST || (this.JST = {}), this.JST["templates/shopify_v2/header"] = function(obj) {
            var __p = [];
            with(obj || {}) __p.push("<div class='jdgm-rev-widg jdgm--js' data-number-of-reviews='0' data-average-rating='0.00'>\n  <div class='jdgm-rev-widg__header'>\n    <h2 class='jdgm-rev-widg__title'>Customer Reviews</h2>\n    <div class='jdgm-rev-widg__summary'>\n      <div class='jdgm-rev-widg__summary-stars'></div>\n      <div class='jdgm-rev-widg__summary-text'>No reviews yet</div>\n    </div>\n    <a href='#' class='jdgm-write-rev-link'>Write a review</a>\n  </div>\n</div>\n");
            return __p.join("")
        }
    }.call(this),
    function() {
        this.JST || (this.JST = {}), this.JST["templates/shopify_v2/badge"] = function(obj) {
            var __p = [];
            with(obj || {}) __p.push("<div class='jdgm-prev-badge jdgm--js' data-average-rating='", averageRating, "' data-number-of-reviews='", reviewCount, "'>\n  <span class='jdgm-prev-badge__stars' data-score='", averageRating, "'></span>\n  <span class='jdgm-prev-badge__text'>", previewBadgeText, "</span>\n</div>\n");
            return __p.join("")
        }
    }.call(this),
    function() {
        this.JST || (this.JST = {}), this.JST["templates/shopify_v2/review_keywords"] = function(obj) {
            var __p = [];
            with(obj || {}) {
                __p.push("<div class='jdgm-keywords'>\n  ");
                for (var i = 0; i < keywordData.length; i++) {
                    __p.push("\n    ");
                    var _item = keywordData[i];
                    __p.push('\n    <span role="button" class="jdgm-chip" data-text="', ("" + _item.content).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), '">\n      ', ("" + _item.content).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "\n      "), _item.quantity > 1 && __p.push("\n        (", ("" + _item.quantity).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), ")\n      "), __p.push("\n    </span>\n  ")
                }
                __p.push("\n</div>\n")
            }
            return __p.join("")
        }
    }.call(this),
    function() {
        this.JST || (this.JST = {}), this.JST["templates/shopify_v3/custom_forms_avg_responses"] = function(obj) {
            var __p = [];
            with(obj || {}) __p.push(""), cf_answers && (__p.push("\n  "), jdgm.asyncEach(cf_answers, function(e) {
                if (__p.push("\n    <div class='jdgm-rev__cf-ans'>\n      <b class='jdgm-rev__cf-ans__title'>", ("" + e.title).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), ":</b>\n      "), "scale" == e.question_type) {
                    __p.push("\n        <div class='jdgm-cf-bars-wrapper' data-value='", ("" + e.value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'>\n          <div class='jdgm-rev__scale-range'>\n            ");
                    var t = e.value.split("/")[0];
                    __p.push("\n            ");
                    var r = e.value.split("/")[1];
                    __p.push("\n            ");
                    for (var n = 1; r >= n; n++) __p.push("\n              "), t >= n ? __p.push('\n                <a href="#" rel="nofollow" class="jdgm-cf-bar jdgm--filled"></a>\n              ') : __p.push('\n                <a href="#" rel="nofollow" class="jdgm-cf-bar jdgm--empty"></a>\n              '), __p.push("\n            ");
                    __p.push("\n          </div>\n          <div class='jdgm-rev__scale-first'>", ("" + e.lower_value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "</div>\n          <div class='jdgm-rev__scale-last'>", ("" + e.top_value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "</div>\n        </div>\n      ")
                } else "slider" == e.question_type && __p.push("\n        <div class='jdgm-rev__slider-wrapper'>\n          <div class='jdgm-rev__slider-range'>\n            <div class='jdgm-rev__slider-pointer' style='left: ", ("" + e.value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "%'></div>\n          </div>\n          <div class='jdgm-rev__slider-first'>", ("" + e.lower_value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "</div>\n          <div class='jdgm-rev__slider-last'>", ("" + e.top_value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "</div>\n        </div>\n      ");
                __p.push("\n    </div>\n  ")
            }), __p.push("\n")), __p.push("\n");
            return __p.join("")
        }
    }.call(this),
    function() {
        this.JST || (this.JST = {}), this.JST["templates/shopify_v3/custom_forms_filters"] = function(obj) {
            var __p = [];
            with(obj || {}) __p.push(""), cf_questions && (__p.push("\n  "), jdgm.asyncEach(cf_questions, function(e) {
                __p.push("\n    <div class='jdgm-rev__cf-ans' data-question-id='", ("" + e.id).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "'>\n      <b class='jdgm-rev__cf-ans__title'>", ("" + e.title).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), ":</b>\n      <div class='jdgm-rev__cf-options-wrapper'>\n        ");
                for (var t = 0; t < e.cf_options.length; t++) __p.push('\n          <span role="button" class="jdgm-rev__cf-option jdgm-chip">\n            ', ("" + e.cf_options[t]).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "\n          </span>\n        ");
                __p.push("\n      </div>\n    </div>\n  ")
            }), __p.push('\n  <div class="jdgm-custom-forms-filters__button jdgm-chip" role="button" aria-expanded="false">', ("" + jdgmSettings.widget_custom_forms_filter_button).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;"), "</div>\n")), __p.push("\n");
            return __p.join("")
        }
    }.call(this), jdgm.$(function(e) {
        jdgm.templates = jdgm.templates || {}, jdgm.templates.header = JST["templates/shopify_v2/header"], jdgm.templates.badge = JST["templates/shopify_v2/badge"], jdgm.templates.reviewKeywords = JST["templates/shopify_v2/review_keywords"], jdgm.templates.customFormsAvgResponses = JST["templates/shopify_v3/custom_forms_avg_responses"], jdgm.templates.customFormsFilters = JST["templates/shopify_v3/custom_forms_filters"], jdgm.templates.emptyBadge = function() {
            return jdgm.templates.badge({
                averageRating: "0.00",
                reviewCount: 0,
                previewBadgeText: "No reviews"
            })
        }
    }),
    function() {
        jdgm.$(function(e) {
            var t, r, n, i, a;
            return a = jdgm._safeRun, n = function() {
                return {}
            }, t = e(), i = function() {
                var t, r;
                return t = new Date, r = t.getFullYear() + "-" + t.getMonth() + "-" + t.getDate() + " ", e("<i><span class='jdgm-rev__timestamp' data-content='" + r + "'></span></i>")
            }, r = function(t) {
                var r, n;
                return r = new Date, n = r.getMonth() + "/" + r.getDate() + "/" + r.getFullYear(), e("<i><span class='jdgm-carousel-item__timestamp' data-time='" + n + "'></span></i>")
            }, a(function() {
                return e(jdgm._htmlFor("sort_dropdown")).dotdotdot({
                    height: 0
                }), jdgm._htmlFor("header"), jdgm.templates.emptyBadge()
            }), a(function() {
                return jdgm.visibleRevWidget(), jdgm.visibleAllReviewsPage(), jdgm.eachRevWidgets(n), jdgm.eachPrevBadges(n), jdgm.ajaxParamsFor(t), jdgm.setupLazyLoadPicture(t), jdgm.changeToRefreshBtn(t), jdgm.renderAskQuestionBtn(t)
            }), a(function() {
                return jdgm.initializeWidgets(e("<i><i class='jdgm-review-widget'></i></i>"))
            }), a(function() {
                return jdgm.pluralizeLongText("review/reviews", 1), jdgm.customizeTimestamp(i(), "mm/dd/yyyy"), jdgm.customizeCarouselTimestamp(r(), "timestamp"), jdgm._renderSubtab([{}]), jdgm._renderAllRevsSubtab(0, 0), jdgm.openSubtab(t), jdgm._fixAuthorNameIfFromShop(t), jdgm._customizeReviewWidget(t)
            }), a(function() {
                return jdgm.batchRenderBadges(t), jdgm.batchRenderBadgesWithCallback(t, void 0), jdgm.renderJsBadge(0, 0, "")
            })
        })
    }.call(this),
    function() {
        var e, t, r, n;
        e = jdgm.$, jdgm.forceShowHideRevWidget = function(e, t) {
            return e.toggle(t), e.find(".jdgm-rev-widg").toggle(t)
        }, jdgm.visibleRevWidget = function() {
            return e(".jdgm-review-widget:visible").filter(n)
        }, n = function() {
            return "hidden" !== e(this).css("visibility")
        }, jdgm.visibleAllReviewsPage = function() {
            return e(".jdgm-all-reviews-widget:visible").filter(n)
        }, jdgm.getWidgetPrefix = function(e) {
            var t, r;
            return r = {
                "jdgm-review-widget": "jdgm-rev-widg",
                "jdgm-revs-tab": "jdgm-revs-tab",
                "jdgm-all-reviews-widget": "jdgm-all-reviews"
            }, t = null, Object.keys(r).forEach(function(n) {
                return e.hasClass(n) ? t = r[n] : void 0
            }), t
        }, jdgm.eachWidgetWithReviews = function(t) {
            return jdgm.asyncEach(jdgm.caches.$widgetWithReviews, function(r) {
                var n;
                return n = e(r), n.data("unique-string") || (n.data("unique-string", Date.now().toString(36) + "-" + jdgm.random(1e6).toString(36)), n.data("class-prefix", jdgm.getWidgetPrefix(n))), t(n)
            })
        }, jdgm.eachRevWidgets = function(t) {
            return jdgm.asyncEach(jdgm.caches.$revWidgets, function(r) {
                return t(e(r))
            })
        }, jdgm.eachPrevBadges = function(t) {
            return jdgm.asyncEach(jdgm.caches.$prevBadges, function(r) {
                return t(e(r))
            })
        }, jdgm.ajaxParamsFor = function(n) {
            var i, a, d;
            return a = (d = n.find(".jdgm-rev-widg").data("updated-at")) ? Date.parse(d) / 1e3 : Date.now() / 1e3 / jdgmSettings.ajaxCdnCacheTtl, i = e.extend(jdgm.shopParams(), {
                per_page: n.find(".jdgm-paginate").data("per-page"),
                product_id: n.data("id"),
                sort_by: n.data("sort-by"),
                sort_dir: n.data("sort-dir"),
                filter_rating: n.data("filter-rating"),
                search: n.find(".jdgm-review-search").val() || null,
                keyword: t(n),
                cf_answer: r(n),
                ts: jdgmSettings.enable_ajax_cdn_cache && parseInt(a) || null
            }), jdgm.compactHash(i)
        }, r = function(e) {
            var t, r;
            return t = e.find(".jdgm-rev__cf-option.jdgm-chip.active"), 0 === t.length ? null : (r = t.closest(".jdgm-rev__cf-ans").data("question-id"), [r, t.text().trim()])
        }, t = function(e) {
            var t;
            return t = e.find(".jdgm-keywords .jdgm-chip.active"), 0 === t.length ? null : t.data("text") || t.text().trim().replace(/\(\d+\)/, "").trim()
        }, jdgm.changeToRefreshBtn = function(e) {
            var t;
            return e.find(".jdgm-ask-question-btn").hide(), t = e.find(".jdgm-write-rev-link"), t.text(jdgmSettings.widget_refresh_page_text).off().on("click", function() {
                return window.location = window.location.pathname, !1
            })
        }, jdgm.renderAskQuestionBtn = function(t) {
            var r;
            if (!(t.find(".jdgm-ask-question-btn").length > 0)) return r = e("<a style='display: none' href='#' class='jdgm-ask-question-btn' role='button' aria-expanded='false'>" + jdgmSettings.widget_open_question_form_text + "</a>"), r.insertAfter(t.find(".jdgm-write-rev-link"))
        }, jdgm.initializeWidgets = function(t) {
            return null == t && (t = e("body")), t.find(".jdgm-review-widget:not(." + jdgm.DONE_SETUP_WIDGET_CLASS + ")").each(function(t, r) {
                var n;
                return n = e(r), jdgm._addEmptyWidgetHeader(n), jdgm._customizeReviewWidget(n), jdgm.setupMediaGallery(n), jdgm._renderAndSetupReviewForm(n), jdgm._setupQuestionsForm(n), jdgm._setupLoadReviewsEventsFor(n), jdgm._setupFormsSubmit(n), n.addClass(jdgm.DONE_SETUP_WIDGET_CLASS)
            }), jdgm.customizeReviews()
        }, jdgm.$(function(e) {
            return jdgm.caches = {
                $widgetWithReviews: e(".jdgm-review-widget, .jdgm-revs-tab, .jdgm-all-reviews-widget"),
                $revWidgets: e(".jdgm-review-widget"),
                $prevBadges: e(".jdgm-preview-badge")
            }
        })
    }.call(this),
    function() {
        var e, t, r, n, i, a, d, g, s, o, m, u, l, c, _, p, v;
        e = jdgm.$, t = "[^\\s}{/]+", l = "[^<]/", v = /_/g, c = new RegExp(t + l), u = new RegExp(l + t), r = new RegExp(t + l + t), o = 864e5, _ = new Date, p = new Date(_.getUTCFullYear(), _.getUTCMonth(), _.getUTCDate()), jdgm.pluralizeLongText = function(e, t) {
            var n, i;
            return e.match(r) ? (i = t > 1 ? u : c, n = e.match(i)[0].replace(v, " ").replace("/", ""), t > 1 && (n = n.substr(1)), e.replace(r, n)) : e
        }, jdgm.customizeTimestamp = function(t, r) {
            return jdgm.asyncEach(t.find(".jdgm-rev__timestamp"), function(t) {
                var n, i, a;
                return n = e(t), (a = n.data("content")) ? (i = g(a, r), n.text(i).removeClass("jdgm-spinner")) : void 0
            })
        }, jdgm.customizeCarouselTimestamp = function(t, r, n) {
            return null == r && (r = null), null == n && (n = ".jdgm-carousel-item__timestamp"), jdgm.asyncEach(t.find(n), function(t) {
                var i, a, d;
                return i = e(t), (d = ".jdgm-full-rev__timestamp" === n ? i.data("content") : i.data("time")) ? (d = d.split("/"), d = d[2] + "-" + d[0] + "-" + d[1], a = g(d, r), i.text(a).removeClass("jdgm-spinner")) : void 0
            })
        }, jdgm._customizeBadgeTexts = function(e, t, r) {
            return t ? i(e, t, r) : e.text(jdgmSettings.badge_no_review_text)
        }, i = function(e, t, r) {
            var n, i;
            return (i = jdgmSettings.badge_n_reviews_text) ? (n = i.replace("{{ n }}", t), n = jdgm.pluralizeLongText(n, t), n = n.replace("{{ average_rating }}", r), n = n.replace("{{ average_rating_1_decimal }}", parseFloat(r).toPrecision(2)), e.html(n)) : void 0
        }, d = function(e, t) {
            return new Date(e, t + 1, 0).getDate()
        }, s = function(e, t) {
            var r;
            return r = 12 * (t.getFullYear() - e.getFullYear()), r += t.getMonth() - e.getMonth() - 1, t.getDate() >= e.getDate() && (r += 1), 0 >= r ? 0 : r
        }, m = function(e) {
            var t, r, n, i, a, g, m, u;
            return u = e.substr(0, 10).split("-"), g = new Date(u[0], u[1] - 1, u[2]), r = Math.floor((p - g) / o), i = Math.floor(r / 7), n = s(g, p), a = Math.floor(n / 12), t = d(p.getFullYear(), p.getMonth()), m = 0 === r ? jdgmSettings.widget_today_text : 7 > r ? 1 === r ? jdgmSettings.widget_yesterday_text : r + " days ago" : t >= r ? 1 === i ? "1 week ago" : i + " weeks ago" : 12 > n ? 1 === n ? "1 month ago" : n + " months ago" : 1 === a ? "1 year ago" : a + " years ago", "0 months ago" === m && (m = "1 month ago"), m
        }, n = function(e) {
            return e.indexOf("year") >= 0 ? e = a(e, "years") : e.indexOf("month") >= 0 ? e = a(e, "months") : e.indexOf("week") >= 0 ? e = a(e, "weeks") : e.indexOf("days") >= 0 && (e = a(e, "days")), e
        }, a = function(e, t) {
            var r, n;
            return n = e.match(/\d+/)[0], (r = jdgmSettings["widget_" + t + "_text"]) ? (e = r.replace("{{ n }}", n), jdgm.pluralizeLongText(e, n)) : e
        }, g = function(e, t) {
            var r;
            return r = e.substr(0, 10).split("-"), t || (t = jdgmSettings.review_date_format), t && "timestamp" !== t ? t.replace("yyyy", r[0].toString()).replace("yy", r[0].toString().substr(2, 3)).replace("mm", r[1].toString()).replace("dd", r[2].toString()) : n(m(e))
        }
    }.call(this),
    function() {
        var e, t, r;
        e = jdgm.$, t = function(t, r, n, i, a) {
            var d;
            return null == a && (a = {}), d = t.data("url") || r.data("url"), jdgmSettings.enable_ajax_cdn_cache && (d = d.replace(jdgm.API_HOST, jdgm.SPECIAL_CDN_HOST_HTTPS)), e.ajax({
                url: d,
                data: n,
                success: function(e) {
                    return i && i(e, a), r.find('[data-tabname="reviews"] .jdgm-subtab__count').text(e.total_count), r.find(".jdgm-paginate__page[data-page='" + n.page + "']").focus()
                }
            })
        }, r = function(r, n, i, a) {
            var d, g, s;
            return null == a && (a = e.noop), n && n(), d = r.find(".jdgm-paginate"), g = e.extend(jdgm.shopParams(), a()), jdgm.triggerEvent("beforeFetchingReviews"), g.primary_language ? (t(d, r, g, i, {
                hideOtherLang: !1
            }), g = e.extend(jdgm.shopParams(), a(!1)), s = {
                otherLang: !0,
                hideOtherLang: !1
            }, t(d, r, g, i, s)) : t(d, r, g, i)
        }, jdgm.setupPaginate = function(r, n, i, a) {
            return null == a && (a = e.noop), r.on("click", ".jdgm-paginate__page:not(.jdgm-curt), .jdgm-paginate__load-more", function(d) {
                var g, s, o;
                return n && n(), g = e(this), s = g.closest(".jdgm-paginate"), o = e.extend(jdgm.shopParams(), {
                    page: g.data("page"),
                    per_page: s.data("per-page")
                }, a()), jdgm.triggerEvent("beforeFetchingReviews"), t(s, r, o, i)
            })
        }, jdgm.setupSearch = function(t, n, i, a) {
            return null == a && (a = e.noop), t.on("change", ".jdgm-review-search", function(e) {
                return t.trigger("jdgm.searchReviews", [{
                    resetFilterKeyword: !0
                }])
            }), t.on("jdgm.searchReviews", function(e, d) {
                return d && Object.keys(d).length > 0 && jdgm._resetFilterAndSearch(t, d), r(t, n, i, a)
            }), t.on("jdgm.filterReviewsByCustomForms", function(e) {
                return r(t, n, i, a)
            })
        }, jdgm.fetchSingleReview = function(r, n, i, a, d) {
            var g, s;
            return null == d && (d = e.noop), i && i(), g = r.find(".jdgm-paginate"), s = e.extend(jdgm.shopParams(), {
                page: 1,
                per_page: g.data("per-page"),
                review_uuid: n
            }, d()), jdgm.triggerEvent("beforeFetchingReviews", {
                single: !0
            }), t(g, r, s, a)
        }, jdgm._appendPaginateResultToBody = function(t, r, n, i, a) {
            var d, g, s, o, m;
            return s = e(t.html), o = s.find(n), g = r.find(i), g.append(o), jdgm.triggerEvent("doneAppendMoreReviews", {
                $reviews: o,
                $widget: r
            }), d = g.siblings(".jdgm-paginate"), m = s.filter(".jdgm-paginate"), 0 === m.length && (m = s.find(".jdgm-paginate")), m.text().length <= 0 ? d.remove() : (d.html(m.html()), d.show()), a ? a(r) : void 0
        }
    }.call(this),
    function() {
        var e, t, r, n, i, a, d, g, s, o;
        e = jdgm.$, r = "jdgm-histogram__row--selected", t = ".jdgm-rev-widg__other-lang", n = {
            "most-recent": {
                by: "created_at",
                dir: "desc"
            },
            "highest-rating": {
                by: "rating",
                dir: "desc"
            },
            "lowest-rating": {
                by: "rating",
                dir: "asc"
            },
            "with-pictures": {
                by: "with_pictures",
                dir: null
            },
            "pictures-first": {
                by: "pictures_first",
                dir: null
            },
            "videos-first": {
                by: "videos_first",
                dir: null
            },
            "most-helpful": {
                by: "most_helpful",
                dir: null
            },
            "verified-only": {
                by: "verified_only",
                dir: null
            }
        }, jdgm.filterReviewsByRating = function(e, t) {
            var n;
            return t.find("." + r).removeClass(r), n = t.find(".jdgm-histogram__row[data-rating=" + e + "]"), n.addClass(r), t.data("filter-rating", e), t.data("before-callback")(t), jdgm._resetFilterAndSearch(t, {
                resetFilterKeyword: !0
            }), d(t)
        }, jdgm._setupSortAndFilterFor = function(t, r, n, i) {
            return null == i && (i = e.noop), t.data("before-callback", r), t.data("success-callback", n), t.data("extra-params-getter", i), s(t), g(t), setTimeout(function() {
                return o(t)
            })
        }, s = function(t) {
            return t.find(".jdgm-histogram__row").on("click", function(r) {
                return jdgm.filterReviewsByRating(e(this).data("rating"), t)
            })
        }, o = function(e) {
            var t;
            return e.find(".jdgm-rev-widg__sort-wrapper").html(JST["templates/shopify_v2/sort_dropdown"]()), t = e.find(".jdgm-rev-widg__sort-wrapper .jdgm-sort-dropdown"), t.on("change", function(r) {
                var i;
                return i = n[t.val()], e.data("sort-by", i.by), e.data("sort-dir", i.dir), e.data("before-callback")(e), d(e)
            }), a(t)
        }, a = function(e) {
            var t;
            return t = jdgmSettings.default_sort_method, e.val(t)
        }, g = function(e) {
            return e.find(".jdgm-histogram__clear-filter").text(jdgmSettings.widget_rating_filter_see_all_text)
        }, i = function(e) {
            return e.find(".jdgm-histogram__clear-filter").toggle(!!e.data("filter-rating"))
        }, d = function(r) {
            var n, a, d;
            return d = r.find(".jdgm-paginate").data("url") || r.data("url"), jdgmSettings.enable_ajax_cdn_cache && (d = d.replace(jdgm.API_HOST, jdgm.SPECIAL_CDN_HOST_HTTPS)), n = r.data("extra-params-getter"), a = e.extend(jdgm.ajaxParamsFor(r), n()), jdgm.triggerEvent("beforeFetchingReviews"), e.ajax({
                url: d,
                data: a,
                success: function(e) {
                    return i(r), r.find('[data-tabname="reviews"] .jdgm-subtab__count').text(e.total_count), r.data("success-callback")(e, r)
                }
            }), r.find(t).length > 0 ? (a = e.extend(jdgm.ajaxParamsFor(r), n(!1)), e.ajax({
                url: d,
                data: a,
                success: function(e) {
                    return i(r), r.find('[data-tabname="reviews"] .jdgm-subtab__count').text(e.total_count), r.data("success-callback")(e, r, null, {
                        otherLang: !0
                    })
                },
                error: function(e) {
                    return console.error(e.responseJSON && e.responseJSON.error || "Something went wrong")
                }
            })) : void 0
        }
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, r, n, i;
            return jdgm._widgetActionsWrapper = function(e) {
                return null == e && (e = !0), jdgm._htmlFor("widget_actions_wrapper", {
                    addSearch: e
                })
            }, jdgm._widgetSearchRow = function(t, r) {
                var i, a;
                return null == r && (r = !1), i = e("<div class='jdgm-row-search'></div>"), a = "", jdgmSettings.widget_add_search_bar && (a += n()), r && (a += jdgm._widgetReviewKeywords(t)), 0 === a.length ? "" : i.append(a)
            }, jdgm._widgetReviewKeywords = function(e) {
                return jdgmSettings.widget_show_review_keywords ? (i(e), r(e)) : ""
            }, jdgm._resetFilterAndSearch = function(e, t) {
                return null == t && (t = {}), t && (t.resetAll || t.resetSearch) && e.find(".jdgm-review-search").val(null), t && (t.resetAll || t.resetFilterRating) && (e.data("filter-rating", null), e.find(".jdgm-histogram__row").removeClass("jdgm-histogram__row--selected"), e.find(".jdgm-histogram__clear-filter").hide()), t && (t.resetAll || t.resetFilterKeyword) ? e.find(".jdgm-keywords .jdgm-chip").removeClass("active") : void 0
            }, n = function() {
                var t, r;
                return t = e("<input type='text' />").attr({
                    "class": "jdgm-review-search",
                    name: jdgmSettings.widget_search_bar_placeholder,
                    placeholder: jdgmSettings.widget_search_bar_placeholder,
                    "aria-label": jdgmSettings.widget_search_bar_placeholder
                }), r = e("<div class='jdgm-review-search-wrapper'></div>"), r.append(t), r[0].outerHTML
            }, r = function(e) {
                var t, r;
                return t = e.find(".jdgm-keyword-data"), 0 === t.length ? "" : (r = jdgm.templates.reviewKeywords({
                    keywordData: t.data("json")
                }), t.remove(), r)
            }, i = function(t) {
                return t.on("click", ".jdgm-keywords .jdgm-chip", function(r) {
                    var n;
                    return r.preventDefault(), r.stopPropagation(), n = e(r.currentTarget).addClass("current"), t.find(".jdgm-keywords .jdgm-chip:not(.current)").removeClass("active"), n.toggleClass("active").removeClass("current"), t.trigger("jdgm.searchReviews", [{
                        resetSearch: !0,
                        resetFilterRating: !0
                    }])
                })
            }, t = e(), jdgm._safeRun(function() {
                return jdgm._widgetActionsWrapper(!0), jdgm._widgetSearchRow(), jdgm._widgetReviewKeywords(t)
            }), jdgm._safeRun(function() {
                return n(), r(t), i(t)
            })
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t;
            if (!jdgm.__hasSetUpSubtab) return jdgm.__hasSetUpSubtab = !0, jdgm._renderSubtab = function(r) {
                var n;
                return n = "", e.each(r, function(e, r) {
                    return n += t(r.key, r.title, r.count, 0 === e)
                }), "<div class='jdgm-subtab'>" + n + "</div>"
            }, jdgm._renderAllRevsSubtab = function(t, r) {
                var n;
                return n = [{
                    key: "product-reviews",
                    title: jdgmSettings.widget_product_reviews_subtab_text,
                    count: r
                }, {
                    key: "shop-reviews",
                    title: jdgmSettings.widget_shop_reviews_subtab_text,
                    count: t
                }], "shop-reviews" === jdgmSettings.widget_first_sub_tab && (n = n.reverse()), e(jdgm._renderSubtab(n))
            }, jdgm.openSubtab = function(e, t, r) {
                var n;
                return null == t && (t = "reviews"), null == r && (r = null), e.find(".jdgm-subtab__name.jdgm--active").removeClass("jdgm--active"), e.find(".jdgm-subtab__name[data-tabname=" + t + "]").addClass("jdgm--active"), r || (r = e.find(".jdgm-subtab")), n = r.data("open-tab-callback"), n ? n(t, e) : void 0
            }, t = function(e, t, r, n) {
                var i;
                return i = n && "jdgm--active" || "", "<span class='jdgm-subtab__name " + i + "' data-tabname='" + e + "' tabindex='0'>" + t + " (<span class='jdgm-subtab__count'>" + r + "</span>)</span>"
            }, e("body").on("click", ".jdgm-subtab__name", function(t) {
                var r, n, i, a;
                return n = e(this), r = n.closest(".jdgm-subtab"), a = n.data("tabname"), i = r.closest(".jdgm-widget"), "questions" === a && i.find(".jdgm-row-actions, .jdgm-sort-dropdown-wrapper").hide(), "reviews" === a && i.find(".jdgm-row-actions, .jdgm-sort-dropdown-wrapper").show(), jdgm.openSubtab(i, n.data("tabname"), r)
            })
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t;
            return jdgm._templateVerifiedByJudgeme = function(e, t) {
                return null == e && (e = 0), null == t && (t = 0), ['<div class="jdgm-verified-by-judgeme">', '<div class="jdgm-verified-wrapper">', '<div class="jdgm-rating">', "<span class='jdgm-rating__stars' data-score='" + e + "' />", "<span class='jdgm-rating__count' data-value='" + t + "' />", "</div>", '<div class="jdgm-verified-by">', '<span class="jdgm-verified-by__text"></span>', '<span class="jdgm-verified-by__image"></span>', "</div>", "</div>", "</div>"].join("")
            }, jdgm._templateVerifiedCheckmark = function() {
                return ['<svg width="16" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">', '<path d="M1.41221 0C0.908409 0 0.5 0.408409 0.5 0.912207V15.0879C0.5 15.5917 0.908409 16.0001 1.41221 16.0001H15.5878C16.0916 16.0001 16.5 15.5917 16.5 15.0879V9.09481C16.5 8.80642 16.1485 8.66519 15.949 8.8734L12.7891 12.1708C11.4389 13.5797 10.0296 14.2803 8.56106 14.2725C7.10415 14.2763 5.72054 13.6231 4.41024 12.3128C3.01877 10.9213 2.28569 9.41149 2.21099 7.78333C2.15231 6.27994 2.73914 4.83048 3.97149 3.43497C4.1276 3.25818 4.39581 3.25584 4.56243 3.42246L7.33696 6.19699C7.50217 6.36219 7.50389 6.63088 7.35958 6.81526C6.68903 7.67203 6.66365 8.41032 7.28346 9.03013C7.90962 9.65629 8.60847 9.56682 9.38 8.76171L16.411 1.42462C16.4681 1.36505 16.5 1.28573 16.5 1.20322V0.912207C16.5 0.408409 16.0916 0 15.5878 0H1.41221Z" fill="#3EB2A2"/>', "</svg>"].join("")
            }, jdgm._renderVerifiedByJudgeme = function(e, r, n, i, a) {
                var d, g, s;
                return null == r && (r = !1), null == n && (n = !0), null == i && (i = !0), null == a && (a = !1), n ? (jdgm.buildStarsFor(e.find(".jdgm-rating__stars")), d = e.find(".jdgm-rating__count"), d.text(jdgmSettings.widget_number_of_reviews_text.replace("{{ number_of_reviews }}", d.data("value")))) : e.find(".jdgm-rating").remove(), jdgmSettings.can_be_branded ? (s = e.find(".jdgm-verified-by__text"), e.hasClass("jdgm-verified-badge") || s.text(jdgmSettings.widget_verified_by_text), g = e.find(".jdgm-verified-by__image"), g.length > 0 && (g.data("alt", "Judge.me Logo"), a ? g.data("url", r ? "logos/logo-judgeme-2025-rebranding_monochromatic.svg" : "logos/logo-judgeme-2025-rebranding.svg") : g.data("url", r ? "logos/logo-judgeme_mono.svg" : "logos/logo-judgeme.svg"), jdgm._loadSvg(g, jdgm.JM_PUBLIC_IMAGE_URL, jdgm.JM_PUBLIC_IMAGE_URL, r), i) ? t(e, r) : void 0) : e.find(".jdgm-verified-by").remove()
            }, jdgm._renderVerifiedJudgeme = function(t, r, n, i) {
                var a, d, g;
                return null == n && (n = !0), null == i && (i = !0), n ? (jdgm.buildStarsFor(t.find(".jdgm-rating__stars")), a = t.find(".jdgm-rating__count"), a.text(jdgmSettings.widget_number_of_reviews_text.replace("{{ number_of_reviews }}", a.data("value")))) : t.find(".jdgm-rating").remove(), jdgmSettings.widget_show_verified_branding ? (g = t.find(".jdgm-verified-by__text"), t.hasClass("jdgm-verified-badge") || g.text(jdgmSettings.widget_verified_text), d = t.find(".jdgm-verified-by__image"), d.length > 0 ? e.get(jdgm.JM_PUBLIC_IMAGE_URL + "logos/verified-checkmark.svg", function(t) {
                    var n;
                    return n = e(t).find("svg"), n.find("path").attr("fill", r), d.html(n)
                }) : void 0) : t.find(".jdgm-verified-by").remove()
            }, t = function(e, t) {
                var r, n, i, a;
                return a = e.data("widget-selector"), i = e.data("color"), n = "", t && (n = ["." + a + " .jdgm-verified-wrapper .jdgm-svg__mono svg path { fill: " + i + "; }", "." + a + " .jdgm-verified-wrapper .jdgm-svg__mono svg circle { fill: " + i + "; }"].join("")), r = ["<style>", ".jdgm-verified-by-judgeme { text-align: center; }", "." + a + " .jdgm-verified-wrapper { color: " + i + "; }", n, "</style>"].join(""), e.before(r)
            }
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, r, n, i, a, d, g, s, o, m;
            return n = location.origin + "/products/", t = "jdgm-widget jdgm-preview-badge jdgm--from-js", a = "jdgm--waiting-for-batch-done", r = new DOMParser, i = 3e3, jdgm.batchRenderBadges = function(t, r) {
                var n;
                return t && e.isArray(t) ? (n = e.map(t, function(e, t) {
                    return m(e.productHandle, e.badgePlaceholder, r)
                }), e.when.apply(this, n).then(d(t), function() {
                    return setTimeout(d(t), i)
                })) : void 0
            }, jdgm.batchRenderBadgesWithCallback = function(e, t) {
                return jdgm.batchRenderBadges(e, t)
            }, jdgm.renderJsBadge = function(r, n, i) {
                var a, d;
                return d = o(r, n), a = e(i), a.addClass(t).html(d), jdgm.buildStarsFor(a.find(".jdgm-prev-badge__stars"), r), a
            }, m = function(t, r, i) {
                var d;
                return d = jdgmSettings.productUrlBuilder && jdgmSettings.productUrlBuilder({
                    handle: t
                }) || n + t, e.ajax({
                    url: d,
                    success: function(n) {
                        var d;
                        return s(n, r, t, i), d = e(r), d.find(".jdgm-prev-badge").addClass(a)
                    }
                })
            }, s = function(t, n, i, a) {
                var d, g, s, o;
                return s = r.parseFromString(t, "text/html"), d = e(s).find(".jdgm-rev-widg"), g = d.data("average-rating") || 0, o = d.data("number-of-reviews") || 0, a ? a(g, o, n, i) : jdgm.renderJsBadge(g, o, n), jdgmSettings.renderBadge ? jdgmSettings.renderBadge(g, o, n, i) : void 0
            }, d = function(t) {
                return function() {
                    return jdgm.customizeBadges(), jdgm.asyncEach(t, function(t) {
                        return e(t.badgePlaceholder).find(".jdgm-prev-badge").removeClass(a)
                    })
                }
            }, o = function(e, t) {
                var r;
                return 0 === t ? jdgm.templates.emptyBadge() : (r = g(t), jdgm.templates.badge({
                    averageRating: e,
                    reviewCount: t,
                    previewBadgeText: r
                }))
            }, g = function(e) {
                var t;
                return t = 1 === e && " review" || " reviews", e + t
            }
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, r, n, i, a, d, g;
            return t = ['.jdgm-widget.jdgm-review-widget[data-auto-install="true"]', '.jdgm-carousel-wrapper[data-auto-install="true"]', '.jdgm-widget.jdgm-ugc-media-wrapper[data-auto-install="true"]'], n = {
                review_widget: {
                    all: ".jdgm-widget.jdgm-review-widget",
                    app_block_auto_install: "[id^=shopify-block-judgeme_review_widget_] > .jdgm-widget.jdgm-review-widget"
                },
                preview_badge: {
                    all: ".jdgm-widget.jdgm-preview-badge",
                    app_block_auto_install: "[id^=shopify-block-judgeme_preview_badge_product_page_] > .jdgm-widget.jdgm-preview-badge"
                }
            }, r = ["shopify"], i = function(t, r) {
                var i;
                return (i = e(n[t].app_block_auto_install + "[data-id=" + r + "]").length) > 0 && i < e(n[t].all + "[data-id=" + r + "]").length
            }, a = function() {
                return jdgm.asyncEach(Object.keys(n), function(t) {
                    var r, a;
                    return a = e(n[t].all).data("id"), r = !window.BOOMR || "Impulse" !== window.BOOMR.themeName, r && a && i(t, a) ? e(n[t].app_block_auto_install + "[data-id=" + a + "]").closest(".shopify-app-block").remove() : void 0
                })
            }, d = function() {
                return jdgm.asyncEach(t, function(t) {
                    var r, n, i;
                    return n = e(t), n.length > 0 ? (i = t.replace('[data-auto-install="true"]', ""), r = e(i), n.length === r.length ? e(t + ":not(:first)").remove() : n.remove()) : void 0
                })
            }, g = function() {
                return jdgm.asyncEach(t, function(t) {
                    return e(t).attr("data-auto-install", "processed")
                })
            }, r.indexOf(jdgmSettings.platform) >= 0 ? (d(), a(), g()) : void 0
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, r, n, i, a, d;
            return r = {
                "left-of-reviewer-name": "",
                "right-of-timestamp": "jdgm-buyer-badge--right-of-timestamp",
                "top-right-of-review": "jdgm-buyer-badge--top-right",
                removed: "jdgm-buyer-badge--removed"
            }, d = {
                bgColor: jdgmSettings.verified_badge_bg_color || jdgmSettings.linkColor,
                color: jdgmSettings.verified_badge_text_color || jdgmSettings.bgColor,
                text: jdgmSettings.verified_badge_text,
                placement: jdgmSettings.verified_badge_placement
            }, t = e("body"), a = function() {
                var e;
                return e = r[d.placement], t.addClass(e)
            }, n = function() {
                return "transparent" === jdgmSettings.verified_badge_bg_color ? t.addClass("jdgm-buyer-badge--text-only") : void 0
            }, i = function() {
                var e, r;
                return e = jdgmSettings.widget_star_color || jdgmSettings.linkColor, jdgm.isVersion3 && (e = jdgmSettings.widget_star_color || jdgmSettings.widget_primary_color), r = JST["templates/shopify_v2/setting_css_style"]({
                    verifiedBadgeOpts: d,
                    linkColor: e,
                    bgColor: jdgmSettings.bgColor,
                    answerLabel: jdgmSettings.widget_answer_label_text,
                    questionLabel: jdgmSettings.widget_question_label_text,
                    buttonColor: jdgmSettings.buttonColor,
                    writeReviewBgColor: jdgmSettings.widget_write_review_bg_color || jdgmSettings.bgColor,
                    writeReviewTextColor: jdgmSettings.widget_write_review_text_color || jdgmSettings.buttonColor
                }), t.append(r)
            }, a(), n(), i()
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            return jdgm._addEmptyPreviewBadge = function(e) {
                var t;
                return t = e.find(".judgeme-badge").length > 0, e.find(".jdgm-prev-badge__stars").length <= 0 && !t ? (e.append(jdgm.templates.emptyBadge()), jdgm.buildStarsFor(e.find(".jdgm-prev-badge__stars"), 0)) : void 0
            }, jdgm._addEmptyWidgetHeader = function(e) {
                var t;
                return t = e.find(".judgeme-reviews").length > 0, e.find(".jdgm-rev-widg").length <= 0 && !t ? (e.append(jdgm.templates.header()), jdgm.buildStarsFor(e.find(".jdgm-rev-widg__summary-stars"), 0)) : void 0
            }, jdgm.eachRevWidgets(jdgm._addEmptyWidgetHeader), jdgm.eachPrevBadges(jdgm._addEmptyPreviewBadge)
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, r, n, i;
            return t = function() {
                return jdgmSettings.disable_web_reviews ? jdgm.caches.$revWidgets.each(function(t, r) {
                    var n, i;
                    return n = e(r), i = n.find(".jdgm-rev-widg").data("number-of-reviews"), n.find(".jdgm-rev-widg .jdgm-rev-widg__summary").toggle(i > 0), jdgmSettings.enable_question_anwser ? void 0 : jdgm.forceShowHideRevWidget(n, i > 0)
                }) : void 0
            }, n = function() {
                return jdgmSettings.hide_badge_preview_if_no_reviews ? jdgm.eachPrevBadges(function(e) {
                    var t;
                    return t = e.find(".jdgm-prev-badge").data("number-of-reviews"), e.toggle(t > 0)
                }) : void 0
            }, i = function() {
                return "show" === e.urlParam("judgeme_badge") ? jdgm.eachPrevBadges(function(e) {
                    var t;
                    return t = e.find(".jdgm-prev-badge"), e.show(), t.length > 0 ? t[0].style.setProperty("display", "block", "important") : void 0
                }) : void 0
            }, r = function() {
                return e(".judgeme-badge, .judgeme-badge + span").hide()
            }, t(), n(), i(), r()
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, r, n, i, a, d, g, s, o, m, u, l, c, _, p, v, j, f, h, w, b, y, S;
            return o = ".jdgm-rev__social", m = function() {
                return "\u2605"
            }, r = "https://www.facebook.com/dialog/share?", t = {
                app_id: "141224836283514",
                display: "popup"
            }, g = "https://judge.me/facebook/reviews/", c = "https://twitter.com/intent/tweet?", u = {
                via: ""
            }, l = 140, d = 500, n = "https://plus.google.com/share?", a = "https://pinterest.com/pin/create/button/?", i = "https://www.linkedin.com/shareArticle?", s = {
                Facebook: "jdgm-rev__share-fb",
                Twitter: "jdgm-rev__share-twitter",
                Pinterest: "jdgm-rev__share-pinterest",
                LinkedIn: "jdgm-rev__share-linkedin"
            }, jdgm.shareReviewFor = function(e, t) {
                var r, n;
                return n = w(e), r = jdgm._shareUrlFor(n, t), window.open(r, null, "height=500,width=600,status=yes,toolbar=no,menubar=no,location=no")
            }, jdgm._shareUrlFor = function(e, t) {
                switch (t) {
                    case "Google":
                        return v(e);
                    case "Twitter":
                        return S(e);
                    case "Instagram":
                        return instagramShareUrlFor(e);
                    case "LinkedIn":
                        return j(e);
                    case "Pinterest":
                        return f(e);
                    default:
                        return p(e)
                }
            }, jdgm.renderShareBtns = function(t) {
                var r;
                return r = e("<div class='jdgm-rev__social-inner'></div>"), h(r), e.each(t, function(t, n) {
                    var i, a;
                    return i = e(n), a = i.find(".jdgm-rev__source"), "shop-app" === a.attr("data-source") || i.find(".jdgm-rev__social-inner").length > 0 ? void 0 : i.find(".jdgm-rev__social").append(r.clone())
                })
            }, h = function(t) {
                return e.each(jdgmSettings.social_share_options_order.split(","), function(e, r) {
                    return t.append(b(r, s[r]))
                })
            }, b = function(e, t) {
                return "<span class='jdgm-rev__share-btn " + t + "' title='" + e + "' data-social-media='" + e + "' tabindex='0'></span>"
            }, w = function(t) {
                var r, n, i, a, d, g;
                return a = t.find(".jdgm-rev__rating").data("score") || 5, g = t.find(".jdgm-rev__title").text(), r = t.find(".jdgm-rev__body"), n = jdgmSettings.widget_review_max_height ? r.trigger("originalContent.dot")[0].innerText : r.text(), d = y(a), i = t.find(".jdgm-rev__pic-img").first().prop("src") || e("head").find('meta[property="og:image"]').prop("content"), {
                    rating: a,
                    title: g,
                    body: n,
                    starText: d,
                    textToShare: d + " " + g + " " + n,
                    uuid: t.data("review-id"),
                    media: i
                }
            }, y = function(t) {
                return e.map(new Array(t), m).join("")
            }, _ = function() {
                return window.location.origin + window.location.pathname
            }, p = function(n) {
                return r + e.param(e.extend({}, t, {
                    redirect_uri: g + n.uuid,
                    href: _(),
                    quote: n.textToShare
                }))
            }, S = function(t) {
                var r, n;
                return n = jdgm.truncate(t.textToShare, l), r = e.extend({}, u, {
                    url: _(),
                    text: n
                }), c + e.param(r)
            }, v = function(t) {
                return n + e.param({
                    url: _()
                })
            }, f = function(t) {
                var r;
                return r = {
                    url: _(),
                    description: jdgm.truncate(t.textToShare, d),
                    media: t.media
                }, a + e.param(r)
            }, j = function(t) {
                var r;
                return r = {
                    mini: !0,
                    url: _(),
                    title: t.title,
                    summary: t.textToShare,
                    source: "Judge.me"
                }, i + e.param(r)
            }, e("body").on("click", ".jdgm-rev__share-btn", function(t) {
                var r, n, i;
                return n = e(t.currentTarget), r = n.closest(".jdgm-rev"), i = n.data("social-media"), jdgm.shareReviewFor(r, i)
            })
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, r, n, i, a, d, g, s, o, m, u, l, c, _, p, v, j;
            return t = ".jdgm-rev__votes", n = "submitted", a = "up", i = "down", r = "jdgm_thumb_votes", jdgm.createVote = function(t, r) {
                return e.ajax({
                    url: "https://judge.me/thumbs",
                    method: "POST",
                    data: {
                        review_uuid: s(t),
                        thumb_type: r
                    },
                    success: function() {
                        return v(t) ? void 0 : d(t, r)
                    }
                })
            }, jdgm.renderThumbBtns = function(r) {
                return e.each(r, function(r, n) {
                    var d, g, s, m;
                    return d = e(n), d.find(".jdgm-rev__votes-inner").length > 0 ? void 0 : (m = p(d, a), g = p(d, i), s = o(m, g), d.find(t).append(s))
                }), l()
            }, s = function(e) {
                return e.data("review-id")
            }, o = function(e, t) {
                return ["<div class='jdgm-rev__votes-inner'>", c("up", "jdgm-rev_thumb-up"), _(e, "jdgm-rev_thump-up-count"), c("down", "jdgm-rev_thumb-down"), _(t, "jdgm-rev_thump-down-count"), "</div>"].join("")
            }, c = function(e, t) {
                return "<span class='jdgm-rev__thumb-btn " + t + "' title='" + e + "' data-thumb-vote='" + e + "' tabindex='0'></span>"
            }, _ = function(e, t) {
                return "<span class='jdgm-rev__thumb-count " + t + "' data-thumb-count='" + e + "'>" + e + "</span>"
            }, p = function(e, t) {
                var r, n, i;
                return n = e.data("thumb-" + t + "-count") || 0, i = m(g(e)[t]), r = Math.max(n, i), g(e)[t] = r, r
            }, g = function(e) {
                var t, r;
                return (t = j())[r = s(e)] || (t[r] = {
                    up: 0,
                    down: 0
                })
            }, v = function(e) {
                return g(e)[n]
            }, m = function(e, t) {
                return null == t && (t = 0), (parseInt(e) || 0) + t
            }, d = function(e, t) {
                return g(e)[t] += 1, g(e)[n] = !0, e.find(".jdgm-rev_thump-" + t + "-count").html(g(e)[t]), l()
            }, j = function() {
                return jdgm._existingThumbVotes || (jdgm._existingThumbVotes = u())
            }, u = function() {
                var e, t;
                if (e = localStorage.getItem(r), !e || e.length <= 0) return {};
                try {
                    return t = JSON.parse(e)
                } catch (n) {
                    return console.log("Judge.me could not process thumbs data. Reseting thumbs data"), {}
                }
            }, l = function() {
                return localStorage.setItem(r, JSON.stringify(j()))
            }, e("body").on("click", ".jdgm-rev__thumb-btn", function(t) {
                var r, n, i;
                return n = e(t.currentTarget), r = n.closest(".jdgm-rev"), i = n.data("thumb-vote"), v(r) ? void 0 : jdgm.createVote(r, i)
            })
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, r, n, i, a, d, g;
            return r = "data", n = {
                cFsAvgResponses: ".jdgm-custom-forms-avg-responses",
                cFsFilters: ".jdgm-custom-forms-filters"
            }, jdgm._setupCustomForms = function(e) {
                return i(e), a(e)
            }, i = function(e) {
                var t, r;
                return t = e.find(n.cFsAvgResponses), 0 !== t.length ? (r = g(t, n.cFsAvgResponses), r ? t.append(jdgm.templates.customFormsAvgResponses({
                    cf_answers: r
                })) : t.remove()) : void 0
            }, a = function(e) {
                var t, r, i, a;
                return t = e.find(n.cFsFilters), 0 !== t.length ? (a = g(t, n.cFsFilters)) ? (t.append(jdgm.templates.customFormsFilters({
                    cf_questions: a
                })), r = t.find(n.cFsFilters + "__button.jdgm-chip"), i = e.find(".jdgm-row-actions"), i.append(t.detach()), i.append(r)) : t.remove() : void 0
            }, g = function(e, t) {
                var n, i;
                return n = e.find(t + "-" + r), i = n.data("json"), n.remove(), i
            }, d = function() {
                return e(document).on("click", n.cFsFilters + "__button.jdgm-chip", function(t) {
                    var r, i, a;
                    return r = e(t.currentTarget), a = r.closest(".jdgm-review-widget"), "carousel" === jdgmSettings.widget_theme && (a = r.closest(".jdgm-widget__popup-content.jdgm-rev-widg__popup-content")), i = a.find(n.cFsFilters), "false" === r.attr("aria-expanded") ? (i.slideDown(), r.attr("aria-expanded", !0)) : "true" === r.attr("aria-expanded") ? (i.slideUp(), r.attr("aria-expanded", !1)) : void 0
                }), e(document).on("click", ".jdgm-rev__cf-option.jdgm-chip", function(t) {
                    var r, n;
                    return t.preventDefault(), t.stopPropagation(), r = e(t.currentTarget).addClass("current"), n = r.closest(".jdgm-review-widget"), "carousel" === jdgmSettings.widget_theme && (n = r.closest(".jdgm-widget__popup-content.jdgm-rev-widg__popup-content")), n.find(".jdgm-rev__cf-option.jdgm-chip:not(.current)").removeClass("active"), r.toggleClass("active").removeClass("current"), n.trigger("jdgm.filterReviewsByCustomForms")
                })
            }, d(), t = e(), jdgm._safeRun(function() {
                return jdgm._setupCustomForms(t), i(t), a(t), g(t, "")
            })
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, r, n, i, a, d, g, s;
            return s = {}, jdgm._customizeReviewWidget = function(e) {
                return d(e, "updateNumberOfReviews"), d(e, "customizeWidgetTitle"), d(e, "customizeSummary"), d(e, "customizeHistogram"), d(e, "customizeWidgetActions"), d(e, "customizeRowStars"), d(e, "customizeWidgetSort"), d(e, "customizePagination"), d(e, "customizeFooter"), d(e, "setupCFsFiltersAndAvgResponses")
            }, d = function(e, t) {
                var r;
                return s[t] ? s[t].call(this, e) : (r = {
                    "jdgm-review-widget": "_inREV",
                    "jdgm-revs-tab": "_inFRT",
                    "jdgm-all-reviews-widget": "_inARP"
                }, Object.keys(r).forEach(function(n) {
                    return e.hasClass(n) ? t += r[n] : void 0
                }), s[t] ? s[t].call(this, e) : void 0)
            }, s.updateNumberOfReviews_inREV = function(e) {
                var t;
                return t = e.find(".jdgm-rev-widg"), e.data("number-of-reviews", t.data("number-of-reviews")), e.data("number-of-questions", t.data("number-of-questions"))
            }, s.updateNumberOfReviews_inFRT = function(e) {
                return g(e, ".jdgm-revs-tab__content-header")
            }, s.updateNumberOfReviews_inARP = function(e) {
                return g(e, ".jdgm-all-reviews__header")
            }, s.customizeWidgetTitle_inREV = function(e) {
                var t, r;
                return r = e.data("product-title"), t = jdgmSettings.widget_title.replace("{{ product_name }}", r), e.find(".jdgm-rev-widg__title").text(t)
            }, s.customizeWidgetTitle_inFRT = function(e) {
                var t;
                return t = e.find(".jdgm-revs-tab__title + a, .jdgm-revs-tab__url"), jdgmSettings.floating_tab_title && e.find(".jdgm-revs-tab__title").text(jdgmSettings.floating_tab_title), jdgmSettings.floating_tab_url && jdgmSettings.floating_tab_url_enabled ? (e.find(".jdgm-revs-tab__title + a, .jdgm-revs-tab__url").attr("href", jdgmSettings.floating_tab_url), t.attr("href", jdgmSettings.floating_tab_url)) : t.removeAttr("href")
            }, s.customizeSummary_inREV = function(e) {
                return i(e, "jdgm-rev-widg", ".jdgm-rev-widg")
            }, s.customizeSummary_inFRT = function(e) {
                var t, r, n, i, a, d;
                return r = e.find(".jdgm-revs-tab__url"), d = e.data("number-of-product-reviews") + e.data("number-of-shop-reviews"), t = e.find(".jdgm-all-reviews-rating"), n = t.data("score"), i = jdgmSettings.widget_summary_average_rating_text.replace("{{ average_rating }}", n), t.append("<span class='jdgm-link'>" + i + "</span>"), t.detach(), a = jdgmSettings.widget_summary_text.replace("{{ average_rating }}", n).replace("{{ number_of_reviews }}", d), a = a.replace("{{ average_rating_1_decimal }}", parseFloat(n).toPrecision(2)), a = jdgm.pluralizeLongText(a, d), r.html("<span>" + a + "</span>"), r.prepend(t)
            }, s.customizeSummary_inARP = function(e) {
                return e.find(".jdgm-all-reviews__summary").addClass("jdgm-rev-widg__summary"), i(e, "jdgm-all-reviews", ".jdgm-all-reviews__header")
            }, s.customizeHistogram_inREV = function(e) {
                var t;
                return jdgm.isVersion3 ? (t = r(e), e.find(".jdgm-rev-widg__summary").after(t.detach())) : void 0
            }, s.customizeHistogram_inFRT = function(e) {
                var t;
                return jdgm.isVersion3 ? (t = r(e), t.wrap('<div class="jdgm-histogram-wrapper"></div>')) : void 0
            }, s.customizeHistogram_inARP = function(e) {
                var t;
                return jdgm.isVersion3 ? (t = r(e), e.find(".jdgm-all-reviews__summary").after(t.detach())) : void 0
            }, s.customizeWidgetActions_inREV = function(e) {
                var t;
                return t = e.data("number-of-reviews"), a(e, "jdgm-rev-widg", t, !0)
            }, s.customizeWidgetActions_inFRT = function(t) {
                var r, n, i;
                return r = t.find(".jdgm-revs-tab__content-header"), jdgm.isVersion3 ? (n = e('<div class="jdgm-row-stars"></div>'), i = e('<div class="jdgm-revs-tab__actions"></div>'), i.append(r.find(".jdgm-write-rev-link").detach()), n.append(r.find(".jdgm-histogram-wrapper").detach()), n.append(i), r.prepend(n), r.find(".jdgm-row-stars").after(jdgm._widgetSearchRow(t))) : (r.prepend(jdgm._widgetActionsWrapper()), r.prepend(r.find(".jdgm-review-search").detach()), r.find(".jdgm-widget-actions-wrapper").append(r.find(".jdgm-write-rev-link").detach()))
            }, s.customizeWidgetActions_inARP = function(e) {
                var t;
                return t = e.data("number-of-product-reviews") + e.data("number-of-shop-reviews"), a(e, "jdgm-all-reviews", t)
            }, s.customizeRowStars = function(e) {
                var t;
                return t = e.find(".jdgm-row-stars"), jdgmSettings.widget_show_histogram || !jdgmSettings.disable_web_reviews || jdgmSettings.enable_question_anwser || (e.hasClass("jdgm-revs-tab") ? t.remove() : t.addClass("jdgm-row-stars--only-summary")), jdgmSettings.widget_show_histogram || t.find(".jdgm-histogram").remove(), jdgmSettings.disable_web_reviews && !jdgmSettings.enable_question_anwser ? t.find(".jdgm-widget-actions-wrapper").remove() : void 0
            }, s.customizeWidgetSort = function(t) {
                var r, n, i;
                return jdgm.isVersion3 ? (r = e('<div class="jdgm-row-actions"></div>'), r.append(t.find(".jdgm-rev-widg__sort-wrapper").detach()), i = "." + t.data("class-prefix") + "__body", "jdgm-revs-tab" === t.data("class-prefix") && (i = ".jdgm-revs-tab__content-body"), "leex" === jdgmSettings.widget_theme ? (n = e('<div class="jdgm-rev-widg__actions"></div>'), n.append(r), t.find(i).before(n)) : t.find(i).before(r)) : void 0
            }, s.setupCFsFiltersAndAvgResponses_inREV = function(e) {
                return jdgm.isVersion3 ? jdgm._setupCustomForms(e) : void 0
            }, s.customizePagination_inREV = function(e) {
                var t;
                return t = e.find(".jdgm-rev-widg").data("number-of-reviews"), n(e, t)
            }, s.customizePagination_inFRT = function(e) {
                var t;
                return t = e.find(".jdgm-revs-tab__content-header").data("number-of-product-reviews"), n(e, t)
            }, s.customizeFooter_inREV = function(e) {
                var t;
                return jdgmSettings.widget_show_review_information ? (t = '<div class="jdgm-collected-link"><a class="jdgm-link" href="https://judge.me/authenticity" target="_blank">' + jdgmSettings.how_reviews_are_collected + "</a></div>", e.find(".jdgm-rev-widg__body").append(t)) : void 0
            }, n = function(e, t) {
                var r;
                return r = e.find(".jdgm-paginate"), r.length > 0 && jdgm.isWidgetLoadMore() && r.find(".jdgm-paginate__load-more").length > 0 && t > e.find(".jdgm-rev").length ? r.html("<a class='jdgm-btn jdgm-btn--solid jdgm-paginate__load-more' data-page='2' role='button'>" + jdgmSettings.widget_load_more_text + "</a>") : void 0
            }, a = function(e, t, r, n) {
                var i;
                return null == n && (n = !1), jdgm.isVersion3 ? (e.find("." + t + "__summary").wrap('<div class="jdgm-row-stars"></div>'), i = e.find(".jdgm-row-stars"), i.append(e.find(".jdgm-histogram").detach()), i.append(jdgm._widgetActionsWrapper(!1)), e.find("." + t + "__header").append(jdgm._widgetSearchRow(e, !0))) : (e.find("." + t + "__summary").after(jdgm._widgetActionsWrapper(r > 0)), e.find(".jdgm-rev-widg__sort-wrapper").before(jdgm._widgetReviewKeywords(e))), e.find(".jdgm-widget-actions-wrapper").append(e.find(".jdgm-write-rev-link").detach()), n && jdgmSettings.enable_question_anwser ? jdgm.renderAskQuestionBtn(e) : void 0
            }, i = function(r, n, i) {
                var a, d, g, s, o, m, u, l, c, _, p;
                return r.find(".jdgm-rev-widg__summary").wrapInner('<div class="jdgm-rev-widg__summary-inner"></div>'), l = r.find(i).data("number-of-reviews"), d = r.find(i).data("average-rating"), a = r.find("." + n + "__summary-text"), l ? (u = jdgmSettings.widget_summary_text.replace("{{ average_rating }}", d).replace("{{ number_of_reviews }}", l), u = u.replace("{{ average_rating_1_decimal }}", parseFloat(d).toPrecision(2)), u = jdgm.pluralizeLongText(u, l), u = e("<i>" + u + "</i>").text(), a.text(u), s = jdgmSettings.can_be_branded && jdgmSettings.shop_use_review_site && jdgmSettings.widget_enabled_branded_link, jdgm.isVersion3 ? (g = jdgmSettings.widget_summary_average_rating_text.replace("{{ average_rating }}", d), o = g, s && (o = "<a class='jdgm-link' target='_blank' href='" + jdgmSettings.branding_url + "'>" + g + "</a>"), p = "<span class='" + n + "__summary-average'>" + o + "</span>", r.find("." + n + "__summary-stars").append(p)) : (_ = window.location.pathname.split("/products/"), s && 2 === _.length && (c = _[1] ? "/products/" + _[1] : "", m = "<a class='jdgm-rev__prod-link' target='_blank' href='" + (jdgmSettings.branding_url + c) + "'>" + u + "</a>", a.html(m))), t(r, n)) : a.text(jdgmSettings.widget_no_review_text)
            }, t = function(e, t) {
                var r;
                if (!jdgm.WIDGET_REBRANDING_ENABLED) return jdgmSettings.can_be_branded && jdgmSettings.widget_show_collected_by_judgeme ? (r = "<a class='jdgm-link' target='_blank' href='https://judge.me/trust'>" + jdgmSettings.widget_collected_by_judgeme_text + "</a>", e.find("." + t + "__summary-text").after(r)) : void 0
            }, r = function(t) {
                var r;
                return r = t.find(".jdgm-histogram"), r.find(".jdgm-histogram__percentage").remove(), jdgm.asyncEach(r.find(".jdgm-histogram__frequency"), function(t) {
                    var r, n;
                    return r = e(t), n = r.text().replace(/\(|\)/g, ""), r.text(n)
                }), r
            }, g = function(e, t) {
                var r;
                return r = e.find(t), e.data("number-of-product-reviews", r.data("number-of-product-reviews")), e.data("number-of-shop-reviews", r.data("number-of-shop-reviews")), e.data("number-of-reviews", r.data("number-of-product-reviews") + r.data("number-of-shop-reviews"))
            }, jdgm.eachWidgetWithReviews(function(e) {
                return e.hasClass(jdgm.DONE_SETUP_WIDGET_CLASS) || jdgm._customizeReviewWidget(e), e.addClass(jdgm.DONE_SETUP_WIDGET_CLASS)
            })
        })
    }.call(this),
    function() {
        jdgm.$(function(e) {
            var t, r, n, i, a, d, g, s, o, m, u, l, c, _, p, v, j, f, h, w, b, y, S, x, R, C, T, k, F, E, A, B, P, z, L, W, D;
            return a = "<b class='jdgm-rev__replier'></b>", n = "jdgm-rev__body-read-more", i = "." + n, t = "1528", s = "https://judgeme-public-images.imgix.net/judgeme/flags", g = "https://judgeme-public-images.imgix.net/judgeme/verified-badge-v2", o = ".jdgm-rev__prod-variant-wrapper", d = ".jdgm-rev-widg__summary-text", r = {
                "": "fullname",
                all_initials: "all-initials",
                last_initial: "last-initial"
            }, jdgm.customizeReviews = function() {
                var t;
                return t = e(".jdgm-rev:not(." + jdgm.DONE_SETUP_CLASS + ")"), w(t), b(t), E(t), jdgmSettings.show_product_url_for_grouped_product && y(t), jdgmSettings.widget_review_max_height && jdgm.setupLimitingReviewHeight(t), L(t.find(".jdgm-rev__avatar-image")), z(t), P(t), D(t), jdgm.isVersion3 && f(t), v(t), x(t), h(t), jdgm.customizeTimestamp(t), jdgmSettings.widget_social_share && jdgm.renderShareBtns(t), jdgmSettings.widget_thumb && jdgm.renderThumbBtns(t), jdgm.triggerEvent("doneCustomizeReviews", {
                    $reviews: t
                }), t.addClass(jdgm.DONE_SETUP_CLASS), jdgmSettings.widget_show_verified_branding && jdgm.WIDGET_REBRANDING_ENABLED ? l() : void 0
            }, jdgm.customizeQuestions = function() {
                var t;
                return t = e(".jdgm-quest:not(." + jdgm.DONE_SETUP_CLASS + ")"), b(t), jdgmSettings.widget_review_max_height && jdgm.setupLimitingReviewHeight(t), L(t.find(".jdgm-rev__avatar-image")), z(t), jdgm.isVersion3 && f(t), jdgm.customizeTimestamp(t), jdgm.customizeAnswers(), jdgm.triggerEvent("doneCustomizeQuestions", {
                    $questions: t
                }), t.addClass(jdgm.DONE_SETUP_CLASS)
            }, jdgm.customizeAnswers = function() {
                var t;
                return t = e(".jdgm-ans:not(." + jdgm.DONE_SETUP_CLASS + ")"), b(t), jdgmSettings.widget_review_max_height && jdgm.setupLimitingReviewHeight(t), jdgm.customizeTimestamp(t), jdgm.isVersion3 && w(t), t.addClass(jdgm.DONE_SETUP_CLASS)
            }, jdgm._fixAuthorNameIfFromShop = function(e) {
                var t, r;
                return r = e.find(".jdgm-quest[data-from-shop=true] .jdgm-quest__asker"), r.find(".jdgm-rev__author").html(a), F(r), t = e.find(".jdgm-ans[data-from-shop=true] .jdgm-ans__answerer"), t.find(".jdgm-rev__author").html(a), F(t)
            }, w = function(t) {
                var r, n;
                return n = jdgmSettings.widget_replied_text.replace("{{ shop_name }}", a), jdgmSettings.reply_name_text && (r = e(a).text(jdgmSettings.reply_name_text), n = jdgmSettings.widget_replied_text.replace("{{ shop_name }}", r.prop("outerHTML"))), t.find(".jdgm-rev__replier-wrapper, .jdgm-ans__answerer").html(n)
            }, b = function(t) {
                var n, i;
                return i = r[jdgmSettings.widget_reviewer_name_as_initial] || "fullname", n = t.find(".jdgm-rev__author-wrapper"), n.each(function(t, r) {
                    var n;
                    return n = e(r), p(n, i), jdgmSettings.widget_review_location_show ? _(n) : void 0
                }), F(n), B(t), A(n)
            }, p = function(e, t) {
                var r;
                return (r = e.data(t)) ? e.find(".jdgm-rev__author").text(r) : void 0
            }, _ = function(e) {
                var t, r, n, i, a, d, g;
                return r = e.data("location-city"), i = e.data("location-country-code"), n = e.data("location-country"), d = e.data("location-state-code"), a = e.data("location-state"), r && n && i ? (t = {
                    city_only: "(" + r + ")",
                    full_country_state_name: "(" + ["" + r, "" + a, "" + n].filter(Boolean).join(", ") + ")",
                    country_state_iso_code: "(" + ["" + r, "" + d, "" + i].filter(Boolean).join(", ") + ")",
                    full_country_name: "(" + r + ", " + n + ")",
                    country_iso_code: "(" + r + ", " + i + ")",
                    country_only: "(" + n + ")",
                    country_code_only: "(" + i + ")",
                    city_state_only: "(" + ["" + r, "" + a].filter(Boolean).join(", ") + ")",
                    city_state_code_only: "(" + ["" + r, "" + d].filter(Boolean).join(", ") + ")",
                    state_only: "(" + a + ")",
                    state_country_only: "(" + ["" + a, "" + n].filter(Boolean).join(", ") + ")",
                    state_iso_code: "(" + d + ")"
                }, g = t[jdgmSettings.widget_location_format], e.find(".jdgm-rev__location").text(g)) : void 0
            }, A = function(e) {
                return e.removeAttr("data-location-city"), e.removeAttr("data-location-country-code"), e.removeAttr("data-location-country"), e.removeAttr("data-location-state-code"), e.removeAttr("data-location-state")
            }, F = function(e) {
                return e.removeAttr("data-fullname"), e.removeAttr("data-all-initials"), e.removeAttr("data-last-initial")
            }, B = function(e) {
                var t;
                return t = jdgmSettings.widget_reviewer_name_as_initial, "" !== t && e.find(".jdgm-author-fullname").remove(), "all_initials" !== t && e.find(".jdgm-author-all-initials").remove(), "last_initial" !== t ? e.find(".jdgm-author-last-initial").remove() : void 0
            }, f = function(t) {
                var r, n;
                return n = {
                    "jdgm-row-extra": ["jdgm-rev__location", "jdgm-rev__location-country-flag-img"],
                    "jdgm-row-profile": ["jdgm-rev__pinned", "jdgm-rev__icon", "jdgm-rev__author-wrapper", "jdgm-rev__buyer-badge-wrapper"],
                    "jdgm-row-rating": ["jdgm-rev__rating", "jdgm-rev__timestamp"],
                    "jdgm-row-product": ["jdgm-rev__prod-info-wrapper"]
                }, r = ".jdgm-rev__pics, .jdgm-rev__vids, .jdgm-rev__buyer-badge-wrapper, .jdgm-rev__reply, .jdgm-rev__prod-variant-wrapper", jdgm.asyncEach(t, function(t) {
                    var i, a, d, g;
                    return d = e(t), c(d.find(".jdgm-rev__header"), n), d.find(".jdgm-rev__icon:not(.jdgm--loading, .jdgm-rev__avatar)").text(""), a = d.find(".jdgm-rev__location"), g = a.text().replace(/\(|\)/g, ""), a.text(g), jdgm.asyncEach(d.find(r), function(t) {
                        var r;
                        return r = e(t), 0 === r.children().length && "" === r.text().trim() ? r.remove() : void 0
                    }), d.find(".jdgm-rev__author-wrapper").append(d.find(".jdgm-rev__buyer-badge-wrapper").detach()), "align" === jdgmSettings.widget_theme && k(d), i = d.find(".jdgm-rev__custom-form"), i.length > 0 && d.find(".jdgm-rev__body").after(i.detach()), j(d)
                })
            }, k = function(e) {
                var t;
                return t = e.find(".jdgm-row-rating"), e.find(".jdgm-rev__content").prepend(t), e.find(".jdgm-rev__author-wrapper").append(e.find(".jdgm-row-extra"))
            }, h = function(t) {
                return jdgm.asyncEach(t, function(t) {
                    var r, n, i, a, d;
                    return n = e(t), r = n.find(".jdgm-rev__custom-form"), i = n.find(o), a = "align" === jdgmSettings.widget_theme, d = "carousel" === jdgmSettings.widget_theme, i.length > 0 && r.length > 0 && !a ? i.insertBefore(r) : i.length > 0 && !a ? i.insertAfter(n.find(".jdgm-rev__body")) : i.length > 0 && a && (i.insertAfter(n.find(".jdgm-rev__author-wrapper")), i.css("margin-bottom", "-10px")), d ? i.css("display", "none") : void 0
                })
            }, v = function(t) {
                return jdgm.asyncEach(t, function(t) {
                    var r, n, i, a, d, g;
                    if (d = e(t), a = d.find(".jdgm-rev__custom-form"), a.length > 0 && a.children().length > 0) {
                        if (!jdgm.isVersion3) return a.find(".jdgm-rev__slider-wrapper").closest(".jdgm-rev__cf-ans").remove(), a.find(".jdgm-rev__scale-first").remove(), a.find(".jdgm-rev__scale-last").remove();
                        if (a.append('<div class="jdgm-rev__cf-ans--type jdgm-rev__cf-ans--text-type"></div>'), a.append('<div class="jdgm-rev__cf-ans--type jdgm-rev__cf-ans--graphic-type"></div>'), i = a.find(".jdgm-rev__cf-ans--text-type"), n = a.find(".jdgm-rev__cf-ans--graphic-type"), r = a.find(".jdgm-rev__cf-ans"), jdgm.asyncEach(r, function(t) {
                                var r;
                                return r = e(t), r.find(".jdgm-cf-bars-wrapper").length > 0 || r.find(".jdgm-rev__slider-wrapper").length > 0 ? (r.find(".jdgm-cf-bars-wrapper .jdgm-cf-bar").wrapAll('<div class="jdgm-rev__scale-range"></div>'), n.append(t)) : i.append(t)
                            }), "horizontal" === jdgmSettings.custom_forms_style && a.addClass("custom-form--horizontal-style"), "align" === jdgmSettings.widget_theme && (a.find(".jdgm-rev__cf-ans--text-type").wrap('<div class="jdgm-rev__header-custom-form"></div>'), g = a.find(".jdgm-rev__header-custom-form"), d.find(".jdgm-rev__header .jdgm-row-profile").append(g), "horizontal" === jdgmSettings.custom_forms_style)) return g.addClass("custom-form--horizontal-style")
                    }
                })
            }, j = function(e) {
                return e.find(".jdgm-rev_all-rev-page-picture-separator").remove(), jdgm.setupLazyLoadPicture(e.find(".jdgm-rev__product-picture .jdgm-rev__pic-img"))
            }, c = function(t, r) {
                return Object.keys(r).forEach(function(n) {
                    var i;
                    return i = e("<div>", {
                        "class": n
                    }), r[n].forEach(function(e) {
                        var r;
                        return r = t.find("." + e).detach(), i.append(r)
                    }), t.prepend(i)
                })
            }, jdgm.setupLimitingReviewHeight = function(e, t) {
                var r;
                return null == t && (t = !1), r = e.find(".jdgm-rev__body:not(.jdgm-rev__body--no-readmore):not(.is-truncated), .jdgm-ans__body"), setTimeout(function() {
                    return u(r), R(r, t)
                }, 0)
            }, u = function(t) {
                return e.each(t, function(t, r) {
                    var a, d;
                    return a = e(r), 0 === a.find(i).length ? (d = "<a class='" + n + "' tabindex='0' aria-label='" + jdgmSettings.widget_read_more_text + "' role='button'>" + jdgmSettings.widget_read_more_text + "</a>", a.append(d)) : void 0
                })
            }, R = function(t, r) {
                var n;
                return null == r && (r = !1), t.length <= 0 && !r ? void 0 : (n = t.css("lineHeight").replace("px", ""), t.dotdotdot({
                    height: jdgmSettings.widget_review_max_height * n,
                    after: i
                }).on("click", i, function(t) {
                    var r, n;
                    return r = e(this), n = r.closest(".jdgm-rev__body, .jdgm-ans__body"), n.trigger("destroy.dot").removeClass("is-truncated"), jdgm.triggerEvent("doneDestroyDot", {
                        $reviewBody: n
                    })
                }))
            }, y = function(t) {
                var r;
                return r = window.location.pathname, t.each(function(t, n) {
                    var i, a, d, g, s;
                    return i = e(n), g = i.data("product-url"), d = i.data("product-title"), g ? (s = g.indexOf(r) > -1, a = C(g, d, s), s || i.addClass("jdgm-rev-extra-padding")) : d && (a = T(d)), i.find(".jdgm-rev__timestamp").after(a)
                })
            }, C = function(e, t, r) {
                return [" <span class='jdgm-rev__prod-info-wrapper" + (r && " jdgm-hidden" || "") + "'>", "<span class='jdgm-rev__prod-link-prefix'></span>", " <a href='" + jdgm.escapeHTML(e) + "' target='_blank' class='jdgm-rev__prod-link'>", t, "</a>", "</span>"].join("")
            }, T = function(e) {
                return [" <span class='jdgm-rev__prod-info-wrapper'>", "<span class='jdgm-rev__prod-link-prefix'></span> ", e, " <span class='jdgm-rev__out-of-store-text'></span>", "</span>"].join("")
            }, E = function(t) {
                return t.find(".jdgm-rev__cf-ans__title").each(function(t, r) {
                    return r = e(r), r.text(r.text().replace("?:", "?").replace(".:", ".").replace("!:", "!"))
                })
            }, L = function(t) {
                return t.unveil(200, function() {
                    return e(this).parent(".jdgm-rev__icon").removeClass("jdgm--loading").addClass("jdgm-rev__avatar")
                }), setTimeout(function() {
                    return jdgm.ScrollEvent.trigger("unveil")
                })
            }, z = function(t) {
                var r;
                return r = t.find(".jdgm-rev__icon[data-gravatar-hash]"), r.each(function(t, r) {
                    return S(e(r))
                })
            }, S = function(r) {
                var n, i, a, d;
                return (n = r.data("gravatar-hash")) ? (d = "https://secure.gravatar.com/avatar/" + n + ".png?default=mp&filetype=png&rating=pg&secure=true", i = d + "&size=48", a = d + "&size=96", e.ajax({
                    url: a,
                    type: "HEAD",
                    crossDomain: !0,
                    success: function(n, d, g) {
                        var s;
                        if (g.getResponseHeader("content-length") !== t) return s = e("<img data-src='" + i + "' data-src-retina='" + a + "' class='jdgm-rev__avatar-image' alt='Reviewer avatar'>"), r.html(s), r.addClass("jdgm--loading"), L(s)
                    },
                    complete: function() {
                        return r.removeAttr("data-gravatar-hash"), jdgm.triggerEvent("doneFetchGravatar", {
                            $gravatarIcon: r
                        })
                    }
                })) : void 0
            }, P = function(t) {
                return jdgmSettings.widget_show_country_flag ? jdgm.asyncEach(t, function(t) {
                    var r, n, i, a, d, g;
                    return i = e(t), r = i.find(".jdgm-rev__location"), a = r.attr("data-country-code"), a ? (d = a.toUpperCase(), g = s + "/" + d + ".svg", n = e("<img class='jdgm-rev__location-country-flag-img jdgm--loading' alt='" + d + "'>"), r.before(n), n.attr("data-src", g), W(n)) : void 0
                }) : void 0
            }, D = function(t) {
                return jdgmSettings.widget_show_collected_via_shop_app ? jdgm.asyncEach(t, function(t) {
                    var r, n, i, a, d;
                    return n = e(t), i = n.find(".jdgm-rev__source"), "shop-app" === i.attr("data-source") ? "light" === (d = jdgmSettings.widget_verified_by_shop_badge_style) || "dark" === d ? (a = g + "/verified-by-shop_" + jdgmSettings.widget_verified_by_shop_badge_style + ".svg", r = e("<img class='jdgm-rev__verification-badge-img jdgm--loading' alt='Verified by Shop'>"), i.append(r), r.attr("data-src", a), W(r), n.find(".jdgm-rev__buyer-badge-wrapper").hide()) : i.text(jdgmSettings.widget_verified_by_shop_text || "Verified by Shop") : void 0
                }) : void 0
            }, W = function(t) {
                return t.unveil(200, function() {
                    return e(this).removeClass("jdgm--loading")
                }), setTimeout(function() {
                    return jdgm.ScrollEvent.trigger("unveil")
                })
            }, x = function(t) {
                var r, n;
                return r = e(".jdgm-keywords .jdgm-chip.active").data("text"), n = e(".jdgm-review-search").val(), r || n ? jdgm.asyncEach(t, function(t) {
                    var i;
                    return i = e(t), m(i.find(".jdgm-rev__title"), r || n, null === n), m(i.find(".jdgm-rev__body"), r || n, null === n), e.each(i.find(".jdgm-rev__cf-ans__value, .jdgm-rev__reply-content"), function(t, i) {
                        return m(e(i), r || n, null === n)
                    })
                }) : void 0
            }, m = function(e, t, r) {
                var n, i, a;
                return null == r && (r = !0), t = (t + "").trim(), r || (t = t.split(" ").join("|")), i = "\\b(" + t + ")\\b", t.match(/[^\u0000-\u007F]+/) && (i = "(" + t + ")"), n = e.html(), a = new RegExp(i, "gi"), e.html(n.replace(a, "<mark>$1</mark>"))
            }, e(document).on("jdgm.beforeReLayoutGrids", function(e, t) {
                return jdgmSettings.widget_load_with_code_splitting ? jdgm.setupLimitingReviewHeight(t.$reviewWrappers) : void 0
            }), e(document).on("jdgm.doneShowReviewsTab", function(e, t) {
                return "carousel" !== jdgmSettings.widget_theme ? jdgm.setupLimitingReviewHeight(t.$tabModal, !0) : void 0
            }), l = function() {
                var t;
                if (jdgm.WIDGET_REBRANDING_ENABLED && (t = e(d), !(t.text().includes(jdgmSettings.widget_no_review_text) || t.find('img[alt="Verified Checkmark"]').length > 0))) return t.append("<img src='" + jdgm.JM_PUBLIC_IMAGE_URL + "logos/verified-checkmark.svg' alt='Verified Checkmark' />"), t.addClass("jdgm-all-reviews__summary-text--verified")
            }, jdgm.customizeReviews()
        })
    }.call(this);