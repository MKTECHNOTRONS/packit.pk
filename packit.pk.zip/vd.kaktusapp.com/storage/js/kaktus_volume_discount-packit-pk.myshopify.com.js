var kaktusvbaseUrl = "https://vd.kaktusapp.com/";
var kaktusvApiUrl = "https://vd.kaktusapp.com/";
var kaktusvShop = "packit-pk.myshopify.com";
var kaktusvTriggerEvents = [6];
var kaktusvPageIds = [];
var kaktusvCertainBtns = [];
var kaktusvCurrencyCode = "USD";
var kaktusvCurrencySymbol = "$";
var kaktusvUrl = window.location.href;
var kaktusvVersion = "134"
var kaktusvShowPopupAllPeriod = 0;
var kaktusvShowPopupPerDay = 0;
var kaktusvWhenPopupDisplayed = 0;
var kaktusvRemoveFunnelProducts = 3;
var kaktusvMaxShowOffer = 0;
var kaktusvTriggerButton = "";
var kaktusvbuyItNow = "";
var kaktusvCartButton = "";
var kaktusvInlineWidget = "";
var kaktusvInlineWidgetCartPage = "";
var kaktusvInlineWidgetThankYouPage = "";
var kaktusvInlineWidgetSelectedPage = "";
var kaktusvCartSubtotal = "";
var kaktusvCartSubtotalContainer = "";
var kaktusvTikTok = "";
var kaktusvPinterest = "";
var kaktusvFacebook = "";
var kaktusvSnapchat = "";
var kaktusvSnapchatEmail = "";
var kaktusvGoogle = "";
var kaktusvAppName = "VolumeDiscount";
var kaktusvTranslations = {
    "en": {
        "checkout_btn": "Grab this deal",
        "discount_tag_text": "Save",
        "total_text": "Total:",
        "most_popular_tag_text": "Most popular"
    }
};
if (!kaktusvApp) {
    var kaktusvApp = function() {
        let currentProductId;
        let purchaseData = [];
        let orderData = [];
        let statisticArr = [];
        let iframe;
        let excludeOffers = [];
        let triggerProduct = false;
        let volumeOffer = null;
        const currentLocale = Shopify.locale;
        const appContainerClass = '.kaktusv-app-container';
        let facebookId = kaktusvFacebook || null;
        let googleId = kaktusvGoogle || null;
        let pinterestId = kaktusvPinterest || null;
        let snapId = kaktusvSnapchat || null;
        let snapEmail = kaktusvSnapchatEmail || null;
        let tikTokId = kaktusvTikTok || null;
        const params = new URLSearchParams(window.location.search);
        const offerTypes = {
            crossSell: 1,
            upsell: 2,
            bundle: 3,
            postPurchase: 4,
            discount: 5,
            frequentlyBoughtTogether: 6,
            homePage: 8,
            exitIntent: 7,
            cartPage: 9,
            beforeCheckout: 10,
            slider: 11,
            bundleByProduct: 13,
            bundleComboProducts: 14,
            bundleBuilder: 15,
            fbt: 16,
            volumeDiscount: 17
        }
        const triggerTypes = {
            addToCart: '1',
            cartPage: '2',
            thankYouPage: '3',
            selectedPages: '4',
            certainButtons: '5',
            productPage: '6',
            exitIntent: '7',
            homePage: '8',
            collectionPage: '9',
            blogPage: '10',
            beforeCheckout: '11',
            buyItNow: '12'
        }
        const popupTypes = {
            popup: '1',
            float_popup: '2',
            inline: '3'
        }
        const inlineWidgetPosition = {
            before: '1',
            after: '2'
        }
        if (Shopify.designMode) {
            buildPreviewContainer();
        }
        kaktusvCurrencySymbol = decodeHTML(kaktusvCurrencySymbol.replace(/(<([^>]+)>)/ig, ""));
        const currentCurrencyCode = Shopify.currency.active;
        let currentCurrencySymbol = kaktusvCurrencySymbol;
        let currencyRate = 1;
        const country = Shopify.country;
        if (kaktusvCurrencyCode !== currentCurrencyCode) {
            currencyRate = Shopify.currency.rate;
            const regexStr = `\\${getMainCurrencySymbol()}`;
            const regex = new RegExp(regexStr, 'g')
            currentCurrencySymbol = kaktusvCurrencySymbol.replace(regex, getCurrencySymbol(country, currentCurrencyCode));
        }

        function getCurrencySymbol(locale, currency) {
            return (0).toLocaleString(`en-${locale}`, {
                style: 'currency',
                currency: currency,
                minimumFractionDigits: 0,
                maximumFractionDigits: 0
            }).replace(/\d/g, '').trim()
        }

        function getMainCurrencySymbol() {
            if (kaktusvCurrencySymbol.includes('{{')) {
                return kaktusvCurrencySymbol.replace(/{{(.*?)}}/ig, '').trim();
            } else {
                return kaktusvCurrencySymbol.trim();
            }
        }

        function getPriceByRate(price) {
            return (parseFloat(price) * currencyRate).toFixed(2);
        }

        function getStorePriceByRate(price) {
            return (parseFloat(price) / currencyRate).toFixed(2);
        }

        function currencyFormat(num) {
            if (currentCurrencySymbol.includes('{{')) {
                return currentCurrencySymbol.replace(/{{(.*?)}}/ig, formatNumber(num));
            } else {
                return currentCurrencySymbol + formatNumber(num);
            }
        }

        function formatNumber(num) {
            num = parseFloat(num).toFixed(2);
            return parseFloat(num).toLocaleString(`en-${country}`, {
                style: 'currency',
                currency: currentCurrencyCode,
            }).replace(/[^\d.,\.]/g, '')
        }

        function decodeHTML(html) {
            const txt = document.createElement('textarea');
            txt.innerHTML = html;
            return txt.value;
        };

        function setCookieData() {
            let url = location.href;
            const oneWeek = new Date(Date.now() + 3600000 * 24 * 7);
            if (url.includes('#')) {
                url = url.split('#');
                if (url[url.length - 1]) {
                    let parameter = '#' + url[url.length - 1];
                    setCookie('kaktusvUrl', parameter, {
                        expires: oneWeek
                    });
                }
            }
        }
        setCookieData();

        function setCookie(name, value, options = {}) {
            options = {
                path: '/',
                ...options
            };
            if (options.expires instanceof Date) {
                options.expires = options.expires.toUTCString();
            }
            let updatedCookie = encodeURIComponent(name) + "=" + encodeURIComponent(value);
            for (let optionKey in options) {
                updatedCookie += "; " + optionKey;
                let optionValue = options[optionKey];
                if (optionValue !== true) {
                    updatedCookie += "=" + optionValue;
                }
            }
            document.cookie = updatedCookie;
        }

        function getCookie(name) {
            let matches = document.cookie.match(new RegExp("(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"));
            return matches ? decodeURIComponent(matches[1]) : undefined;
        }

        function setContainerId() {
            return `kaktusv-app-${makeId(5)}`;
        }

        function buildPopUpType(dataOffer, dataCart, currentProductId, triggerType, allVariantsId) {
            for (let key in dataOffer.offers) {
                const offerItem = dataOffer.offers[key];
                const popUpType = (offerItem.popup_type).toString();
                switch (popUpType) {
                    case popupTypes.inline:
                        buildInlineWidget({
                            dataOffer,
                            offerItem,
                            dataCart,
                            currentProductId,
                            triggerType,
                            allVariantsId
                        });
                        break;
                }
            }
            socialPixel();
        }

        function buildInlineWidget(params) {
            const {
                offerItem,
                triggerType
            } = params;
            let rootId = setContainerId();
            let nodeElement = null;
            nodeElement = getInlineNode(triggerType);

            function getInlineNode(triggerType) {
                let defaultNodeElements = [];
                let inlineWidgetArr = [];
                switch (triggerType) {
                    case triggerTypes.cartPage:
                        defaultNodeElements = [appContainerClass, 'cart-items', 'form[action*="/cart"]'];
                        inlineWidgetArr = kaktusvInlineWidgetCartPage.length ? decodeHTML(kaktusvInlineWidgetCartPage).split(',') : inlineWidgetArr;
                        break;
                    case triggerTypes.productPage:
                        defaultNodeElements = [appContainerClass, 'form[action*="/cart/add"]'];
                        inlineWidgetArr = kaktusvInlineWidget.length ? decodeHTML(kaktusvInlineWidget).split(',') : inlineWidgetArr;
                        break;
                    case triggerTypes.selectedPages:
                        defaultNodeElements = [appContainerClass, '.kaktusv-container'];
                        inlineWidgetArr = kaktusvInlineWidgetSelectedPage.length ? decodeHTML(kaktusvInlineWidgetSelectedPage).split(',') : inlineWidgetArr;
                        break;
                    case triggerTypes.thankYouPage:
                        defaultNodeElements = [appContainerClass, '.section__header'];
                        inlineWidgetArr = kaktusvInlineWidgetThankYouPage.length ? decodeHTML(kaktusvInlineWidgetThankYouPage).split(',') : inlineWidgetArr;
                        break;
                }
                const commonInlineWidgetArr = inlineWidgetArr.concat(defaultNodeElements);
                const uniqueInlineWidgetArr = [...new Set(commonInlineWidgetArr)];
                if (uniqueInlineWidgetArr.length) {
                    for (let i = 0; i < uniqueInlineWidgetArr.length; i++) {
                        const itemTrim = uniqueInlineWidgetArr[i].trim();
                        const currentNode = document.querySelector(itemTrim);
                        if (currentNode != null) {
                            return currentNode;
                        }
                    }
                } else {
                    return null;
                }
            }
            if (!nodeElement) return;
            const isSylesheet = document.querySelector('link#KaktusVolumeDiscountCss');
            if (!isSylesheet) {
                styleLoader();
            }
            buildInlineContainer();

            function styleLoader() {
                const headID = document.getElementsByTagName('head')[0];
                const link = document.createElement('link');
                link.type = 'text/css';
                link.id = 'KaktusVolumeDiscountCss';
                link.rel = 'stylesheet';
                headID.appendChild(link);
                link.href = kaktusvbaseUrl + `css/kaktus-volume-discount.css?v=${kaktusvVersion}`;
            };

            function buildInlineContainer() {
                clearPreviewContainer();
                const insertPosition = (offerItem.inline_position).toString();
                const element = document.createElement("div");
                element.setAttribute("id", rootId);
                element.style.width = '100%';
                element.style.margin = '20px 0';
                element.style.fontFamily = 'inherit';
                element.style.display = 'none';
                if (insertPosition === inlineWidgetPosition.before) {
                    nodeElement.before(element);
                } else {
                    nodeElement.after(element);
                }
            }
            const offerType = offerItem.offer_type;
            switch (offerType) {
                case offerTypes.volumeDiscount:
                    buildVolumeDiscountInline({
                        rootId,
                        ...params
                    });
                    break;
            }
        }

        function removeAppContainer(rootId) {
            const kaktusvPopup = document.querySelector(`#${rootId}`);
            iframe = null;
            if (kaktusvPopup) {
                kaktusvPopup.remove();
            }
            document.querySelector('body').style.overflow = '';
            document.querySelector('body').style.height = '';
            document.querySelector('html').style.overflow = '';
            document.querySelector('html').style.height = '';
        }

        function buildPreviewContainer() {
            const rootDiv = document.querySelector(appContainerClass);
            if (!rootDiv) return;
            const html = '<span>The <b>Kaktus APP</b> will be displayed here!</span>';
            const element = document.createElement("div");
            element.classList.add('kaktusv-app-preview');
            element.style.padding = '20px';
            element.style.border = '1px solid #e4e4e4';
            element.style.borderRadius = '8px';
            element.style.textAlign = 'center';
            element.innerHTML = html;
            rootDiv.append(element);
        }

        function clearPreviewContainer() {
            const previewContainer = document.querySelector(appContainerClass);
            if (previewContainer) {
                previewContainer.innerHTML = '';
            }
        }

        function getAppSelector(element, rootId) {
            let rootNode = document.querySelector(`#${rootId}`);
            if (iframe) {
                rootNode = iframe.contentWindow.document.querySelector(`#${rootId}`);
            }
            return rootNode.querySelector(element);
        }

        function getAppSelectorAll(element, rootId) {
            let rootNode = document.querySelector(`#${rootId}`);
            if (iframe) {
                rootNode = iframe.contentWindow.document.querySelector(`#${rootId}`);
            }
            return rootNode.querySelectorAll(element);
        }

        function buildVolumeDiscountInline(params) {
            const {
                dataOffer,
                offerItem,
                currentProductId,
                rootId,
                triggerType,
                allVariantsId
            } = params;
            const offerObj = {
                mainOfferId: offerItem.main_offer_id,
                offerId: offerItem.id,
                offerDesign: dataOffer.design[offerItem.id],
                allowPageReload: offerItem.reload_page ? true : false,
                pageReload: false,
                currentTriggerType: triggerType,
                volumeId: makeId(5),
                hideVariationPrice: offerItem.hide_variation_price
            }
            const offerTexts = getOfferTexts(dataOffer, offerItem)
            const offerProduct = offerItem.products ? offerItem.products[currentProductId] : null;
            const triggerProductData = dataOffer.products[currentProductId];
            const triggerVariants = getActiveVariants(triggerProductData.variants, offerProduct);
            const updatedTriggerVariants = checkSoldOutProduct(triggerVariants);
            if (!updatedTriggerVariants.length) {
                return;
            }
            triggerProductData.variants = updatedTriggerVariants;
            const copyright = !dataOffer.brand ? '' : buildCopyright();
            const html = `
                <div class="kaktusv-popup__body kaktusv-bd kaktusv-width-container">
                    <div class="kaktusv-popup__main kaktusv-bg-main">
                        <div class="kaktusv-countdown kaktusv-timer">
                            <div class="kaktusv-countdown__wrap">
                                <div class="kaktusv-countdown__msg kaktusv-timer-msg"></div>
                                <div class="kaktusv-countdown__time"></div>
                            </div>
                        </div>

                        <div class="kaktusv-popup__main--wrapper kaktusv-wallpaper"></div>

                        <div class="kaktusv-popup__heading kaktusv-bg-heading">


                            <h2 class="kaktusv-popup__title kaktusv-title"></h2>
                            <p class="kaktusv-popup__description kaktusv-description"></p>
                        </div>

                        <div class="kaktusv-popup__options"></div>

                        <div class="kaktusv-popup__buttons kaktusv-bg-bottom">
                            <a href="#" class="kaktusv-checkout-btn" data-checkout="${offerItem.checkout_btn_event}" data-redirect="${offerItem.specific_url}"></a>
                        </div>
                        ${copyright}
                    </div>
                </div>

                <style type="text/css" id="kaktusv-custom-css"></style>
            `;
            const element = document.createElement("div");
            element.classList.add("kaktusv-inline", "kaktusv-volume");
            element.innerHTML = html;
            const rootDiv = document.getElementById(rootId);
            rootDiv.append(element);
            const timerData = {
                minutes: offerObj.offerDesign.main.timer_min,
                seconds: offerObj.offerDesign.main.timer_sec,
                display: getAppSelector('.kaktusv-countdown__time', rootId),
                rootId,
                offerId: offerObj.offerId,
                mainOfferId: offerObj.mainOfferId,
                offerObj: offerObj
            }
            buildTimer(timerData.minutes, timerData.seconds, timerData.display);
            const countDownTimer = new Timer(timerData);
            const volumeData = offerItem.volume_discount;
            const volumeDataOptions = volumeData.options;
            volumeDataOptions.forEach((option, i) => {
                const productData = {
                    allow_highlight: volumeData.allow_highlight_option,
                    highlight_option: volumeData.highlight_option,
                    option_number: i + 1,
                    product: triggerProductData
                }
                fillVolumeOption(option, productData, rootId, offerObj);
            })
            setTranslation(rootId, dataOffer);
            buildWidget(offerObj.offerDesign, rootId, countDownTimer);
            changeWidgetText(element, offerTexts);
            addVolumeEvents({
                element,
                offerObj,
                rootId,
                countDownTimer,
                volumeDataOptions
            });
            volumeOffer = {
                volumeDataOptions,
                offerObj,
                allVariantsId
            };
            setTimeout(() => {
                rootDiv.style.display = 'block';
            }, 500);
        }

        function setTranslation(rootId, dataOffer) {
            const settingTexts = getSettingTexts(dataOffer)
            const dataTranslation = {
                "checkout-btn-text": {
                    value: "checkout_btn",
                    element: "kaktusv-checkout-btn"
                },
                "total-text": {
                    value: "total_text",
                    element: "kaktusv-total"
                },
                "discount-tag-text": {
                    value: "discount_tag_text",
                    element: "kaktusv-save"
                },
                "most-popular-tag-text": {
                    value: "most_popular_tag_text",
                    element: "kaktusv-save-label"
                },
            };
            for (let key in dataTranslation) {
                const {
                    value,
                    element
                } = dataTranslation[key];
                const option = settingTexts[value];
                if (option == null) return;
                const nodeList = getAppSelectorAll('.' + element, rootId)
                nodeList.forEach((node) => {
                    node.innerText = option;
                });
            }
        }

        function getSettingTexts(dataOffer) {
            const defaultLocale = dataOffer.current_lang;
            const defaultLang = kaktusvTranslations[defaultLocale] || kaktusvTranslations[Object.keys(kaktusvTranslations)[0]];
            const currentLang = kaktusvTranslations[currentLocale] || defaultLang;
            return {
                'checkout_btn': currentLang.checkout_btn || defaultLang.checkout_btn,
                'total_text': currentLang.total_text || defaultLang.total_text,
                'discount_tag_text': currentLang.discount_tag_text || defaultLang.discount_tag_text,
                'most_popular_tag_text': currentLang.most_popular_tag_text || defaultLang.most_popular_tag_text
            }
        }

        function getOfferTexts(dataOffer, offerItem) {
            const {
                translate
            } = offerItem;
            let data = translate[currentLocale] || offerItem;
            return {
                'title': data.title || offerItem.title,
                'allow_set_description': offerItem.allow_set_description,
                'description': data.description || offerItem.description,
                'timer_text': data.timer_text || offerItem.timer_text
            }
        }

        function fillVolumeOption(optionData, productData, rootId, offerObj) {
            const {
                custom_text,
                allow_range,
                range_from,
                range_to,
                discount_type,
                discount_value
            } = optionData;
            const {
                product,
                allow_highlight,
                highlight_option,
                option_number
            } = productData;
            const highlightLabel = allow_highlight && +option_number === +highlight_option ? `<div class="kaktusv-option__label kaktusv-save-label kaktusv-highlight"></div>` : '';
            let discountLabel = '';
            let comparePrice = '';
            let productPrice = getPriceByRate(product.variants[0].variantPrice);
            let compareTotalPrice = parseFloat(discount_value) ? `<strike class="kaktusv-compare-price kaktusv-total-compare-price"></strike>` : '';
            if (parseFloat(discount_value)) {
                const discount = discount_type === '%' ? `${discount_value}${discount_type}` : currencyFormat(getPriceByRate(discount_value));
                discountLabel = `<p class="kaktusv-option__save-text kaktusv-discount-text"><span class="kaktusv-save"></span> ${discount}</p>`;
                comparePrice = `<strike class="kaktusv-compare-price">${currencyFormat(productPrice)}</strike>`;
                if (discount_type === '%') {
                    productPrice = (+productPrice - (+productPrice * +discount_value / 100)).toFixed(2);
                } else {
                    productPrice = (+productPrice - +discount_value).toFixed(2);
                }
            }
            let optionHtml = '';
            if (product.variants.length > 1) {
                let variantsHtml = '';
                variantsHtml = '<select class="kaktusv-variations">';
                for (let key in product.variants) {
                    if (product.variants.hasOwnProperty(key)) {
                        let variantPrice = getPriceByRate(product.variants[key]['variantPrice']);
                        if (discount_value) {
                            if (discount_type === "%") {
                                variantPrice = (variantPrice - (variantPrice * +discount_value / 100)).toFixed(2);
                            } else {
                                variantPrice = (+variantPrice - +discount_value).toFixed(2);
                            }
                        }
                        variantsHtml += `
                        <option
                            value="${product.variants[key]['productId']}"
                            data-price="${getPriceByRate(product.variants[key]['variantPrice'])}"
                            data-store-price="${product.variants[key]['variantPrice']}"
                            data-discount-price="${variantPrice}"
                        >
                            ${product.variants[key]['title']} ${offerObj.hideVariationPrice ? '' : ' - ' + currencyFormat(variantPrice)}
                        </option>
                    `;
                    }
                }
                variantsHtml += '</select>';
                if (range_from >= 1) {
                    for (let i = 0; i < range_from; i++) {
                        optionHtml += `
                            <div class="kaktusv-option__product">
                                <span class="kaktusv-option__number">#${i + 1}</span>

                                <div class="kaktusv-option__select">
                                    ${variantsHtml}
                                </div>
                            </div>
                        `;
                    }
                }
                if (range_to) {
                    optionHtml += setPlusRow(range_from);
                }
            } else {
                const variantItem = product.variants[Object.keys(product.variants)[0]];
                optionHtml = setQtyRow(range_from, range_to, allow_range, variantItem);
            }

            function setPlusRow(range_from) {
                return `
                    <div class="kaktusv-option__product">
                        <span class="kaktusv-option__number">#${+range_from + 1}</span>

                        <div class="kaktusv-option__plus kaktusv-variations">
                            <svg width="16" height="16" viewBox="0 0 14 14" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                <rect x="6" width="2" height="14" rx="1" fill="currentColor"></rect>
                                <rect x="14" y="6" width="2" height="14" rx="1" transform="rotate(90 14 6)" fill="currentColor"></rect>
                            </svg>
                        </div>
                    </div>
                `
            }

            function setQtyRow(range_from, range_to, allow_range, variantItem) {
                const variantTitle = variantItem['title'];
                let titleHtml = '';
                if (variantTitle.toLowerCase() !== "default title") {
                    let variantPrice = getPriceByRate(variantItem['variantPrice']);
                    if (product.discount != undefined && product.discount_type != undefined && parseInt(product.discount) != 0) {
                        variantPrice = calcVariantsDiscountPrice(product, variantItem);
                    }
                    titleHtml = `<span class="kaktusv-variations">${variantTitle} - ${currencyFormat(variantPrice)}</span>`;
                }
                if (allow_range && range_to) {
                    return `
                        ${titleHtml}
                        <div class="kaktusv-option__product">
                            <div class="kaktusv-option__qty kaktusv-variations" data-max-qty="${range_to}">
                                <div class="kaktusv-option__qty-btn kaktusv-qty-btn kaktusv-qty-minus">-</div>
                                <input class="kaktusv-option__qty-input" type="number" value="${range_from}" min="${range_from}" max="${range_to}">
                                <div class="kaktusv-option__qty-btn kaktusv-qty-btn kaktusv-qty-plus">+</div>
                            </div>
                        </div>
                    `
                } else {
                    return `
                        ${titleHtml}
                        <input type="hidden" class="kaktusv-option__qty-input" type="number" value="${range_from}" min="${range_from}">
                    `
                }
            }
            const html = `
                ${highlightLabel}

                <div class="kaktusv-option__content">
                    <div class="kaktusv-option__info">
                        <div class="kaktusv-option__radio kaktusv-radio-border">
                            <div class="kaktusv-option__radio-dot kaktusv-radio-bg"></div>
                        </div>

                        <p class="kaktusv-prod-title">${custom_text}</p>
                    </div>

                    <div class="kaktusv-option__result">
                        ${discountLabel}

                        <div class="kaktusv-option__price-block">
                            ${comparePrice}
                            <span class="kaktusv-price"
                                data-price="${getPriceByRate(product.variants[0].variantPrice)}"
                                data-discount-price="${productPrice}"
                                data-storePrice="${product.variants[0]['variantPrice']}"
                                data-productId="${product.variants[0]['productId']}"
                            >
                                ${currencyFormat(productPrice)}
                            </span>
                        </div>

                        <span class="kaktusv-option__total-block">
                            <span class="kaktusv-total"></span>
                            ${compareTotalPrice}
                            <span class="kaktusv-total-price"></span>
                        </span>
                    </div>
                </div>

                <div class="kaktusv-option__products" data-rangeto="${range_to ? range_to : null}">
                    ${optionHtml}
                </div>
            `;
            const element = document.createElement("div");
            element.classList.add("kaktusv-option", "kaktusv-product-bg", "kaktusv-product-border");
            element.setAttribute('data-discountType', discount_type)
            element.setAttribute('data-discount', discount_value)
            const activeOption = allow_highlight && highlight_option ? +highlight_option : 1;
            if (option_number === activeOption) {
                element.classList.add("kaktusv-bg-active");
            }
            element.innerHTML = html;
            calcVolumeTotalOptionPrice(element);
            addVolumeRowEvents(element);
            const plusVariantBtn = element.querySelector('.kaktusv-option__plus');
            if (plusVariantBtn) {
                addNewRowEvent(plusVariantBtn, element);
            }
            const rootDiv = getAppSelector('.kaktusv-popup__options', rootId);
            rootDiv.append(element);
        }

        function variantOptionEvent(variant, optionRow) {
            variant.addEventListener('change', () => {
                calcVolumeTotalOptionPrice(optionRow);
                setOptionPrice(optionRow);
            });
        }

        function addVolumeRowEvents(optionRow) {
            const variations = optionRow.querySelectorAll('select.kaktusv-variations');
            const qtyInput = optionRow.querySelector('.kaktusv-option__qty-input');
            const qtyPlusBtn = optionRow.querySelector('.kaktusv-qty-plus');
            const qtyMinusBtn = optionRow.querySelector('.kaktusv-qty-minus');
            if (variations.length) {
                variations.forEach(variant => {
                    variantOptionEvent(variant, optionRow)
                });
            }
            if (qtyInput && qtyPlusBtn && qtyMinusBtn) {
                const maxVal = qtyInput.max;
                qtyPlusBtn.addEventListener('click', function() {
                    changeQtyValue(qtyInput, 'add', maxVal);
                    calcVolumeTotalOptionPrice(optionRow);
                });
                qtyMinusBtn.addEventListener('click', function() {
                    changeQtyValue(qtyInput, 'sub', maxVal);
                    calcVolumeTotalOptionPrice(optionRow);
                });
                qtyInput.addEventListener('change', function() {
                    changeQtyValue(qtyInput, 'change', maxVal);
                    calcVolumeTotalOptionPrice(optionRow);
                })
            }
        }

        function addVolumeEvents(params) {
            const {
                element,
                offerObj,
                rootId,
                countDownTimer,
                volumeDataOptions
            } = params;
            const {
                mainOfferId,
                offerId,
                volumeId
            } = offerObj;
            const checkoutBtn = element.querySelector('.kaktusv-checkout-btn');
            const options = element.querySelectorAll('.kaktusv-option');
            checkoutBtn.addEventListener('click', function(event) {
                event.preventDefault();
                const checkoutEvent = this.getAttribute('data-checkout');
                const redirectUrl = this.getAttribute('data-redirect');
                statisticArr.push(offerId);
                let productCount = 0;
                const product = element.querySelector('.kaktusv-bg-active');
                const productVolumeData = getVolumeProducts(product);
                let activeProductsLength = +productVolumeData.length;
                element.querySelector('.kaktusv-popup__body').classList.add('kaktusv-preload');
                addVolumeProducts(productVolumeData);

                function addVolumeProducts(productVolumeData) {
                    if (!productVolumeData.length) return
                    productVolumeData.forEach((productItem, i) => {
                        setTimeout(() => {
                            const {
                                propertyId,
                                variantId,
                                storePrice,
                                discountType,
                                discountValue,
                                qty
                            } = productItem;
                            addItem(variantId, qty, {
                                offer: propertyId
                            }).then(() => {
                                createOrderData(variantId, propertyId, discountType, discountValue, qty);
                                createPurchaseData(mainOfferId, offerId, variantId, propertyId, storePrice);
                                createVolumeProductsData(volumeId, variantId, propertyId);
                                productCount++
                                if (offerObj.allowPageReload) {
                                    offerObj.pageReload = true;
                                }
                                if (activeProductsLength === productCount) {
                                    sendStatistic(mainOfferId, offerId, true);
                                    createVolumeData(volumeId, volumeDataOptions);
                                    setTimeout(() => {
                                        element.querySelector('.kaktusv-popup__body').classList.remove('kaktusv-preload');
                                        checkoutBtnEvents(checkoutEvent, redirectUrl, rootId, offerObj, countDownTimer);
                                    }, 1500);
                                }
                            })
                        }, 1000 * i);
                    });
                }
            });
            options.forEach(option => {
                option.addEventListener('click', setActiveOption);
            })

            function setActiveOption(e) {
                e.preventDefault();
                if (!this.classList.contains('kaktusv-bg-active')) {
                    options.forEach(element => element.classList.remove('kaktusv-bg-active'));
                    this.classList.add('kaktusv-bg-active');
                    removeDefaultColor(offerObj.offerDesign, rootId);
                    changeActiveColor(offerObj.offerDesign, rootId);
                }
            }
        }

        function getVolumeProducts(product) {
            let productVolumeData = [];
            const variants = product.querySelectorAll('select.kaktusv-variations');
            if (variants.length) {
                let uniqIds = [];
                variants.forEach(variantItem => {
                    const variantId = variantItem.selectedOptions[0].value;
                    if (uniqIds.includes(variantId)) {
                        const targetElement = productVolumeData.find(el => +el.variantId === +variantId);
                        targetElement.qty = +targetElement.qty + 1;
                    } else {
                        productVolumeData.push({
                            propertyId: makeId(5),
                            variantId,
                            storePrice: variantItem.selectedOptions[0].getAttribute('data-store-price'),
                            discountType: product.getAttribute('data-discountType'),
                            discountValue: product.getAttribute('data-discount') || null,
                            qty: 1
                        });
                        uniqIds.push(variantId);
                    }
                })
            } else {
                productVolumeData.push({
                    propertyId: makeId(5),
                    variantId: product.querySelector('.kaktusv-price').getAttribute('data-productId'),
                    storePrice: product.querySelector('.kaktusv-price').getAttribute('data-storePrice'),
                    discountType: product.getAttribute('data-discountType'),
                    discountValue: product.getAttribute('data-discount') || null,
                    qty: +product.querySelector('.kaktusv-option__qty-input').value
                })
            }
            return productVolumeData;
        }

        function createVolumeProductsData(volumeId, variantId, propertyId) {
            if (!volumeId) return;
            const localVolumeData = localStorage.getItem('kaktusvVolumeData');
            let volumeData = localVolumeData ? JSON.parse(localVolumeData) : [];
            let productData = {
                volumeId: volumeId,
                volumeProducts: [],
                volumeOptions: []
            }
            if (volumeData.length) {
                const checkVolumeId = volumeData.find(item => item.volumeId === volumeId);
                if (checkVolumeId) {
                    setProductsData(checkVolumeId);
                } else {
                    volumeData.push(productData);
                    setProductsData(productData);
                }
            } else {
                volumeData.push(productData);
                setProductsData(productData);
            }
            localStorage.setItem('kaktusvVolumeData', JSON.stringify(volumeData));

            function setProductsData(data) {
                data.volumeProducts.push({
                    variantId: variantId,
                    propertyId: propertyId
                })
            }
        }

        function createVolumeData(volumeId, volumeDataOptions) {
            if (!volumeId) return;
            const localVolumeData = localStorage.getItem('kaktusvVolumeData');
            let volumeData = localVolumeData ? JSON.parse(localVolumeData) : [];
            if (volumeData.length) {
                const checkVolumeId = volumeData.find(item => item.volumeId === volumeId);
                if (checkVolumeId) {
                    volumeDataOptions.forEach(option => {
                        const {
                            range_from,
                            allow_range,
                            range_to,
                            discount_type,
                            discount_value
                        } = option;
                        checkVolumeId.volumeOptions.push({
                            range_from,
                            allow_range,
                            range_to,
                            discount_type,
                            discount_value
                        });
                    })
                }
            }
            localStorage.setItem('kaktusvVolumeData', JSON.stringify(volumeData));
        }

        function calcVolumeTotalOptionPrice(optionRow) {
            const comparePriceDiv = optionRow.querySelector('.kaktusv-total-compare-price');
            const totalPriceDiv = optionRow.querySelector('.kaktusv-total-price');
            const qtyInput = optionRow.querySelector('.kaktusv-option__qty-input');
            let totalPrice = 0;
            let totalComparePrice = 0;
            const variations = optionRow.querySelectorAll('select.kaktusv-variations');
            if (variations.length) {
                variations.forEach(variant => {
                    const variantPrice = variant.selectedOptions[0].getAttribute('data-price');
                    const variantDiscountPrice = variant.selectedOptions[0].getAttribute('data-discount-price');
                    totalComparePrice += +variantPrice;
                    totalPrice += +variantDiscountPrice;
                })
            } else {
                const productPrice = optionRow.querySelector('.kaktusv-price').getAttribute('data-price');
                const discountPrice = optionRow.querySelector('.kaktusv-price').getAttribute('data-discount-price');
                totalPrice = qtyInput ? +discountPrice * +qtyInput.value : +discountPrice;
                totalComparePrice = qtyInput ? +productPrice * +qtyInput.value : +productPrice;
            }
            if (comparePriceDiv) {
                comparePriceDiv.innerHTML = currencyFormat(totalComparePrice);
            }
            totalPriceDiv.innerHTML = currencyFormat(totalPrice);
        }

        function addNewRowEvent(btn, optionRow) {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                const self = this;
                buildVariantRow(optionRow, self);
            });
        }

        function buildVariantRow(optionRow, self) {
            const rangeTo = optionRow.querySelector('.kaktusv-option__products').getAttribute('data-rangeto');
            const products = optionRow.querySelectorAll('.kaktusv-option__product');
            const plusRowTempl = self.closest('.kaktusv-option__product').cloneNode(true);
            const selectTempl = self.closest('.kaktusv-option__products').querySelector('.kaktusv-option__select').cloneNode(true);
            const optionDiv = self.closest('.kaktusv-option__product');
            const variant = selectTempl.querySelector('select.kaktusv-variations');
            if (variant.length) {
                variantOptionEvent(variant, optionRow);
            }
            self.remove();
            optionDiv.append(selectTempl);
            calcVolumeTotalOptionPrice(optionRow);
            if (products.length < rangeTo) {
                plusRowTempl.querySelector('.kaktusv-option__number').innerHTML = `#${products.length + 1}`;
                const btn = plusRowTempl.querySelector('.kaktusv-option__plus');
                addNewRowEvent(btn, optionRow);
                optionRow.querySelector('.kaktusv-option__products').append(plusRowTempl);
            }
        }

        function setOptionPrice(optionRow) {
            const priceBlock = optionRow.querySelector('.kaktusv-option__price-block');
            const comparePriceDiv = priceBlock.querySelector('.kaktusv-compare-price');
            const totalPriceDiv = priceBlock.querySelector('.kaktusv-price');
            const variations = optionRow.querySelectorAll('select.kaktusv-variations');
            const priceArr = [];
            let newPrice = 0;
            let newComparePrice = 0;
            variations.forEach(variant => {
                const variantPrice = variant.selectedOptions[0].getAttribute('data-price');
                const variantDiscountPrice = variant.selectedOptions[0].getAttribute('data-discount-price');
                newPrice = +variantDiscountPrice;
                newComparePrice = +variantPrice;
                priceArr.push(+variantPrice)
            });
            const allEqual = priceArr.every(v => v === priceArr[0]);
            if (allEqual) {
                priceBlock.classList.remove('kaktusv-hide');
                totalPriceDiv.innerHTML = currencyFormat(newPrice);
                if (comparePriceDiv) {
                    comparePriceDiv.innerHTML = currencyFormat(newComparePrice);
                }
            } else {
                priceBlock.classList.add('kaktusv-hide');
            }
        }

        function setActiveColor(widgetJson, rootId) {
            const element = getAppSelector('.kaktusv-bg-active', rootId);
            const obj = {
                "w-prod-bg": {
                    cssOption: "background"
                },
                "w-border-color": {
                    cssOption: "border-color"
                }
            }
            let option = widgetJson.product.active_background;
            if (!option) return;
            for (let key in obj) {
                let {
                    cssOption
                } = obj[key];
                if (cssOption === 'background') {
                    option = convertHexToRGBA(option, 0.1);
                }
                element.style[cssOption] = option;
            }
        }

        function changeActiveColor(widgetJson, rootId) {
            const element = getAppSelector('.kaktusv-bg-active', rootId);
            let option = widgetJson.product.active_background;
            if (!option) return;
            const obj = {
                "w-prod-bg": {
                    cssOption: "background"
                },
                "w-border-color": {
                    cssOption: "border-color"
                }
            }
            for (let key in obj) {
                let {
                    cssOption
                } = obj[key];
                if (cssOption === 'background') {
                    option = convertHexToRGBA(option, 0.1);
                }
                element.style[cssOption] = option;
            }
        }

        function removeDefaultColor(widgetJson, rootId) {
            const obj = {
                "w-prod-bg": {
                    data: "product",
                    value: "background",
                    element: "kaktusv-product-bg",
                    cssOption: "background"
                },
                "w-border-color": {
                    data: "product",
                    value: "prod_border_color",
                    element: "kaktusv-product-border",
                    cssOption: "border-color"
                }
            }
            for (let key in obj) {
                let {
                    data,
                    value,
                    element,
                    cssOption
                } = obj[key];
                const option = widgetJson[data][value];
                const elements = getAppSelectorAll('.' + element, rootId);
                elements.forEach((element) => {
                    element.style[cssOption] = option;
                })
            }
        }

        function convertHexToRGBA(hexCode, opacity = 1) {
            let hex = hexCode.replace('#', '');
            if (hex.length === 3) {
                hex = `${hex[0]}${hex[0]}${hex[1]}${hex[1]}${hex[2]}${hex[2]}`;
            }
            const r = parseInt(hex.substring(0, 2), 16);
            const g = parseInt(hex.substring(2, 4), 16);
            const b = parseInt(hex.substring(4, 6), 16);
            if (opacity > 1 && opacity <= 100) {
                opacity = opacity / 100;
            }
            return `rgba(${r},${g},${b},${opacity})`;
        };

        function buildCopyright() {
            return '<div class="kaktusv-copyright"><a href="https://kaktusapp.com/" target="_blank">Powered by Kaktus</a></div>';
        }

        function getActiveVariants(allVariants, activeVariants) {
            const variants = [];
            for (let key in allVariants) {
                if (activeVariants) {
                    if (activeVariants.includes(allVariants[key].productId)) {
                        variants.push(allVariants[key]);
                    }
                } else {
                    variants.push(allVariants[key]);
                }
            }
            return variants;
        }

        function checkSoldOutProduct(offerVariants) {
            if (typeof(kaktusAppData) === 'undefined') {
                return offerVariants
            }
            const {
                product
            } = kaktusAppData
            if (!product) {
                return offerVariants
            }
            return offerVariants.filter(item => {
                const targetVariant = product.variants.find(variantItem => +variantItem.id === +item.productId);
                if (!targetVariant) {
                    return true;
                }
                return targetVariant.available
            })
        }

        function changeQtyValue(qty, type, maxVal) {
            let currentQty = +qty.value;
            let minValue = +qty.getAttribute('min');
            let nextQty;
            switch (type) {
                case 'add':
                    {
                        if (maxVal) {
                            maxVal = +maxVal;
                            nextQty = currentQty < maxVal ? currentQty + 1 : maxVal;
                        } else {
                            nextQty = currentQty + 1;
                        }
                        break;
                    }
                case 'sub':
                    {
                        currentQty === minValue ? nextQty = minValue : nextQty = currentQty - 1;
                        break;
                    }
                case 'change':
                    {
                        if (maxVal) {
                            maxVal = +maxVal;
                            nextQty = currentQty < maxVal ? currentQty : maxVal;
                        } else {
                            nextQty = currentQty;
                        }
                        if (nextQty <= minValue || nextQty <= 0) {
                            nextQty = minValue || 1;
                        }
                    }
            }
            qty.value = nextQty;
        }

        function makeId(length) {
            let result = '';
            const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
            const charactersLength = characters.length;
            for (let i = 0; i < length; i++) {
                result += characters.charAt(Math.floor(Math.random() * charactersLength));
            }
            return result;
        }

        function changeWidgetText(element, offerTexts) {
            const titleRow = element.querySelector('.kaktusv-title');
            const descriptionRow = element.querySelector('.kaktusv-description');
            const timerRow = element.querySelector('.kaktusv-timer-msg');
            titleRow.innerText = offerTexts.title;
            if (offerTexts.allow_set_description) {
                descriptionRow.classList.remove('kaktusv-hide');
                descriptionRow.innerText = offerTexts.description;
            } else {
                descriptionRow.classList.add('kaktusv-hide');
            }
            timerRow.innerText = offerTexts.timer_text;
        }
        window.addEventListener('resize', function() {
            const topSection = iframe ? iframe.contentWindow.document.querySelector('.kaktusv-popup__top') : false;
            if (topSection) {
                if (window.innerWidth < 768) {
                    topSection.style.display = "none";
                } else {
                    topSection.style.display = "flex";
                }
            }
        });

        function checkoutBtnEvents(val, customUrl, rootId, offerObj, countDownTimer) {
            const goCheckout = '1';
            const goCart = '2';
            const goCustomUrl = '3';
            const closePopUp = '4';
            switch (val) {
                case goCheckout:
                    createOrder();
                    break;
                case goCart:
                    goToCart();
                    break;
                case goCustomUrl:
                    if (customUrl) location.href = `https://${customUrl}`;
                    break;
                case closePopUp:
                    closeModal('1', rootId, offerObj, countDownTimer);
                    break;
                default:
                    createOrder();
                    break;
            }
        }

        function closeModal(closeEvent = '1', rootId, offerObj, countDownTimer) {
            const goCheckout = '2';
            const {
                mainOfferId,
                offerId
            } = offerObj;
            if (closeEvent === goCheckout) {
                sendStatistic(mainOfferId, offerId);
                setTimeout(() => {
                    createOrder();
                }, 1000);
            } else {
                sendStatistic(mainOfferId, offerId);
                if (countDownTimer) {
                    countDownTimer.stopTimer()
                }
                removeAppContainer(rootId);
                statisticArr.length = 0;
                if (offerObj.pageReload) {
                    setTimeout(() => {
                        cartReload(offerObj);
                    }, 1000);
                }
            }
        }

        function buildWidget(dataOffer, rootId, countDownTimer) {
            fillWidget(dataOffer, rootId, countDownTimer);
            fillWidgetSettings(dataOffer, rootId);
        }
        const dataJsonTopSection = {
            "kaktusv-background-top": {
                data: "top",
                value: "background_top",
                input: "kaktusv-bg-top-input",
                element: "kaktusv-bg-top",
                cssOption: "background"
            },
            "kaktusv-close-btn-bd-radius": {
                data: "top",
                value: "close_border_radius",
                input: "kaktusv-close-border-radius",
                element: "kaktusv-close",
                cssOption: "border-radius",
                cssType: "size"
            },
            "kaktusv-alert-text-color": {
                data: "top",
                value: "alert_text_color",
                input: "kaktusv-alert-text-color",
                element: "kaktusv-alert-text",
                cssOption: "color"
            },
            "kaktusv-alert-text-font-size": {
                data: "top",
                value: "alert_text_font_size",
                input: "kaktusv-alert-text-font-size",
                element: "kaktusv-alert-text",
                cssOption: "font-size",
                cssType: "size"
            },
            "kaktusv-alert-text-font-weight": {
                data: "top",
                value: "alert_text_font_weight",
                input: "kaktusv-alert-text-font-weight",
                element: "kaktusv-alert-text",
                cssOption: "font-weight"
            },
            "kaktusv-alert-text-font-style": {
                data: "top",
                value: "alert_text_font_style",
                input: "kaktusv-alert-text-font-style",
                element: "kaktusv-alert-text",
                cssOption: "font-style"
            },
            "kaktusv-alert-text-line-height": {
                data: "top",
                value: "alert_text_line_height",
                input: "kaktusv-alert-text-line-height",
                element: "kaktusv-alert-text",
                cssOption: "line-height",
                cssType: "size"
            },
            "kaktusv-alert-prod-color": {
                data: "top",
                value: "alert_prod_color",
                input: "kaktusv-alert-prod-color",
                element: "kaktusv-alert-prod",
                cssOption: "color"
            },
            "kaktusv-alert-prod-font-size": {
                data: "top",
                value: "alert_prod_font_size",
                input: "kaktusv-alert-prod-font-size",
                element: "kaktusv-alert-prod",
                cssOption: "font-size",
                cssType: "size"
            },
            "kaktusv-alert-prod-font-weight": {
                data: "top",
                value: "alert_prod_font_weight",
                input: "kaktusv-alert-prod-font-weight",
                element: "kaktusv-alert-prod",
                cssOption: "font-weight"
            },
            "kaktusv-alert-prod-font-style": {
                data: "top",
                value: "alert_prod_font_style",
                input: "kaktusv-alert-prod-font-style",
                element: "kaktusv-alert-prod",
                cssOption: "font-style"
            },
            "kaktusv-alert-prod-line-height": {
                data: "top",
                value: "alert_prod_line_height",
                input: "kaktusv-alert-prod-line-height",
                element: "kaktusv-alert-prod",
                cssOption: "line-height",
                cssType: "size"
            }
        };
        const dataJsonMainSection = {
            "kaktusv-bg-main": {
                data: "main",
                value: "background_main",
                input: "kaktusv-bg-main-input",
                element: "kaktusv-bg-main",
                cssOption: "background"
            },
            "kaktusv-bg-heading": {
                data: "main",
                value: "background_heading",
                element: "kaktusv-bg-heading",
                cssOption: "background"
            },
            "kaktusv-timer": {
                data: "main",
                value: "timer_bg",
                input: "kaktusv-timer-bg",
                element: "kaktusv-timer",
                cssOption: "background"
            },
            "kaktusv-timer-border-radius-left": {
                data: "main",
                value: "timer_border_radius",
                input: "kaktusv-timer-border-radius",
                element: "kaktusv-timer",
                cssOption: "border-bottom-left-radius",
                cssType: "size"
            },
            "kaktusv-timer-border-radius-right": {
                data: "main",
                value: "timer_border_radius",
                input: "kaktusv-timer-border-radius",
                element: "kaktusv-timer",
                cssOption: "border-bottom-right-radius",
                cssType: "size"
            },
            "kaktusv-timer-font-size": {
                data: "main",
                value: "timer_font_size",
                input: "kaktusv-timer-fs",
                element: "kaktusv-timer",
                cssOption: "font-size",
                cssType: "size"
            },
            "kaktusv-timer-color": {
                data: "main",
                value: "timer_color",
                input: "kaktusv-timer-color",
                element: "kaktusv-timer",
                cssOption: "color"
            },
            "kaktusv-timer-font-weight": {
                data: "main",
                value: "timer_font_weight",
                input: "kaktusv-timer-font-weight",
                element: "kaktusv-timer",
                cssOption: "font-weight"
            },
            "kaktusv-timer-font-style": {
                data: "main",
                value: "timer_font_style",
                input: "kaktusv-timer-font-style",
                element: "kaktusv-timer",
                cssOption: "font-style"
            },
            "kaktusv-timer-line-height": {
                data: "main",
                value: "timer_line_height",
                input: "kaktusv-timer-line-height",
                element: "kaktusv-timer",
                cssOption: "line-height",
                cssType: "size"
            },
            "kaktusv-title-font-size": {
                data: "main",
                value: "title_font_size",
                input: "kaktusv-title-fs",
                element: "kaktusv-title",
                cssOption: "font-size",
                cssType: "size"
            },
            "kaktusv-title-color": {
                data: "main",
                value: "title_color",
                input: "kaktusv-title-color",
                element: "kaktusv-title",
                cssOption: "color"
            },
            "kaktusv-title-font-weight": {
                data: "main",
                value: "title_font_weight",
                input: "kaktusv-title-font-weight",
                element: "kaktusv-title",
                cssOption: "font-weight"
            },
            "kaktusv-title-font-style": {
                data: "main",
                value: "title_font_style",
                input: "kaktusv-title-font-style",
                element: "kaktusv-title",
                cssOption: "font-style"
            },
            "kaktusv-title-line-height": {
                data: "main",
                value: "title_line_height",
                input: "kaktusv-title-line-height",
                element: "kaktusv-title",
                cssOption: "line-height",
                cssType: "size"
            },
            "kaktusv-description-font-size": {
                data: "main",
                value: "description_font_size",
                input: "kaktusv-description-fs",
                element: "kaktusv-description",
                cssOption: "font-size",
                cssType: "size"
            },
            "kaktusv-description-color": {
                data: "main",
                value: "description_color",
                input: "kaktusv-description-color",
                element: "kaktusv-description",
                cssOption: "color"
            },
            "kaktusv-description-font-weight": {
                data: "main",
                value: "description_font_weight",
                input: "kaktusv-description-font-weight",
                element: "kaktusv-description",
                cssOption: "font-weight"
            },
            "kaktusv-description-font-style": {
                data: "main",
                value: "description_font_style",
                input: "kaktusv-description-font-style",
                element: "kaktusv-description",
                cssOption: "font-style"
            },
            "kaktusv-description-line-height": {
                data: "main",
                value: "description_line_height",
                input: "kaktusv-description-line-height",
                element: "kaktusv-description",
                cssOption: "line-height",
                cssType: "size"
            },
            "kaktusv-border-width": {
                data: "main",
                value: "border_width",
                input: "kaktusv-border-size",
                element: "kaktusv-bd",
                cssOption: "border-width",
                cssType: "size"
            },
            "kaktusv-border-color": {
                data: "main",
                value: "border_color",
                input: "kaktusv-border-color",
                element: "kaktusv-bd",
                cssOption: "border-color"
            },
            "kaktusv-border-radius": {
                data: "main",
                value: "border_radius",
                input: "kaktusv-border-radius",
                element: "kaktusv-bd",
                cssOption: "border-radius",
                cssType: "size"
            },
            "kaktusv-border-radius-top": {
                data: "main",
                value: "border_radius",
                input: "w-border-radius",
                element: "kaktusv-bg-top",
                cssOption: "border-top-right-radius",
                cssType: "size"
            },
            "kaktusv-total-color": {
                data: "main",
                value: "total_color",
                input: "kaktusv-total-color",
                element: "kaktusv-total",
                cssOption: "color"
            },
            "kaktusv-total-font-size": {
                data: "main",
                value: "total_font_size",
                input: "kaktusv-total-font-size",
                element: "kaktusv-total",
                cssOption: "font-size",
                cssType: "size"
            },
            "kaktusv-total-font-weight": {
                data: "main",
                value: "total_font_weight",
                input: "kaktusv-total-font-weight",
                element: "kaktusv-total",
                cssOption: "font-weight"
            },
            "kaktusv-total-font-style": {
                data: "main",
                value: "total_font_style",
                input: "kaktusv-total-font-style",
                element: "kaktusv-total",
                cssOption: "font-style"
            },
            "kaktusv-total-line-height": {
                data: "main",
                value: "total_line_height",
                input: "kaktusv-total-line-height",
                element: "kaktusv-total",
                cssOption: "line-height",
                cssType: "size"
            },
            "kaktusv-total-price-color": {
                data: "main",
                value: "total_price_color",
                input: "kaktusv-total-price-color",
                element: "kaktusv-total-price",
                cssOption: "color"
            },
            "kaktusv-total-price-font-size": {
                data: "main",
                value: "total_price_font_size",
                input: "kaktusv-total-price-font-size",
                element: "kaktusv-total-price",
                cssOption: "font-size",
                cssType: "size"
            },
            "kaktusv-total-price-font-weight": {
                data: "main",
                value: "total_price_font_weight",
                input: "kaktusv-total-price-font-weight",
                element: "kaktusv-total-price",
                cssOption: "font-weight"
            },
            "kaktusv-total-price-font-style": {
                data: "main",
                value: "total_price_font_style",
                input: "kaktusv-total-price-font-style",
                element: "kaktusv-total-price",
                cssOption: "font-style"
            },
            "kaktusv-total-price-line-height": {
                data: "main",
                value: "total_price_line_height",
                input: "kaktusv-total-price-line-height",
                element: "kaktusv-total-price",
                cssOption: "line-height",
                cssType: "size"
            },
            "kaktusv-product-name-color": {
                data: "main",
                value: "product_name_color",
                element: "kaktusv-product-name",
                cssOption: "color"
            },
            "kaktusv-product-name-font-size": {
                data: "main",
                value: "product_name_font_size",
                element: "kaktusv-product-name",
                cssOption: "font-size",
                cssType: "size"
            },
            "kaktusv-product-name-font-weight": {
                data: "main",
                value: "product_name_font_weight",
                element: "kaktusv-product-name",
                cssOption: "font-weight"
            },
            "kaktusv-product-name-font-style": {
                data: "main",
                value: "product_name_font_style",
                element: "kaktusv-product-name",
                cssOption: "font-style"
            },
            "kaktusv-product-name-line-height": {
                data: "main",
                value: "product_name_line_height",
                element: "kaktusv-product-name",
                cssOption: "line-height",
                cssType: "size"
            },
            "kaktusv-product-price-color": {
                data: "main",
                value: "product_price_color",
                element: "kaktusv-product-price",
                cssOption: "color"
            },
            "kaktusv-product-price-font-size": {
                data: "main",
                value: "product_price_font_size",
                element: "kaktusv-product-price",
                cssOption: "font-size",
                cssType: "size"
            },
            "kaktusv-product-price-font-weight": {
                data: "main",
                value: "product_price_font_weight",
                element: "kaktusv-product-price",
                cssOption: "font-weight"
            },
            "kaktusv-product-price-font-style": {
                data: "main",
                value: "product_price_font_style",
                element: "kaktusv-product-price",
                cssOption: "font-style"
            },
            "kaktusv-product-price-line-height": {
                data: "main",
                value: "product_price_line_height",
                element: "kaktusv-product-price",
                cssOption: "line-height",
                cssType: "size"
            }
        };
        const dataJsonBottomSection = {
            "kaktusv-background-bottom": {
                data: "bottom",
                value: "background_bottom",
                input: "kaktusv-bg-bottom-input",
                element: "kaktusv-bg-bottom",
                cssOption: "background"
            },
            "kaktusv-reject-btn-bd-radius": {
                data: "bottom",
                value: "reject_btn_border_radius",
                input: "kaktusv-reject-btn-bd-radius",
                element: "kaktusv-reject-btn",
                cssOption: "border-radius",
                cssType: "size"
            },
            "kaktusv-reject-btn-font-size": {
                data: "bottom",
                value: "reject_btn_font_size",
                input: "kaktusv-reject-btn-font-size",
                element: "kaktusv-reject-btn",
                cssOption: "font-size",
                cssType: "size"
            },
            "kaktusv-reject-btn-font-weight": {
                data: "bottom",
                value: "reject_btn_font_weight",
                input: "kaktusv-reject-btn-font-weight",
                element: "kaktusv-reject-btn",
                cssOption: "font-weight"
            },
            "kaktusv-reject-btn-font-style": {
                data: "bottom",
                value: "reject_btn_font_style",
                input: "kaktusv-reject-btn-font-style",
                element: "kaktusv-reject-btn",
                cssOption: "font-style"
            },
            "kaktusv-reject-btn-line-height": {
                data: "bottom",
                value: "reject_btn_line_height",
                input: "kaktusv-reject-btn-line-height",
                element: "kaktusv-reject-btn",
                cssOption: "line-height",
                cssType: "size"
            },
            "kaktusv-reject-btn-padding-top": {
                data: "bottom",
                value: "reject_btn_padding_t_b",
                input: "kaktusv-reject-btn-padding-t-b",
                element: "kaktusv-reject-btn",
                cssOption: "padding-top",
                cssType: "size"
            },
            "kaktusv-reject-btn-padding-bottom": {
                data: "bottom",
                value: "reject_btn_padding_t_b",
                input: "kaktusv-reject-btn-padding-t-b",
                element: "kaktusv-reject-btn",
                cssOption: "padding-bottom",
                cssType: "size"
            },
            "kaktusv-reject-btn-padding-left": {
                data: "bottom",
                value: "reject_btn_padding_l_r",
                input: "kaktusv-reject-btn-padding-l-r",
                element: "kaktusv-reject-btn",
                cssOption: "padding-left",
                cssType: "size"
            },
            "kaktusv-reject-btn-padding-right": {
                data: "bottom",
                value: "reject_btn_padding_l_r",
                input: "kaktusv-reject-btn-padding-l-r",
                element: "kaktusv-reject-btn",
                cssOption: "padding-right",
                cssType: "size"
            },
            "kaktusv-checkout-btn-bd-radius": {
                data: "bottom",
                value: "checkout_btn_border_radius",
                input: "kaktusv-checkout-btn-bd-radius",
                element: "kaktusv-checkout-btn",
                cssOption: "border-radius",
                cssType: "size"
            },
            "kaktusv-checkout-btn-font-size": {
                data: "bottom",
                value: "checkout_btn_font_size",
                input: "kaktusv-checkout-btn-font-size",
                element: "kaktusv-checkout-btn",
                cssOption: "font-size",
                cssType: "size"
            },
            "kaktusv-checkout-btn-font-weight": {
                data: "bottom",
                value: "checkout_btn_font_weight",
                input: "kaktusv-checkout-btn-font-weight",
                element: "kaktusv-checkout-btn",
                cssOption: "font-weight"
            },
            "kaktusv-checkout-btn-font-style": {
                data: "bottom",
                value: "checkout_btn_font_style",
                input: "kaktusv-checkout-btn-font-style",
                element: "kaktusv-checkout-btn",
                cssOption: "font-style"
            },
            "kaktusv-checkout-btn-line-height": {
                data: "bottom",
                value: "checkout_btn_line_height",
                input: "kaktusv-checkout-btn-line-height",
                element: "kaktusv-checkout-btn",
                cssOption: "line-height",
                cssType: "size"
            },
            "kaktusv-checkout-btn-padding-top": {
                data: "bottom",
                value: "checkout_btn_padding_t_b",
                input: "kaktusv-checkout-btn-padding-t-b",
                element: "kaktusv-checkout-btn",
                cssOption: "padding-top",
                cssType: "size"
            },
            "kaktusv-checkout-btn-padding-bottom": {
                data: "bottom",
                value: "checkout_btn_padding_t_b",
                input: "kaktusv-checkout-btn-padding-t-b",
                element: "kaktusv-checkout-btn",
                cssOption: "padding-bottom",
                cssType: "size"
            },
            "kaktusv-checkout-btn-padding-left": {
                data: "bottom",
                value: "checkout_btn_padding_l_r",
                input: "kaktusv-checkout-btn-padding-l-r",
                element: "kaktusv-checkout-btn",
                cssOption: "padding-left",
                cssType: "size"
            },
            "kaktusv-checkout-btn-padding-right": {
                data: "bottom",
                value: "checkout_btn_padding_l_r",
                input: "kaktusv-checkout-btn-padding-l-r",
                element: "kaktusv-checkout-btn",
                cssOption: "padding-right",
                cssType: "size"
            }
        };
        const dataJsonBtnStyle = {
            "kaktusv-reject-btn-bg": {
                data: "bottom",
                value: "reject_btn_bg",
                secondValue: "reject_btn_bg_hover",
                input: "kaktusv-reject-btn-bg",
                inputHover: "kaktusv-reject-btn-bg-h",
                element: "kaktusv-reject-btn",
                cssOption: "background"
            },
            "kaktusv-reject-btn-color": {
                data: "bottom",
                value: "reject_btn_font_color",
                secondValue: "reject_btn_font_color_hover",
                input: "kaktusv-reject-btn-color",
                inputHover: "kaktusv-reject-btn-color-h",
                element: "kaktusv-reject-btn",
                cssOption: "color"
            },
            "kaktusv-reject-btn-color-icon": {
                data: "bottom",
                value: "reject_btn_font_color",
                secondValue: "reject_btn_font_color_hover",
                input: "kaktusv-reject-btn-color",
                inputHover: "kaktusv-reject-btn-color-h",
                element: "kaktusv-reject-btn",
                cssOption: "fill"
            },
            "kaktusv-checkout-btn-bg": {
                data: "bottom",
                value: "checkout_btn_bg",
                secondValue: "checkout_btn_bg_hover",
                input: "kaktusv-checkout-btn-bg",
                inputHover: "kaktusv-checkout-btn-bg-h",
                element: "kaktusv-checkout-btn",
                cssOption: "background"
            },
            "kaktusv-checkout-btn-color": {
                data: "bottom",
                value: "checkout_btn_font_color",
                secondValue: "checkout_btn_font_color_hover",
                input: "kaktusv-checkout-btn-color",
                inputHover: "kaktusv-checkout-btn-color-h",
                element: "kaktusv-checkout-btn",
                cssOption: "color"
            },
            "kaktusv-close-bg-color": {
                data: "top",
                value: "close_bg_color",
                secondValue: "close_bg_color_hover",
                input: "kaktusv-close-bg-color",
                inputHover: "kaktusv-close-bg-color-h",
                element: "kaktusv-close",
                cssOption: "background"
            },
            "kaktusv-close-color": {
                data: "top",
                value: "close_color",
                secondValue: "close_color_hover",
                input: "kaktusv-close-color",
                inputHover: "kaktusv-close-color-h",
                element: "kaktusv-close",
                cssOption: "color"
            },
            "kaktusv-cart-btn-bg": {
                data: "product",
                value: "cart_btn_bg",
                secondValue: "cart_btn_bg_hover",
                input: "kaktusv-cart-btn-bg",
                inputHover: "kaktusv-cart-btn-bg-h",
                element: "kaktusv-cart-btn",
                cssOption: "background"
            },
            "kaktusv-cart-btn-color": {
                data: "product",
                value: "cart_btn_font_color",
                secondValue: "cart_btn_font_color_hover",
                input: "kaktusv-cart-btn-color",
                inputHover: "kaktusv-cart-btn-color-h",
                element: "kaktusv-cart-btn",
                cssOption: "color"
            },
            "kaktusv-cart-btn-color-icon": {
                data: "product",
                value: "cart_btn_font_color",
                secondValue: "cart_btn_font_color_hover",
                input: "kaktusv-cart-btn-color",
                inputHover: "kaktusv-cart-btn-color-h",
                element: "kaktusv-cart-btn",
                cssOption: "fill"
            },
            "kaktusv-qty-btn-bg": {
                data: "product",
                value: "qty_btn_bg",
                secondValue: "qty_btn_bg_hover",
                input: "kaktusv-qty-btn-bg",
                inputHover: "kaktusv-qty-btn-bg-h",
                element: "kaktusv-qty-btn",
                cssOption: "background"
            },
            "kaktusv-qty-btn-color": {
                data: "product",
                value: "qty_btn_color",
                secondValue: "qty_btn_color_hover",
                input: "kaktusv-qty-btn-color",
                inputHover: "kaktusv-qty-btn-color-h",
                element: "kaktusv-qty-btn",
                cssOption: "color"
            },
            "kaktusv-remove-btn-bg": {
                data: "product",
                value: "remove_btn_bg",
                secondValue: "remove_btn_bg_hover",
                element: "kaktusv-remove-btn",
                cssOption: "background"
            },
            "kaktusv-remove-btn-color": {
                data: "product",
                value: "remove_btn_font_color",
                secondValue: "remove_btn_font_color_hover",
                element: "kaktusv-remove-btn",
                cssOption: "color"
            },
            "kaktusv-remove-btn-color-icon": {
                data: "product",
                value: "remove_btn_font_color",
                secondValue: "remove_btn_font_color_hover",
                element: "kaktusv-remove-btn",
                cssOption: "fill"
            }
        };
        const dataJsonProductStyle = {
            "kaktusv-prod-bg-img": {
                data: "product",
                value: "background_img",
                input: "kaktusv-prod-bg-img",
                element: "kaktusv-product-item",
                cssOption: "background"
            },
            "kaktusv-prod-bg": {
                data: "product",
                value: "background",
                input: "kaktusv-prod-bg",
                element: "kaktusv-product-bg",
                cssOption: "background"
            },
            "kaktusv-cart-btn-bd-radius": {
                data: "product",
                value: "cart_btn_border_radius",
                input: "kaktusv-cart-btn-radius",
                element: "kaktusv-cart-btn",
                cssOption: "border-radius",
                cssType: "size"
            },
            "kaktusv-cart-btn-font-size": {
                data: "product",
                value: "cart_btn_font_size",
                input: "kaktusv-cart-btn-font-size",
                element: "kaktusv-cart-btn",
                cssOption: "font-size",
                cssType: "size"
            },
            "kaktusv-cart-btn-font-weight": {
                data: "product",
                value: "cart_btn_font_weight",
                input: "kaktusv-cart-btn-font-weight",
                element: "kaktusv-cart-btn",
                cssOption: "font-weight"
            },
            "kaktusv-cart-btn-font-style": {
                data: "product",
                value: "cart_btn_font_style",
                input: "kaktusv-cart-btn-font-style",
                element: "kaktusv-cart-btn",
                cssOption: "font-style"
            },
            "kaktusv-cart-btn-line-height": {
                data: "product",
                value: "cart_btn_line_height",
                input: "kaktusv-cart-btn-line-height",
                element: "kaktusv-cart-btn",
                cssOption: "line-height",
                cssType: "size"
            },
            "kaktusv-cart-btn-padding-top": {
                data: "product",
                value: "cart_btn_padding_t_b",
                input: "kaktusv-cart-btn-padding-t-b",
                element: "kaktusv-cart-btn",
                cssOption: "padding-top",
                cssType: "size"
            },
            "kaktusv-cart-btn-padding-bottom": {
                data: "product",
                value: "cart_btn_padding_t_b",
                input: "kaktusv-cart-btn-padding-t-b",
                element: "kaktusv-cart-btn",
                cssOption: "padding-bottom",
                cssType: "size"
            },
            "kaktusv-cart-btn-padding-left": {
                data: "product",
                value: "cart_btn_padding_l_r",
                input: "kaktusv-cart-btn-padding-l-r",
                element: "kaktusv-cart-btn",
                cssOption: "padding-left",
                cssType: "size"
            },
            "kaktusv-cart-btn-padding-right": {
                data: "product",
                value: "cart_btn_padding_l_r",
                input: "kaktusv-cart-btn-padding-l-r",
                element: "kaktusv-cart-btn",
                cssOption: "padding-right",
                cssType: "size"
            },
            "kaktusv-remove-btn-bd-radius": {
                data: "product",
                value: "remove_btn_border_radius",
                element: "kaktusv-remove-btn",
                cssOption: "border-radius",
                cssType: "size"
            },
            "kaktusv-remove-btn-font-size": {
                data: "product",
                value: "remove_btn_font_size",
                element: "kaktusv-remove-btn",
                cssOption: "font-size",
                cssType: "size"
            },
            "kaktusv-remove-btn-font-weight": {
                data: "product",
                value: "remove_btn_font_weight",
                element: "kaktusv-remove-btn",
                cssOption: "font-weight"
            },
            "kaktusv-remove-btn-font-style": {
                data: "product",
                value: "remove_btn_font_style",
                element: "kaktusv-remove-btn",
                cssOption: "font-style"
            },
            "kaktusv-remove-btn-line-height": {
                data: "product",
                value: "remove_btn_line_height",
                element: "kaktusv-remove-btn",
                cssOption: "line-height",
                cssType: "size"
            },
            "kaktusv-remove-btn-padding-top": {
                data: "product",
                value: "remove_btn_padding_t_b",
                element: "kaktusv-remove-btn",
                cssOption: "padding-top",
                cssType: "size"
            },
            "kaktusv-remove-btn-padding-bottom": {
                data: "product",
                value: "remove_btn_padding_t_b",
                element: "kaktusv-remove-btn",
                cssOption: "padding-bottom",
                cssType: "size"
            },
            "kaktusv-remove-btn-padding-left": {
                data: "product",
                value: "remove_btn_padding_l_r",
                element: "kaktusv-remove-btn",
                cssOption: "padding-left",
                cssType: "size"
            },
            "kaktusv-remove-btn-padding-right": {
                data: "product",
                value: "remove_btn_padding_l_r",
                element: "kaktusv-remove-btn",
                cssOption: "padding-right",
                cssType: "size"
            },
            "kaktusv-cart-border-width": {
                data: "product",
                value: "prod_border_width",
                input: "kaktusv-cart-border-size",
                element: "kaktusv-product-border",
                cssOption: "border-width",
                cssType: "size"
            },
            "kaktusv-cart-border-color": {
                data: "product",
                value: "prod_border_color",
                input: "kaktusv-cart-border-color",
                element: "kaktusv-product-border",
                cssOption: "border-color"
            },
            "kaktusv-cart-border-radius": {
                data: "product",
                value: "prod_border_radius",
                input: "kaktusv-cart-border-radius",
                element: "kaktusv-product-border",
                cssOption: "border-radius",
                cssType: "size"
            },
            "kaktusv-prod-title-color": {
                data: "product",
                value: "prod_title_color",
                input: "kaktusv-prod-title-color",
                element: "kaktusv-prod-title",
                cssOption: "color"
            },
            "kaktusv-prod-title-font-size": {
                data: "product",
                value: "prod_title_font_size",
                input: "kaktusv-prod-title-font-size",
                element: "kaktusv-prod-title",
                cssOption: "font-size",
                cssType: "size"
            },
            "kaktusv-prod-title-font-weight": {
                data: "product",
                value: "prod_title_font_weight",
                input: "kaktusv-prod-title-font-weight",
                element: "kaktusv-prod-title",
                cssOption: "font-weight"
            },
            "kaktusv-prod-title-font-style": {
                data: "product",
                value: "prod_title_font_style",
                input: "kaktusv-prod-title-font-style",
                element: "kaktusv-prod-title",
                cssOption: "font-style"
            },
            "kaktusv-prod-title-line-height": {
                data: "product",
                value: "prod_title_line_height",
                input: "kaktusv-prod-title-line-height",
                element: "kaktusv-prod-title",
                cssOption: "line-height",
                cssType: "size"
            },
            "kaktusv-prod-desc-color": {
                data: "product",
                value: "prod_desc_color",
                input: "kaktusv-prod-desc-color",
                element: "kaktusv-prod-desc",
                cssOption: "color"
            },
            "kaktusv-prod-desc-font-size": {
                data: "product",
                value: "prod_desc_font_size",
                input: "kaktusv-prod-desc-font-size",
                element: "kaktusv-prod-desc",
                cssOption: "font-size",
                cssType: "size"
            },
            "kaktusv-prod-desc-font-weight": {
                data: "product",
                value: "prod_desc_font_weight",
                input: "kaktusv-prod-desc-font-weight",
                element: "kaktusv-prod-desc",
                cssOption: "font-weight"
            },
            "kaktusv-prod-desc-font-style": {
                data: "product",
                value: "prod_desc_font_style",
                input: "kaktusv-prod-desc-font-style",
                element: "kaktusv-prod-desc",
                cssOption: "font-style"
            },
            "kaktusv-prod-desc-line-height": {
                data: "product",
                value: "prod_desc_line_height",
                input: "kaktusv-prod-desc-line-height",
                element: "kaktusv-prod-desc",
                cssOption: "line-height",
                cssType: "size"
            },
            "kaktusv-qty-background": {
                data: "product",
                value: "qty_background",
                input: "kaktusv-qty-bg",
                element: "kaktusv-qty-input",
                cssOption: "background"
            },
            "kaktusv-qty-border": {
                data: "product",
                value: "qty_btn_bg",
                input: "kaktusv-qty-btn-bg",
                element: "kaktusv-qty-input",
                cssOption: "border-color"
            },
            "kaktusv-qty-color": {
                data: "product",
                value: "qty_font_color",
                input: "kaktusv-qty-color",
                element: "kaktusv-qty-input",
                cssOption: "color"
            },
            "kaktusv-qty-border-radius-top": {
                data: "product",
                value: "qty_border_radius",
                input: "kaktusv-qty-border-radius",
                element: "kaktusv-qty-input",
                cssOption: "border-top-left-radius",
                cssType: "size"
            },
            "kaktusv-qty-border-radius-bottom": {
                data: "product",
                value: "qty_border_radius",
                input: "kaktusv-qty-border-radius",
                element: "kaktusv-qty-input",
                cssOption: "border-bottom-left-radius",
                cssType: "size"
            },
            "kaktusv-qty-border-radius-btn-top": {
                data: "product",
                value: "qty_border_radius",
                input: "kaktusv-qty-border-radius",
                element: "kaktusv-qty-btn-t",
                cssOption: "border-top-right-radius",
                cssType: "size"
            },
            "kaktusv-qty-border-radius-btn-bottom": {
                data: "product",
                value: "qty_border_radius",
                input: "kaktusv-qty-border-radius",
                element: "kaktusv-qty-btn-b",
                cssOption: "border-bottom-right-radius",
                cssType: "size"
            },
            "kaktusv-price-color": {
                data: "product",
                value: "price_color",
                input: "kaktusv-price-color",
                element: "kaktusv-price",
                cssOption: "color"
            },
            "kaktusv-price-font-size": {
                data: "product",
                value: "price_font_size",
                input: "kaktusv-price-font-size",
                element: "kaktusv-price",
                cssOption: "font-size",
                cssType: "size"
            },
            "kaktusv-price-font-weight": {
                data: "product",
                value: "price_font_weight",
                input: "kaktusv-price-font-weight",
                element: "kaktusv-price",
                cssOption: "font-weight"
            },
            "kaktusv-price-font-style": {
                data: "product",
                value: "price_font_style",
                input: "kaktusv-price-font-style",
                element: "kaktusv-price",
                cssOption: "font-style"
            },
            "kaktusv-price-line-height": {
                data: "product",
                value: "price_line_height",
                input: "kaktusv-price-line-height",
                element: "kaktusv-price",
                cssOption: "line-height",
                cssType: "size"
            },
            "kaktusv-compare-price-color": {
                data: "product",
                value: "compare_price_color",
                input: "kaktusv-compare-price-color",
                element: "kaktusv-compare-price",
                cssOption: "color"
            },
            "kaktusv-compare-price-font-size": {
                data: "product",
                value: "compare_price_font_size",
                input: "kaktusv-compare-price-font-size",
                element: "kaktusv-compare-price",
                cssOption: "font-size",
                cssType: "size"
            },
            "kaktusv-compare-price-font-weight": {
                data: "product",
                value: "compare_price_font_weight",
                input: "kaktusv-compare-price-font-weight",
                element: "kaktusv-compare-price",
                cssOption: "font-weight"
            },
            "kaktusv-compare-price-font-style": {
                data: "product",
                value: "compare_price_font_style",
                input: "kaktusv-compare-price-font-style",
                element: "kaktusv-compare-price",
                cssOption: "font-style"
            },
            "kaktusv-compare-price-line-height": {
                data: "product",
                value: "compare_price_line_height",
                input: "kaktusv-compare-price-line-height",
                element: "kaktusv-compare-price",
                cssOption: "line-height",
                cssType: "size"
            },
            "kaktusv-save-background-color": {
                data: "product",
                value: "save_bg",
                input: "kaktusv-save-bg",
                element: "kaktusv-save-label",
                cssOption: "background"
            },
            "kaktusv-save-border-radius": {
                data: "product",
                value: "save_border_radius",
                input: "kaktusv-save-border-radius",
                element: "kaktusv-save-label",
                cssOption: "border-radius",
                cssType: "size"
            },
            "kaktusv-save-color": {
                data: "product",
                value: "save_color",
                input: "kaktusv-save-color",
                element: "kaktusv-save-label",
                cssOption: "color"
            },
            "kaktusv-save-font-size": {
                data: "product",
                value: "save_font_size",
                input: "kaktusv-save-font-size",
                element: "kaktusv-save-label",
                cssOption: "font-size",
                cssType: "size"
            },
            "kaktusv-save-font-weight": {
                data: "product",
                value: "save_font_weight",
                input: "kaktusv-save-font-weight",
                element: "kaktusv-save-label",
                cssOption: "font-weight"
            },
            "kaktusv-save-font-style": {
                data: "product",
                value: "save_font_style",
                input: "kaktusv-save-font-style",
                element: "kaktusv-save-label",
                cssOption: "font-style"
            },
            "kaktusv-save-line-height": {
                data: "product",
                value: "save_line_height",
                input: "kaktusv-save-line-height",
                element: "kaktusv-save-label",
                cssOption: "line-height",
                cssType: "size"
            },
            "kaktusv-save-padding": {
                data: "product",
                value: "save_padding",
                input: "kaktusv-save-padding",
                element: "kaktusv-save-label",
                cssOption: "padding",
                cssType: "size"
            },
            "kaktusv-variations-bg": {
                data: "product",
                value: "variations_background",
                input: "kaktusv-variations-bg",
                element: "kaktusv-variations",
                cssOption: "background-color"
            },
            "kaktusv-variations-color": {
                data: "product",
                value: "variations_font_color",
                input: "kaktusv-variations-color",
                element: "kaktusv-variations",
                cssOption: "color"
            },
            "kaktusv-variations-border-widrh": {
                data: "product",
                value: "variations_border_width",
                input: "kaktusv-variations-border-size",
                element: "kaktusv-variations",
                cssOption: "border-width",
                cssType: "size"
            },
            "kaktusv-variations-border-color": {
                data: "product",
                value: "variations_border_color",
                input: "kaktusv-variations-border-color",
                element: "kaktusv-variations",
                cssOption: "border-color",
            },
            "kaktusv-variations-border-radius": {
                data: "product",
                value: "variations_border_radius",
                input: "kaktusv-variations-border-radius",
                element: "kaktusv-variations",
                cssOption: "border-radius",
                cssType: "size"
            },
            "kaktusv-discount-text-color": {
                data: "product",
                value: "discount_text_color",
                element: "kaktusv-discount-text",
                cssOption: "color"
            },
            "kaktusv-discount-text-font-size": {
                data: "product",
                value: "discount_text_font_size",
                element: "kaktusv-discount-text",
                cssOption: "font-size",
                cssType: "size"
            },
            "kaktusv-discount-text-font-weight": {
                data: "product",
                value: "discount_text_font_weight",
                element: "kaktusv-discount-text",
                cssOption: "font-weight"
            },
            "kaktusv-discount-text-font-style": {
                data: "product",
                value: "discount_text_font_style",
                element: "kaktusv-discount-text",
                cssOption: "font-style"
            },
            "kaktusv-discount-text-line-height": {
                data: "product",
                value: "discount_text_line_height",
                element: "kaktusv-discount-text",
                cssOption: "line-height",
                cssType: "size"
            },
            "kaktusv-radio-bg": {
                data: "product",
                value: "radio_btn_bg",
                element: "kaktusv-radio-bg",
                cssOption: "background-color"
            },
            "kaktusv-radio-border": {
                data: "product",
                value: "radio_btn_bg",
                element: "kaktusv-radio-border",
                cssOption: "border-color"
            },
            "kaktusv-border-active": {
                data: "product",
                value: "active_background",
                element: "kaktusv-bg-active",
                cssOption: "border-color"
            }
        };
        const dataShowHide = {
            "kaktusv-close": {
                data: "top",
                value: "close_show",
                input: "kaktusv-close-show",
                element: "kaktusv-close"
            },
            "kaktusv-alert-text": {
                data: "top",
                value: "alert_text_show",
                input: "kaktusv-alert-text-show",
                element: "kaktusv-alert-text"
            },
            "kaktusv-alert-prod": {
                data: "top",
                value: "alert_prod_show",
                input: "kaktusv-alert-prod-show",
                element: "kaktusv-alert-prod"
            },
            "kaktusv-alert-prod-img": {
                data: "top",
                value: "alert_prod_show",
                input: "kaktusv-alert-prod-show",
                element: "kaktusv-popup__cart-alert--img"
            },
            "kaktusv-timer": {
                data: "main",
                value: "timer_show",
                input: "kaktusv-timer-show",
                element: "kaktusv-timer"
            },
            "kaktusv-title": {
                data: "main",
                value: "title_show",
                input: "kaktusv-title-show",
                element: "kaktusv-title"
            },
            "kaktusv-description": {
                data: "main",
                value: "description_show",
                input: "kaktusv-description-show",
                element: "kaktusv-description"
            },
            "kaktusv-total": {
                data: "main",
                value: "total_show",
                input: "kaktusv-total-show",
                element: "kaktusv-total"
            },
            "kaktusv-total-price": {
                data: "main",
                value: "total_price_show",
                input: "kaktusv-total-price-show",
                element: "kaktusv-total-price"
            },
            "kaktusv-reject-btn": {
                data: "bottom",
                value: "reject_btn_show",
                input: "kaktusv-reject-btn-show",
                element: "kaktusv-reject-btn"
            },
            "kaktusv-checkout-btn": {
                data: "bottom",
                value: "checkout_btn_show",
                input: "kaktusv-checkout-btn-show",
                element: "kaktusv-checkout-btn"
            },
            "kaktusv-prod-title": {
                data: "product",
                value: "prod_title_show",
                input: "kaktusv-prod-title-show",
                element: "kaktusv-prod-title"
            },
            "kaktusv-prod-desc": {
                data: "product",
                value: "prod_desc_show",
                input: "kaktusv-prod-desc-show",
                element: "kaktusv-prod-desc"
            },
            "kaktusv-price": {
                data: "product",
                value: "price_show",
                input: "kaktusv-price-show",
                element: "kaktusv-price"
            },
            "kaktusv-compare-price": {
                data: "product",
                value: "compare_price_show",
                input: "kaktusv-compare-price-show",
                element: "kaktusv-compare-price"
            },
            "kaktusv-save": {
                data: "product",
                value: "save_show",
                input: "kaktusv-save-show",
                element: "kaktusv-save-label"
            },
            "kaktusv-qty": {
                data: "product",
                value: "qty_show",
                input: "kaktusv-qty-show",
                element: "kaktusv-qty"
            },
            "kaktusv-variations": {
                data: "product",
                value: "variations_show",
                input: "kaktusv-variations-show",
                element: "kaktusv-variations-wrap"
            },
            "kaktusv-top-show": {
                data: "top",
                value: "top_show",
                input: "kaktusv-top-show",
                element: "kaktusv-bg-top"
            },
            "kaktusv-discount-text-show": {
                data: "product",
                value: "discount_text_show",
                element: "kaktusv-discount-text"
            }
        };

        function fillWidget(widgetJson, rootId, countDownTimer) {
            const cartBtnText = getAppSelectorAll('.kaktusv-cart-btn-text', rootId);
            const cartBtnTextAdded = getAppSelectorAll('.kaktusv-cart-btn-added-text', rootId);
            const cartBtn = getAppSelectorAll('.kaktusv-cart-btn', rootId);
            const beforeAlert = getAppSelector('.kaktusv-before-alert', rootId);
            const type = widgetJson.widget_type;
            switch (type) {
                case offerTypes.crossSell:
                case offerTypes.postPurchase:
                case offerTypes.discount:
                case offerTypes.exitIntent:
                case offerTypes.cartPage:
                case offerTypes.beforeCheckout:
                case offerTypes.homePage:
                    cartBtnText.forEach((element) => element.classList.remove(`kaktusv-cart-btn-text-upsell`));
                    cartBtnTextAdded.forEach((element) => element.classList.remove(`kaktusv-cart-btn-added-text-upsell`));
                    cartBtn.forEach((element) => element.setAttribute('data-cart', 'add'));
                    if (beforeAlert) {
                        beforeAlert.classList.remove(`kaktusv-alert-upsell`);
                    }
                    break;
                case offerTypes.upsell:
                    cartBtnText.forEach((element) => element.classList.add(`kaktusv-cart-btn-text-upsell`));
                    cartBtnTextAdded.forEach((element) => element.classList.add(`kaktusv-cart-btn-added-text-upsell`));
                    cartBtn.forEach((element) => element.setAttribute('data-cart', 'replace'));
                    if (beforeAlert) {
                        beforeAlert.classList.add(`kaktusv-alert-upsell`);
                    }
                    break;
            }
            getObjJsonKeys(rootId, widgetJson, dataJsonMainSection);
            getObjJsonKeys(rootId, widgetJson, dataJsonBottomSection);
            getObjJsonKeys(rootId, widgetJson, dataJsonProductStyle);
            getObjJsonKeys(rootId, widgetJson, dataJsonBtnStyle, "btn");
            getObjJsonKeys(rootId, widgetJson, dataShowHide, "show");
            if (type != offerTypes.volumeDiscount) {
                getObjJsonKeys(rootId, widgetJson, dataJsonTopSection);
                setProductDescription(rootId, widgetJson);
            } else if (type === offerTypes.volumeDiscount) {
                setActiveColor(widgetJson, rootId);
            }
            const timerShow = widgetJson.main.timer_show;
            if (timerShow) {
                countDownTimer.startTimer();
            }
            const wallpaper = widgetJson.main.wallpaper;
            const wallpaperDiv = getAppSelector('.kaktusv-wallpaper', rootId);
            let wallpaperVal;
            if (wallpaper === 'wallpaper_0') {
                wallpaperVal = 'transparent';
            } else {
                const coverWallpaper = ['wallpaper_20', 'wallpaper_21', 'wallpaper_22', 'wallpaper_23', 'wallpaper_24', 'wallpaper_25', 'wallpaper_26'];
                if (coverWallpaper.includes(wallpaper)) {
                    wallpaperDiv.classList.add('cover');
                } else {
                    wallpaperDiv.classList.remove('cover');
                }
                wallpaperVal = `url("${kaktusvbaseUrl}assets/images/widgets/wallpapers/${wallpaper}.png")`;
            }
            wallpaperDiv.style.background = wallpaperVal;
            const custom_css = widgetJson.custom_css;
            const customCssDiv = getAppSelector('#kaktusv-custom-css', rootId);
            if (custom_css) {
                customCssDiv.innerText = custom_css.replace(/.kaktusv-/g, `#${rootId} .kaktusv-`);
            } else {
                customCssDiv.innerText = '';
            }
            const prodDesc = getAppSelectorAll('.kaktusv-desc-short', rootId);
            prodDesc.forEach((element) => {
                let str = element.innerText.trim();
                if (str.length > 100) {
                    let trimmedStr = str.substring(0, 100) + "...";
                    element.innerText = trimmedStr;
                }
            });
        }

        function fillWidgetSettings(widgetJson, rootId) {
            const kaktusvPopup = getAppSelector('.kaktusv-popup', rootId);
            const kaktusvWrap = getAppSelector('.kaktusv-popup__wrap', rootId);
            const kaktusvBody = getAppSelector('.kaktusv-popup__body', rootId);
            const productWrapp = getAppSelector('.kaktusv-product__wrapp', rootId);
            const position = widgetJson.design_type.position,
                animation = widgetJson.design_type.animation,
                layout = widgetJson.design_type.layout,
                layout_col = widgetJson.design_type.layout_col ? widgetJson.design_type.layout_col : 'grid-item-2',
                widgetWidth = widgetJson.design_type.widget_width;
            if (widgetJson.widget_type != offerTypes.volumeDiscount) {
                if (kaktusvPopup) {
                    kaktusvPopup.classList.remove('kaktusv-popup__position--full', 'kaktusv-popup__position--right_bottom', 'kaktusv-popup__position--left_bottom', 'kaktusv-popup__position--bottom', 'kaktusv-popup__position--top', 'kaktusv-popup__position--center');
                    kaktusvPopup.classList.add(`kaktusv-popup__position--${position}`);
                    kaktusvPopup.classList.remove("kaktusv-hide");
                    kaktusvWrap.setAttribute('class', 'kaktusv-popup__wrap');
                    kaktusvWrap.classList.add(`animate__animated`, `${animation}`);
                }
            }
            if (widgetJson.widget_type != offerTypes.slider) {
                if (widgetJson.widget_type != offerTypes.volumeDiscount) {
                    productWrapp.classList.remove('kaktusv-product--grid', 'kaktusv-product--list', 'kaktusv-product--metro', 'kaktusv-grid-item-2', 'kaktusv-grid-item-3', 'kaktusv-grid-item-4');
                    const productItem = getAppSelectorAll('.kaktusv-product__item', rootId);
                    productItem.forEach((element) => element.classList.remove('kaktusv-product__item--grid', 'kaktusv-product__item--list', 'kaktusv-product__item--metro'));
                    if (layout) {
                        productWrapp.classList.add(`kaktusv-product--${layout}`, `kaktusv-${layout_col}`);
                        productItem.forEach((element) => element.classList.add(`kaktusv-product__item--${layout}`));
                    } else {
                        productWrapp.classList.add('kaktusv-product--grid', 'kaktusv-grid-item-2');
                        productItem.forEach((element) => element.classList.add(`kaktusv-product__item--grid`));
                    }
                }
                kaktusvBody.classList.remove('kaktusv-width-container', 'kaktusv-width-full');
                kaktusvBody.classList.add(`kaktusv-width-${widgetWidth}`);
            }
        }

        function getObjJsonKeys(rootId, widgetJson, obj, type) {
            for (let key in obj) {
                if (type === "show") {
                    setShowHide(rootId, widgetJson, obj[key].data, obj[key].value, obj[key].element);
                } else if (type === "btn") {
                    setJsonDataBtn(rootId, widgetJson, obj[key].data, obj[key].value, obj[key].secondValue, obj[key].element, obj[key].cssOption);
                } else {
                    setJsonData(rootId, widgetJson, obj[key].data, obj[key].value, obj[key].element, obj[key].cssOption, obj[key].cssType);
                }
            }
        }

        function setJsonData(rootId, widgetJson, obj, value, element, styleOpt, type) {
            if (!widgetJson[obj]) return;
            const option = widgetJson[obj][value];
            let inputOption = option;
            if (option == null) return;
            if (styleOpt === "border-top-right-radius" && element === ".kaktusv-bg-top" && inputOption != 0) {
                inputOption = +inputOption + 3;
            }
            if (type === "size") {
                inputOption = inputOption + 'px';
            }
            const elements = getAppSelectorAll('.' + element, rootId);
            elements.forEach((element) => {
                element.style[styleOpt] = inputOption;
            })
        }

        function setJsonDataBtn(rootId, widgetJson, obj, value, value_2, element, styleOpt) {
            if (!widgetJson[obj]) return;
            const option = widgetJson[obj][value];
            const option_2 = widgetJson[obj][value_2];
            let btn;
            if (option == null) return;
            let inputOption = option;
            btn = inputOption;
            let inputOption_2 = option_2;
            const elements = getAppSelectorAll('.' + element, rootId);
            elements.forEach((element) => {
                element.style[styleOpt] = inputOption;
                element.addEventListener("mouseover", function() {
                    this.style[styleOpt] = inputOption_2;
                }, false);
                element.addEventListener("mouseout", function() {
                    this.style[styleOpt] = btn;
                }, false);
            })
        }

        function setShowHide(rootId, widgetJson, obj, value, element) {
            if (!widgetJson[obj]) return;
            const option = widgetJson[obj][value];
            if (option == null) return;
            const elements = getAppSelectorAll('.' + element, rootId);
            elements.forEach((element) => {
                if (option) {
                    element.classList.remove('kaktusv-hide');
                } else {
                    element.classList.add('kaktusv-hide');
                }
            })
        }

        function setProductDescription(rootId, widgetJson) {
            const option = widgetJson['product']['prod_desc_show_full'];
            if (option == null) return;
            const shortDescription = getAppSelectorAll('.kaktusv-desc-short', rootId);
            const fullDescription = getAppSelectorAll('.kaktusv-desc-full', rootId);
            shortDescription.forEach((element) => {
                if (option) {
                    element.classList.add('kaktusv-hide');
                } else {
                    element.classList.remove('kaktusv-hide');
                }
            })
            fullDescription.forEach((element) => {
                if (option) {
                    element.classList.remove('kaktusv-hide');
                } else {
                    element.classList.add('kaktusv-hide');
                }
            })
        }
        class Timer {
            constructor(data) {
                this.element = data.display;
                this.minutes = parseInt(data.minutes);
                this.seconds = parseInt(data.seconds);
                this.rootId = data.rootId;
                this.mainOfferId = data.mainOfferId;
                this.offerId = data.offerId;
                this.offerObj = null
                this.pageReload = false;
                this.currentTriggerType = 0;
                if (data.offerObj) {
                    this.offerObj = data.offerObj;
                    this.pageReload = data.offerObj.pageReload || false;
                    this.currentTriggerType = data.offerObj.currentTriggerType || 0;
                }
                this.counter = null;
            }
            startTimer() {
                this.counter = setInterval(() => {
                    if (+this.seconds === 0) {
                        if (+this.minutes === 0) {
                            this.stopTimer()
                            removeAppContainer(this.rootId);
                            sendStatistic(this.mainOfferId, this.offerId);
                            statisticArr.length = 0;
                            if (this.currentTriggerType === triggerTypes.buyItNow || this.currentTriggerType === triggerTypes.beforeCheckout) {
                                setTimeout(() => {
                                    createOrder();
                                }, 1000);
                            } else if (this.pageReload) {
                                setTimeout(() => {
                                    cartReload(this.offerObj);
                                }, 1000);
                            }
                        } else {
                            this.minutes--;
                            this.seconds = 59;
                        }
                    }
                    this.seconds = this.seconds < 10 ? '0' + +this.seconds : this.seconds;
                    this.minutes = this.minutes < 10 ? '0' + +this.minutes : this.minutes;
                    this.element.innerText = this.minutes + ":" + this.seconds;
                    this.seconds--;
                }, 1000);
            }
            reStartTimer(element, minutes, seconds, rootId) {
                this.element = element;
                this.minutes = parseInt(minutes);
                this.seconds = parseInt(seconds);
                this.rootId = rootId;
                this.stopTimer();
                this.startTimer();
            }
            stopTimer() {
                clearInterval(this.counter);
            }
        }

        function buildTimer(minutes, seconds, display) {
            display.innerHTML = "";
            minutes = parseInt(minutes);
            seconds = parseInt(seconds);
            seconds = seconds < 10 ? "0" + seconds : seconds;
            minutes = minutes < 10 ? "0" + minutes : minutes;
            display.innerText = minutes + ":" + seconds;
        }
        async function fetchCart() {
            const options = {
                method: 'GET',
                headers: {
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                }
            };
            const resp = await fetch("/cart.json", options);
            return await resp.json();
        }
        async function addItem(variantId, quantity, properties = {}) {
            const options = {
                method: 'POST',
                headers: {
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                },
                body: JSON.stringify({
                    id: variantId,
                    quantity: quantity,
                    properties: properties
                })
            };
            const url = "/cart/add.json";
            const resp = await fetch(url, options);
            return await resp.json();
        }
        async function removeItem(data) {
            const options = {
                method: 'POST',
                headers: {
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                },
                body: JSON.stringify({ ...data,
                    quantity: 0
                })
            };
            const url = "/cart/change.js";
            const resp = await fetch(url, options);
            return await resp.json();
        }

        function removeItemById(id) {
            return removeItem({
                id: `${id}`
            });
        }

        function removeItemByLine(oneBasedLineIndex) {
            return removeItem({
                line: oneBasedLineIndex
            });
        }
        async function updateItem(data) {
            const options = {
                method: 'POST',
                headers: {
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                },
                body: JSON.stringify(data)
            };
            const url = "/cart/change.js";
            const resp = await fetch(url, options);
            return await resp.json();
        }

        function updateItemByLine(oneBasedLineIndex, newQuantity, newProperties = {}) {
            return updateItem({
                line: oneBasedLineIndex,
                quantity: newQuantity,
                properties: newProperties
            });
        }
        async function fetchPage(url) {
            const options = {
                method: 'GET',
                headers: {
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                }
            };
            const resp = await fetch(`${url}.json`, options);
            return await resp.json();
        }
        async function fetchProduct(handle) {
            const root = Shopify ? .routes ? .root || "/";
            const options = {
                method: 'GET',
                headers: {
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                }
            };
            const resp = await fetch(`${root}products/${handle}.json`, options);
            return resp.json();
        }

        function setOfferFetchUrl(offerParams, url) {
            const domain = kaktusvShop;
            const product_id = offerParams.productId ? `&product_id=${offerParams.productId}` : '';
            const variants_id = offerParams.variantsId ? `&variants_id=${offerParams.variantsId}` : '';
            const trigger_event = offerParams.triggerType;
            const display_on_device = window.innerWidth > 991 ? '3' : '2';
            const cart_value = offerParams.cartValue ? offerParams.cartValue : 0;
            const page_id = trigger_event === '4' ? `&page_select=${offerParams.targetCode}` : '';
            const button_code = trigger_event === '5' ? `&button_code=${encodeURIComponent(offerParams.targetCode)}` : '';
            const exclude_offers = excludeOffers.length ? `&exclude_offers=${excludeOffers.join(',')}` : '';
            const cart = offerParams.cart ? offerParams.cart : 0;
            let logged_user = '0';
            let user_tags = '0';
            if (typeof(kaktusAppData) !== 'undefined') {
                const {
                    customerId,
                    customerTags
                } = kaktusAppData;
                if (customerTags.length === 1 && customerTags.includes('')) {
                    customerTags.pop();
                }
                logged_user = customerId ? '1' : logged_user;
                user_tags = customerTags.length ? customerTags.join(',') : user_tags;
            }
            let kaktusvUrl = getCookie('kaktusvUrl');
            let parameter = '';
            if (kaktusvUrl) {
                parameter = kaktusvUrl;
            }
            const url_parameter = parameter ? `&url_parameter=${encodeURIComponent(parameter)}` : '';
            return kaktusvApiUrl + `${url}?domain=${domain}${product_id}${variants_id}&cart=${cart}&trigger_event=${trigger_event}&display_on_device=${display_on_device}&cart_value=${cart_value}&logged_user=${logged_user}&user_tags=${user_tags}${page_id}${button_code}${url_parameter}${exclude_offers}`;
        }
        async function offerVolumeDiscountFetch(offerParams) {
            getExcludeCartOffer();
            const options = {
                headers: {
                    'Content-Type': 'application/json',
                    "Accept": "application/json"
                }
            };
            const url = setOfferFetchUrl(offerParams, 'api/front/volume-discount');
            const resp = await fetch(url, options);
            if (!resp.ok) {
                throw new Error(`HTTP error, status = ${resp.status}`);
            }
            return await resp.json();
        }
        async function offerFetchPrewiev(offerParams) {
            const options = {
                headers: {
                    'Content-Type': 'application/json',
                    "Accept": "application/json"
                }
            };
            const domain = kaktusvShop;
            const product_id = offerParams.productId ? `&product_id=${offerParams.productId}` : '';
            const params = new URLSearchParams(window.location.search)
            const main_offer_id = params.get('offerId');
            let url = kaktusvApiUrl + `api/front/offers/popup-data?domain=${domain}${product_id}&main_offer_id=${main_offer_id}`;
            const resp = await fetch(url, options);
            if (!resp.ok) {
                throw new Error(`HTTP error, status = ${resp.status}`);
            }
            return await resp.json();
        }
        async function createStatisticFetch(main_offer_id, offer_id, addedToCart, funnelViews) {
            const options = {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    "Accept": "application/json"
                },
                body: JSON.stringify(createStatisticRequest(main_offer_id, offer_id, addedToCart, funnelViews))
            };
            let url = kaktusvApiUrl + `api/front/statistic`;
            const resp = await fetch(url, options);
            if (!resp.ok) {
                throw new Error(`HTTP error, status = ${resp.status}`);
            }
            return await resp.text();
        }

        function createStatisticRequest(main_offer_id, offer_id, addedToCart, views) {
            const domain = kaktusvShop;
            const action = addedToCart ? 'accept' : 'decline';
            return {
                domain: domain,
                main_offer_id: main_offer_id,
                offer_id: offer_id,
                action: action,
                views: views
            }
        }

        function sendStatistic(mainOfferId, offerId, funnelAction = false) {
            if (statisticArr.includes(offerId)) {
                const offerIdsArr = statisticArr.filter(element => element === offerId);
                let funnelViews;
                if (funnelAction) {
                    funnelViews = offerIdsArr.length > 1 ? 0 : 1;
                } else {
                    funnelViews = offerIdsArr.length >= 1 ? 0 : 1;
                }
                createStatisticFetch(mainOfferId, offerId, funnelAction, funnelViews);
            } else {
                createStatisticFetch(mainOfferId, offerId, funnelAction, 1);
            }
        }
        async function createPurchaseFetch(data) {
            const options = {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    "Accept": "application/json"
                },
                body: JSON.stringify(createPurchaseRequest(data))
            };
            let url = kaktusvApiUrl + `api/front/purchase`;
            const resp = await fetch(url, options);
            if (!resp.ok) {
                throw new Error(`HTTP error, status = ${resp.status}`);
            }
            return await resp.text();
        }

        function createPurchaseRequest(data) {
            const domain = kaktusvShop;
            const main_offer_id = data.main_offer_id;
            const amount = [];
            data.offer_amount.forEach(item => {
                amount.push({
                    offer_id: item.offer_id,
                    amount: item.amount
                })
            });
            return {
                domain: domain,
                main_offer_id: main_offer_id,
                offer_amount: amount
            }
        }

        function createPurchaseData(mainOfferId, offerId, variantId, propertyId, storePrice) {
            const localOfferData = localStorage.getItem('kaktusvPurchaseData');
            purchaseData = localOfferData ? JSON.parse(localOfferData) : purchaseData;
            let offerData = {
                'main_offer_id': mainOfferId,
                'offer': []
            }
            if (purchaseData.length) {
                const checkMainOfferId = purchaseData.find(item => item.main_offer_id === mainOfferId);
                if (checkMainOfferId) {
                    setOfferData(checkMainOfferId);
                } else {
                    purchaseData.push(offerData);
                    setOfferData(offerData);
                }
            } else {
                purchaseData.push(offerData)
                setOfferData(offerData);
            }

            function setOfferData(data) {
                data.offer.push({
                    offer_id: offerId,
                    product_id: variantId,
                    property_id: propertyId,
                    product_store_price: storePrice
                })
            }
            localStorage.setItem('kaktusvPurchaseData', JSON.stringify(purchaseData));
            localStorage.setItem('kaktusvPurchaseDataApp', JSON.stringify(purchaseData));
        }
        const s_ajaxListener = new Object();
        s_ajaxListener.tempOpen = XMLHttpRequest.prototype.open;
        s_ajaxListener.tempSend = XMLHttpRequest.prototype.send;
        s_ajaxListener.callback = function() {
            let thisUrl = this.url.replace(/\?(.+)/ig, "");
            if (thisUrl === "/cart/add.js" || thisUrl === "/cart/add.json" || thisUrl === "/cart/add") {
                let dataStr, variantsId;
                if (typeof(this.data) === 'object') {
                    if (this.data instanceof FormData) {
                        for (let pair of this.data.entries()) {
                            if (pair[0] === 'id') {
                                variantsId = pair[1];
                            }
                        }
                    }
                } else if (typeof(this.data) === 'string') {
                    if (this.data.includes('&')) {
                        dataStr = this.data.split('&');
                        dataStr.forEach(element => {
                            if (element.includes('id=')) {
                                variantsId = element.split('=');
                                variantsId = variantsId[variantsId.length - 1];
                            }
                        });
                    } else if (this.data.includes('{')) {
                        dataStr = JSON.parse(this.data);
                        variantsId = dataStr.id ? dataStr.id : dataStr.items[0].id;
                    }
                }
                if (volumeOffer && volumeOffer.allVariantsId.includes(+variantsId)) {
                    addToCartVolume(variantsId);
                }
            }
            if (thisUrl === "/cart/change.js" || thisUrl === "/cart/change.json" || thisUrl === "/cart/change") {
                setTimeout(() => {
                    checkVolumeProducts();
                    setTimeout(() => {
                        cartPageDiscount();
                    }, 1000);
                }, 500);
            }
        }
        XMLHttpRequest.prototype.open = function(a, b) {
            if (!a) var a = '';
            if (!b) var b = '';
            s_ajaxListener.tempOpen.apply(this, arguments);
            s_ajaxListener.method = a;
            s_ajaxListener.url = b;
            if (a.toLowerCase() == 'get') {
                s_ajaxListener.data = b.split('?');
                s_ajaxListener.data = s_ajaxListener.data[1];
            }
        }
        XMLHttpRequest.prototype.send = function(a, b) {
            if (!a) var a = '';
            if (!b) var b = '';
            s_ajaxListener.tempSend.apply(this, arguments);
            if (s_ajaxListener.method.toLowerCase() == 'post') s_ajaxListener.data = a;
            s_ajaxListener.callback();
        }
        const nativeFetch = window.fetch;
        window.fetch = async function(...args) {
            if (typeof(args[0]) != "string") {
                return nativeFetch.apply(window, args);
            }
            let thisUrl = args[0].replace(/\?(.+)/ig, "");
            if (thisUrl === "/cart/add.js" || thisUrl === "/cart/add.json" || thisUrl === "/cart/add") {
                if (typeof args[1].body === 'string' && (args[1].body.includes('offer') || triggerProduct)) {
                    triggerProduct = false;
                    return nativeFetch.apply(window, args);
                }
                let response = await nativeFetch.apply(window, args);
                if (response.status === 200) {
                    let dataArgs, variantsId;
                    if (typeof(args[1].body) === 'object' && args[1].body instanceof FormData) {
                        for (let pair of args[1].body.entries()) {
                            if (pair[0] === 'id') {
                                variantsId = pair[1];
                            }
                        }
                    } else if (typeof(args[1].body) === 'string') {
                        if (args[1].body.includes('&')) {
                            dataArgs = args[1].body.split('&');
                            dataArgs.forEach(element => {
                                if (element.includes('id=')) {
                                    variantsId = element.split('=');
                                    variantsId = variantsId[variantsId.length - 1];
                                }
                            });
                        } else if (args[1].body.includes('{')) {
                            dataArgs = JSON.parse(args[1].body);
                            variantsId = dataArgs.id ? dataArgs.id : dataArgs.items[0].id;
                        }
                    } else {
                        return response;
                    }
                    if (volumeOffer && volumeOffer.allVariantsId.includes(+variantsId)) {
                        addToCartVolume(variantsId);
                    }
                }
                return response
            } else if (thisUrl === "/cart/change.js" || thisUrl === "/cart/change.json" || thisUrl === "/cart/change") {
                let response = await nativeFetch.apply(window, args);
                if (response.status === 200) {
                    checkVolumeProducts();
                    setTimeout(() => {
                        cartPageDiscount();
                    }, 1000);
                }
                return response
            } else {
                return nativeFetch.apply(window, args);
            }
        }

        function addToCartVolume(variantsId) {
            fetchCart().then(dataCart => {
                const targetProduct = dataCart.items.find(product => product.variant_id === +variantsId && (!!!product.properties || (product.properties && !product.properties.offer)));
                const funnelProduct = dataCart.items.find(product => product.variant_id === +variantsId && (product.properties && product.properties.offer));
                if (targetProduct) {
                    const targetIndex = dataCart.items.findIndex(product => product.variant_id === +variantsId && (!!!product.properties || (product.properties && !product.properties.offer)));
                    let {
                        variant_id,
                        quantity,
                        properties
                    } = targetProduct;
                    let propertyId = funnelProduct ? funnelProduct.properties.offer : makeId(5);
                    let {
                        volumeDataOptions,
                        offerObj
                    } = volumeOffer;
                    let discountType = null;
                    let discountValue = null;
                    volumeDataOptions.forEach(option => {
                        const optionQty = option.allow_range ? option.range_to : option.range_from;
                        if (optionQty <= quantity || option.range_from <= quantity) {
                            discountType = option.discount_type;
                            discountValue = option.discount_value;
                        }
                    })
                    updateItemByLine(targetIndex + 1, quantity, { ...properties,
                        offer: propertyId
                    }).then(() => {
                        createOrderData(variant_id, propertyId, discountType, discountValue, quantity);
                        createVolumeProductsData(offerObj.volumeId, variant_id, propertyId);
                        createVolumeData(offerObj.volumeId, volumeDataOptions);
                    });
                }
            });
        }

        function checkVolumeProducts() {
            const localVolumeData = JSON.parse(localStorage.getItem('kaktusvVolumeData'));
            const localDataOrder = JSON.parse(localStorage.getItem('kaktusDataOrder'));
            if (!localVolumeData) return;
            fetchCart().then(dataCart => {
                localVolumeData.forEach(volumeSet => {
                    let volumeOrderQty = 0;
                    let volumeCartQty = 0;
                    for (let i = 0; i < volumeSet.volumeProducts.length; i++) {
                        const targetProduct = localDataOrder.find(item => item.propertyId === volumeSet.volumeProducts[i].propertyId);
                        if (targetProduct) {
                            volumeOrderQty += +targetProduct.qty;
                        }
                        const targetCartProduct = dataCart.items.find(item => item.properties && item.properties.offer && item.properties.offer === volumeSet.volumeProducts[i].propertyId);
                        if (targetCartProduct) {
                            volumeCartQty += +targetCartProduct.quantity;
                        }
                    }
                    if (+volumeOrderQty !== +volumeCartQty) {
                        let volumeDiscountArr = [];
                        createVolumeDiscountArray(volumeDiscountArr, volumeSet, volumeCartQty);
                        changeVolumeDiscount(dataCart, volumeDiscountArr, localDataOrder, volumeSet);
                    }
                });
                updateVolumeData(dataCart, localVolumeData);
            });
        }

        function createVolumeDiscountArray(volumeDiscountArr, volumeSet, volumeCartQty) {
            let currentCartQty = volumeCartQty;
            let currentOption = null;
            volumeSet.volumeOptions.forEach(option => {
                const optionQty = option.allow_range ? option.range_to : option.range_from;
                if (optionQty <= currentCartQty || option.range_from <= currentCartQty) {
                    currentOption = {
                        qty: optionQty,
                        discount_type: option.discount_type,
                        discount_value: option.discount_value
                    };
                }
            });
            if (currentOption === null) {
                volumeDiscountArr.push({
                    qty: `${currentCartQty}`,
                    discount_type: null,
                    discount_value: null
                });
                return false;
            } else {
                volumeDiscountArr.push(currentOption);
            }
            currentCartQty = +currentCartQty - +currentOption.qty;
            if (currentCartQty <= 0) return false;
            createVolumeDiscountArray(volumeDiscountArr, volumeSet, currentCartQty);
        }

        function changeVolumeDiscount(dataCart, volumeDiscountArr, localDataOrder, volumeSet) {
            const {
                volumeProducts
            } = volumeSet;
            dataCart.items.forEach(product => {
                const isProductInSet = volumeProducts.find(item => (+item.variantId === +product.id) && (product.properties && product.properties.offer) && (product.properties.offer === item.propertyId));
                if (product.properties && product.properties.offer && isProductInSet) {
                    const productProperty = product.properties.offer;
                    const productQty = product.quantity;
                    let productPrice = +product.discounted_price / 100;
                    let currentProductQty = productQty;
                    let isDiscount = false;
                    const totalPrice = productPrice * productQty;
                    let totalDiscountedPrice = totalPrice;
                    for (let i = 0; i < volumeDiscountArr.length; i++) {
                        let discount = 0;
                        let {
                            qty,
                            discount_type,
                            discount_value
                        } = volumeDiscountArr[i];
                        if (+qty === 0) {
                            continue;
                        }
                        if (+qty >= +currentProductQty) {
                            if (discount_value) {
                                if (discount_type === "%") {
                                    discount = +productPrice * +discount_value / 100;
                                } else {
                                    discount = +discount_value;
                                }
                                isDiscount = true;
                                totalDiscountedPrice = (totalDiscountedPrice * 100 - (discount * +currentProductQty * 100)) / 100;
                            }
                            qty = +qty - +currentProductQty;
                            volumeDiscountArr[i].qty = `${qty}`;
                            break;
                        } else {
                            if (discount_value) {
                                if (discount_type === "%") {
                                    discount = +productPrice * +discount_value / 100;
                                } else {
                                    discount = +discount_value;
                                }
                                isDiscount = true;
                                totalDiscountedPrice = (totalDiscountedPrice * 100 - (discount * +qty * 100)) / 100;
                            }
                            currentProductQty = currentProductQty - +qty;
                            volumeDiscountArr[i].qty = `0`;
                        }
                    }
                    const result = (totalPrice * 100 - totalDiscountedPrice * 100) / 100;
                    let currentDiscount = isDiscount ? (result / productQty).toFixed(2) : null;
                    const targetOrderProduct = localDataOrder.find(item => item.propertyId === productProperty);
                    targetOrderProduct.qty = productQty;
                    targetOrderProduct.discountType = `${kaktusvCurrencySymbol.includes('{{') ? currentCurrencySymbol.replace(/{{(.*?)}}/ig, '') : currentCurrencySymbol}`;
                    targetOrderProduct.discountValue = `${currentDiscount}`;
                }
            });
            localStorage.setItem('kaktusDataOrder', JSON.stringify(localDataOrder));
        }

        function updateVolumeData(dataCart, localVolumeData) {
            if (dataCart.items.length < 1 || localVolumeData.length < 1) {
                localStorage.removeItem('kaktusvVolumeData');
            } else {
                localVolumeData.forEach((volumeSet, index) => {
                    if (volumeSet.volumeProducts.length) {
                        for (let i = 0; i < volumeSet.volumeProducts.length; i++) {
                            const isVolumeProduct = dataCart.items.find(item => item.properties.offer === volumeSet.volumeProducts[i].propertyId);
                            if (!isVolumeProduct) {
                                volumeSet.volumeProducts.splice(i, 1);
                            }
                        }
                    } else {
                        localVolumeData.splice(index, 1);
                    }
                });
                localStorage.setItem('kaktusvVolumeData', JSON.stringify(localVolumeData));
            }
        }
        if (location.href.includes('/cart')) {
            checkVolumeProducts();
            setTimeout(() => {
                cartPageDiscount();
            }, 1000);
        }
        if ("/thank_you" === location.href.slice(-10) || Shopify.checkout) {
            const orderItems = Shopify.checkout.line_items;
            const offerData = JSON.parse(localStorage.getItem('kaktusvPurchaseDataApp'));
            sendPurchaseAPI(offerData, orderItems);
            localStorage.removeItem('kaktusDataOrder');
        }

        function sendPurchaseAPI(offerData, orderItems) {
            if (!offerData) {
                return
            }
            offerData.forEach(mainOfferItem => {
                const offerDataItem = {
                    'main_offer_id': mainOfferItem.main_offer_id,
                    'offer_amount': []
                }
                mainOfferItem.offer.forEach(offerItem => {
                    const lineItemProperty = orderItems.find(item => offerItem.property_id === item.properties.offer)
                    if (lineItemProperty) {
                        let discount;
                        let qty = +lineItemProperty.quantity !== 0 ? +lineItemProperty.quantity : 1;
                        if (lineItemProperty.applied_discounts.length > 0 && lineItemProperty.applied_discounts[0].amount) {
                            discount = lineItemProperty.applied_discounts[0].amount;
                        }
                        if (offerDataItem.offer_amount.length) {
                            const checkOfferId = offerDataItem.offer_amount.find(item => item.offer_id === offerItem.offer_id);
                            if (checkOfferId) {
                                checkOfferId.amount = (+checkOfferId.amount + (discount ? (+offerItem.product_store_price * qty) - discount : +offerItem.product_store_price * qty)).toFixed(2);
                            } else {
                                offerDataItem.offer_amount.push({
                                    offer_id: offerItem.offer_id,
                                    amount: discount ? ((+offerItem.product_store_price * qty) - discount).toFixed(2) : (+offerItem.product_store_price * qty).toFixed(2)
                                });
                            }
                        } else {
                            offerDataItem.offer_amount.push({
                                offer_id: offerItem.offer_id,
                                amount: discount ? ((+offerItem.product_store_price * qty) - discount).toFixed(2) : (+offerItem.product_store_price * qty).toFixed(2)
                            });
                        }
                    }
                })
                if (offerDataItem.offer_amount.length) {
                    createPurchaseFetch(offerDataItem);
                }
            })
            localStorage.removeItem('kaktusvPurchaseDataApp');
        }
        if (location.href.includes('/products/')) {
            const triggerType = triggerTypes.productPage;
            if (Object.keys(kaktusvTriggerEvents).length && kaktusvTriggerEvents.includes(+triggerType)) {
                let url = location.href.split('/');
                let productsIndex = url.indexOf('products');
                url = url[productsIndex + 1];
                fetchProduct(url).then(function(dataPage) {
                    const productId = dataPage.product.id;
                    const allVariantsId = dataPage.product.variants.map(item => item.id);
                    fetchCart().then(function(dataCart) {
                        let cart = '0';
                        if (dataCart.items.length) {
                            cart = dataCart.items.map(item => item.product_id);
                            cart = cart.join();
                        }
                        const offerParams = {
                            triggerType,
                            productId,
                            cart,
                            cartValue: dataCart.total_price
                        }
                        if (location.href.includes('offerId')) {
                            offerFetchPrewiev(offerParams).then(dataOffer => {
                                if (dataOffer.offers) {
                                    currentProductId = dataPage.product.id;
                                    let isProductInResp = dataOffer.products[productId];
                                    if (!isProductInResp) {
                                        dataOffer.products[productId] = setTriggerProductToOffer(dataPage.product);
                                    }
                                    buildPopUpType(dataOffer, dataCart, currentProductId, triggerType, allVariantsId);
                                }
                            });
                        } else {
                            offerVolumeDiscountFetch(offerParams).then(dataOffer => {
                                if (dataOffer.offers) {
                                    currentProductId = dataPage.product.id;
                                    let isProductInResp = dataOffer.products[productId];
                                    if (!isProductInResp) {
                                        dataOffer.products[productId] = setTriggerProductToOffer(dataPage.product);
                                    }
                                    buildPopUpType(dataOffer, dataCart, currentProductId, triggerType, allVariantsId);
                                }
                            });
                        }
                    });
                })
            }
        }

        function setTriggerProductToOffer(product) {
            const regex = /(<([^>]+)>)/ig;
            const variantsObj = {};
            for (let key in product.variants) {
                if (product.variants.hasOwnProperty(key)) {
                    let variantItem = product.variants[key];
                    let variantObj = {
                        title: variantItem.title,
                        description: product.body_html ? (product.body_html).replace(regex, "") : "",
                        inventory_management: variantItem.inventory_management,
                        productId: variantItem.id,
                        variantPrice: kaktusvCurrencyCode !== currentCurrencyCode ? getStorePriceByRate(variantItem.price) : variantItem.price,
                    }
                    variantsObj[variantItem.id] = variantObj;
                }
            }
            return {
                title: product.title,
                description: product.body_html ? (product.body_html).replace(regex, "") : "",
                inventory_management: product.variants[0].inventory_management,
                productId: product.id,
                variants: variantsObj,
                fbtTriggeredProduct: true
            }
        }

        function setTriggerProductIds(product) {
            const variantsArr = [];
            for (let key in product.variants) {
                if (product.variants.hasOwnProperty(key)) {
                    variantsArr.push(product.variants[key].id);
                }
            }
            return {
                [product.id]: variantsArr
            }
        }! function() {
            let lastBtn = null
            document.addEventListener('click', function(e) {
                if (!e.target.closest) return;
                lastBtn = e.target.closest('button, input[type=submit]');
            }, true);
            document.addEventListener('submit', function(e) {
                if ('submitter' in e) return;
                var canditates = [document.activeElement, lastBtn];
                lastBtn = null;
                for (var i = 0; i < canditates.length; i++) {
                    var candidate = canditates[i];
                    if (!candidate) continue;
                    if (!candidate.form) continue;
                    if (!candidate.matches('button, input[type=submit]')) continue;
                    e.submitter = candidate;
                    return;
                }
                e.submitter = e.target.querySelector('button, input[type=submit]')
            }, true);
        }();
        document.addEventListener("submit", function(e) {
            if ("string" == typeof e.target.action) {
                let actionUrl = e.target.action;
                if (actionUrl.includes('?')) {
                    actionUrl = actionUrl.split('?')[0];
                }
                if ("/checkout" === actionUrl.slice(-9) || "/cart" === actionUrl.slice(-5)) {
                    const btnType = e.submitter.getAttribute('name');
                    if (btnType && btnType === 'update') return;
                    e.preventDefault();
                    createOrder();
                }
            }
        });
        if (!!document.querySelector('a[href="/checkout"]')) {
            document.querySelector('a[href="/checkout"]').addEventListener('click', function(e) {
                e.preventDefault();
                createOrder();
            })
        }
        if (kaktusvTriggerButton.length && Object.keys(kaktusvTriggerEvents).length && !kaktusvTriggerEvents.includes(11)) {
            storeCheckoutEvent();
        }

        function storeCheckoutEvent() {
            let triggersString = decodeHTML(kaktusvTriggerButton);
            const checkoutButtonArr = triggersString.split(',');
            let clicked = false;
            document.addEventListener("click", function(e) {
                checkoutButtonArr.forEach(item => {
                    const itemTrim = item.trim();
                    const currentTrigger = document.querySelectorAll(itemTrim);
                    if (currentTrigger != null) {
                        currentTrigger.forEach(elem => {
                            if (e.target === elem && !clicked) {
                                e.preventDefault();
                                e.stopImmediatePropagation();
                                createOrder();
                                clicked = true;
                                setTimeout(() => {
                                    clicked = false;
                                }, 500);
                            }
                        });
                    }
                })
            }, true);
        }
        async function createOrderFetch(dataCart, orderData) {
            const options = {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    "Accept": "application/json"
                },
                body: JSON.stringify(createOrderRequest(dataCart, orderData))
            };
            let url = kaktusvApiUrl + `api/front/draft-order`;
            const resp = await fetch(url, options);
            if (!resp.ok) {
                throw new Error(`HTTP error, status = ${resp.status}`);
            }
            return await resp.json();
        }

        function createOrderRequest(dataCart, orderData) {
            const domain = kaktusvShop;
            const line_items = [];
            let discount = null;
            let properties = null;
            dataCart.forEach(item => {
                let qty = item.quantity;
                if (orderData) {
                    if (!!item.properties && !!item.properties.offer) {
                        const lineItemProperty = orderData.find(prod => prod.propertyId === item.properties.offer);
                        if (lineItemProperty) {
                            discount = lineItemProperty.discountValue != null ? {
                                value_type: lineItemProperty.discountType,
                                value: +lineItemProperty.discountValue
                            } : null;
                            item.properties.offer = lineItemProperty.propertyId;
                            properties = item.properties;
                            qty = +lineItemProperty.qty;
                        }
                    } else {
                        discount = null;
                        properties = item.properties;
                    }
                }
                line_items.push({
                    title: item.title,
                    product_id: item.product_id,
                    variant_id: item.variant_id,
                    price: kaktusvCurrencyCode !== currentCurrencyCode ? getStorePriceByRate(item.price / 1000) * 1000 : item.price,
                    quantity: qty,
                    discount: discount,
                    properties: properties
                })
                if (+item.quantity > +qty) {
                    let result = +item.quantity - +qty;
                    item.properties.offer = null;
                    line_items.push({
                        title: item.title,
                        product_id: item.product_id,
                        variant_id: item.variant_id,
                        price: kaktusvCurrencyCode !== currentCurrencyCode ? getStorePriceByRate(item.price / 1000) * 1000 : item.price,
                        quantity: result,
                        discount: null,
                        properties: item.properties
                    })
                }
            })
            return {
                domain: domain,
                line_items: line_items
            }
        }

        function createOrderData(variantId, propertyId, discountType, discountValue, qty) {
            const localOrderData = localStorage.getItem('kaktusDataOrder');
            orderData = localOrderData ? JSON.parse(localOrderData) : orderData;
            let productData = {
                variantId: variantId,
                propertyId: propertyId,
                discountType: discountType,
                discountValue: discountValue,
                qty: qty
            }
            orderData.push(productData);
            localStorage.setItem('kaktusDataOrder', JSON.stringify(orderData));
        }

        function createOrder() {
            const modalBody = document.querySelector("#kaktusv-app");
            if (modalBody) {
                getAppSelector('.kaktusv-popup__body').classList.add('kaktusv-preload');
            }
            const line_items = [];
            fetchCart().then(function(dataCart) {
                const orderData = JSON.parse(localStorage.getItem('kaktusDataOrder'));
                dataCart.items.forEach(item => {
                    if (orderData) {
                        if (!!item.properties && !!item.properties.offer) {
                            const lineItemProperty = orderData.find(prod => prod.propertyId === item.properties.offer);
                            if (lineItemProperty) {
                                if (lineItemProperty.discountValue != null) {
                                    line_items.push(item);
                                }
                            }
                        }
                    }
                });
                if (line_items.length) {
                    createOrderFetch(dataCart.items, orderData).then(result => {
                        setTimeout(() => {
                            location.href = result.checkout;
                        }, 1000);
                    }, error => {
                        location.href = '/checkout';
                    })
                } else {
                    location.href = '/checkout';
                }
            })
        }

        function goToCart() {
            const modalBody = document.querySelector("#kaktusv-app");
            if (modalBody) {
                getAppSelector('.kaktusv-popup__body').classList.add('kaktusv-preload');
            }
            let domain = location.href.split('/');
            domain = domain[0] + '//' + domain[2];
            location.href = domain + '/cart';
        };

        function facebookPixel() {
            if (!facebookId) {
                return;
            } else {
                ! function(f, b, e, v, n, t, s) {
                    if (f.fbq) return;
                    n = f.fbq = function() {
                        n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments)
                    };
                    if (!f._fbq) f._fbq = n;
                    n.push = n;
                    n.loaded = !0;
                    n.version = '2.0';
                    n.queue = [];
                    t = b.createElement(e);
                    t.async = !0;
                    t.src = v;
                    s = b.getElementsByTagName(e)[0];
                    s.parentNode.insertBefore(t, s)
                }(window, document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');
                fbq('init', facebookId);
                fbq('track', 'PageView');
            }
        }

        function googleAnalytics() {
            if (!googleId) {
                return;
            } else {
                (function(i, s, o, g, r, a, m) {
                    i['GoogleAnalyticsObject'] = r;
                    i[r] = i[r] || function() {
                        (i[r].q = i[r].q || []).push(arguments)
                    }, i[r].l = 1 * new Date();
                    a = s.createElement(o), m = s.getElementsByTagName(o)[0];
                    a.async = 1;
                    a.src = g;
                    m.parentNode.insertBefore(a, m)
                })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');
                ga('create', googleId, 'auto');
                ga('send', 'pageview');
            }
        }

        function pinteresPixel() {
            if (!pinterestId) {
                return;
            } else {
                ! function(e) {
                    if (!window.pintrk) {
                        window.pintrk = function() {
                            window.pintrk.queue.push(Array.prototype.slice.call(arguments))
                        };
                        var
                            n = window.pintrk;
                        n.queue = [], n.version = "3.0";
                        var
                            t = document.createElement("script");
                        t.async = !0, t.src = e;
                        var
                            r = document.getElementsByTagName("script")[0];
                        r.parentNode.insertBefore(t, r)
                    }
                }
                ("https://s.pinimg.com/ct/core.js");
                pintrk('load', pinterestId);
                pintrk('page');
                pintrk('track', 'pagevisit');
            }
        }

        function snapPixel() {
            if (!snapId) {
                return;
            } else {
                (function(win, doc, sdk_url) {
                    if (win.snaptr) return;
                    var tr = win.snaptr = function() {
                        tr.handleRequest ? tr.handleRequest.apply(tr, arguments) : tr.queue.push(arguments);
                    };
                    tr.queue = [];
                    var s = 'script';
                    var new_script_section = doc.createElement(s);
                    new_script_section.async = !0;
                    new_script_section.src = sdk_url;
                    var insert_pos = doc.getElementsByTagName(s)[0];
                    insert_pos.parentNode.insertBefore(new_script_section, insert_pos);
                })(window, document, 'https://sc-static.net/scevent.min.js');
                snaptr('init', snapId, {
                    'user_email': snapEmail
                })
                snaptr('track', 'PAGE_VIEW');
            }
        }

        function tikTokPixel() {
            if (!tikTokId) {
                return;
            } else {
                ! function(w, d, t) {
                    w.TiktokAnalyticsObject = t;
                    var ttq = w[t] = w[t] || [];
                    ttq.methods = ["page", "track", "identify", "instances", "debug", "on", "off", "once", "ready", "alias", "group", "enableCookie", "disableCookie"], ttq.setAndDefer = function(t, e) {
                        t[e] = function() {
                            t.push([e].concat(Array.prototype.slice.call(arguments, 0)))
                        }
                    };
                    for (var i = 0; i < ttq.methods.length; i++) ttq.setAndDefer(ttq, ttq.methods[i]);
                    ttq.instance = function(t) {
                        for (var e = ttq._i[t] || [], n = 0; n < ttq.methods.length; n++) ttq.setAndDefer(e, ttq.methods[n]);
                        return e
                    }, ttq.load = function(e, n) {
                        var i = "https://analytics.tiktok.com/i18n/pixel/events.js";
                        ttq._i = ttq._i || {}, ttq._i[e] = [], ttq._i[e]._u = i, ttq._t = ttq._t || {}, ttq._t[e] = +new Date, ttq._o = ttq._o || {}, ttq._o[e] = n || {};
                        var o = document.createElement("script");
                        o.type = "text/javascript", o.async = !0, o.src = i + "?sdkid=" + e + "&lib=" + t;
                        var a = document.getElementsByTagName("script")[0];
                        a.parentNode.insertBefore(o, a)
                    };
                    ttq.load(tikTokId);
                    ttq.page();
                }(window, document, 'ttq');
            }
        }

        function socialPixel() {
            facebookPixel();
            googleAnalytics();
            pinteresPixel();
            snapPixel();
            tikTokPixel()
        }

        function getExcludeCartOffer() {
            const offerId = localStorage.getItem(`kaktusvExcludeCartOfferId`);
            if (!offerId) return;
            excludeOffers.push(offerId);
            localStorage.removeItem(`kaktusvExcludeCartOfferId`);
        }

        function cartReload(offerObj) {
            if (offerObj.cartOfferExcludeId) {
                localStorage.setItem(`kaktusvExcludeCartOfferId`, offerObj.cartOfferExcludeId);
            }
            location.reload();
        }

        function cartPageDiscount() {
            let defaultSubTotalPriceClass = ['.cart-subtotal__price', '.totals__subtotal-value'];
            let settingSubTotalPriceClass = kaktusvCartSubtotal.length ? decodeHTML(kaktusvCartSubtotal).split(',') : [];
            let defaultSubTotalContainerClass = ['.cart-subtotal', '.totals'];
            let settingSubTotalContainerClass = kaktusvCartSubtotalContainer.length ? decodeHTML(kaktusvCartSubtotalContainer).split(',') : [];
            const subTotalPrice = getCartSelector(defaultSubTotalPriceClass, settingSubTotalPriceClass);
            const subTotalContainer = getCartSelector(defaultSubTotalContainerClass, settingSubTotalContainerClass);

            function getCartSelector(defaultNodeElements, settingsNodeElements) {
                const commonNodeArr = settingsNodeElements.concat(defaultNodeElements);
                const uniqueNodeArr = [...new Set(commonNodeArr)];
                if (uniqueNodeArr.length) {
                    for (let i = 0; i < uniqueNodeArr.length; i++) {
                        const itemTrim = uniqueNodeArr[i].trim();
                        const currentNode = document.querySelector(itemTrim);
                        if (currentNode != null) {
                            return currentNode;
                        }
                    }
                } else {
                    return null;
                }
            }
            if (!subTotalPrice || !subTotalContainer) return;
            const localDataOrder = JSON.parse(localStorage.getItem('kaktusDataOrder'));
            if ("/cart" === location.href.slice(-5) && localDataOrder) {
                runCartPageDiscount();
            }

            function runCartPageDiscount() {
                const kaktusvCartContainer = document.querySelector(`.kaktus-cart-container`);
                if (kaktusvCartContainer) {
                    subTotalPrice.style.textDecoration = '';
                    kaktusvCartContainer.remove();
                }
                const isDiscount = localDataOrder.find(product => product.discountValue != null);
                if (!isDiscount) return;
                fetchCart().then(function(dataCart) {
                    const {
                        total_price,
                        items
                    } = dataCart;
                    if (items.length) {
                        let totalDiscountPrice = calcDiscountPrice(localDataOrder, items);
                        buildDiscountContainer(total_price, totalDiscountPrice);
                    }
                });
            }

            function calcDiscountPrice(localDataOrder, items) {
                let totalDiscountPrice = 0;
                items.forEach(productItem => {
                    if (!!productItem.properties && !!productItem.properties.offer) {
                        const lineItemProperty = localDataOrder.find(product => product.propertyId === productItem.properties.offer);
                        if (lineItemProperty && +lineItemProperty.discountValue) {
                            let productPrice = productItem.discounted_price / 100;
                            if (lineItemProperty.discountType === '%') {
                                productPrice = (+productPrice - (+productPrice * +lineItemProperty.discountValue / 100)).toFixed(2);
                            } else {
                                productPrice = (+productPrice - +lineItemProperty.discountValue).toFixed(2);
                            }
                            totalDiscountPrice += productPrice * lineItemProperty.qty;
                        } else {
                            totalDiscountPrice += (productItem.discounted_price / 100) * productItem.quantity;
                        }
                    } else {
                        totalDiscountPrice += (productItem.discounted_price / 100) * productItem.quantity;
                    }
                })
                return totalDiscountPrice;
            }

            function buildDiscountContainer(totalPrice, totalDiscountPrice) {
                const discount = (totalPrice - (totalDiscountPrice * 100)) / 100;
                if (+discount === 0) return;
                const html = `
                    <p style="margin: 0 0 10px 0;">- ${currencyFormat(discount)}</p>
                    <p style="margin: 0; font-size: 1.4rem;">${currencyFormat(totalDiscountPrice)}</p>
                `;
                const element = document.createElement("div");
                element.classList.add("kaktus-cart-container");
                element.style.textAlign = 'right';
                element.innerHTML = html;
                subTotalContainer.after(element);
                subTotalPrice.style.textDecoration = 'line-through';
            }
        }
        class SupportModal {
            constructor() {
                this.storeUrl = (typeof kaktusvShop !== 'undefined') ? kaktusvShop : window.location.hostname;
                this.template = this.buildTemplate();
                this.crisp = this.setCrisp();
                this.closeButton = this.template.querySelector('.kaktusv-support-modal__close');
                this.rejectButton = this.template.querySelector('.kaktusv_reject_btn');
                this.supportBtnOpener = this.template.querySelector('.kaktusv_support_btn');
                this.initEvents();
            }
            getBrandName() {
                return "Kaktus";
            }
            buildTemplate() {
                const style = this.initWidgetStyles();
                const icon = `
                    <svg height="120" viewBox="0 0 199 187" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M30.968 95.5194C22.455 91.7019 16.9675 82.7234 15.7304 73.4715C14.4933 64.2195 17.0247 54.8001 21.1199 46.4178C27.1014 34.169 38.0968 22.8102 51.742 22.4346C57.5521 22.2753 63.2927 24.1372 69.1027 23.8595C78.371 23.4145 86.4308 17.6779 93.8904 12.1659C101.35 6.65395 109.406 0.913321 118.678 0.46828C127.95 0.0232376 138.154 7.53179 136.802 16.7103C136.357 19.7398 134.74 22.753 135.532 25.7173C136.978 31.1068 144.723 31.462 149.778 29.0979C154.832 26.7339 159.695 22.7571 165.236 23.4308C170.478 24.0718 174.398 28.9428 175.627 34.0751C176.856 39.2073 175.974 44.5887 175.088 49.7904L169.907 80.1104C168.682 87.2433 167.22 94.8743 162.063 99.9576C156.486 105.453 148.038 106.556 140.228 107.127C106 109.634 71.5908 107.567 37.909 100.982" fill="#F4F6F9"/>
                        <path d="M190.089 101.456C190.269 102.018 190.353 102.606 190.338 103.195C190.302 104.162 189.947 105.089 189.329 105.833C189.342 106.538 189.121 107.227 188.701 107.793C188.424 108.129 188.069 108.392 187.666 108.557C187.264 108.723 186.827 108.788 186.394 108.744C186.757 110.01 186.635 111.463 185.789 112.468C184.944 113.472 182.956 113.529 181.927 112.631L183.707 109.165C182.739 108.292 181.912 107.274 181.257 106.147C180.968 105.754 180.846 105.262 180.918 104.78C181.102 104.139 181.915 103.857 182.552 104.028C182.625 104.048 182.697 104.073 182.768 104.102C182.527 103.894 182.278 103.693 182.029 103.502C181.253 102.897 180.461 102.22 180.155 101.285C179.849 100.35 180.269 99.1083 181.229 98.896C181.78 98.8299 182.337 98.9445 182.817 99.2226C183.176 99.3901 183.527 99.5656 183.879 99.7493C183.425 98.7572 182.976 97.7691 182.523 96.781C182.408 96.6011 182.334 96.3985 182.304 96.1872C182.275 95.9759 182.291 95.7607 182.352 95.5562C182.459 95.3747 182.62 95.2312 182.812 95.1456C183.005 95.0599 183.219 95.0365 183.425 95.0785C183.835 95.174 184.221 95.3548 184.556 95.6092C185.953 96.5238 187.361 97.4507 188.48 98.6878C188.892 99.1394 189.251 99.6366 189.55 100.17C189.608 98.9433 189.291 97.7282 188.639 96.6871C187.869 95.5058 186.987 94.401 186.006 93.3881C185.414 92.7185 184.83 91.6978 185.406 91.0118C185.863 90.4606 186.737 90.5831 187.398 90.8608C188.378 91.2678 189.249 91.8977 189.943 92.7003C190.637 93.503 191.135 94.4564 191.396 95.4848C191.657 96.5132 191.675 97.5884 191.448 98.6249C191.221 99.6614 190.756 100.631 190.089 101.456ZM73.8798 150.835C73.4603 150.612 73.0602 150.354 72.6835 150.064C72.8668 150.668 72.9455 151.299 72.9162 151.929C72.8185 153.145 72.5618 154.342 72.1527 155.49C71.7614 156.94 71.2138 158.343 70.5195 159.675C69.8159 161.016 68.6932 162.09 67.3226 162.733C66.163 163.223 64.8728 163.272 63.6193 163.28C60.1013 163.308 56.5859 163.077 53.1016 162.59L54.0203 161.002C51.9502 163.897 49.1861 166.31 46.0749 167.514C40.1791 169.768 35.8675 166.179 31.1762 162.447C27.7873 159.748 24.5169 156.731 20.487 155.147C14.9301 152.954 8.01767 153.408 3.95105 149.051C-0.838258 143.923 1.45228 135.663 4.25727 129.232C12.4779 110.401 22.7866 92.551 34.9897 76.0192L28.8897 49.7005C24.1412 49.2106 14.4973 48.1327 14.4973 48.1327C18.9232 40.6486 23.684 32.0458 28.657 23.5615C32.4051 17.1635 40.571 12.4272 47.6672 16.6204C48.1957 16.9325 48.6958 17.2905 49.1616 17.6902C51.5624 19.7561 53.0077 22.7449 53.8243 25.803C54.6082 28.7223 54.8777 31.7437 55.2656 34.7406C56.522 34.2761 57.8909 34.2091 59.1867 34.5487C60.4824 34.8882 61.6425 35.6179 62.5097 36.6388C63.3769 37.6598 63.9093 38.9226 64.0348 40.2563C64.1602 41.5899 63.8726 42.9299 63.211 44.0946C62.3866 45.5252 61.0569 46.5956 59.4833 47.0956C62.8966 52.5872 66.1181 57.4336 69.5845 62.4597L69.7152 62.2066C81.7966 64.1419 93.7801 68.2698 104.134 74.7903C111.239 104.526 99.7902 129.518 73.8798 150.835Z" fill="white"/>
                        <path d="M190.939 77.1331L129.608 44.9203C125.424 42.7226 120.25 44.333 118.053 48.5173L70.3969 139.25C68.1991 143.434 69.8096 148.608 73.9939 150.805L135.324 183.018C139.509 185.216 144.682 183.606 146.88 179.421L194.536 88.6889C196.734 84.5046 195.123 79.3309 190.939 77.1331Z" fill="white"/>
                        <path d="M108.43 90.9913C119.028 90.9913 127.619 82.3997 127.619 71.8014C127.619 61.2032 119.028 52.6116 108.43 52.6116C97.8313 52.6116 89.2397 61.2032 89.2397 71.8014C89.2397 82.3997 97.8313 90.9913 108.43 90.9913Z" fill="#FEAABC"/>
                        <path d="M146.487 132.429L153.901 120.487C154.685 119.225 155.49 117.914 155.718 116.445C155.947 114.975 155.457 113.284 154.167 112.541C152.803 111.757 151.043 112.26 149.716 113.109C148.389 113.958 147.267 115.126 145.85 115.804C144.433 116.481 142.498 116.522 141.501 115.301C140.42 113.978 140.685 111.541 139.052 110.969C138.145 110.651 137.186 111.178 136.255 111.418C135.324 111.659 134.005 111.316 134.001 110.353C130.796 113.987 129.012 118.368 126.382 122.43" fill="#9ED5F0"/>
                        <path d="M106.176 72.157C106.519 66.0408 106.863 59.9259 107.209 53.8123C107.254 53.0284 108.479 53.0243 108.434 53.8123C108.102 59.6918 107.77 65.5726 107.438 71.4547H107.462L107.503 71.4833C113.838 70.3754 120.227 69.6067 126.644 69.1805C127.432 69.1315 127.428 70.3564 126.644 70.4054C120.691 70.8011 114.762 71.496 108.879 72.4877L122.626 82.5073C123.259 82.9687 122.647 84.0302 122.01 83.5648L107.054 72.6633C106.965 72.7164 106.864 72.7449 106.761 72.7458C106.657 72.7467 106.556 72.7199 106.466 72.6683C106.376 72.6166 106.302 72.542 106.251 72.4521C106.2 72.3622 106.174 72.2603 106.176 72.157ZM182.854 108.303L145.817 178.849C144.91 180.568 143.358 181.858 141.501 182.436C139.645 183.014 137.635 182.832 135.912 181.931L74.7821 149.827C74.1288 149.909 73.4633 149.954 72.7937 149.978C72.796 149.996 72.796 150.014 72.7937 150.031C73.1796 150.323 73.5894 150.583 74.0186 150.807L135.349 183.013C136.343 183.537 137.431 183.859 138.551 183.962C139.67 184.064 140.799 183.945 141.872 183.611C142.945 183.277 143.942 182.734 144.805 182.014C145.669 181.295 146.382 180.412 146.903 179.416L183.368 109.986L183.707 109.169C183.408 108.901 183.124 108.617 182.854 108.32V108.303ZM190.95 77.1096L129.62 44.9156C128.626 44.392 127.537 44.0698 126.418 43.9673C125.299 43.8648 124.17 43.984 123.097 44.3181C122.024 44.6522 121.027 45.1946 120.164 45.9144C119.3 46.6341 118.587 47.517 118.065 48.5126L115.252 53.8654C115.636 54.0124 116.016 54.1716 116.387 54.3431L119.147 49.0843C119.771 47.8997 120.705 46.9079 121.851 46.2157C122.996 45.5235 124.309 45.1572 125.648 45.1564C126.835 45.1552 128.004 45.4454 129.053 46.0016L190.383 78.208C192.102 79.1154 193.392 80.6673 193.97 82.5238C194.548 84.3804 194.366 86.3902 193.465 88.1132L190.579 93.6088C190.85 94.0422 191.07 94.5052 191.236 94.9889L194.551 88.6807C195.602 86.6701 195.813 84.3252 195.138 82.1595C194.463 79.9938 192.957 78.1839 190.95 77.126V77.1096ZM82.948 129.167C90.2973 133.705 97.7542 138.05 105.319 142.204C107.455 143.377 109.6 144.534 111.753 145.675C112.451 146.042 113.072 144.985 112.374 144.617C104.752 140.575 97.2329 136.34 89.8155 131.911C87.7196 130.656 85.636 129.389 83.5645 128.11C82.8949 127.685 82.2988 128.755 82.948 129.167ZM86.2144 124.598L95.2744 129.522C95.9645 129.898 96.5851 128.841 95.891 128.465L86.8309 123.541C86.1245 123.161 85.508 124.219 86.2021 124.598H86.2144ZM91.0037 118.956C96.4286 121.866 101.972 124.541 107.634 126.983C108.352 127.289 108.977 126.236 108.254 125.921C102.587 123.488 97.0383 120.809 91.6079 117.886C90.9138 117.523 90.2932 118.58 90.9914 118.956H91.0037ZM94.1394 114.362L97.7895 116.608C97.9302 116.689 98.097 116.712 98.2542 116.672C98.4115 116.631 98.5466 116.531 98.6306 116.392C98.7083 116.25 98.7287 116.084 98.6877 115.927C98.6467 115.771 98.5474 115.636 98.4101 115.551L94.76 113.305C94.6189 113.224 94.4517 113.202 94.2944 113.243C94.1371 113.285 94.0023 113.386 93.9189 113.525C93.8415 113.667 93.8212 113.832 93.8622 113.988C93.9032 114.144 94.0024 114.278 94.1394 114.362ZM123.537 119.556C122.847 119.176 122.226 120.234 122.92 120.613L126.272 122.447C125.145 124.388 124.032 126.335 122.932 128.289C122.549 128.979 123.606 129.6 123.99 128.91C125.092 126.942 126.211 124.984 127.346 123.035L146.989 133.81L152.705 136.933L147.806 137.252C147.022 137.301 147.018 138.525 147.806 138.476L156.813 137.893C157.286 137.86 157.695 137.207 157.246 136.847C155.461 135.409 153.993 133.617 152.934 131.584C152.566 130.886 151.509 131.507 151.876 132.205C152.764 133.895 153.921 135.428 155.302 136.745L154.665 136.786C154.645 136.712 154.609 136.643 154.56 136.583C154.512 136.523 154.452 136.474 154.383 136.439L130.294 123.263L127.946 121.969C131.033 116.699 134.233 111.498 137.545 106.364C138.906 104.274 140.277 102.197 141.657 100.133C141.704 100.066 141.735 99.9897 141.749 99.909C141.762 99.8282 141.757 99.7454 141.734 99.6669C141.711 99.5883 141.67 99.516 141.615 99.4554C141.56 99.3948 141.492 99.3474 141.416 99.3168L142.641 98.1164C141.903 100.86 141.161 103.605 140.416 106.352C140.378 106.506 140.401 106.67 140.482 106.807C140.563 106.945 140.693 107.045 140.847 107.088C141.001 107.13 141.165 107.111 141.304 107.035C141.444 106.958 141.549 106.831 141.596 106.678C142.535 103.211 143.472 99.7442 144.409 96.2791C144.442 96.1492 144.431 96.0122 144.38 95.8887C144.328 95.7652 144.237 95.6619 144.121 95.5946C144.005 95.5272 143.871 95.4994 143.738 95.5153C143.605 95.5313 143.48 95.5901 143.384 95.683L135.581 103.294C135.014 103.845 135.879 104.71 136.447 104.159L139.501 101.187C135.1 107.796 130.889 114.53 126.868 121.389L123.537 119.556ZM188.57 81.1763L160.806 67.5065L133.14 53.8817C130.915 52.7875 128.412 51.2931 125.831 51.8402C123.81 52.2485 122.001 54.241 122.544 56.3764C122.736 57.1399 123.92 56.8174 123.724 56.0538C123.239 54.1389 125.48 52.9059 127.089 52.9631C128.193 53.0537 129.269 53.3573 130.257 53.8572C131.327 54.3431 132.376 54.8861 133.434 55.4047L146.675 61.9374L173.063 74.9334L187.949 82.2623C188.631 82.5849 189.272 81.5478 188.545 81.1803L188.57 81.1763ZM169.878 87.6722C169.517 87.2526 169.059 86.9273 168.544 86.7246C168.029 86.5218 167.472 86.4477 166.922 86.5086C166.405 86.591 165.924 86.8272 165.542 87.1864C165.199 87.4885 164.823 88.0029 164.346 87.6436C163.529 87.019 163.627 85.7573 163.492 84.855C163.345 83.8833 162.962 82.8625 161.986 82.4746C161.01 82.0867 160.014 82.5767 159.128 82.985C158.773 83.1975 158.369 83.3116 157.956 83.3157C157.515 83.2463 157.356 82.838 157.299 82.4461C157.148 81.4335 157.36 80.3637 156.784 79.4492C156.444 78.965 155.983 78.5781 155.448 78.3267C154.912 78.0753 154.32 77.9683 153.73 78.0161C152.223 78.1018 150.954 79 149.79 79.8779C149.165 80.3433 149.79 81.409 150.407 80.9354C151.346 80.229 152.391 79.3961 153.595 79.2491C154.469 79.147 155.567 79.4859 155.882 80.3882C156.196 81.2906 155.91 82.2868 156.221 83.1932C156.366 83.6354 156.665 84.011 157.064 84.2521C157.462 84.4932 157.933 84.5839 158.393 84.5079C159.311 84.3773 160.055 83.7403 160.953 83.577C161.949 83.3933 162.214 84.3936 162.325 85.1816C162.464 86.1697 162.464 87.1251 163.047 87.9866C163.631 88.8481 164.546 89.2891 165.497 88.8032C166.052 88.5215 166.387 87.8805 167.004 87.7294C167.266 87.6821 167.534 87.6881 167.794 87.747C168.054 87.8059 168.299 87.9166 168.514 88.0724C169.65 88.8155 169.939 90.3629 170.209 91.5919C170.38 92.3635 171.56 92.0369 171.389 91.2652C171.087 90.0158 170.76 88.693 169.878 87.6722ZM160.079 93.9314C160.171 94.2249 160.356 94.4808 160.605 94.6611C160.855 94.8413 161.156 94.9362 161.463 94.9317C162.214 94.9317 162.774 94.3724 163.439 94.1151C164.578 93.6823 165.836 94.205 166.885 94.65C168.278 95.242 169.658 95.9198 171.197 95.9443C171.359 95.9443 171.515 95.8798 171.63 95.7649C171.745 95.6501 171.809 95.4943 171.809 95.3319C171.809 95.1694 171.745 95.0136 171.63 94.8988C171.515 94.7839 171.359 94.7194 171.197 94.7194C168.474 94.6786 166.101 92.0737 163.301 92.8739C162.98 92.9744 162.671 93.1114 162.382 93.2822C162.178 93.3965 161.614 93.8375 161.353 93.6905C160.994 93.4945 161.508 92.4411 161.594 92.1757C162.031 90.8324 161.692 89.3177 160.336 88.6276C159.983 88.4666 159.6 88.3829 159.212 88.3821C158.823 88.3813 158.44 88.4635 158.086 88.6232C157.732 88.7829 157.416 89.0164 157.16 89.3079C156.904 89.5995 156.713 89.9425 156.6 90.3139C156.368 91.0652 157.548 91.3877 157.784 90.6365C157.867 90.3545 158.034 90.1048 158.264 89.9214C158.493 89.738 158.774 89.6298 159.067 89.6115C159.36 89.5932 159.652 89.6658 159.902 89.8192C160.153 89.9726 160.35 90.1996 160.467 90.4691C160.969 91.6245 159.736 92.7596 160.079 93.9477V93.9314ZM97.5364 87.5987L74.9495 130.649C75.419 130.621 75.8886 130.604 76.3581 130.596L98.5857 88.2683C98.2223 88.056 97.8753 87.8315 97.5364 87.5987Z" fill="#3F4254"/>
                        <path d="M190.399 92.3305C189.399 91.1464 187.541 89.7296 185.908 90.0644C185.5 90.1385 185.135 90.3648 184.888 90.6977C184.641 91.0305 184.53 91.4449 184.577 91.8569C184.671 92.8123 185.336 93.5554 185.945 94.2413C186.896 95.3029 187.986 96.5237 188.558 97.8915C187.366 96.7387 186.036 95.7388 184.597 94.915C183.87 94.474 182.939 94.2291 182.209 94.7966C181.359 95.4499 181.706 96.4584 182.074 97.2709C182.258 97.6792 182.445 98.0874 182.629 98.4957C182.297 98.3356 181.933 98.2561 181.564 98.264C181.196 98.2718 180.835 98.3666 180.51 98.5406C180.159 98.7833 179.877 99.112 179.689 99.4952C179.502 99.8784 179.416 100.303 179.44 100.729C179.485 102.04 180.302 102.848 181.216 103.587C181.011 103.682 180.828 103.817 180.677 103.984C180.526 104.152 180.411 104.349 180.339 104.563C180.028 105.535 180.718 106.515 181.249 107.274C181.838 108.123 182.523 108.901 183.291 109.593C183.87 110.12 184.74 109.258 184.156 108.728C183.156 107.852 182.319 106.807 181.682 105.641C181.445 105.192 181.404 104.714 181.992 104.604C182.159 104.575 182.331 104.591 182.49 104.649C182.845 104.795 183.163 105.018 183.421 105.302C183.683 105.563 183.96 105.865 184.238 106.188C184.566 106.573 184.865 106.983 185.132 107.413C185.503 107.986 185.778 108.614 185.949 109.275C186.07 109.728 186.089 110.202 186.004 110.663C185.92 111.124 185.733 111.561 185.459 111.941C184.858 112.757 183.47 113.207 182.601 112.5C181.996 112.002 181.127 112.864 181.735 113.366C182.322 113.82 183.046 114.062 183.788 114.05C184.53 114.038 185.246 113.774 185.818 113.301C186.998 112.366 187.357 110.769 187.157 109.324C187.916 109.217 188.611 108.842 189.117 108.266C189.629 107.638 189.916 106.856 189.934 106.045C190.414 105.425 190.738 104.698 190.877 103.926C191.008 103.14 190.968 102.335 190.758 101.566C191.734 100.206 192.229 98.5594 192.164 96.8866C192.099 95.2139 191.478 93.6106 190.399 92.3305ZM187.231 108.087C187.109 108.122 186.985 108.145 186.859 108.156C186.267 106.731 185.371 105.452 184.234 104.408C183.882 104.053 183.466 103.768 183.009 103.567C182.338 103.077 181.72 102.517 181.167 101.897C180.947 101.662 180.793 101.372 180.721 101.058C180.649 100.744 180.662 100.416 180.759 100.108C181.074 99.2919 181.841 99.4757 182.498 99.7737C182.797 99.9044 183.095 100.047 183.397 100.182C184.012 100.484 184.612 100.816 185.193 101.178C185.835 101.578 186.441 102.031 187.006 102.534C187.88 103.322 188.639 104.408 188.721 105.596C188.743 105.916 188.714 106.237 188.635 106.547C188.559 106.854 188.42 107.142 188.227 107.392C187.979 107.726 187.629 107.969 187.231 108.087ZM188.864 102.779C187.729 101.276 186.006 100.194 184.336 99.3246C184.254 99.1531 184.177 98.9816 184.099 98.806C183.727 97.9894 183.282 97.1729 182.984 96.3563C182.65 95.4499 183.568 95.7561 184.046 96.0541C185.749 97.1198 187.798 98.4835 188.917 100.296C189.12 100.626 189.289 100.975 189.423 101.337L189.403 101.362H189.435C189.572 101.74 189.662 102.134 189.705 102.534C189.726 102.709 189.737 102.884 189.738 103.06C189.737 103.408 189.689 103.755 189.595 104.089C189.415 103.608 189.169 103.155 188.864 102.742V102.779ZM190.146 100.051C190.157 98.5915 189.713 97.1645 188.876 95.9684C188.36 95.2197 187.792 94.5075 187.178 93.8371C186.696 93.29 185.953 92.6571 185.81 91.8977C185.663 91.0811 186.72 91.2975 187.178 91.4894C187.867 91.7771 188.496 92.1927 189.031 92.7143C190.123 93.7365 190.81 95.1179 190.967 96.6053C191.076 97.8548 190.815 99.1088 190.215 100.211C190.183 100.1 190.158 100.06 190.134 100.015L190.146 100.051ZM57.6949 81.4862C57.6015 82.1407 57.7131 82.808 58.0143 83.3965C58.3156 83.985 58.7916 84.4659 59.3771 84.7729C59.9173 85.0822 60.5442 85.205 61.1612 85.1223C61.7781 85.0397 62.3507 84.7562 62.7904 84.3156C63.187 83.904 63.4731 83.3989 63.6223 82.8472C63.7715 82.2954 63.7789 81.7149 63.6438 81.1595C63.4808 80.6059 63.1542 80.1146 62.7067 79.7503C62.2592 79.3859 61.7119 79.1655 61.1368 79.118C60.5126 79.0377 59.8786 79.1446 59.3152 79.4252C58.7518 79.7058 58.2845 80.1474 57.9725 80.6941C57.8981 80.8419 57.8806 81.0119 57.9235 81.1718C57.8113 81.2309 57.7253 81.33 57.6826 81.4494L57.6949 81.4862ZM59.03 81.2983C59.079 81.2085 59.1321 81.1228 59.1852 81.037V81.0166C59.2178 80.9799 59.2505 80.939 59.2872 80.9023C59.3464 80.8399 59.4105 80.7826 59.4791 80.7308L59.5445 80.6859L59.7119 80.5798L59.8466 80.5103L59.9242 80.4818C60.0057 80.4503 60.0889 80.423 60.1732 80.4001C60.259 80.3756 60.3447 80.3593 60.4305 80.3429H60.508C60.576 80.3387 60.6442 80.3387 60.7122 80.3429H61.0143H61.0674L61.2144 80.3715C61.2962 80.3871 61.3768 80.409 61.4553 80.4368L61.5492 80.4695L61.6758 80.5308C61.7628 80.578 61.8473 80.6298 61.9289 80.6859H61.9493C61.982 80.7227 62.0228 80.7553 62.0596 80.7921L62.1616 80.9023V80.9227C62.2256 81.0215 62.2843 81.1238 62.3372 81.2289V81.2534C62.3546 81.3003 62.3696 81.348 62.3821 81.3963C62.4055 81.4797 62.4246 81.5642 62.4393 81.6495C62.4407 81.6753 62.4407 81.7012 62.4393 81.7271C62.4393 81.7761 62.4393 81.8291 62.4393 81.8781C62.4386 81.9832 62.4318 82.0882 62.4189 82.1925C62.4189 82.217 62.3944 82.3477 62.3862 82.3722C62.3657 82.4723 62.3371 82.5707 62.3005 82.6661C62.2921 82.6982 62.2811 82.7296 62.2678 82.76L62.227 82.8499C62.1735 82.9569 62.1135 83.0605 62.0473 83.1602L61.9861 83.2459L61.9289 83.3194C61.8623 83.3942 61.7914 83.4651 61.7166 83.5317L61.639 83.593L61.5615 83.646L61.4308 83.7236L61.3083 83.7808C61.2232 83.8141 61.1359 83.8414 61.047 83.8624L60.9368 83.8829H60.8061C60.7218 83.889 60.6372 83.889 60.553 83.8829H60.4509C60.3749 83.8668 60.2999 83.8463 60.2263 83.8216L60.0875 83.7767C60.0398 83.7497 59.9907 83.7252 59.9405 83.7032C59.8256 83.643 59.7151 83.5748 59.6098 83.4991L59.5281 83.4337C59.471 83.3806 59.4097 83.3276 59.3567 83.2704C59.3036 83.2132 59.275 83.1847 59.2383 83.1398L59.1852 83.0785C59.176 83.0611 59.1651 83.0447 59.1525 83.0295C59.0749 82.9152 59.0096 82.7968 58.9443 82.6784C58.9361 82.667 58.9292 82.6546 58.9239 82.6416C58.9239 82.6416 58.9239 82.6416 58.9239 82.609C58.9239 82.5763 58.8749 82.462 58.8545 82.3885C58.834 82.315 58.8259 82.2742 58.8136 82.2211V82.1843C58.8114 82.1544 58.8114 82.1244 58.8136 82.0945C58.8136 82.0374 58.8136 81.9761 58.8136 81.919C58.8136 81.8618 58.8422 81.6658 58.8136 81.7883C58.8282 81.6803 58.8199 81.5703 58.7891 81.4657C58.8879 81.4249 58.971 81.3533 59.0259 81.2616L59.03 81.2983ZM87.1983 84.4055C86.8513 86.2306 85.0466 87.3084 83.3032 87.239C83.4397 87.6616 83.4911 88.1071 83.4542 88.5497C83.2909 90.6524 81.376 92.5265 79.2161 91.5547C78.3653 91.153 77.7046 90.4353 77.3747 89.5541C77.135 89.7454 76.8732 89.9071 76.5949 90.0359C74.1859 91.1342 71.4953 89.2478 71.3973 86.6633C71.3034 84.1687 74.0512 82.3395 76.3499 83.103C77.0971 83.348 76.7582 84.532 76.0233 84.283C75.5307 84.1276 75.0038 84.1182 74.506 84.2559C74.0083 84.3936 73.561 84.6724 73.2183 85.0587C72.88 85.4405 72.6758 85.9224 72.6367 86.431C72.5977 86.9396 72.7259 87.447 73.0019 87.876C73.2595 88.3493 73.6676 88.7232 74.1616 88.9384C74.6556 89.1536 75.2073 89.1978 75.7293 89.0641C76.285 88.8945 76.7725 88.5528 77.1216 88.0883C77.1377 87.3984 77.3883 86.7346 77.832 86.2061C77.9184 86.1224 78.0273 86.0659 78.1454 86.0434C78.2635 86.0209 78.3856 86.0334 78.4967 86.0794C78.6077 86.1254 78.7029 86.2029 78.7706 86.3023C78.8382 86.4017 78.8753 86.5186 78.8773 86.6388C78.8551 87.2805 78.6696 87.9059 78.3383 88.4558C78.4894 89.6806 79.5918 90.9055 80.8126 90.5381C82.3437 90.1053 82.801 87.533 81.4454 86.6511C80.7962 86.2142 81.4005 85.1649 82.062 85.5936C82.5079 85.8836 83.0299 86.035 83.5619 86.0284C84.0939 86.0219 84.6119 85.8578 85.0507 85.5569C85.4724 85.2596 85.7852 84.8325 85.9415 84.3408C86.0978 83.8491 86.0889 83.3197 85.9163 82.8335C85.7802 82.3294 85.4832 81.8835 85.0705 81.5637C84.6578 81.2438 84.1519 81.0675 83.6298 81.0615C83.0845 81.0696 82.5545 81.2434 82.1103 81.56C81.6662 81.8765 81.3289 82.3207 81.1433 82.8335C80.9024 83.5807 79.7388 83.2663 79.9633 82.5069C80.1789 81.7718 80.1941 80.9925 80.0075 80.2495C79.8209 79.5066 79.4391 78.827 78.9017 78.281C77.1134 79.5917 77.1706 82.8335 79.1876 83.9318C79.8817 84.3075 79.261 85.365 78.5669 84.9893C75.6436 83.3929 75.6844 78.5056 78.6649 76.9867C78.7832 76.9231 78.9183 76.898 79.0515 76.9148C79.1847 76.9316 79.3093 76.9896 79.408 77.0807C80.4817 77.9788 81.17 79.2546 81.3311 80.6451C81.8117 80.2794 82.3709 80.0305 82.9643 79.9183C85.5651 79.4284 87.6964 81.8495 87.1983 84.4055ZM80.9432 142.383C81.1127 142.269 81.2653 142.132 81.3964 141.975C81.6698 141.684 81.8445 141.315 81.8958 140.919C81.9471 140.523 81.8724 140.121 81.6822 139.77C81.2739 139.052 80.4002 138.672 79.7061 138.296C78.2374 137.445 76.6608 136.796 75.0189 136.365C73.9228 136.115 72.7978 136.016 71.6749 136.071C72.3976 135.181 73.9001 134.936 74.9821 134.944C76.6725 134.965 79.0937 135.5 80.4124 134.091C81.7312 132.682 80.4778 130.722 78.9181 130.22C77.9375 129.978 76.9234 129.899 75.9171 129.988C74.7953 130.023 73.6762 130.12 72.565 130.277C70.7154 130.543 68.8291 131.021 67.4042 132.319C66.1384 133.458 65.4403 135.099 65.085 136.737C64.3174 140.268 65.2443 144.376 63.2355 147.573C62.2721 149.026 60.8117 150.079 59.128 150.533C58.9769 150.578 58.8259 150.611 58.6707 150.643C58.7973 149.236 58.7767 147.82 58.6095 146.417C58.2067 143.096 57.0716 139.905 55.2859 137.076C54.7065 136.17 54.061 135.309 53.3547 134.499C54.7388 132.592 55.584 130.175 56.3271 128.077C57.7644 124.017 58.7756 119.819 59.3444 115.55C59.6273 113.455 59.8045 111.347 59.8752 109.234C59.9038 108.446 58.6789 108.446 58.6503 109.234C58.472 114.519 57.6172 119.759 56.1066 124.827C55.4265 127.273 54.5344 129.656 53.4405 131.947C53.1592 132.513 52.84 133.058 52.485 133.581C52.3748 133.47 52.2727 133.356 52.1625 133.246C50.9376 132.074 49.5535 130.89 47.9734 130.261C46.4994 129.677 44.707 129.743 43.6577 131.057C43.2856 131.558 43.0293 132.136 42.9071 132.748C42.785 133.36 42.8001 133.992 42.9514 134.597C43.6863 137.884 47.5365 138.439 50.1986 137.223C51.0964 136.801 51.9024 136.208 52.5708 135.475C53.7876 136.914 54.8053 138.509 55.5963 140.219C57.3734 144.003 57.9504 148.241 57.2499 152.362C56.4382 156.564 54.361 160.418 51.2969 163.406C48.1775 166.469 43.87 168.563 39.5053 167.044C37.4108 166.314 35.553 164.978 33.8096 163.639C31.8947 162.165 30.0533 160.606 28.1588 159.111C26.3238 157.586 24.3276 156.267 22.2059 155.175C20.2912 154.295 18.2794 153.644 16.2121 153.236C12.3415 152.383 7.89104 151.872 4.89824 148.998C1.79111 146.013 1.5298 141.55 2.30556 137.565C3.1834 133.025 5.20446 128.803 7.12345 124.631C11.4334 115.264 16.267 106.147 21.6016 97.3239C24.2691 92.9116 27.0591 88.5782 29.9716 84.3238C31.4252 82.1952 32.91 80.0884 34.4261 78.0034C34.6752 77.6645 35.1366 77.1868 35.4346 76.7214C40.7522 77.6645 46.2043 77.5382 51.4725 76.3498C53.2756 75.9094 55.0409 75.3265 56.7517 74.6064C56.7004 74.6942 56.6749 74.7946 56.6782 74.8963C56.7455 76.6226 56.4041 78.3404 55.6818 79.9099C54.9595 81.4793 53.8768 82.856 52.5218 83.9278C51.1628 84.9657 49.5697 85.6541 47.8825 85.9324C46.1953 86.2108 44.4656 86.0706 42.8452 85.5242C40.983 84.9331 39.3201 83.8395 38.0396 82.364C37.521 81.7679 36.6595 82.6376 37.1699 83.2296C38.4275 84.6468 39.9994 85.7498 41.7599 86.4503C43.5204 87.1508 45.4204 87.4293 47.3079 87.2635C49.2062 87.073 51.0289 86.4199 52.6162 85.3614C54.2036 84.3029 55.5072 82.8714 56.4128 81.1922C57.3086 79.5762 57.8186 77.775 57.9031 75.9293C60.3664 77.1023 63.1483 77.4281 65.8159 76.8561C68.0084 76.3495 70.0175 75.2449 71.6199 73.6649C73.2222 72.0849 74.355 70.0915 74.8923 67.9063C75.076 67.1387 73.896 66.812 73.7123 67.5796C73.1019 70.0449 71.6652 72.2265 69.6416 73.7612C67.9161 75.0399 65.8516 75.7809 63.7068 75.8913C61.562 76.0017 59.4323 75.4766 57.5847 74.3818C57.5377 74.3538 57.4868 74.3332 57.4336 74.3206C60.3096 73.0651 63.0051 71.4311 65.4484 69.4619C67.7272 67.6005 69.7751 65.4731 71.5483 63.1251C77.7047 64.2152 83.7424 65.8928 89.5787 68.1349C89.6549 67.7293 89.7447 67.3292 89.8481 66.9345C86.0311 65.462 82.1239 64.2346 78.1505 63.2599C75.4557 62.5984 72.7338 62.054 69.9846 61.6267C69.9411 61.6226 69.8974 61.6226 69.8539 61.6267C69.0047 60.4018 68.1677 59.1769 67.3307 57.9153C70.1773 56.521 72.6981 54.5422 74.7284 52.108C76.7588 49.6738 78.2532 46.8389 79.1141 43.7883C79.2284 43.38 79.306 42.841 78.9793 42.5634C78.4812 42.1102 77.734 42.6777 77.2645 43.1636C75.5727 44.9236 73.2747 45.9739 70.8367 46.1013C68.3988 46.2287 66.0038 45.4236 64.1378 43.8495C64.5938 42.7539 64.7834 41.5657 64.6912 40.3825C64.5989 39.1994 64.2274 38.0549 63.607 37.0432C64.1923 35.1023 64.6022 33.1127 64.8319 31.0985C65.4239 25.4517 63.0395 18.1882 57.3438 13.6806C52.8933 10.1611 43.674 9.18933 39.5503 13.0845C33.4585 10.7531 27.3667 19.1191 27.9138 23.7859C26.5787 25.9009 25.4151 28.1506 24.182 30.3186C20.834 36.1572 17.535 42.0244 14.1135 47.8222C14.0622 47.9157 14.036 48.0209 14.0372 48.1275C14.0384 48.2341 14.067 48.3386 14.1204 48.4309C14.1737 48.5232 14.2499 48.6002 14.3417 48.6545C14.4334 48.7088 14.5377 48.7386 14.6442 48.7409C19.2743 49.2594 23.9003 49.7739 28.5263 50.2557L30.4983 58.7564C31.5871 63.4817 32.6759 68.2057 33.7647 72.9283C33.9934 73.9123 34.2179 74.8922 34.4466 75.8762C24.336 89.6065 15.5238 104.247 8.12377 119.609C6.33135 123.328 4.53077 127.072 3.02008 130.914C1.75845 134.128 0.749959 137.553 0.700963 141.032C0.651968 144.298 1.63188 147.54 4.02857 149.843C6.42526 152.146 9.7447 153.077 12.9335 153.771C16.4326 154.53 19.899 155.163 23.0388 156.984C26.5216 159.025 29.5062 161.81 32.6705 164.272C35.3897 166.391 38.3866 168.522 41.9388 168.763C45.4909 169.004 48.9125 167.179 51.5011 164.864C52.0965 164.325 52.6635 163.755 53.1996 163.157C55.3799 163.455 57.5724 163.668 59.769 163.774C61.8963 163.876 64.1378 164.035 66.2446 163.672C70.5439 162.929 72.022 158.527 73.0999 154.873C73.5771 153.485 73.7348 152.007 73.5612 150.549C74.8412 150.499 76.1086 150.278 77.3298 149.892C78.2526 149.578 80.3512 148.765 79.5918 147.385C79.1864 146.791 78.5853 146.357 77.8933 146.16C78.816 146.291 79.8082 146.532 80.7064 146.266C81.1178 146.172 81.4898 145.953 81.7713 145.638C82.0528 145.324 82.2299 144.93 82.2784 144.511C82.3314 143.608 81.6945 142.857 80.9432 142.383ZM48.6879 136.463C46.8342 136.945 44.6049 136.332 44.1395 134.266C43.7312 132.405 44.9561 130.727 46.9608 131.204C48.7736 131.637 50.4313 133.14 51.7379 134.532C50.9322 135.462 49.8674 136.13 48.6797 136.451L48.6879 136.463ZM32.842 63.4191C31.8267 59.0476 30.8114 54.6734 29.7961 50.2965C29.7389 50.0434 29.6777 49.7861 29.6205 49.5289C29.5829 49.4005 29.5051 49.2876 29.3985 49.2067C29.292 49.1259 29.1622 49.0814 29.0285 49.0798C24.5658 48.6184 20.1032 48.1244 15.6405 47.6262C18.3475 43.0207 20.981 38.3784 23.6267 33.7442C25.0966 31.1719 26.5719 28.6065 28.0527 26.0478C29.2775 23.9329 30.4738 21.8751 32.2295 20.1398C33.1955 19.185 34.2698 18.3463 35.4306 17.641C35.1819 19.38 35.1326 21.1416 35.2836 22.8917C35.5163 24.9536 36.2798 27.0196 37.7823 28.4486C39.5707 30.1512 42.1388 30.731 44.5968 30.9596C46.7281 31.1597 48.9574 31.1311 50.9049 30.2369L51.4521 31.025C51.9355 32.4671 52.4971 33.8819 53.1342 35.2631C52.8798 35.455 52.6397 35.6652 52.4156 35.8918C52.3523 35.9475 52.3011 36.0157 52.2653 36.0921C52.2295 36.1685 52.2099 36.2514 52.2077 36.3358C52.2054 36.4201 52.2207 36.504 52.2524 36.5822C52.2841 36.6603 52.3316 36.7311 52.392 36.7901C52.4523 36.849 52.5242 36.8948 52.6031 36.9247C52.682 36.9546 52.7662 36.9678 52.8505 36.9636C52.9347 36.9594 53.0172 36.9378 53.0927 36.9002C53.1683 36.8626 53.2352 36.8098 53.2894 36.7452C54.0435 35.9692 54.9938 35.4121 56.0392 35.1333C57.0847 34.8544 58.1862 34.8641 59.2266 35.1614C60.267 35.4587 61.2073 36.0325 61.9476 36.8216C62.6878 37.6108 63.2003 38.5858 63.4305 39.6431C63.6608 40.7003 63.6001 41.8002 63.255 42.8257C62.9099 43.8512 62.2932 44.764 61.4707 45.467C60.6481 46.1699 59.6504 46.6368 58.5836 46.8178C57.5169 46.9989 56.421 46.8874 55.4125 46.4953C55.2609 46.4362 55.0921 46.4399 54.9432 46.5053C54.7942 46.5708 54.6774 46.6928 54.6184 46.8444C54.5594 46.996 54.563 47.1648 54.6285 47.3137C54.6939 47.4626 54.8159 47.5795 54.9675 47.6385C55.7558 47.9407 56.5934 48.0944 57.4377 48.0917C58.0912 48.0896 58.7416 48.0032 59.373 47.8345C62.5278 52.8892 65.7996 57.8663 69.1884 62.7658C69.2392 62.845 69.307 62.9119 69.3868 62.9616C69.4667 63.0112 69.5566 63.0425 69.6501 63.0531C69.7436 63.0636 69.8382 63.0532 69.9271 63.0226C70.0161 62.992 70.0971 62.9419 70.1642 62.8761H70.2132C67.1989 66.734 63.4014 69.9095 59.0709 72.1934C54.5904 74.4967 49.6661 75.8071 44.6335 76.0354C41.6487 76.1762 38.6575 75.9927 35.7123 75.4883H35.6347C34.6983 71.4652 33.7647 67.4381 32.8338 63.4069L32.842 63.4191ZM78.5424 148.018V148.038V148.018ZM79.6612 145.192C78.7507 145.156 77.8361 144.96 76.9256 144.874C76.0151 144.788 75.1373 144.735 74.2431 144.707C72.9502 144.668 71.6586 144.692 70.3684 144.776C69.6849 144.71 68.9952 144.757 68.3269 144.915C68.2816 144.926 68.2378 144.943 68.1963 144.964C68.1582 144.962 68.12 144.962 68.0819 144.964C67.3062 145.054 67.298 146.283 68.0819 146.189C68.7025 146.111 69.3068 146.058 69.9438 146.013C70.4296 146.013 70.9155 146.054 71.3973 146.099C72.7288 146.225 74.0506 146.439 75.3537 146.74C76.3867 146.977 77.5135 147.218 78.3587 147.822C78.3179 147.793 78.3995 147.859 78.473 147.924L78.5098 147.953C78.4634 147.992 78.4197 148.034 78.3791 148.079C78.0452 148.304 77.6845 148.487 77.3053 148.622C74.8555 149.561 72.12 149.382 69.5477 149.386C69.3853 149.386 69.2295 149.45 69.1146 149.565C68.9998 149.68 68.9353 149.836 68.9353 149.998C68.9353 150.161 68.9998 150.316 69.1146 150.431C69.2295 150.546 69.3853 150.611 69.5477 150.611C70.4664 150.611 71.4054 150.611 72.3445 150.611C72.3851 150.8 72.4137 150.993 72.4303 151.186C72.5895 153.138 71.7852 155.179 71.1564 157C70.5684 158.695 69.7396 160.438 68.2616 161.545C66.7019 162.708 64.7176 162.651 62.8639 162.643C60.7734 162.643 58.6857 162.542 56.6007 162.341C55.7841 162.265 54.9675 162.172 54.1509 162.063C56.4634 159.111 57.9764 155.612 58.5442 151.905H58.6585C60.2721 151.596 61.7678 150.844 62.9782 149.733C65.7056 147.246 65.7465 143.49 65.9098 140.068C65.9264 138.444 66.222 136.835 66.7835 135.312C67.0841 134.562 67.5417 133.885 68.1255 133.326C68.7093 132.768 69.4058 132.341 70.1683 132.074C71.9811 131.429 73.9981 131.257 75.9089 131.212C76.8276 131.188 77.8688 131.106 78.7425 131.457C79.3386 131.698 80.0613 132.474 79.604 133.144C79.1957 133.744 78.224 133.789 77.583 133.805C76.55 133.83 75.5211 133.691 74.4922 133.728C73.0019 133.777 71.385 134.283 70.5194 135.581C70.3929 135.772 70.2914 135.977 70.2173 136.194C69.8988 136.234 69.5844 136.279 69.266 136.337C68.4902 136.471 68.8209 137.655 69.5926 137.516C71.0356 137.228 72.5175 137.189 73.9736 137.402C75.3076 137.652 76.5988 138.092 77.8075 138.709C78.5098 139.048 79.1998 139.419 79.8735 139.807C80.4369 140.13 81.0331 140.624 80.4288 141.236C80.198 141.457 79.9038 141.6 79.5877 141.644C78.1561 140.977 76.6476 140.489 75.0964 140.191C72.8306 139.745 70.5052 139.69 68.2207 140.028C67.445 140.142 67.7757 141.322 68.5474 141.212C71.0624 140.849 73.6251 141.007 76.0763 141.677H75.5129L69.2333 141.567C69.0709 141.567 68.9151 141.631 68.8003 141.746C68.6854 141.861 68.6209 142.017 68.6209 142.179C68.6209 142.342 68.6854 142.497 68.8003 142.612C68.9151 142.727 69.0709 142.792 69.2333 142.792L75.8395 142.865C76.8848 142.865 77.9382 142.926 78.9834 142.89L79.3917 142.865C80.0042 143.135 80.6942 143.478 80.9759 144.021C81.4005 144.911 80.3022 145.209 79.653 145.18L79.6612 145.192ZM52.926 41.6896C53.5776 40.6094 54.4644 39.69 55.5206 39.0001C56.5767 38.3101 57.7749 37.8673 59.0259 37.7047C59.3526 37.6598 59.6384 38.0231 59.6384 38.3171C59.6342 38.4782 59.5684 38.6316 59.4544 38.7456C59.3405 38.8596 59.1871 38.9254 59.0259 38.9296C57.9874 39.0842 56.9963 39.4677 56.1242 40.0524C55.2521 40.637 54.5209 41.4083 53.9835 42.3102C53.9012 42.4505 53.7666 42.5523 53.6092 42.5932C53.4519 42.6342 53.2847 42.611 53.1444 42.5287C53.0042 42.4464 52.9024 42.3117 52.8615 42.1544C52.8205 41.997 52.8437 41.8299 52.926 41.6896ZM38.9705 57.8663C40.1836 57.6052 41.3389 57.1251 42.3797 56.4495C43.3841 57.3151 44.6989 58.1603 46.0299 57.6458C47.3609 57.1314 47.9489 55.5676 47.7529 54.1875C47.5786 53.3014 47.2716 52.4466 46.8424 51.652C46.7891 51.5516 46.7045 51.4714 46.6015 51.4234C47.0751 50.3162 47.3515 49.1348 47.4181 47.9325C47.4589 47.1445 46.234 47.1445 46.1932 47.9325C46.1356 48.9998 45.8867 50.0481 45.4583 51.0273C45.1916 50.7346 44.8552 50.5141 44.4805 50.3864C44.1057 50.2586 43.7047 50.2277 43.3147 50.2965C42.7558 50.3939 42.2557 50.7026 41.9182 51.1587C41.5807 51.6148 41.4316 52.1832 41.5019 52.7463C41.2033 52.8307 40.9273 52.9809 40.6942 53.1858C40.4611 53.3906 40.2767 53.645 40.1545 53.9303C40.0113 54.2523 39.9761 54.612 40.0541 54.9556C40.1321 55.2993 40.3191 55.6085 40.5873 55.8371C40.6425 55.8825 40.7012 55.9234 40.7629 55.9595C40.0913 56.2907 39.3807 56.5363 38.6479 56.6904C37.8722 56.8455 38.2029 58.0255 38.9705 57.8663ZM45.593 53.2811C45.695 53.2777 45.7947 53.2508 45.8846 53.2027C45.9745 53.1546 46.0522 53.0864 46.1116 53.0035C46.3251 53.4592 46.4722 53.9432 46.5484 54.4407C46.5894 54.7502 46.5714 55.0647 46.4954 55.3675C46.4304 55.6216 46.3182 55.8612 46.1646 56.0739C45.9915 56.297 45.7503 56.4575 45.4777 56.5312C45.2051 56.6049 44.9159 56.5877 44.6539 56.4822C44.184 56.3105 43.7514 56.0499 43.3801 55.7146C44.2353 55.0187 44.9812 54.1984 45.593 53.2811ZM42.6941 52.289C42.7094 52.2253 42.7285 52.1626 42.7513 52.1012C42.7309 52.1542 42.8942 51.8848 42.8615 51.9215C42.9064 51.8725 42.9514 51.8235 43.0003 51.7786L43.0861 51.7092C43.1394 51.67 43.1953 51.6345 43.2535 51.603L43.3719 51.55L43.5475 51.4969H43.5924H43.6455C43.8598 51.4691 44.0773 51.5152 44.262 51.6275C44.5101 51.7707 44.7136 51.9798 44.8499 52.2318C44.6066 52.6366 44.3337 53.0228 44.0333 53.3873C43.6604 53.0822 43.2279 52.8583 42.7635 52.7299C42.7635 52.7054 42.7635 52.6891 42.7635 52.7299C42.7429 52.6727 42.7265 52.614 42.7145 52.5544C42.7145 52.5544 42.7145 52.4319 42.7145 52.4278C42.7179 52.4103 42.7179 52.3923 42.7145 52.3747C42.7127 52.3452 42.7058 52.3162 42.6941 52.289ZM41.2447 54.5142C41.2554 54.4413 41.2819 54.3716 41.3223 54.31C41.3999 54.1778 41.5101 54.0675 41.6422 53.9896C41.7744 53.9117 41.9242 53.8688 42.0776 53.865C42.3355 54.1314 42.6596 54.3245 43.0167 54.4244C42.8289 54.5958 42.6329 54.7592 42.4287 54.9143C42.3426 54.868 42.2455 54.8458 42.1477 54.8501C42.05 54.8544 41.9552 54.8851 41.8735 54.9388C41.8389 54.9652 41.802 54.9884 41.7632 55.0082H41.6734C41.6734 55.0082 41.5713 54.9715 41.5468 54.9674C41.5083 54.9392 41.4673 54.9146 41.4243 54.8939C41.3937 54.8674 41.3651 54.8387 41.3386 54.8082C41.3276 54.787 41.3153 54.7666 41.3018 54.7469C41.3018 54.7265 41.3018 54.7061 41.3018 54.6897C41.3018 54.6734 41.3018 54.6081 41.3018 54.5918C41.3018 54.5754 41.3018 54.5632 41.3018 54.5632C41.2826 54.5437 41.2606 54.5272 41.2365 54.5142H41.2447ZM34.5691 30.8331L33.2339 33.7769C33.1507 33.9155 33.0163 34.0159 32.8597 34.0564C32.7031 34.0968 32.5369 34.0742 32.3969 33.9933C32.2592 33.9092 32.1593 33.7752 32.1182 33.6191C32.0771 33.4631 32.098 33.2972 32.1764 33.1563L33.5034 30.192C33.5871 30.0596 33.7175 29.9634 33.8687 29.9226C34.02 29.8817 34.181 29.8992 34.32 29.9716C34.4607 30.0538 34.5643 30.1871 34.6092 30.3438C34.6541 30.5005 34.6368 30.6684 34.5609 30.8126L34.5691 30.8331ZM31.8008 29.8899L30.2493 33.1154C30.2104 33.188 30.1574 33.2519 30.0932 33.3035C30.0291 33.3551 29.9553 33.3932 29.8761 33.4156C29.7969 33.438 29.714 33.4443 29.6324 33.4339C29.5507 33.4236 29.472 33.3969 29.4009 33.3554C29.3298 33.314 29.2678 33.2586 29.2186 33.1927C29.1694 33.1267 29.1339 33.0515 29.1144 32.9716C29.0949 32.8916 29.0917 32.8086 29.105 32.7274C29.1183 32.6461 29.1478 32.5684 29.1918 32.4989L30.7433 29.2693C30.8256 29.1291 30.9603 29.0273 31.1176 28.9863C31.275 28.9453 31.4421 28.9686 31.5824 29.0509C31.7226 29.1332 31.8244 29.2678 31.8654 29.4251C31.9063 29.5825 31.8831 29.7497 31.8008 29.8899ZM29.8165 25.5334C29.7961 25.453 29.7961 25.3688 29.8165 25.2884C29.8203 25.2083 29.8457 25.1307 29.89 25.0639C29.9725 24.9269 30.1038 24.8262 30.2575 24.7821L31.074 24.5576C31.234 24.5179 31.4031 24.5397 31.5477 24.6188C31.6835 24.7025 31.7838 24.8333 31.8294 24.9863C31.8519 25.0664 31.8519 25.1511 31.8294 25.2313C31.8249 25.3125 31.7996 25.3913 31.7559 25.4599C31.6738 25.5955 31.5443 25.6959 31.3925 25.7416L30.5759 25.9621C30.4161 26.0039 30.2463 25.9819 30.1023 25.9009C30.0292 25.8599 29.9654 25.8043 29.9148 25.7376C29.8643 25.6708 29.828 25.5944 29.8083 25.513L29.8165 25.5334ZM36.0512 29.0039C35.8893 29.0012 35.7346 28.9369 35.6184 28.8242L34.5119 27.6402C34.3999 27.5235 34.3358 27.3691 34.3322 27.2074C34.3314 27.1269 34.3469 27.047 34.3778 26.9726C34.4086 26.8982 34.4543 26.8309 34.5119 26.7746C34.6266 26.6597 34.7823 26.5951 34.9447 26.595C35.1069 26.596 35.2622 26.6605 35.3775 26.7746L36.484 27.9587C36.5967 28.0749 36.6609 28.2296 36.6636 28.3915C36.6642 28.472 36.6486 28.5518 36.6178 28.6261C36.5869 28.7005 36.5414 28.7678 36.484 28.8242C36.4245 28.8784 36.355 28.9204 36.2793 28.9477C36.2037 28.9751 36.1234 28.9872 36.043 28.9835L36.0512 29.0039Z" fill="#3F4254"/>
                    </svg>
                `;
                const html = `
                    <div class="kaktusv-support-modal__content">
                        <span class="kaktusv-support-modal__close">
                            <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="times" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 352 512" class="svg-inline--fa fa-times fa-w-11 fa-2x">
                                <path fill="#4e5d78" d="M242.72 256l100.07-100.07c12.28-12.28 12.28-32.19 0-44.48l-22.24-22.24c-12.28-12.28-32.19-12.28-44.48 0L176 189.28 75.93 89.21c-12.28-12.28-32.19-12.28-44.48 0L9.21 111.45c-12.28 12.28-12.28 32.19 0 44.48L109.28 256 9.21 356.07c-12.28 12.28-12.28 32.19 0 44.48l22.24 22.24c12.28 12.28 32.2 12.28 44.48 0L176 322.72l100.07 100.07c12.28 12.28 32.2 12.28 44.48 0l22.24-22.24c12.28-12.28 12.28-32.19 0-44.48L242.72 256z"></path>
                            </svg>
                        </span>
                        <h3 class="kaktusv-support-modal__message">You should be able to see the Volume-Discount Widget, in case you don’t see it, please click Fix for ME, and we will fix it right away.</h3>

                        ${icon}

                        <div class="kaktusv-support-modal__btns">
                            <button class="kaktusv-support-modal__btn kaktusv-support-modal__btn--yellow kaktusv_support_btn">Fix for Me</button>
                            <button class="kaktusv-support-modal__btn kaktusv-support-modal__btn--gray kaktusv_reject_btn">I can see it</button>
                        </div>
                    </div>

                    ${style}
                `;
                const element = document.createElement("div");
                element.classList.add("kaktusv-support-modal", "kaktusv-support-modal__hide");
                element.innerHTML = html;
                return element;
            }
            initWidgetStyles() {
                return `
                    <style>
                        .kaktusv-support-modal {
                            position: fixed;
                            left: 30px;
                            bottom: 10%;
                            width: 300px;
                            height: 350px;
                            padding: 30px;
                            background: #fff;
                            box-shadow: 0px 3px 16px 0px rgba(0,0,0,0.08);
                            border: 1px solid #f1f1f2;
                            border-radius: 8px;
                            z-index: 999;
                            transition: 0.7s;
                        }

                        @media (max-width: 480px){
                            .kaktusv-support-modal {
                                width: 80%;
                            }
                        }

                        @media (max-width: 380px){
                            .kaktusv-support-modal {
                                padding: 15px;
                            }
                        }

                        .kaktusv-support-modal__hide {
                            transform: translateY(120%);
                        }

                        .kaktusv-support-modal__content {
                            position: relative;
                            display: flex;
                            height: 100%;
                            flex-direction: column;
                            justify-content: space-between;
                            align-items: center;
                        }

                        .kaktusv-support-modal__close {
                            position: absolute;
                            width: 10px;
                            top: -25px;
                            right: -17px;
                            transition: 0.3s;
                            cursor: pointer;
                        }

                        @media (max-width: 380px){
                            .kaktusv-support-modal__close {
                                width: 8px;
                                top: -16px;
                                right: -7px;
                            }
                        }

                        .kaktusv-support-modal__close:hover {
                            transform: scale(1.2);
                        }

                        .kaktusv-support-modal__message {
                            text-align: center;
                            margin: 0px;
                            font-size: 16px;
                        }

                        @media (max-width: 380px){
                            .kaktusv-support-modal__message {
                                font-size: 14px;
                            }
                        }

                        .kaktusv-support-modal__btns {
                            display: flex;
                            justify-content: center;
                            gap: 10px;
                        }

                        @media (max-width: 480px){
                            .kaktusv-support-modal__btns {
                                flex-direction: column;
                            }
                        }

                        .kaktusv-support-modal__btn {
                            padding: 10px 25px;
                            border-radius: 6px;
                            transition: 0.5s;
                            cursor: pointer;
                            border: none;
                            color: white;
                        }

                        .kaktusv-support-modal__btn--yellow {
                            background: #FFB73E;
                        }

                        .kaktusv-support-modal__btn--yellow:hover {
                            background: #b09059;
                        }

                        .kaktusv-support-modal__btn--gray {
                            background: #f9f9f9;
                            color: #78829d
                        }

                        .kaktusv-support-modal__btn--gray:hover {
                            background: #f1f1f2;
                        }
                    </style>
                `
            }
            initEvents() {
                this.closeButton.addEventListener('click', this.hide.bind(this));
                this.rejectButton.addEventListener('click', this.hide.bind(this));
                this.supportBtnOpener.addEventListener('click', e => {
                    e.preventDefault();
                    $crisp.push(["do", "chat:open"])
                    $crisp.push(["do", "message:send", ["text", `Hi, I'm using ${this.getBrandName()} Volume-Discount and can't see the widget. Please assist.`]]);
                });
                return this;
            }
            show() {
                document.head.append(this.crisp);
                document.body.append(this.template);
                this.template.classList.remove('kaktusv-support-modal__hide');
            }
            hide() {
                this.template.classList.add('kaktusv-support-modal__hide');
                this.template.remove();
                this.crisp.remove();
            }
            setCrisp() {
                const scriptTag = document.createElement('script');
                scriptTag.setAttribute('type', 'text/javascript');
                scriptTag.innerHTML = `
                    window.$crisp=[];
                    window.CRISP_WEBSITE_ID="4e50b386-fde3-4da7-97f2-80e38503c5ab";
                    $crisp.push(["set", "user:email", "{{ $userEmail }}"]);
                    $crisp.push(["set", "user:name", "{{ $storeOwnerName }}"]);
                    $crisp.push(["set", "session:segments", [["Volume-Discount"]]]);
                    $crisp.push(["set", "session:event", ["user:welcome"]]);
                    $crisp.push(["set", "session:data", [
                        [
                            ["myshopifyurl", "${this.storeUrl}"],
                            ["totalsales", "{{ $allAmount }}"],
                            ["totalOffers", "{{ $countOffers }}"]
                        ]
                    ]]);

                    (function(){
                        d=document;
                        s=d.createElement("script");
                        s.src="https://client.crisp.chat/l.js";
                        s.async=1;
                        d.getElementsByTagName("head")[0].appendChild(s);
                    })();`;
                return scriptTag;
            }
        }
        if (location.href.includes('offerId') && params.get('appName') === kaktusvAppName) {
            const supportModal = new SupportModal();
            supportModal.show();
        }
    };
    kaktusvApp();
}