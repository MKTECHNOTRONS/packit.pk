var e, t;
! function(e) {
    e.CHROME = "chrome", e.FIREFOX = "firefox", e.SAFARI = "safari", e.OTHER = "other"
}(e || (e = {})),
function(e) {
    e.ONE_STEP = "oneStep", e.TWO_STEP = "twoStep", e.OFF = "off"
}(t || (t = {}));
var i, n, o, r, s, a;
! function(e) {
    e.CUSTOM_BUTTONS = "custom-buttons", e.FLYOUT_WIDGET = "flyout-widget", e.PARTNER_JS_API = "partner-js-api"
}(i || (i = {})),
function(e) {
    e.NOT_SHOPIFY = "not_shopify", e.STORAGE_NOT_DEFINED = "storage_not_defined", e.LOCALSTORAGE_NOT_AVAILABLE = "localstorage_not_available", e.IN_COMAPTIBLE_BROWSER = "incompatible_browser", e.NO_SERVICE_WORKER = "no_service_worker", e.NO_SUBDOMAIN = "no_subdomain", e.OLD_IOS_DEVICE = "old_ios_device", e.MICROSOFT_EDGE = "microsoft_edge", e.NOT_ADDED_TO_HOME_SCREEN = "not_added_to_home_screen", e.INCOGNITO = "incognito", e.NOTIFICATION_NOT_DEFINED = "notification_not_defined", e.NO_FILE_SYSTEM = "no_file_system", e.DISABLED_RESYNC = "disable_resync"
}(n || (n = {})),
function(e) {
    e.NO_SUBSCRIBER_TOKEN = "no_subsriber_token", e.INVALID_SUBSCRIBER_TOKEN = "invalid_subscriber_token", e.PERMISSION_DENIED = "permission_denied", e.PERMISSION_NOT_GRANTED = "permission_not_granted", e.INVALID_STATE_ERROR = "InvalidStateError", e.UNKNOWN_EVENT = "unknown_event"
}(o || (o = {})),
function(e) {
    e.BACK_IN_STOCK = "back_in_stock", e.PRICE_DROP = "price_drop"
}(r || (r = {})),
function(e) {
    e.SILENT = "silent", e.DEBUG = "debug"
}(s || (s = {})),
function(e) {
    e.CART_DELETED = "cart_deleted", e.CART_UPDATED = "cart_updated", e.PRODUCT_VIEWED = "product_viewed"
}(a || (a = {}));
const c = [{
        name: "track"
    }, {
        name: "identify"
    }, {
        name: "trackLink"
    }, {
        name: "page"
    }, {
        name: "viewProduct",
        isEcommerce: !0
    }, {
        name: "viewCategory",
        isEcommerce: !0
    }, {
        name: "search",
        isEcommerce: !0
    }],
    u = {
        WIDGET_CONFIG_KEY: {
            HOME: "home",
            PRICE_DROP: "price_drop",
            BACK_IN_STOCK: "back_in_stock"
        },
        EVENT_API_PATH: {
            PRICE_DROP: "price-drop",
            BACK_IN_STOCK: "back-in-stock"
        },
        ENVIRONMENT: {
            staging: "staging",
            production: "production"
        },
        STORAGE_KEYS: {
            NETWORK_REQUEST_QUEUE: "pushowl_network_request_queue",
            VISITOR_TOKEN: "pushowl_visitor_token",
            SESSION_TOKEN: "pushowl_session_token",
            SUBSCRIBER_TOKEN: "pushowl_subscriber_token",
            SUBSCRIPTION: "pushowl_subscription",
            SW_SUBSCRIPTION: "pushowl_sw_subscription",
            SW_SUBSCRIBER_TOKEN: "pushowl_sw_subscriber_token",
            EMAIL: "pushowl_email",
            BACK_IN_STOCK_SUBSCRIPTIONS: "pushowl_back_in_stock_subscriptions",
            PRICE_DROP_SUBSCRIPTIONS: "pushowl_price_drop_subscriptions",
            SYNCED_CART_JSON: "pushowl_synced_cart_json",
            SYNCED_CUSTOMER_ID: "pushowl_synced_customer_id",
            SYNCED_AC_EVENTS: "pushowl_ac_events",
            SESSION_PAGEVIEW_COUNT: "pushowl_session_pageview_count",
            SESSION_SUBSCRIBER_CHECK: "pushowl_session_subscriber_check",
            OPTIN_DEFERRED_UNTIL: "pushowl_optin_deferred_until",
            LOG_LEVEL: "pushowl_log_level",
            HAS_RAISED_UNSUBSCRIPTION_EVENT: "pushowl_has_raised_unsubscription_event",
            IS_PERMISSION_GRANTED: "pushowl_is_permission_granted",
            REFERRER: "pushowl_referrer",
            LANDING_PAGE_URL: "pushowl_landing_page_url",
            LANDING_PAGE_URL_PARAMS: "pushowl_landing_page_url_params",
            ORIGINAL_URL_PARAMS: "pushowl_original_url_params",
            IOS_STANDALONE_MODE_LOG: "pushowl_ios_standalone_mode_log",
            INSTALL_PROMPT_SEEN_COUNT: "pushowl_install_prompt_seen_count",
            INSTALL_PROMPT_DISMISSED: "pushowl_install_prompt_dismissed",
            CONSENT: "pushowl_channels_consent",
            PUSHOWL_SUBDOMAIN: "pushowl_subdomain",
            PUSHOWL_ENVIRONMENT: "pushowl_environment",
            CURRENT_CONFIG_KEY: "pushowl_current_config_key",
            PHONE: "pushowl_phone"
        },
        NOTIFICATION_PERMISSION: {
            DEFAULT: "default",
            GRANTED: "granted",
            DENIED: "denied",
            DISMISSED: "dismissed",
            SERVICE_WORKER_FAILURE: "service_worker_failure"
        },
        DEFAULT_TIMEOUT: {
            DEFAULT: 0,
            MOBILE: 10
        }
    },
    l = {
        EVENTS: {
            CLICK: "click",
            ANIMATION_END: "animationend",
            TRANSITION_END: "transitionend"
        },
        WIDGET_CLASSES: {
            MINIMIZE: "minimize",
            MAXIMIZE: "maximize"
        }
    },
    d = {
        [u.ENVIRONMENT.staging]: "https://api-staging.pushowl.com",
        [u.ENVIRONMENT.production]: "https://api.pushowl.com"
    },
    p = {
        [u.ENVIRONMENT.staging]: "https://cdn-staging.pushowl.com/config",
        [u.ENVIRONMENT.production]: "https://cdn.pushowl.com/config"
    },
    h = {
        [u.ENVIRONMENT.staging]: "web.com.pushowl.staging",
        [u.ENVIRONMENT.production]: "web.com.pushowl.prod"
    },
    g = {
        HOME: "home",
        COLLECTION: "collection",
        PRODUCT: "product",
        CART: "cart",
        CHECKOUT: "checkout",
        ORDER: "order",
        ORDERS: "orders",
        THANK_YOU: "thank_you"
    },
    w = {
        CART: "cart",
        ACCOUNT: "account",
        ORDERS: "orders"
    },
    m = "subscribe",
    b = "unsubscribe",
    f = "debug",
    _ = "disabled",
    S = "browser-prompt",
    v = "custom-prompt",
    y = "optin-flyout",
    E = "price-drop-flyout",
    I = "back-in-stock-flyout",
    T = "wordpress",
    N = "prestashop";

function O(e, t, i, n) {
    return new(i || (i = Promise))((function(o, r) {
        function s(e) {
            try {
                c(n.next(e))
            } catch (e) {
                r(e)
            }
        }

        function a(e) {
            try {
                c(n.throw(e))
            } catch (e) {
                r(e)
            }
        }

        function c(e) {
            var t;
            e.done ? o(e.value) : (t = e.value, t instanceof i ? t : new i((function(e) {
                e(t)
            }))).then(s, a)
        }
        c((n = n.apply(e, t || [])).next())
    }))
}

function M(e) {
    return new Promise((function(t, i) {
        e.oncomplete = e.onsuccess = function() {
            return t(e.result)
        }, e.onabort = e.onerror = function() {
            return i(e.error)
        }
    }))
}
var C;

function A() {
    return C || (C = function(e, t) {
        var i = indexedDB.open(e);
        i.onupgradeneeded = function() {
            return i.result.createObjectStore(t)
        };
        var n = M(i);
        return function(e, i) {
            return n.then((function(n) {
                return i(n.transaction(t, e).objectStore(t))
            }))
        }
    }("keyval-store", "keyval")), C
}
const L = Object.prototype.toString,
    P = new Set(["network error", "Failed to fetch", "NetworkError when attempting to fetch resource.", "The Internet connection appears to be offline.", "Load failed", "Network request failed", "fetch failed", "terminated"]);

function k(e) {
    var t;
    return !(!e || (t = e, "[object Error]" !== L.call(t)) || "TypeError" !== e.name || "string" != typeof e.message) && ("Load failed" === e.message ? void 0 === e.stack : P.has(e.message))
}
class D {
    constructor(e) {
        this.key = e, window.localStorage.getItem(e) ? this.subscriptions = window.localStorage.getItem(this.key).split(",") : this.subscriptions = []
    }
    subscribe(e) {
        this.isSubscribed(e) || (this.subscriptions.push(e.id.toString()), window.localStorage[this.key] = this.subscriptions)
    }
    isSubscribed(e) {
        return this.subscriptions.indexOf(e.id.toString()) > -1
    }
}
class j {
    constructor() {
        this.back_in_stock = new D(u.STORAGE_KEYS.BACK_IN_STOCK_SUBSCRIPTIONS), this.price_drop = new D(u.STORAGE_KEYS.PRICE_DROP_SUBSCRIPTIONS), Promise.all([H.get(u.STORAGE_KEYS.SW_SUBSCRIPTION), H.get(u.STORAGE_KEYS.SW_SUBSCRIBER_TOKEN)]).then((e => {
            var [t, i] = e;
            t && i && (this.sw_subscription_data = t, this.sw_subscriber_token = i)
        })).catch((e => {
            we("Error while fetching subscription data", e)
        }))
    }
    static getOrCreateToken(e, t) {
        var i = e.getItem(t);
        if (i) return i;
        var n = function() {
                return (65536 * (1 + Math.random()) | 0).toString(16).substring(1)
            },
            o = "".concat(n() + n(), "-").concat(n(), "-4").concat(n().substr(0, 3), "-").concat(n(), "-").concat(n()).concat(n()).concat(n()).toLowerCase();
        return e.setItem(t, o), o
    }
    static get queue() {
        try {
            var e = localStorage.getItem(u.STORAGE_KEYS.NETWORK_REQUEST_QUEUE);
            return e ? JSON.parse(e) : []
        } catch (e) {
            return []
        }
    }
    static set queue(e) {
        e ? localStorage.setItem(u.STORAGE_KEYS.NETWORK_REQUEST_QUEUE, JSON.stringify(e)) : localStorage.removeItem(u.STORAGE_KEYS.NETWORK_REQUEST_QUEUE)
    }
    static get email() {
        return localStorage.getItem(u.STORAGE_KEYS.EMAIL)
    }
    static set email(e) {
        localStorage.setItem(u.STORAGE_KEYS.EMAIL, e)
    }
    static get phone() {
        return localStorage.getItem(u.STORAGE_KEYS.PHONE)
    }
    static set phone(e) {
        localStorage.setItem(u.STORAGE_KEYS.PHONE, e)
    }
    static set pushowlEnvironment(e) {
        localStorage.setItem(u.STORAGE_KEYS.PUSHOWL_ENVIRONMENT, e)
    }
    static get consent() {
        var e = localStorage.getItem(u.STORAGE_KEYS.CONSENT);
        if (e) try {
            return JSON.parse(e)
        } catch (e) {
            return []
        }
        return []
    }
    static set consent(e) {
        localStorage.setItem(u.STORAGE_KEYS.CONSENT, JSON.stringify(e))
    }
    static get subscriberToken() {
        return this.sw_subscriber_token || localStorage.getItem(u.STORAGE_KEYS.SUBSCRIBER_TOKEN)
    }
    static set subscriberToken(e) {
        e ? (localStorage.setItem(u.STORAGE_KEYS.SUBSCRIBER_TOKEN, e), H.set(u.STORAGE_KEYS.SUBSCRIBER_TOKEN, e)) : (localStorage.removeItem(u.STORAGE_KEYS.SUBSCRIBER_TOKEN), H.del(u.STORAGE_KEYS.SUBSCRIBER_TOKEN))
    }
    static get installPromptDismissed() {
        return Boolean(localStorage.getItem(u.STORAGE_KEYS.INSTALL_PROMPT_DISMISSED))
    }
    static set installPromptDismissed(e) {
        localStorage.setItem(u.STORAGE_KEYS.INSTALL_PROMPT_DISMISSED, "".concat(e))
    }
    static get hasLoggediOSStandaloneMode() {
        return localStorage.getItem(u.STORAGE_KEYS.IOS_STANDALONE_MODE_LOG)
    }
    static set hasLoggediOSStandaloneMode(e) {
        localStorage.setItem(u.STORAGE_KEYS.IOS_STANDALONE_MODE_LOG, e)
    }
    static get originalURLParams() {
        return localStorage.getItem(u.STORAGE_KEYS.ORIGINAL_URL_PARAMS)
    }
    static set originalURLParams(e) {
        localStorage.setItem(u.STORAGE_KEYS.ORIGINAL_URL_PARAMS, e)
    }
    static get visitorToken() {
        return Y() ? this.getOrCreateToken(localStorage, u.STORAGE_KEYS.VISITOR_TOKEN) : (localStorage.removeItem(u.STORAGE_KEYS.VISITOR_TOKEN), null)
    }
    static get sessionToken() {
        return this.getOrCreateToken(sessionStorage, u.STORAGE_KEYS.SESSION_TOKEN)
    }
    static get syncedCustomerId() {
        return localStorage.getItem(u.STORAGE_KEYS.SYNCED_CUSTOMER_ID)
    }
    static set syncedCustomerId(e) {
        localStorage.setItem(u.STORAGE_KEYS.SYNCED_CUSTOMER_ID, e.toString())
    }
    static get synced_cart_json() {
        var e = localStorage.getItem(u.STORAGE_KEYS.SYNCED_CART_JSON);
        return e ? JSON.parse(e) : void 0
    }
    static set synced_cart_json(e) {
        e && ("[object String]" !== Object.prototype.toString.call(e) && (e = JSON.stringify(e)), localStorage.setItem(u.STORAGE_KEYS.SYNCED_CART_JSON, e))
    }
    static get ac_events() {
        try {
            return JSON.parse(localStorage.getItem(u.STORAGE_KEYS.SYNCED_AC_EVENTS)) || []
        } catch (e) {
            return []
        }
    }
    static set ac_events(e) {
        var t = "string" == typeof e ? e : JSON.stringify(e);
        localStorage.setItem(u.STORAGE_KEYS.SYNCED_AC_EVENTS, t)
    }
    static get subscription() {
        var e = this.sw_subscription_data || localStorage.getItem(u.STORAGE_KEYS.SUBSCRIPTION),
            t = null;
        if (e) try {
            t = JSON.parse(e)
        } catch (i) {
            t = e
        }
        return t
    }
    static set subscription(e) {
        var t = "string" == typeof e ? e : JSON.stringify(e);
        localStorage.setItem(u.STORAGE_KEYS.SUBSCRIPTION, t), H.set(u.STORAGE_KEYS.SW_SUBSCRIPTION, t)
    }
    static get optinDeferredUntil() {
        return parseInt(localStorage.getItem(u.STORAGE_KEYS.OPTIN_DEFERRED_UNTIL) || 0, 10)
    }
    static set optinDeferredUntil(e) {
        null === e ? localStorage.removeItem(u.STORAGE_KEYS.OPTIN_DEFERRED_UNTIL) : localStorage.setItem(u.STORAGE_KEYS.OPTIN_DEFERRED_UNTIL, e)
    }
    static get logLevel() {
        return localStorage.getItem(u.STORAGE_KEYS.LOG_LEVEL)
    }
    static set logLevel(e) {
        localStorage.setItem(u.STORAGE_KEYS.LOG_LEVEL, e)
    }
    static get hasRaisedUnsubscriptionEvent() {
        return localStorage.getItem(u.STORAGE_KEYS.HAS_RAISED_UNSUBSCRIPTION_EVENT)
    }
    static set hasRaisedUnsubscriptionEvent(e) {
        localStorage.setItem(u.STORAGE_KEYS.HAS_RAISED_UNSUBSCRIPTION_EVENT, e)
    }
    static get isPermissionGranted() {
        return "true" === localStorage.getItem(u.STORAGE_KEYS.IS_PERMISSION_GRANTED)
    }
    static set isPermissionGranted(e) {
        e ? localStorage.setItem(u.STORAGE_KEYS.IS_PERMISSION_GRANTED, e) : localStorage.removeItem(u.STORAGE_KEYS.IS_PERMISSION_GRANTED)
    }
    static handlePostSubscription(e, t) {
        j.subscription = e, j.subscriberToken = t, j.hasRaisedUnsubscriptionEvent = ""
    }
}
const R = () => {
        const e = new Error("network error");
        return e.name = "TypeError", e
    },
    x = ({
        path: e,
        method: t,
        appendPlatform: i = !0,
        url: n = null,
        payload: o = null,
        contentType: r = "application/json",
        acceptType: s = "application/json",
        retryCount: a = null
    }) => O(void 0, void 0, void 0, (function*() {
        const c = n ? new URL(n) : new URL(`${(()=>{const{subdomain:e}=B;return`
            $ {
                B.apiEndpoint
            }
            /api/v
            1 / $ {
                e
            }
            `})()}${e}`);
        return i && c.searchParams.append("platform", B.platform), a && c.searchParams.append("retry_count", `${a}`), new Promise(((e, i) => {
            let n = new XMLHttpRequest;
            n.open(t, c.href, !0), n.setRequestHeader("Content-Type", r), n.setRequestHeader("Accept", s), o ? n.send(r.match(/json/) ? JSON.stringify(o) : o) : n.send(), n.onload = function() {
                let t = n.responseText;
                if (429 === n.status && i(R()), n.status >= 200 && n.status < 400) try {
                    const i = s.match(/json/) ? JSON.parse(t) : t;
                    e(i)
                } catch (i) {
                    e(t)
                } else i(t)
            }, n.onerror = function() {
                i(R())
            }, n.onabort = function() {
                i("Request Aborted")
            }
        }))
    }));
class U {
    static run() {
        (j.queue || []).forEach((e => {
            setTimeout((() => {
                this._request(e)
            }), 1e3 * e.retryCount)
        }))
    }
    static _enqueue(e) {
        let t = e;
        return void 0 === e.id && (t = Object.assign({
            id: ce()
        }, e)), j.queue = [...j.queue.slice(0, 5), t], t
    }
    static _retryRequest(e) {
        return O(this, void 0, void 0, (function*() {
            const t = Object.assign(Object.assign({}, e), {
                retryCount: ((null == e ? void 0 : e.retryCount) || 0) + 1
            });
            if (t.retryCount > 5) {
                return fe("APIRequestEventually", {
                    request: t,
                    connectionType: navigator.connection ? navigator.connection.effectiveType : "NA"
                }), Promise.reject()
            }
            const i = this._enqueue(t);
            setTimeout((() => {
                this._request(i)
            }), 1e3 * i.retryCount)
        }))
    }
    static _dequeue(e) {
        j.queue = j.queue.filter((t => t.id !== e.id))
    }
    static _request(e) {
        return O(this, void 0, void 0, (function*() {
            try {
                this._dequeue(e);
                return yield x(e)
            } catch (t) {
                return k(t) ? this._retryRequest(e) : (fe("APIRequestEventuallyError", {
                    error: t,
                    request: e
                }), Promise.reject(t))
            }
        }))
    }
    static get(e) {
        const t = this._enqueue(e);
        return this._request(Object.assign(Object.assign({}, t), {
            method: "GET"
        }))
    }
    static post(e) {
        const t = this._enqueue(e);
        return this._request(Object.assign(Object.assign({}, t), {
            method: "POST"
        }))
    }
    static put(e) {
        const t = this._enqueue(e);
        return this._request(Object.assign(Object.assign({}, t), {
            method: "PUT"
        }))
    }
}
class B {
    static get scriptUrl() {
        let e = document.getElementsByTagName("script");
        for (let t = 0; t < e.length; t++) {
            let i = e[t].src || "";
            if (i.match(/pushowl-\w+.js/)) return i.match(/^http/) || (i = i.replace(/^\/\//, "https://")), i
        }
        return window.location.href
    }
    static get environment() {
        if (!B.scriptUrl) return u.ENVIRONMENT.production;
        let e = ne(new URL(B.scriptUrl).search.substring(1)).environment;
        e && (e = u.ENVIRONMENT[e]);
        const t = window.pushowlEnvironment || e || u.ENVIRONMENT.production;
        return t !== u.ENVIRONMENT.production && (j.pushowlEnvironment = t), t
    }
    static get isProduction() {
        return B.environment == u.ENVIRONMENT.production
    }
    static get apiEndpoint() {
        return d[B.environment]
    }
    static get configApiEndpoint() {
        return p[B.environment]
    }
    static get subdomain() {
        let e = {};
        B.scriptUrl && (e = ne(new URL(B.scriptUrl).search.substring(1))), window.pushowl && window.pushowl.subdomain && (window.pushowlSubdomain = window.pushowl.subdomain);
        const t = window.pushowlSubdomain || e.subdomain;
        return window.pushowlSubdomain = t, window.pushowlSubdomain || e.subdomain
    }
    static get platform() {
        if (!B.scriptUrl) return "shopify";
        const e = ne(new URL(B.scriptUrl).search.substring(1)).platform;
        return e && !["shopify", "sendinblue", "bigcommerce"].includes(e) && B.logToServer({
            message: "unknown platform detected",
            subdomain: B.subdomain,
            data: {
                platform: e,
                script_url: B.scriptUrl
            }
        }), e || "shopify"
    }
    static get plugin() {
        if (!B.scriptUrl) return null;
        return ne(new URL(B.scriptUrl).search.substring(1)).plugin
    }
    static get guid() {
        if (!B.scriptUrl) return null;
        let e = ne(new URL(B.scriptUrl).search.substring(1));
        return window.pushowlGUID || e.guid
    }
    static get visitorId() {
        if (!B.scriptUrl) return null;
        return ne(new URL(B.scriptUrl).search.substring(1)).visitor_id
    }
    static get shopUrl() {
        return location.protocol + "//" + location.host
    }
    static serviceWorkerUrl(e = {}) {
        if (e.custom_sw_path && "disabled" !== e.custom_sw_path) return `${B.shopUrl}${e.custom_sw_path}?v=2&subdomain=${this.subdomain}`;
        if ("bigcommerce" === B.platform) return `${B.shopUrl}/pushowl-service-worker.js?v=2&subdomain=${this.subdomain}`;
        if ("headless" === B.mode) {
            const t = B.platform,
                i = B.plugin;
            return "enabled" === e.root_service_worker ? `${window.location.origin}/service-worker.js?v=2&subdomain=${this.subdomain}` : "sendinblue" === t && window.__st && window.Shopify ? `${B.shopUrl}/apps/sendinblue/service-worker.js?v=2&subdomain=${this.subdomain}` : "sendinblue" === t && i === T ? `${B.shopUrl}/wp-content/plugins/mailin/js/service-worker.js?v=2&subdomain=${this.subdomain}` : "sendinblue" === t && i === N ? `${B.shopUrl}/modules/sendinblue/views/js/service-worker.js?v=2&subdomain=${this.subdomain}` : `${B.shopUrl}/${"sendinblue"===t?"sendinblue":"pushowl"}/service-worker.js?v=2&subdomain=${this.subdomain}`
        }
        return "enabled" === e.should_log ? `${B.shopUrl}/apps/pushowl/sdks/service-worker-logsink.js?v=2&subdomain=${this.subdomain}` : `${B.shopUrl}/apps/pushowl/sdks/service-worker.js?v=2&subdomain=${this.subdomain}`
    }
    static get isWorkerAvailable() {
        return re().isApnsSafari ? Promise.resolve(!0) : new Promise((e => {
            const t = ((new z).config || {}).flags,
                i = B.serviceWorkerUrl(t),
                n = "enabled" === t.sw_get_request;
            fetch(i, {
                method: n ? "GET" : "HEAD"
            }).then((t => {
                if (t.status >= 200 && t.status < 300) return e(!0);
                e(!1)
            }))
        }))
    }
    static get webPushId() {
        return h[this.environment] || h[u.ENVIRONMENT.production]
    }
    static getServiceWorkerUrlWithIntergrations(e, t = {}) {
        const i = Object.keys(t).filter((e => "enabled" === t[e].status));
        if (!i.length) return e;
        return `${e}${new URL(e).search?"&":"?"}integrations=${i.join(",")}`
    }
    static logToServer({
        message: e,
        subdomain: t,
        sessionHash: i = "session",
        data: n
    }) {
        return U.post({
            url: `${B.apiEndpoint}/logs/v1/`,
            acceptType: "text/plain",
            payload: [{
                level: "warn",
                subscriber_token: window.localStorage && window.localStorage.getItem("pushowl_subscriber_token"),
                subdomain: t,
                message: e,
                session_hash: i,
                timestamp: (new Date).toISOString(),
                data: Object.assign({
                    release: "b8b8cbe"
                }, n)
            }]
        })
    }
    static getPreviewLib(e) {
        const t = B.getPreviewBranch();
        return sessionStorage.setItem("pushowl_branch", t), "local" === t ? `https://localhost:3008/latest/sdks/${e}?environment=staging&platform=${B.platform}` : null
    }
    static loadPreviewLib(e) {
        const t = document.createElement("script"),
            i = this.getPreviewLib(e);
        t.onload = () => {}, i && (t.src = i, t.setAttribute("async", ""), document.head.appendChild(t), window.pushowlPreviewLoaded = !0)
    }
    static getPreviewBranch() {
        const e = new URLSearchParams(window.location.search).get("pushowl_branch") || sessionStorage.getItem("pushowl_branch");
        return window.pushowlPreviewLoaded ? null : e
    }
    static isDisabled() {
        const e = new URLSearchParams(window.location.search).get("poTaskType") || sessionStorage.getItem("poTaskType");
        sessionStorage.setItem("pushowl_task_type", e);
        return e === _
    }
}
const Y = () => "shopify" !== B.platform || !B.guid || !!window.Shopify.customerPrivacy && window.Shopify.customerPrivacy.userCanBeTracked(),
    F = () => !!window.indexedDB;
class H {
    static set(e, t) {
        return O(this, void 0, void 0, (function*() {
            if (F()) try {
                ! function(e, t) {
                    (arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : A())("readwrite", (function(i) {
                        return i.put(t, e), M(i.transaction)
                    }))
                }(e, t)
            } catch (e) {
                we("error in indexedDBUtil", e)
            }
        }))
    }
    static get(e) {
        return O(this, void 0, void 0, (function*() {
            if (F()) try {
                return function(e) {
                    return (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : A())("readonly", (function(t) {
                        return M(t.get(e))
                    }))
                }(e)
            } catch (e) {
                return we("error in indexedDBUtil", e), Promise.reject(e)
            }
        }))
    }
    static del(e) {
        return O(this, void 0, void 0, (function*() {
            if (F()) try {
                ! function(e) {
                    (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : A())("readwrite", (function(t) {
                        return t.delete(e), M(t.transaction)
                    }))
                }(e)
            } catch (e) {
                we("error in indexedDBUtil", e)
            }
        }))
    }
}
class z {
    constructor() {
        this.configKey = "pushowl_shopify_config-".concat(1.5, "-").concat(B.guid), this.permissionKey = "pushowl_permission_not_granted-".concat(1.5, "-").concat(B.guid), this.subscriptionVerifiedKey = "pushowl_subscription_verified-".concat(1.5, "-").concat(B.guid), this.optinSeenCountKey = "pushowl_optin_seen_count", window.sessionStorage.setItem(u.STORAGE_KEYS.CURRENT_CONFIG_KEY, this.configKey), this.embedded_form_viewed_key_prefix = "pushowl_embedded_form_viewed"
    }
    get config() {
        var e = window.sessionStorage.getItem(this.configKey),
            t = null;
        if (e) try {
            t = JSON.parse(e)
        } catch (e) {
            t = null
        }
        return t
    }
    set config(e) {
        var t = "string" == typeof e ? e : JSON.stringify(e);
        window.sessionStorage.setItem(this.configKey, t)
    }
    get isPermissionNotGranted() {
        return "true" === window.sessionStorage.getItem(this.permissionKey)
    }
    set isPermissionNotGranted(e) {
        window.sessionStorage.setItem(this.permissionKey, e), window.localStorage.setItem(this.permissionKey, e)
    }
    get subscriptionVerified() {
        return !!window.sessionStorage.getItem(this.subscriptionVerifiedKey)
    }
    set subscriptionVerified(e) {
        window.sessionStorage.setItem(this.subscriptionVerifiedKey, e)
    }
    get optinSeenCount() {
        return parseInt(window.sessionStorage.getItem(this.optinSeenCountKey) || 0, 10)
    }
    set optinSeenCount(e) {
        window.sessionStorage.setItem(this.optinSeenCountKey, e)
    }
    mark_embedded_form_viewed(e) {
        window.sessionStorage.setItem("".concat(this.embedded_form_viewed_key_prefix, "-").concat(e), !0)
    }
    has_viewed_embedded_form(e) {
        return "true" === window.sessionStorage.getItem("".concat(this.embedded_form_viewed_key_prefix, "-").concat(e))
    }
    static get installPromptSeenCount() {
        return parseInt(window.sessionStorage.getItem(u.STORAGE_KEYS.INSTALL_PROMPT_SEEN_COUNT) || 0, 10)
    }
    static set installPromptSeenCount(e) {
        window.sessionStorage.setItem(u.STORAGE_KEYS.INSTALL_PROMPT_SEEN_COUNT, e)
    }
    static get landingPageURL() {
        return sessionStorage.getItem(u.STORAGE_KEYS.LANDING_PAGE_URL)
    }
    static set landingPageURL(e) {
        sessionStorage.setItem(u.STORAGE_KEYS.LANDING_PAGE_URL, e)
    }
    static get referrer() {
        return sessionStorage.getItem(u.STORAGE_KEYS.REFERRER)
    }
    static set referrer(e) {
        sessionStorage.setItem(u.STORAGE_KEYS.REFERRER, e)
    }
    static get landingPageURLParams() {
        return sessionStorage.getItem(u.STORAGE_KEYS.LANDING_PAGE_URL_PARAMS)
    }
    static set landingPageURLParams(e) {
        sessionStorage.setItem(u.STORAGE_KEYS.LANDING_PAGE_URL_PARAMS, e)
    }
    static set windowVariablesForOwly(e) {
        sessionStorage.setItem(u.STORAGE_KEYS.PUSHOWL_SUBDOMAIN, e)
    }
}
const G = e => e.startsWith("https://") ? e : e.replace("//cdn.shopify.com", "https://cdn.shopify.com"),
    K = e => "object" == typeof e && null !== e && "src" in e ? G(e.src) : "string" == typeof e ? G(e) : null;
class V extends class {
    constructor() {}
} {
    constructor(e) {
        super(), this.id = e.id, this.name = e.name, this.price = e.price / 100, this.available = e.available, this.featured_image = K(e.featured_image)
    }
}
class q extends class {
    constructor() {}
    currentVariant() {}
} {
    constructor(e) {
        super(), this.id = e.id, this.title = e.title, this.featured_image = K(e.featured_image), this.price = _e(e.price);
        const t = e.variants;
        this.variants = t.map((e => new V(e)))
    }
    getVariant(e) {
        return e = parseInt(e), this.variants.find((t => t.id == e))
    }
    currentVariant() {
        const e = oe("variant");
        if (!e) {
            for (const e of this.variants)
                if (e.available) return e;
            return this.variants[0]
        }
        return this.getVariant(e)
    }
}
const W = /checkouts\/c\/([^\/]*)\/thank_you/;
class $ extends class {
    constructor() {
        this.product = null
    }
    static get section() {
        return "home"
    }
    static get productAlias() {
        return "all"
    }
    static get customerId() {}
    static getCart() {}
    getProductDetails(e = !1, t) {}
    getRawCurrentProductDetails() {}
} {
    constructor() {
        super(), this.productCache = {}
    }
    static get section() {
        try {
            let {
                pageType: e
            } = window.ShopifyAnalytics.meta.page;
            if (e) return e !== g.PRODUCT && /\/products\/(\S)/.test(location.pathname) && (e = g.PRODUCT), e
        } catch (e) {}
        if (void 0 !== window.Shopify && window.Shopify.Checkout && ("thank_you" === window.Shopify.Checkout.page || "checkout_one_thank_you" === window.Shopify.Checkout.page)) return g.THANK_YOU;
        const {
            hostname: e
        } = location, t = location.pathname, i = t.split("/")[0], n = t.split("/")[1];
        if (W.test(t)) return g.THANK_YOU;
        if ("" === i) return g.HOME;
        if (i === w.CART) return g.CART;
        if (i === w.ACCOUNT && n === w.ORDERS) return g.ORDER;
        if ("account" === i && !i) return g.ORDERS;
        if ("checkout.shopify.com" === e || "checkouts" === n || t.indexOf("checkouts") >= 0) return g.CHECKOUT;
        if (void 0 !== window.__st && window.__st.s) {
            const e = window.__st.s.split("-")[0];
            if ("collections" === e) return g.COLLECTION;
            if ("products" === e) return g.PRODUCT
        }
    }
    static get productAlias() {
        let e = location.pathname.split("/");
        e = e.filter((e => e));
        const t = e.map((e => e.toLocaleLowerCase())).lastIndexOf("products");
        return -1 === t ? "" : e[t + 1]
    }
    static get customerId() {
        if ("headless" === B.mode) return window.pushowl ? window.pushowl.customerId : "";
        let e = null;
        return void 0 !== window.__st && window.__st.cid ? e = window.__st.cid : void 0 !== window.Shopify && void 0 !== window.Shopify.checkout && window.Shopify.checkout.customer_id && (e = window.Shopify.checkout.customer_id.toString()), e
    }
    static getCart() {
        return ae({
            url: `/cart.js?random=${Date.now()}`
        }).then((e => (e.updated_at = (new Date).toISOString(), e)), (() => "Cart API failed"))
    }
    static get pageName() {
        const e = window.location.pathname.match(/\/pages\/([a-z0-9_-]+)$/);
        return e ? e[1] : void 0
    }
    static get collectionName() {
        const e = window.location.pathname.match(/collections\/([a-z0-9_-]+)$/);
        return e ? e[1] : void 0
    }
    static get collectionId() {
        return window.ShopifyAnalytics && window.ShopifyAnalytics.meta && window.ShopifyAnalytics.meta.page ? window.ShopifyAnalytics.meta.page.resourceId : null
    }
    getProductDetails(e = !1, t) {
        const i = t || $.productAlias;
        return this.productCache[i] && !e ? Promise.resolve(this.productCache[i]) : ae({
            url: `/products/${i}.js`
        }).then((e => this.productCache[i] = new q(e)))
    }
    getRawCurrentProductDetails() {
        return Promise.resolve(window.ShopifyAnalytics.meta.product)
    }
}

function Q(e, t) {
    window.sib && window.sib[e] ? window.sib[e](...t) : window.sib.equeue.push({
        [e]: t
    })
}
class J {
    static loadTracker({
        isNewTracker: e,
        maKey: t
    }) {
        if (e) {
            const e = document.createElement("script");
            return e.type = "text/javascript", e.async = !0, e.src = "https://cdn.brevo.com/js/sdk-loader.js", document.body.appendChild(e), window.Brevo = window.Brevo || [], window.Brevo.push(["init", {
                client_key: t
            }]), !0
        }
        return window.sib = {
            equeue: [],
            client_key: t
        }, window.sendinblue = {
            ecommerce: {}
        }, c.forEach((function(e) {
            const t = e.name;
            e.isEcommerce ? window.sendinblue.ecommerce[t] = (...e) => {
                Q(t, e)
            } : window.sendinblue[t] = (...e) => {
                Q(t, e)
            };
            const i = document.createElement("script");
            i.type = "text/javascript", i.id = "sendinblue-js", i.async = !0, i.src = `https://sibautomation.com/sa.js?key=${window.sib.client_key}`, document.body.appendChild(i)
        })), !0
    }
    static set emailId(e) {
        window.sib ? window.sib.email_id = e : window.Brevo && (window.Brevo.email_id = e)
    }
    static get emailId() {
        return window.sib ? window.sib.email_id : window.Brevo ? window.Brevo.email_id : null
    }
}
J.track = ({
    eventName: e,
    eventData: t
}) => {
    try {
        const i = new z,
            n = {};
        if (i.config.privacy && $.customerId && (n.customerId = $.customerId), j.email && (n.email = j.email), "enabled" !== i.config.flags.brevo_email) return;
        window.sendinblue ? window.sendinblue.track(e, n, t) : window.Brevo && window.Brevo.push(["track", e, n, t])
    } catch (e) {
        we("Error in brevoTrack", e)
    }
}, J.identify = (e, t) => {
    window.sendinblue ? window.sendinblue.identify(e, t) : window.Brevo && window.Brevo.push((function() {
        window.Brevo.identify({
            identifiers: {
                email_id: e
            },
            attributes: t
        })
    }))
}, J.viewPage = e => {
    window.sendinblue ? window.sendinblue.page(e) : window.Brevo && window.Brevo.push(["page", e || window.location.pathname])
}, J.viewCategory = e => {
    window.sendinblue ? window.sendinblue.ecommerce.viewCategory(String(e)) : window.Brevo && window.Brevo.push(["viewCategory", String(e)])
}, J.search = (e, t) => {
    window.sendinblue ? window.sendinblue.ecommerce.search(e, t) : window.Brevo && window.Brevo.push(["search", e, t])
}, J.viewProduct = e => {
    window.sendinblue ? window.sendinblue.ecommerce.viewProduct(String(e)) : window.Brevo && window.Brevo.push(["viewProduct", String(e)])
};
const Z = function() {
    function e(e) {
        e = e || {};
        const t = {
            url: location.href,
            headers: {
                "User-Agent": navigator.userAgent
            }
        };
        return {
            event_id: "xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx".replace(/[xy]/g, (function(e) {
                var t = 16 * Math.random() | 0;
                return ("x" === e ? t : 3 & t | 8).toString(16)
            })),
            platform: "javascript",
            release: "b8b8cbe",
            extra: e,
            request: t
        }
    }

    function t(e) {
        return Math.random() < .95 ? Promise.resolve() : fetch("https://o79286.ingest.sentry.io/api/1527936/store/?sentry_version=7&sentry_key=8f53de1cdf86490fb8e55518e1a5d035", {
            method: "post",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(e)
        })
    }

    function i(i, n) {
        const o = e(n);
        return o.message = i, t(o)
    }
    return {
        log: i,
        logException: function(n, o) {
            if (n) try {
                (o = o || {}).errorDump = {
                    str: String(n),
                    stack: n && n.stack
                };
                const i = e(o);
                return i.exception = function(e) {
                    const t = e.stack || "";
                    if (!t) return;
                    const i = t.split("\n").map((e => e.trim())).filter((e => e.startsWith("at"))).map((function(e) {
                        let t = "",
                            i = 0,
                            n = 0,
                            o = "";
                        const r = e.split(/[ ]+/);
                        if ("at" === r[0].trim() && r.length > 1) {
                            let e = "";
                            r.length > 2 ? (t = r[1], e = r[2]) : e = r[1], e = e.replace("(", "").replace(")", "");
                            const s = e.split(":");
                            s.length > 1 && (i = parseInt(s[s.length - 1], 0), n = parseInt(s[s.length - 2], 0), o = s.slice(0, s.length - 2).join(":"))
                        }
                        return {
                            in_app: !0,
                            function: t,
                            colno: Number(i) || i,
                            lineno: Number(n) || n,
                            filename: o
                        }
                    }));
                    return i.reverse(), {
                        values: [{
                            type: e.name || "Error",
                            value: e.message || String(e),
                            stacktrace: {
                                frames: i
                            }
                        }]
                    }
                }(n), t(i)
            } catch (e) {
                i(String(e), e), i(String(n), n)
            }
        }
    }
}();

function X({
    position: e,
    device: t,
    customConfig: i,
    isExpanded: n
}) {
    if ("desktop" === t) {
        const t = "15px",
            o = "15px",
            r = "15px",
            s = "15px",
            a = 68,
            c = `calc(50% - ${568}px / 2)`,
            u = `calc(50% - ${a}px / 2)`,
            l = `calc(50% - ${a}px / 2)`;
        if (i.hasOwnProperty("bottom") && 25 === i.bottom && 15 === i.left && "auto" === i.right) switch (e) {
            case "bottom-left":
                return {
                    bottom: o,
                    left: r
                };
            case "bottom-right":
                return {
                    bottom: o,
                    right: s
                };
            case "bottom-center":
                return n ? {
                    bottom: o,
                    left: c
                } : {
                    bottom: o,
                    left: u
                };
            case "top-left":
                return {
                    top: t,
                    left: r
                };
            case "top-right":
                return {
                    top: t,
                    right: s
                };
            case "top-center":
                return n ? {
                    top: t,
                    left: c
                } : {
                    top: t,
                    left: u
                };
            case "center-left":
                return {
                    top: l,
                    left: r
                };
            case "center-right":
                return {
                    top: l,
                    right: s
                };
            default:
                return i
        }
        let d = {
            left: r
        };
        for (let e in i) d[e] = `${i[e]}px`;
        return d
    }
    if ("mobile" === t) {
        const t = "8px",
            n = "8px",
            o = "8px",
            r = "8px",
            s = `calc(50% - ${48}px / 2)`;
        if (i.hasOwnProperty("bottom") && i.hasOwnProperty("left") && 15 === i.bottom && 15 === i.left) switch (e) {
            case "bottom-left":
                return {
                    bottom: n,
                    left: o
                };
            case "bottom-right":
                return {
                    bottom: n,
                    right: r
                };
            case "top-left":
                return {
                    top: t,
                    left: o
                };
            case "top-right":
                return {
                    top: t,
                    right: r
                };
            case "center-left":
                return {
                    top: s,
                    left: o
                };
            case "center-right":
                return {
                    top: s,
                    right: r
                };
            default:
                return i
        }
        let a = {
            isCustomConfig: !0
        };
        for (let e in i) a[e] = `${i[e]}px`;
        return a
    }
}

function ee(e) {
    let t = document.implementation.createHTMLDocument();
    return t.body.innerHTML = e, t.body.children[0]
}

function te() {
    let e = navigator.userAgent;
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Mobile|mobile|CriOS/i.test(e)
}

function ie() {
    try {
        return Intl.DateTimeFormat().resolvedOptions().timeZone
    } catch (e) {
        return null
    }
}

function ne(e) {
    return [...new URLSearchParams(e).entries()].reduce(((e, [t, i]) => Object.assign(Object.assign({}, e), {
        [t]: i
    })), {})
}

function oe(e, t = null) {
    t || (t = window.location.href);
    return ne(new URL(t).search)[e]
}

function re() {
    let t = navigator.userAgent,
        i = t.search("Firefox") >= 0,
        n = !!window.chrome;
    const o = void 0 !== window.PushManager,
        r = (({
            ua: e,
            maxTouchPoints: t
        }) => {
            if (!(/iPad|iPhone|iPod|Mac OS X/.test(e) && t > 0)) return !1;
            const i = e.match(/EdgiOS\/(\d+\.\d+)/);
            if (i && i.length >= 2) return parseFloat(i[1]) >= 112;
            const n = e.match(/Version\/(\d+\.\d+)/);
            if (n && n.length >= 2) return parseFloat(n[1]) >= 16.4;
            const o = e.match(/CPU iPhone OS (\d+_\d+)/);
            if (o && o.length >= 2) return parseFloat(o[1].replace("_", ".")) >= 16.4;
            return !1
        })({
            ua: t,
            maxTouchPoints: navigator.maxTouchPoints
        });
    let s = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream && !r,
        a = !!window.safari;
    return {
        isiOS: r,
        isSafari: a,
        isApnsSafari: a && !o,
        isFirefox: i,
        isChrome: n,
        isOldIOS: s,
        name: n ? e.CHROME : a ? e.SAFARI : i ? e.FIREFOX : e.OTHER,
        isAndroid: /(android)/i.test(t.toLowerCase())
    }
}

function se(e) {
    const t = (e + "=".repeat((4 - e.length % 4) % 4)).replace(/\-/g, "+").replace(/_/g, "/"),
        i = window.atob(t),
        n = new Uint8Array(i.length);
    for (let e = 0; e < i.length; ++e) n[e] = i.charCodeAt(e);
    return n
}

function ae({
    method: e = "GET",
    url: t,
    contentType: i = "application/json",
    acceptType: n = "application/json",
    payload: o
}) {
    return new Promise(((r, s) => {
        let a = new XMLHttpRequest;
        a.open(e, t, !0), a.setRequestHeader("Content-Type", i), a.setRequestHeader("Accept", n), o ? a.send(i.match(/json/) ? JSON.stringify(o) : o) : a.send(), a.onload = function() {
            let e = a.responseText;
            if (a.status >= 200 && a.status < 400) {
                const t = n.match(/json/) ? JSON.parse(e) : e;
                r(t)
            } else s(e)
        }
    }))
}

function ce(e = 7) {
    for (var t = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-", i = "", n = e; n--;) i += t[~~(Math.random() * t.length)];
    return i
}

function ue({
    name: e,
    value: t
}) {
    document.cookie = `${e}=${encodeURIComponent(t)};domain=${window.location.hostname}`
}

function le({
    name: e,
    value: t,
    days: i = 1,
    path: n = "/"
}) {
    const o = new Date(Date.now() + 864e5 * i).toUTCString();
    document.cookie = e + "=" + encodeURIComponent(t) + "; expires=" + o + "; path=" + n
}

function de(e) {
    return document.cookie.split("; ").reduce(((t, i) => {
        const n = i.split("=");
        return n[0] === e ? decodeURIComponent(n[1]) : t
    }), "")
}

function pe(e, t) {
    le({
        name: e,
        value: "",
        days: -1,
        path: t
    })
}

function he() {
    const e = document.createElement("div");
    return document.body.appendChild(e), "rtl" === window.getComputedStyle(e).direction
}
const ge = [];

function we(...e) {
    const t = console;
    ge.push(e), (localStorage.getItem("pushowl_log_level") === s.DEBUG || location.href.match(/poTaskType=debug/)) && t.log("%c🦉PushOwl", "background: #fb446a; color: white; padding: 2px 0.5em; border-radius: 0.5em;", ...e)
}

function me(e, t) {
    const i = console;
    ge.push([e, t]), (localStorage.getItem("pushowl_log_level") === s.DEBUG || location.href.match(/poTaskType=debug/)) && (e && we(e), i.table(t))
}

function be() {
    const [e, t] = navigator.language.split("-");
    return {
        language: e,
        region: t
    }
}

function fe(e, t = {}) {
    if (navigator.userAgent.match(/Instagram|FBAN/)) return;
    if (k(e)) return;
    if ([n.NOTIFICATION_NOT_DEFINED, n.OLD_IOS_DEVICE, n.MICROSOFT_EDGE, n.NO_SERVICE_WORKER, n.INCOGNITO, n.NO_FILE_SYSTEM, n.LOCALSTORAGE_NOT_AVAILABLE].includes(e)) return;
    let i = "";
    window.pushowl && (i = window.pushowl.getSubdomain ? window.pushowl.getSubdomain() : window.pushowl.subdomain), Z.logException("string" == typeof e ? new Error(e) : e, Object.assign({
        breadcrumbs: ge,
        subdomain: i,
        url: window.location.href
    }, t))
}
const _e = e => "number" == typeof e ? e / 100 : e,
    Se = e => {
        const t = (e => 2 === Object.keys(e).length && e.hasOwnProperty("items") && (e.hasOwnProperty("token") || e.hasOwnProperty("checkout_token")))(e),
            i = {
                id: void 0,
                data: void 0,
                checkout_url: void 0
            },
            n = 0 === e.item_count ? a.CART_DELETED : a.CART_UPDATED,
            o = !t && e.id ? e.id : e.token || e.checkout_token;
        if (o && (i.id = `cart:${o}`, i.data = e.id && !t ? e : (e => ({
                affiliation: B.subdomain,
                currency: _e(e.currency),
                discount: _e(e.total_discount),
                total: _e(e.total_price),
                discount_taxinc: "",
                items: e.items.map((e => ({
                    available_now: !0,
                    category: null,
                    description_short: e.product_description,
                    disc_amount: _e(e.discounted_price),
                    disc_amount_taxinc: "",
                    disc_rate: "",
                    id: e.id,
                    image: e.image,
                    name: e.title,
                    price: _e(e.price),
                    price_predisc: "",
                    price_predisc_taxinc: "",
                    price_taxinc: "",
                    quantity: e.quantity,
                    size: "",
                    sku: e.sku,
                    tax_amount: "",
                    tax_name: "",
                    tax_rate: "",
                    url: `${window.location.origin}${e.url}`,
                    variant_id: e.variant_id,
                    variant_id_name: e.variant_title
                }))),
                shipping: "",
                shipping_taxinc: "",
                subtotal: "",
                subtotal_predisc: "",
                subtotal_predisc_taxinc: "",
                subtotal_taxinc: "",
                tax: "",
                total_before_tax: "",
                url: `${window.location.origin}/cart`
            }))(e)), n === a.CART_UPDATED && (i || {}).data) {
            const e = i.data.items.reduce(((e, t) => e ? `${e},${t.variant_id}:${t.quantity}` : `${t.variant_id}:${t.quantity}`), "");
            i.data.checkout_url = `${window.location.origin}/cart/${e}`
        }
        J.track({
            eventName: n,
            eventData: i
        })
    },
    ve = e => {
        try {
            const t = new URL(e),
                i = new URLSearchParams(t.search),
                n = new URLSearchParams;
            return i.forEach(((e, t) => {
                t.startsWith("utm_") || n.append(t, e)
            })), t.search = n.toString(), t.toString()
        } catch (t) {
            return e
        }
    };

function ye(e, t) {
    var i = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(e);
        t && (n = n.filter((function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable
        }))), i.push.apply(i, n)
    }
    return i
}

function Ee(e) {
    for (var t = 1; t < arguments.length; t++) {
        var i = null != arguments[t] ? arguments[t] : {};
        t % 2 ? ye(Object(i), !0).forEach((function(t) {
            Oe(e, t, i[t])
        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(i)) : ye(Object(i)).forEach((function(t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(i, t))
        }))
    }
    return e
}

function Ie(e) {
    var t = function(e, t) {
        if ("object" != typeof e || !e) return e;
        var i = e[Symbol.toPrimitive];
        if (void 0 !== i) {
            var n = i.call(e, t || "default");
            if ("object" != typeof n) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }
        return ("string" === t ? String : Number)(e)
    }(e, "string");
    return "symbol" == typeof t ? t : t + ""
}

function Te(e, t, i, n, o, r, s) {
    try {
        var a = e[r](s),
            c = a.value
    } catch (e) {
        return void i(e)
    }
    a.done ? t(c) : Promise.resolve(c).then(n, o)
}

function Ne(e) {
    return function() {
        var t = this,
            i = arguments;
        return new Promise((function(n, o) {
            var r = e.apply(t, i);

            function s(e) {
                Te(r, n, o, s, a, "next", e)
            }

            function a(e) {
                Te(r, n, o, s, a, "throw", e)
            }
            s(void 0)
        }))
    }
}

function Oe(e, t, i) {
    return (t = Ie(t)) in e ? Object.defineProperty(e, t, {
        value: i,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = i, e
}

function Me(e, t) {
    if (null == e) return {};
    var i, n, o = function(e, t) {
        if (null == e) return {};
        var i, n, o = {},
            r = Object.keys(e);
        for (n = 0; n < r.length; n++) i = r[n], t.indexOf(i) >= 0 || (o[i] = e[i]);
        return o
    }(e, t);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(e);
        for (n = 0; n < r.length; n++) i = r[n], t.indexOf(i) >= 0 || Object.prototype.propertyIsEnumerable.call(e, i) && (o[i] = e[i])
    }
    return o
}
class Ce {
    static _request(e) {
        return O(this, void 0, void 0, (function*() {
            return yield x(e)
        }))
    }
    static get(e) {
        return this._request(Object.assign(Object.assign({}, e), {
            method: "GET"
        }))
    }
    static post(e) {
        return this._request(Object.assign(Object.assign({}, e), {
            method: "POST"
        }))
    }
    static put(e) {
        return this._request(Object.assign(Object.assign({}, e), {
            method: "PUT"
        }))
    }
}
class Ae {
    static createRequestObj(e) {
        let t = e;
        return void 0 === e.id && (t = Object.assign({
            id: ce()
        }, e)), t
    }
    static _retryRequest(e) {
        return O(this, void 0, void 0, (function*() {
            const t = Object.assign(Object.assign({}, e), {
                retryCount: ((null == e ? void 0 : e.retryCount) || 0) + 1
            });
            if (t.retryCount > 5) {
                return fe("APIRequestSimpleRetry", {
                    request: t,
                    connectionType: navigator.connection ? navigator.connection.effectiveType : "NA"
                }), Promise.reject()
            }
            const i = this.createRequestObj(t);
            setTimeout((() => {
                this._request(i)
            }), 1e3 * i.retryCount)
        }))
    }
    static _request(e) {
        return O(this, void 0, void 0, (function*() {
            try {
                return yield x(e)
            } catch (t) {
                if (k(t)) return this._retryRequest(e);
                fe("APIRequestSimpleRetryError", {
                    error: t,
                    request: e
                }), Promise.reject(t)
            }
        }))
    }
    static get(e) {
        return this._request(Object.assign(Object.assign({}, e), {
            method: "GET"
        }))
    }
    static post(e) {
        return this._request(Object.assign(Object.assign({}, e), {
            method: "POST"
        }))
    }
    static put(e) {
        return this._request(Object.assign(Object.assign({}, e), {
            method: "PUT"
        }))
    }
}
class Le {
    constructor() {
        var {
            subdomain: e
        } = B;
        this.endpoint = B.apiEndpoint, this.subscriber_refresh_endpoint = "".concat(this.endpoint, "/api/v1/accounts/").concat(e, "/subscriber/refresh/"), this.checkout_sync_endpoint = "".concat(this.endpoint, "/api/v1/").concat(e, "/subscriber/event/checkout-sync/"), H.set("subscriber_refresh_endpoint", this.subscriber_refresh_endpoint), z.landingPageURL || (z.landingPageURL = document.URL), z.referrer || (z.referrer = document.referrer), z.landingPageURLParams || (z.landingPageURLParams = window.location.search), j.originalURLParams || (j.originalURLParams = window.location.search)
    }
    config() {
        return "headless" === B.mode ? Ce.get({
            path: "/subscriber/config/widget/?guid=".concat(B.guid)
        }) : Ae.get({
            url: "".concat(B.configApiEndpoint, "/api/v1/").concat(B.subdomain, "/subscriber/config/widget/?guid=").concat(B.guid)
        })
    }
    sendSubscription(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
            i = arguments.length > 2 ? arguments[2] : void 0,
            o = arguments.length > 3 ? arguments[3] : void 0,
            r = arguments.length > 4 ? arguments[4] : void 0,
            s = new z;
        if (s.config && s.config.flags && "enabled" === s.config.flags.disable_resync && t) return Promise.reject(n.DISABLED_RESYNC);
        var a = {};
        z.landingPageURLParams.slice(1).split("&").filter((e => e.includes("utm_"))).forEach((e => {
            var [t, i] = e.split("=");
            a[t] = i
        }));
        var c = {};
        j.originalURLParams.slice(1).split("&").filter((e => e.includes("po_"))).forEach((e => {
            var [t, i] = e.split("=");
            c[t] = i
        }));
        var u = window.location.href,
            l = new URLSearchParams(window.location.search),
            d = !0;
        if (l.get("po_url") && (d = !1, u = l.get("po_url")), re().isOldIOS) return we("PushOwl does not support iOS before 16.4", "platform: ".concat(navigator.platform), "Browser: ".concat(re().name)), Promise.reject(n.OLD_IOS_DEVICE);
        var p = {
            subscription: e,
            browser: re().name,
            previous_token: j.subscriberToken,
            website_push_id: i || B.webPushId,
            customer_id: s.config.privacy ? $.customerId : null,
            language: window.navigator.language,
            timezone: ie(),
            dispatch_method: re().isApnsSafari ? "apns" : "vapid",
            user_agent: navigator.userAgent,
            guid: B.guid,
            optin_seen_count: s.optinSeenCount,
            context: Ee(Ee({
                isPushowlThemeAppExtentionEnabled: !!window.isPushowlThemeAppExtentionEnabled,
                isiOS: re().isiOS,
                is_resync: t,
                subscribe_url: u,
                session_token: j.sessionToken,
                visitor_token: j.visitorToken,
                sib_visitor_id: B.visitorId,
                widget_source: window.poSubscriptionSource,
                worker_available: d
            }, a), {}, {
                permanent: Ee({}, c),
                temporary: {
                    referrer: z.referrer,
                    landing_url: z.landingPageURL
                }
            }),
            source: o,
            source_id: r
        };
        return Ae.post({
            url: "".concat(B.apiEndpoint, "/api/v2/accounts/").concat(B.subdomain, "/subscribers/webpush/"),
            payload: p
        }).then((e => (e && e.result || we("Invalid /subscribe response. response:", e), e.result.token))).catch((() => Promise.reject("Send Subscription API Failed")))
    }
    refreshSubscription(e, t, i) {
        var o = {
            previous_token: e,
            previous_subscription: t,
            current_subscription: i
        };
        return o.context = {
            subscribe_url: window.location.href,
            session_token: j.sessionToken,
            visitor_token: j.visitorToken,
            sib_visitor_id: B.visitorId
        }, re().isOldIOS ? (we("PushOwl does not support iOS before 16.4", "platform: ".concat(navigator.platform), "Browser: ".concat(re().name)), Promise.reject(n.OLD_IOS_DEVICE)) : Ce.post({
            url: this.subscriber_refresh_endpoint,
            payload: o
        }).then((e => e.result.token)).catch((() => Promise.reject("Refresh Subscription API Failed")))
    }
    syncSubscriber() {
        var e = {
            data: [{
                key: "customer_id",
                value: $.customerId
            }],
            token: j.subscriberToken,
            context: {
                subscribe_url: window.location.href,
                session_token: j.sessionToken,
                visitor_token: j.visitorToken
            }
        };
        return Ae.put({
            url: "".concat(B.apiEndpoint, "/api/v1/accounts/").concat(B.subdomain, "/subscriber/"),
            payload: e
        })
    }
    syncCart(e, t) {
        var i = new z,
            n = {
                subscriber_token: j.subscriberToken,
                customer_id: i.config.privacy ? t || $.customerId : null,
                browser: re().name,
                cart_json: e,
                origin: window.location.origin,
                store_root: ((window.Shopify || {}).routes || {}).root || "/"
            };
        return Ce.post({
            path: "/subscriber/event/cart-sync/",
            payload: n
        })
    }
    syncProductView(e) {
        e.variants && e.variants.length > 0 && (e.variants[0].price = _e(e.variants[0].price));
        var t = {
            subscriber_token: j.subscriberToken,
            session: j.sessionToken,
            viewed_time: ~~(Date.now() / 1e3),
            product_data: e,
            store_root: ((window.Shopify || {}).routes || {}).root || "/"
        };
        return Ce.post({
            path: "/subscriber/event/product-view/",
            payload: t
        })
    }
    sendEvent(e, t) {
        return Ne((function*() {
            return Ae.post({
                path: "/subscriber/event/".concat(e, "/"),
                payload: t
            }).catch((e => Promise.reject("Event Update failed")))
        }))()
    }
    unsubscribe(e) {
        return U.post({
            url: "".concat(B.apiEndpoint, "/api/v1/accounts/").concat(B.subdomain, "/subscriber/unsubscribe/"),
            payload: {
                token: e,
                sib_visitor_id: B.visitorId
            }
        })
    }
    syncSubscriberTokenAndCheckoutId(e) {
        var t = JSON.stringify({
            subscriber_token: j.subscriberToken,
            checkout_token: e
        });
        navigator.sendBeacon(this.checkout_sync_endpoint, t)
    }
    debugLog(e) {
        return U.post({
            path: "/subscriber/debug/",
            payload: e
        })
    }
    subscribeThroughPopup(e) {
        var {
            subscriptionData: t,
            flowId: i,
            nodeId: n,
            source: o = "optin_flows"
        } = e, r = {
            subscription_data: t,
            token: j.subscriberToken,
            source: o,
            source_id: n
        };
        return Ce.post({
            path: "/dashboard/optin-flows/".concat(i, "/subscribers/"),
            payload: r
        })
    }
    identifyBrevoContactThroughPhoneNumber(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
            i = (new z).config.brevo_ma_key,
            n = de("sib_cuid");
        if (i && n && e) {
            var o = j.email ? j.email : "".concat(e.replace(/\D/g, ""), "@mailin-sms.com");
            return J.emailId || (J.emailId = o), Ce.post({
                url: "https://in-automate.brevo.com/p",
                appendPlatform: !1,
                payload: {
                    key: i,
                    sib_type: "identify",
                    cuid: n,
                    ma_url: document.location.href,
                    contact: Ee(Ee({}, t), {}, {
                        sms: e
                    }),
                    email_id: o
                }
            })
        }
    }
}
class Pe {
    constructor(e) {
        this.inclusions = e.inclusions, this.exclusions = e.exclusions
    }
}
class ke {
    constructor(e) {
        this.url = new Pe(e.url)
    }
    processCondition(e, t) {
        var i = t.inclusions,
            n = t.exclusions;
        return i.some((t => new RegExp(t).test(e))) && !n.some((t => new RegExp(t).test(e)))
    }
    processUrlActivationRule() {
        try {
            var e = this.url,
                t = window.location.href,
                i = this.processCondition(t, e);
            return we("[Checking page url condition]", "Condition: ", this.url, " / Result: ".concat(i ? "✅" : "❌")), i
        } catch (e) {
            return !0
        }
    }
}
class De {
    constructor(e) {
        this.sku = e.sku || [], this.url = new Pe(e.url)
    }
    processCondition(e, t) {
        var i = t.inclusions,
            n = t.exclusions;
        return i.some((t => new RegExp(t).test(e))) && !n.some((t => new RegExp(t).test(e)))
    }
    processUrlActivationRule() {
        try {
            var e = this.url,
                t = window.location.href,
                i = this.processCondition(t, e);
            return we("[Checking page url condition]", "Condition: ", this.url, " / Result: ".concat(i ? "✅" : "❌")), i
        } catch (e) {
            return !0
        }
    }
    processSKU(e) {
        return this.sku.includes(e)
    }
}
class je {
    constructor(e) {
        this.flyout = new Ve(e.flyout)
    }
}
class Re {
    constructor(e) {
        this.type = e.type, e.config && (this.config = e.config, this.config.overlay = new xe(this.config.overlay))
    }
}
class xe {
    constructor(e) {
        this.enabled = e.enabled, this.title = e.title, this.subtitle = e.description || e.subtitle, this.branding = e.branding
    }
}
class Ue {
    constructor(e) {
        this.money_format = e.money_format
    }
}
class Be {
    constructor(e) {
        this.enabled = e.enabled, this.text = e.text
    }
}
class Ye {
    constructor(e) {
        this.unsubscribe = new Be(e.unsubscribe), this.access_data = new Be(e.access_data), this.delete_data = new Be(e.delete_data)
    }
}
class Fe {
    constructor(e) {
        this.enabled = e.enabled, this.message = e.message, this.actions = new Ye(e.actions)
    }
}
class He {
    constructor(e) {
        this.notification_preference = new Fe(e.notification_preference), this.customer_id = e.customer_id
    }
}
class ze {
    constructor(e) {
        this.bottom = e.bottom || 15, this.diameter = e.diameter || 68, this.left = e.left || 15, this.right = e.right || "auto"
    }
}
class Ge {
    constructor(e) {
        this.bottom = e.bottom || 15, this.left = e.left || 15, this.diameter = e.diameter || 48
    }
}
class Ke {
    constructor(e) {
        this.desktop = new ze(e.desktop), this.mobile = new Ge(e.mobile), this.color = e.color || "rgb(51, 51, 51)", this.overlay = e.overlay
    }
}
class Ve {
    constructor() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        this.enabled = e.enabled, this.is_viewed = e.is_viewed, this.title = e.title, this.buttonText = e.button_text || e.buttonText, this.postSubscriptionTitle = e.post_subscription_message || e.postSubscriptionTitle, this.theme = e.theme, this.position = e.position, this.overlay = e.overlay
    }
    static create_instance(e) {
        var t = new Ve;
        t.enabled = e.enabled, t.is_viewed = e.is_viewed;
        var i = e.metadata;
        return t.metadata = i, t.title = e.title || i.title, t.buttonText = e.buttonText || i.yes_button.text, t.postSubscriptionTitle = e.postSubscriptionTitle || i.post_subscription.post_subscription_widget.title, t
    }
}
class qe {
    constructor(e) {
        var t;
        e = this.preProcess(e), this.home = new je(e.home), this.optin = e.optin ? new Re(e.optin) : null, this.brevo_ma_key = e.brevo_ma_key, this.price_drop = Ve.create_instance(e.price_drop), this.back_in_stock = Ve.create_instance(e.back_in_stock), this.shop = new Ue(e.shop), this.abandoned_cart_enabled = e.abandoned_cart_enabled, this.browse_abandonment_enabled = e.browse_abandonment_enabled, this.optin_report_enabled = e.optin_report_enabled, this.is_beta = e.is_beta || !1, this.privacy = new He(e.privacy), this.vapid_public_key = e.vapid_public_key, this.activation_rule = e.activation_rule && new ke(e.activation_rule), this.automation_rule = e.automation_rule && new De(e.automation_rule), this.flyout_config = e.flyout_config && new Ke(e.flyout_config), this.branding = void 0 === e.branding || e.branding, this.logo = e.logo, this.flags = e.flags, this.wid = e.wid, this.integrations = e.integrations, this.website_push_id = e.website_push_id, this.service_worker = e.service_worker, this.ios_prompt = e.ios_prompt, this.optin_flows = e.optin_flows, this.subscription_confirmation = e.subscription_confirmation, this.embedded_forms = e.embedded_forms, this.is_free_plan = null !== (t = e.is_free_plan) && void 0 !== t && t
    }
    preProcess(e) {
        var t = void 0 === e.branding || e.branding;
        return e.optin && e.optin.config && e.optin.config.overlay && (e.optin.config.overlay.branding = t), e
    }
}
var We = {
    get(e) {
        var t = new z,
            i = new Le;
        return new Promise((n => {
            var o = e ? null : t.config,
                r = () => i.config().then((e => {
                    var i = new qe(e.result);
                    t.config = i, n(i), we("Config fetched: from backend.", i)
                })).catch((e => {
                    we("Error on fetching config", e), fe(e)
                }));
            if (o) {
                we("Config fetched: from local cache.", o);
                try {
                    n(new qe(o))
                } catch (e) {
                    r()
                }
            } else r()
        }))
    }
};

function $e(e) {
    var {
        subdomain: t
    } = e;
    return new Promise(((e, i) => {
        "undefined" == typeof Storage && i(n.STORAGE_NOT_DEFINED), !0 !== function() {
            let e = "test";
            try {
                return localStorage.setItem(e, e), localStorage.removeItem(e), !0
            } catch (e) {
                return !1
            }
        }() && i(n.LOCALSTORAGE_NOT_AVAILABLE), /Edge/.test(navigator.userAgent) && i(n.MICROSOFT_EDGE), t || i(n.NO_SUBDOMAIN), e()
    }))
}
var Qe = () => void 0 === window.Notification ? (we(n.NOTIFICATION_NOT_DEFINED), !1) : re().isOldIOS || re().isApnsSafari || "serviceWorker" in navigator ? re().isOldIOS ? (we(n.OLD_IOS_DEVICE), !1) : !(re().isiOS && !navigator.standalone) || (we(n.NOT_ADDED_TO_HOME_SCREEN), !1) : (we(n.NO_SERVICE_WORKER), !1);

function Je(e, t, i) {
    var n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null,
        o = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null,
        r = new Le;
    return new Promise(((s, a) => {
        r.sendSubscription(e, t, i, n, o).then((t => {
            j.handlePostSubscription(e, t), ue({
                name: u.STORAGE_KEYS.SUBSCRIBER_TOKEN,
                value: t
            }), s(t)
        })).catch((e => {
            we("🔴 Send Subscription Failed", e), a(e)
        }))
    }))
}
var Ze = {
        validateOrSyncSubscription(e) {
            var {
                subscription: t,
                websitePushId: i
            } = e;
            return new Promise(((e, n) => {
                var o = j.subscription;
                if (o)
                    if (t.endpoint === o.endpoint) e();
                    else {
                        var r = new Le;
                        we("Refreshing old subscription on server..."), r.refreshSubscription(j.subscriberToken, o, t).then((i => {
                            j.handlePostSubscription(t, i), ue({
                                name: u.STORAGE_KEYS.SUBSCRIBER_TOKEN,
                                value: i
                            }), e()
                        })).catch((e => {
                            n(e)
                        }))
                    }
                else we("Syncing new subscription to server"), Je(t, !1, i).then(e)
            }))
        },
        verifySubscriber(e) {
            var {
                browserHandler: t
            } = e, i = new z;
            return we("Verifying subscriber..."), new Promise(((e, n) => {
                j.subscriberToken ? j.subscriberToken.match(/failed/i) ? (we("🔴 Subscriber could not be verified. Reason: ", o.INVALID_SUBSCRIBER_TOKEN), n(o.INVALID_SUBSCRIBER_TOKEN)) : i.subscriptionVerified ? e() : re().isApnsSafari ? t.isPermissionGranted ? e() : n() : B.isWorkerAvailable.then((i => {
                    i ? t.getSubscription().then((t => {
                        this.validateOrSyncSubscription({
                            subscription: t
                        }).then((() => {
                            e(), we("🟢 Subscriber verified.")
                        })).catch((() => {
                            n(), we("🔴 Subscriber could not be verified.")
                        }))
                    })).catch(((e, t) => {
                        n(e, t), we("🔴 Subscription could not be fetched.", e, t)
                    })) : t.isPermissionGranted ? e() : n()
                })) : (n(o.NO_SUBSCRIBER_TOKEN), we("🔴 Subscriber could not be verified. Reason: ", o.NO_SUBSCRIBER_TOKEN))
            }))
        },
        handleSubscription(e) {
            var {
                browserHandler: t,
                resolve: i,
                reject: n,
                areWeResyncing: o,
                websitePushId: r,
                showHintScreenOnError: s,
                hintscreenHandler: a,
                enableHintScreen: c,
                source: u,
                source_id: l
            } = e, d = new z, p = new Date;
            t.getSubscription().then((e => {
                c && a.purge(), Je(e, o, r, u, l).then((() => {
                    var {
                        subscriberToken: e
                    } = j;
                    i({
                        subscriberToken: e
                    }), new BroadcastChannel("pushowl").postMessage({
                        subscriberToken: e,
                        subdomain: B.subdomain
                    })
                })).catch(n), o ? we("🟢 Resync-subscription successfull. (bcoz permission was granted but didn't have a valid subscription)", e) : (we("🟢 Subscription successfull", e), document.dispatchEvent(new Event("SubscribedToPushOwl")), this.trackBrowserPromptAnalytics(new Date - p, "allowed"))
            })).catch((e => {
                a && a.purge(), s && a.show(), d.isPermissionNotGranted = !0, we("🔴 Subscription failed", e), o || this.trackBrowserPromptAnalytics(new Date - p, e), n(e)
            }))
        },
        subscribe(e) {
            var {
                enableHintScreen: t = !1,
                hintScreenData: i = null,
                showHintScreenOnError: n = !1,
                websitePushId: o,
                browserHandler: r,
                source: s,
                source_id: a
            } = e, c = new z, u = r.isPermissionGranted;
            return new Promise(((e, l) => {
                var d;
                t ?
                    import ("./PushowlHintScreenHandler.js").then((p => {
                        var {
                            PushowlHintScreenHandler: h
                        } = p;
                        (d = new h({
                            onDismiss: () => {
                                c.isPermissionNotGranted = !0, c.config.optin_report_enabled && window.poAnalytics.track("BrowserPromptOverlayDismissed", {
                                    optinSeenCount: c.optinSeenCount
                                })
                            }
                        })).show(i), this.handleSubscription({
                            browserHandler: r,
                            resolve: e,
                            reject: l,
                            areWeResyncing: u,
                            websitePushId: o,
                            showHintScreenOnError: n,
                            hintscreenHandler: d,
                            enableHintScreen: t,
                            source: s,
                            source_id: a
                        })
                    })) : this.handleSubscription({
                        browserHandler: r,
                        resolve: e,
                        reject: l,
                        areWeResyncing: u,
                        websitePushId: o,
                        showHintScreenOnError: n,
                        hintscreenHandler: null,
                        enableHintScreen: t,
                        source: s,
                        source_id: a
                    })
            })).catch((e => {
                we("Error encountered in loading Pushowl Hint Screen: ".concat(e.message))
            }))
        },
        subscribeIfNotAlready(e) {
            var {
                enableHintScreen: t = !1,
                showHintScreenOnError: i = !0,
                websitePushId: n,
                browserHandler: o,
                hintScreenData: r = null
            } = e;
            return new Promise(((e, s) => {
                o.isPermissionGranted ? j.subscriberToken ? e(!0) : this.subscribe({
                    enableHintScreen: !1,
                    showHintScreenOnError: !1,
                    websitePushId: n,
                    browserHandler: o,
                    hintScreenData: r
                }).then((() => e(!0))).catch((e => s(e))) : this.subscribe({
                    enableHintScreen: t,
                    showHintScreenOnError: i,
                    websitePushId: n,
                    browserHandler: o,
                    hintScreenData: r
                }).then((() => e(!0))).catch((e => s(e)))
            }))
        },
        update(e, t) {
            var i = new Le;
            return t.subscriber_token = j.subscriberToken, i.sendEvent(e, t)
        },
        subscribeProduct(e) {
            var {
                context: t,
                automation: i,
                product: n,
                variant: o,
                source: r
            } = e;
            return this.subscribeIfNotAlready({
                enableHintScreen: !0,
                websitePushId: t.config.website_push_id,
                browserHandler: t.browserHandler
            }).then((() => this.update(i, {
                product_id: n.id,
                product: n,
                variant: o,
                source: r,
                permission: window.Notification && window.Notification.permission
            }).then((e => {
                var {
                    token: t
                } = e.result;
                t && (j.subscriberToken = t), we("Product subscribed for ".concat(i, ". Product ").concat(n.id, ". Variant ").concat(o.id, ". Source: ").concat(r))
            })).catch(fe)))
        },
        unsubscribe(e) {
            var t = new Le;
            e.isPermissionGranted ? t.unsubscribe(j.subscriberToken).then((() => {
                we("🟢 Unsubscription successfull")
            })).catch((e => {
                we("🔴 Unsubscription failed", e)
            })) : we("🟢 Unsubscription successfull")
        },
        trackBrowserPromptAnalytics(e, t) {
            var i = new z;
            if (i.config.optin_report_enabled) {
                window.poAnalytics.track("BrowserPromptShown", {
                    delay: e,
                    optinSeenCount: i.optinSeenCount
                });
                var n = {
                    allowed: "BrowserPromptAllowClicked",
                    denied: "BrowserPromptDenyClicked",
                    default: "BrowserPromptCloseClicked"
                };
                n[t] && window.poAnalytics.track(n[t], {
                    delay: e,
                    optinSeenCount: i.optinSeenCount
                })
            }
        }
    },
    Xe = ["type"];
var et = {
    isSubscribed(e) {
        var {
            context: t,
            product: i,
            featureStorageManager: n
        } = e;
        if (!i) return t.browserHandler.isPermissionGranted;
        if (n) {
            var o = i.currentVariant();
            return t.browserHandler.isPermissionGranted && n.isSubscribed(o)
        }
        return !1
    },
    handlePushOwlButtons(e) {
        var {
            buttons: t,
            onClick: i,
            isSubscribed: n
        } = e;
        if (!(re().isiOS && !navigator.standalone || re().isOldIOS))
            for (var o of Array.from(t)) {
                var r = o.dataset.pushowlPreDisplay,
                    s = o.dataset.pushowlPreVisibility,
                    a = o.dataset.pushowlPostDisplay,
                    c = o.dataset.pushowlPostVisibility,
                    u = o.dataset.pushowlPostSubscriptionMessage;
                n ? (a && (o.style.display = a), c && (o.style.visibility = c), u && (o.innerText = u)) : ("none" === o.style.display && (o.style.display = r || "block"), "hidden" === o.style.visibility && (o.style.visibility = s || "visible")), o.addEventListener("click", i)
            }
    },
    subscribeButtons(e) {
        var {
            context: t
        } = e, i = document.querySelectorAll(".js-pushowl--subscribe");
        we("".concat(i.length, " custom subscribe button(s) detected."), i), document.addEventListener("SubscribedToPushOwl", (() => {
            i.forEach((e => {
                var t = e.dataset.pushowlPostSubscriptionMessage;
                t && (e.innerText = t)
            }))
        })), this.handlePushOwlButtons({
            buttons: i,
            onClick: e => {
                Ze.subscribeIfNotAlready({
                    enableHintScreen: "false" !== e.target.dataset.pushowlOverlay,
                    websitePushId: t.config.website_push_id,
                    browserHandler: t.browserHandler
                }).then((() => {
                    var t = e.target.dataset.pushowlPostSubscriptionMessage;
                    t && (e.target.innerText = t)
                }), null)
            },
            isSubscribed: this.isSubscribed({
                context: t
            })
        })
    },
    priceDropButtons(e) {
        var {
            context: t,
            onSuccess: n
        } = e, o = document.querySelectorAll(".js-pushowl--pd");
        o.length && (we("".concat(o.length, " custom price drop button(s) detected."), o), t.storeLib.getProductDetails().then((e => {
            this.handlePushOwlButtons({
                buttons: o,
                onClick: o => {
                    var r = e.currentVariant();
                    Ze.subscribeProduct({
                        context: t,
                        automation: u.EVENT_API_PATH.PRICE_DROP,
                        product: e,
                        variant: r,
                        source: i.CUSTOM_BUTTONS
                    }).then((() => {
                        t.storageManager.price_drop.subscribe(r);
                        var i = o.target.dataset.pushowlPostSubscriptionMessage;
                        i && (o.target.innerText = i), n(e)
                    })).catch(fe)
                },
                isSubscribed: this.isSubscribed({
                    context: t,
                    product: e,
                    featureStorageManager: t.storageManager.price_drop
                })
            })
        })))
    },
    backInStockButtons(e) {
        var {
            context: t,
            onSuccess: n
        } = e, o = document.querySelectorAll(".js-pushowl--bis");
        o.length && (we("".concat(o.length, " custom back-in-stock button(s) detected."), o), t.storeLib.getProductDetails().then((e => {
            this.handlePushOwlButtons({
                buttons: o,
                onClick: o => {
                    var r = e.currentVariant();
                    Ze.subscribeProduct({
                        context: t,
                        automation: u.EVENT_API_PATH.BACK_IN_STOCK,
                        product: e,
                        variant: r,
                        source: i.CUSTOM_BUTTONS
                    }).then((() => {
                        t.storageManager.back_in_stock.subscribe(r);
                        var i = o.target.dataset.pushowlPostSubscriptionMessage;
                        i && (o.target.innerText = i), n(e)
                    })).catch(fe)
                },
                isSubscribed: this.isSubscribed({
                    context: t,
                    product: e,
                    featureStorageManager: t.storageManager.back_in_stock
                })
            })
        })))
    }
};
class tt {
    constructor({
        endpoint: e,
        props: t
    }) {
        this.endpoint = e, this.meta = {}, this.initVisitor(), this.setVisitorProperties(t);
        let i = null;
        Y() ? i = de("po_visitor") : pe("po_visitor", "/"), this.setVisitorProperties({
            sessionId: i,
            language: navigator.language
        })
    }
    initVisitor() {
        let e = null;
        Y() ? e = de("po_visitor") : pe("po_visitor", "/"), e || (this.meta.isNewVisitor = !0, e = ce(12), Y() && le({
            name: "po_visitor",
            value: e,
            days: 365
        })), this.visitorId = e
    }
    setVisitorProperties(e) {
        this.properties = Object.assign(Object.assign({}, this.properties), e)
    }
    track(e, t, i) {
        if (Y() && this.visitorId && this.properties.visitorToken)
            if (this.properties.wid) {
                if (i) {
                    const i = {
                            sessionId: this.visitorId,
                            sessionToken: this.properties.sessionToken,
                            visitorToken: j.visitorToken,
                            subdomain: B.subdomain,
                            wid: this.properties.wid,
                            language: this.properties.language,
                            flowId: t.flowId,
                            formId: t.formId,
                            nodeId: t.nodeId,
                            channelType: t.channelType,
                            optinType: t.optinType,
                            formStepType: t.formStepType,
                            event: e,
                            platform: B.platform,
                            timestamp: (new Date).toISOString(),
                            uuid: ce()
                        },
                        n = new URL(this.endpoint);
                    return n.searchParams.set("subdomain", i.subdomain), n.searchParams.set("event", i.event), void Ce.post({
                        url: n.toString(),
                        payload: i,
                        acceptType: "text/plain"
                    })
                }
                Ce.post({
                    url: this.endpoint,
                    payload: Object.assign(Object.assign({
                        event: e,
                        sessionId: this.visitorId,
                        uuid: ce(15),
                        properties: t
                    }, this.properties), {
                        platform: B.platform,
                        timestamp: (new Date).toISOString()
                    }),
                    acceptType: "text/plain"
                })
            } else B.logToServer({
                message: "wid empty",
                subdomain: B.subdomain,
                data: Object.assign(Object.assign({}, t), {
                    breadcrumbs: ge
                })
            })
    }
}
const it = (e, t, i) => {
    let n = i.replace("{{amount}}", parseFloat(t).toFixed(2));
    return e.replace("{{product_price}}", n).replace("{{variant_price}}", n)
};
var nt = {
    renderFlyout(e) {
        var {
            flyoutHandler: t,
            title: i,
            buttonText: n,
            automationType: o,
            buttonListener: r,
            theme: s,
            position: a,
            overlay: c
        } = e;
        document.querySelectorAll(".pushowl-widget-node").forEach((e => {
            e && e.remove()
        })), i && (t.setState({
            title: i,
            buttonText: n,
            buttonListener: r,
            theme: s,
            position: a,
            overlay: c
        }), we("Product flyout shown for: ", o), we("🟠 Optin prompt was not shown. Reason: Product flyout shown"))
    },
    renderOptin(e) {
        var {
            rootContext: t,
            flyoutHandler: i
        } = e, n = t.config.home.flyout, {
            title: o,
            theme: r,
            position: s,
            buttonText: a,
            overlay: c
        } = n;
        window.Notification && window.Notification.permission === u.NOTIFICATION_PERMISSION.DEFAULT ? (i.setState({
            title: o,
            buttonText: a,
            theme: r,
            position: s,
            overlay: c,
            buttonListener: () => {
                window.poSubscriptionSource = y, Ze.subscribeIfNotAlready({
                    enableHintScreen: c && c.enabled,
                    websitePushId: t.config.website_push_id,
                    browserHandler: t.browserHandler,
                    hintScreenData: c
                }).then((() => {
                    i.setState({
                        title: n.postSubscriptionTitle,
                        position: s,
                        theme: r
                    })
                })).catch((e => {
                    fe(e)
                }))
            }
        }), we("Flyout shown.", "Config: ", n)) : we("Flyout not shown.", "Config: ", n, "Permission: ", window.Notification.permission)
    },
    renderBackInStock(e) {
        var {
            rootContext: t,
            flyoutHandler: n,
            product: o,
            variant: s
        } = e, a = new j, {
            back_in_stock: c,
            flyout_config: l
        } = t.config, d = c.enabled, p = a.back_in_stock.isSubscribed(s);
        if (d)
            if (window.Notification && window.Notification.permission === u.NOTIFICATION_PERMISSION.GRANTED && p) {
                var h = it(c.postSubscriptionTitle, s.price, t.config.shop.money_format),
                    {
                        theme: g,
                        position: w,
                        overlay: m
                    } = c.metadata;
                this.renderFlyout({
                    flyoutHandler: n,
                    title: h,
                    theme: g,
                    position: w,
                    overlay: m,
                    automationType: r.BACK_IN_STOCK
                })
            } else {
                var {
                    theme: b,
                    position: f,
                    overlay: _
                } = c.metadata;
                this.renderFlyout({
                    flyoutHandler: n,
                    title: c.title,
                    buttonText: c.buttonText,
                    theme: b,
                    position: f,
                    overlay: _,
                    buttonListener: () => {
                        n.setState({
                            title: c.postSubscriptionTitle,
                            position: f,
                            theme: b
                        });
                        var {
                            overlay: e
                        } = c.metadata;
                        window.Notification && "default" === window.Notification.permission && (window.poSubscriptionSource = I), Ze.subscribeIfNotAlready({
                            enableHintScreen: !!l.overlay,
                            showHintScreenOnError: !!l.overlay,
                            websitePushId: t.config.website_push_id,
                            browserHandler: t.browserHandler,
                            hintScreenData: e
                        }).then((() => {
                            Ze.update(u.EVENT_API_PATH.BACK_IN_STOCK, {
                                product_id: o.id,
                                product: o,
                                variant: s,
                                source: i.FLYOUT_WIDGET,
                                permission: window.Notification && window.Notification.permission
                            }).then((e => {
                                a.back_in_stock.subscribe(s);
                                var {
                                    token: t
                                } = e.result;
                                t && (j.subscriberToken = t), we("Product subscribed for ".concat(u.EVENT_API_PATH.BACK_IN_STOCK, ". Product ").concat(o.id, ". Variant ").concat(s.id, ". Source: ").concat(i.FLYOUT_WIDGET))
                            })).catch((e => {
                                fe(e)
                            }))
                        }))
                    },
                    automationType: r.BACK_IN_STOCK
                })
            }
    },
    renderPriceDrop(e) {
        var {
            rootContext: t,
            flyoutHandler: n,
            product: o,
            variant: s
        } = e, a = new j, {
            price_drop: c,
            flyout_config: l
        } = t.config, d = c.enabled, p = a.price_drop.isSubscribed(s), h = c.is_viewed;
        if (d && !h)
            if (window.Notification && window.Notification.permission === u.NOTIFICATION_PERMISSION.GRANTED && p) {
                var {
                    theme: g,
                    position: w,
                    overlay: m
                } = c.metadata;
                this.renderFlyout({
                    flyoutHandler: n,
                    theme: g,
                    position: w,
                    overlay: m,
                    title: c.postSubscriptionTitle,
                    automationType: r.PRICE_DROP
                })
            } else {
                var b = t.config.price_drop.metadata,
                    {
                        theme: f,
                        position: _,
                        overlay: S
                    } = b;
                this.renderFlyout({
                    theme: f,
                    position: _,
                    overlay: S,
                    flyoutHandler: n,
                    title: it(c.title, s.price, t.config.shop.money_format),
                    buttonText: c.buttonText,
                    buttonListener: () => {
                        n.setState({
                            title: c.postSubscriptionTitle,
                            position: _,
                            theme: f
                        });
                        var {
                            overlay: e
                        } = c.metadata;
                        window.Notification && "default" === window.Notification.permission && (window.poSubscriptionSource = E), Ze.subscribeIfNotAlready({
                            enableHintScreen: !!l.overlay,
                            showHintScreenOnError: !!l.overlay,
                            websitePushId: t.config.website_push_id,
                            browserHandler: t.browserHandler,
                            hintScreenData: e
                        }).then((() => {
                            Ze.update(u.EVENT_API_PATH.PRICE_DROP, {
                                product_id: o.id,
                                product: o,
                                variant: s,
                                subscribed_price: s.price,
                                source: i.FLYOUT_WIDGET,
                                permission: window.Notification && window.Notification.permission
                            }).then((e => {
                                a.price_drop.subscribe(s);
                                var {
                                    token: t
                                } = e.result;
                                t && (j.subscriberToken = t), we("Product subscribed for ".concat(u.EVENT_API_PATH.PRICE_DROP, ". Product ").concat(o.id, ". Variant ").concat(s.id, ". Source: ").concat(i.FLYOUT_WIDGET))
                            })).catch((e => {
                                fe(e)
                            }))
                        }))
                    },
                    automationType: r.PRICE_DROP
                })
            }
    }
};
const ot = {
    name: "Pushowl Web Notifications",
    short_name: "PushOwl",
    description: "",
    icons: [],
    start_url: "/",
    scope: "/",
    display: "standalone",
    orientation: "portrait",
    background_color: "#fff",
    theme_color: "#000000"
};
class rt {
    constructor(e) {
        this.syncTriggerManager = e, this.activeFlows = new Map, this.triggeredFlows = new Set, this.triggerSources = new Map
    }
    setup(e, t) {
        var i = this;
        if (e && t && !this.triggeredFlows.has(e.id)) {
            var n = e.id,
                o = {
                    flow: e,
                    callback: function() {
                        for (var e = i.triggerSources.get(n), o = arguments.length, r = new Array(o), s = 0; s < o; s++) r[s] = arguments[s];
                        t(e, ...r)
                    },
                    triggered: !1,
                    enabledConditions: {
                        exitIntent: Boolean(e.exitIntent),
                        scrollDepth: Boolean(e.scrollDepthEnabled),
                        timeSpent: Boolean(e.timeSpentEnabled)
                    },
                    metConditions: {
                        exitIntent: !1,
                        scrollDepth: !1,
                        timeSpent: !1
                    }
                };
            this.activeFlows.set(n, o), e.exitIntent && this._setupExitIntent(n, e.requireAllConditions), e.scrollDepthEnabled && this._setupScrollDepth(n, e.requireAllConditions), e.timeSpentEnabled && this._setupTimeSpent(n, e.requireAllConditions)
        }
    }
    _setupExitIntent(e, t) {
        var i = this.activeFlows.get(e),
            n = n => {
                n.clientY <= 0 && (t ? (i.metConditions.exitIntent = !0, this._checkEnabledConditions(e)) : this._triggerFlow(e, "exitIntent"))
            };
        i.exitIntentHandler = n, document.documentElement.addEventListener("mouseleave", n)
    }
    _setupScrollDepth(e, t) {
        var i, n = this.activeFlows.get(e),
            o = n.flow.scrollDepth,
            r = () => {
                clearTimeout(i), i = setTimeout((() => {
                    var i = this._calculateScrollPercentage();
                    we("[AsyncTriggerManager] Current scroll depth: ".concat(i.toFixed(2), "%, Target: ").concat(o, "%")), i >= o && (t ? (n.metConditions.scrollDepth = !0, this._checkEnabledConditions(e)) : this._triggerFlow(e, "scrollDepth"))
                }), 100)
            };
        n.scrollHandler = r, window.addEventListener("scroll", r)
    }
    _setupTimeSpent(e, t) {
        var i = this.activeFlows.get(e),
            n = setTimeout((() => {
                t ? (i.metConditions.timeSpent = !0, this._checkEnabledConditions(e)) : this._triggerFlow(e, "timeSpent")
            }), 1e3 * i.flow.timeSpent);
        i.timeoutId = n
    }
    _checkEnabledConditions(e) {
        var t = this.activeFlows.get(e);
        t && !t.triggered && (Object.entries(t.enabledConditions).every((e => {
            var [i, n] = e;
            return !n || t.metConditions[i]
        })) && this._triggerFlow(e, "allConditions"))
    }
    _triggerFlow(e, t) {
        var i = this.activeFlows.get(e);
        !i || i.triggered || this.triggeredFlows.has(e) || (we("[AsyncTriggerManager] Flow ".concat(e, " triggered by: ").concat(t)), this.triggerSources.set(e, t), i.triggered = !0, this.triggeredFlows.add(e), i.callback(), this._cleanupFlowListeners(e), this.activeFlows.delete(e))
    }
    _calculateScrollPercentage() {
        var e = window.innerHeight,
            t = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight, document.body.offsetHeight, document.documentElement.offsetHeight, document.body.clientHeight, document.documentElement.clientHeight);
        return (window.pageYOffset || document.documentElement.scrollTop) / (t - e) * 100
    }
    _cleanupFlowListeners(e) {
        var t = this.activeFlows.get(e);
        t && (t.exitIntentHandler && document.documentElement.removeEventListener("mouseleave", t.exitIntentHandler), t.scrollHandler && window.removeEventListener("scroll", t.scrollHandler), t.timeoutId && clearTimeout(t.timeoutId))
    }
    getTriggerSource(e) {
        return this.triggerSources.get(e)
    }
    cleanup(e) {
        this._cleanupFlowListeners(e), this.activeFlows.delete(e), this.triggeredFlows.delete(e)
    }
    cleanupAll() {
        this.activeFlows.forEach(((e, t) => {
            this.cleanup(t)
        }))
    }
}
class st {
    constructor() {
        this.conditions = new Map, we("🪵 SyncTriggerManager initialized")
    }
    setup(e) {
        we("🪵 Setting up sync conditions for flow:", e.id), this.conditions.set(e.id, {
            urlTargeting: {
                inclusionUrls: e.inclusionUrls || [],
                exclusionUrls: e.exclusionUrls || [],
                inclusionUrlsEnabled: e.inclusionUrlsEnabled || !1,
                exclusionUrlsEnabled: e.exclusionUrlsEnabled || !1
            },
            deviceType: this._normalizeDeviceType(e.deviceType)
        })
    }
    _normalizeDeviceType(e) {
        return !e || 0 === e.length || e.includes("all") ? [] : e
    }
    checkAllConditions(e) {
        var t = this.conditions.get(e.id);
        if (we("🪵 Checking conditions for flow:", {
                flowId: e.id,
                conditions: t
            }), !t) return we("🪵 No conditions found for flow:", e.id), !0;
        var i = this.checkUrlConditions(t.urlTargeting),
            n = this.checkDeviceTargetingConditions(t.deviceType);
        return we("🪵 Condition check results:", {
            flowId: e.id,
            urlCheck: i,
            deviceCheck: n
        }), i && n
    }
    checkUrlConditions(e) {
        var t, i, n = window.location.href,
            o = !e.inclusionUrlsEnabled;
        if (e.exclusionUrlsEnabled && (null === (t = e.exclusionUrls) || void 0 === t ? void 0 : t.length) > 0)
            for (var r of e.exclusionUrls)
                if (this._matchUrl(r, n)) return !1;
        if (e.inclusionUrlsEnabled && (null === (i = e.inclusionUrls) || void 0 === i ? void 0 : i.length) > 0)
            for (var s of (o = !1, e.inclusionUrls))
                if (this._matchUrl(s, n)) {
                    o = !0;
                    break
                }
        return o
    }
    _matchUrl(e, t) {
        var i = t.replace(/^https?:\/\//, ""),
            n = e.url.replace(/^https?:\/\//, "");
        switch (e.type) {
            case "contains":
                return i.includes(n);
            case "exact":
                return i === n;
            default:
                return !1
        }
    }
    checkDeviceTargetingConditions(e) {
        return null == e || !e.length || e.some((e => {
            switch (e) {
                case "mobile":
                    return te();
                case "desktop":
                    return !te();
                case "mobile_ios":
                    return re().isiOS || re().isOldIOS;
                case "mobile_android":
                    return re().isAndroid;
                default:
                    return !0
            }
        }))
    }
}
class at {
    constructor(e) {
        this.config = e, this.flows = new Map, this.syncTriggerManager = new st, this.asyncTriggerManager = new rt(this.syncTriggerManager), we("🪵 OptinFlowManager initialized")
    }
    addOptinFlow(e, t) {
        we("🪵 Adding flow:", e.id), this.flows.set(e.id, {
            flow: e,
            renderCallback: t
        }), this.syncTriggerManager.setup(e)
    }
    initialize() {
        we("🪵 Initializing flows, total flows:", this.flows.size), this.flows.forEach((e => {
            var t, i, n, {
                flow: o,
                renderCallback: r
            } = e;
            if (we("🪵 Processing flow:", o.id), null !== (t = o.exclusion_countries_enabled && o.exclusion_countries.includes(null === (i = window) || void 0 === i || null === (n = i.Shopify) || void 0 === n ? void 0 : n.country)) && void 0 !== t && t) we("🪵 User in restricted country, skipping flow:", o.id);
            else {
                var s = o.exitIntent || o.scrollDepthEnabled || o.timeSpentEnabled,
                    a = o.inclusionUrlsEnabled || o.exclusionUrlsEnabled || o.deviceType && o.deviceType.length > 0;
                if (we("🪵 Flow triggers:", {
                        hasAsyncTriggers: s,
                        hasSyncConditions: a,
                        flow: o.id
                    }), !s && !a) return we("🪵 No triggers configured, rendering immediately for flow:", o.id), void r();
                if (a) {
                    var c = this.syncTriggerManager.checkAllConditions(o);
                    if (we("🪵 Sync conditions check result:", {
                            flowId: o.id,
                            passed: c
                        }), !c) return void we("🪵 Sync conditions failed for flow:", o.id)
                }
                s ? (we("🪵 Setting up async triggers for flow:", o.id), this.asyncTriggerManager.setup(o, r)) : a && (we("🪵 Only sync conditions exist and passed, rendering flow:", o.id), r())
            }
        }))
    }
}
var ct, ut, lt;

function dt(e, t) {
    if (lt = new Date, e.nodeType !== Node.ELEMENT_NODE) throw new Error("Can't generate CSS selector for non-element node type.");
    if ("html" === e.tagName.toLowerCase()) return "html";
    var i = {
        root: document.body,
        idName: e => !0,
        className: e => !0,
        tagName: e => !0,
        attr: (e, t) => !1,
        seedMinLength: 1,
        optimizedMinLength: 2,
        threshold: 1e3,
        maxNumberOfTries: 1e4,
        timeoutMs: void 0
    };
    ct = Ee(Ee({}, i), t), ut = function(e, t) {
        if (e.nodeType === Node.DOCUMENT_NODE) return e;
        if (e === t.root) return e.ownerDocument;
        return e
    }(ct.root, i);
    var n = pt(e, "all", (() => pt(e, "two", (() => pt(e, "one", (() => pt(e, "none")))))));
    if (n) {
        var o = yt(Et(n, e));
        return o.length > 0 && (n = o[0]), gt(n)
    }
    throw new Error("Selector was not found.")
}

function pt(e, t, i) {
    for (var n = null, o = [], r = e, s = 0, a = function() {
            var e = (new Date).getTime() - lt.getTime();
            if (void 0 !== ct.timeoutMs && e > ct.timeoutMs) throw new Error("Timeout: Can't find a unique selector after ".concat(e, "ms"));
            var a = _t(function(e) {
                    var t = e.getAttribute("id");
                    if (t && ct.idName(t)) return {
                        name: "#" + CSS.escape(t),
                        penalty: 0
                    };
                    return null
                }(r)) || _t(... function(e) {
                    var t = Array.from(e.attributes).filter((e => ct.attr(e.name, e.value)));
                    return t.map((e => ({
                        name: "[".concat(CSS.escape(e.name), '="').concat(CSS.escape(e.value), '"]'),
                        penalty: .5
                    })))
                }(r)) || _t(... function(e) {
                    return Array.from(e.classList).filter(ct.className).map((e => ({
                        name: "." + CSS.escape(e),
                        penalty: 1
                    })))
                }(r)) || _t(function(e) {
                    var t = e.tagName.toLowerCase();
                    if (ct.tagName(t)) return {
                        name: t,
                        penalty: 2
                    };
                    return null
                }(r)) || [{
                    name: "*",
                    penalty: 3
                }],
                c = function(e) {
                    var t = e.parentNode;
                    if (!t) return null;
                    var i = t.firstChild;
                    if (!i) return null;
                    var n = 0;
                    for (; i && (i.nodeType === Node.ELEMENT_NODE && n++, i !== e);) i = i.nextSibling;
                    return n
                }(r);
            if ("all" == t) c && (a = a.concat(a.filter(ft).map((e => bt(e, c)))));
            else if ("two" == t) a = a.slice(0, 1), c && (a = a.concat(a.filter(ft).map((e => bt(e, c)))));
            else if ("one" == t) {
                var [u] = a = a.slice(0, 1);
                c && ft(u) && (a = [bt(u, c)])
            } else "none" == t && (a = [{
                name: "*",
                penalty: 3
            }], c && (a = [bt(a[0], c)]));
            for (var l of a) l.level = s;
            if (o.push(a), o.length >= ct.seedMinLength && (n = ht(o, i))) return "break";
            r = r.parentElement, s++
        }; r;) {
        if ("break" === a()) break
    }
    return n || (n = ht(o, i)), !n && i ? i() : n
}

function ht(e, t) {
    var i = yt(vt(e));
    if (i.length > ct.threshold) return t ? t() : null;
    for (var n of i)
        if (mt(n)) return n;
    return null
}

function gt(e) {
    for (var t = e[0], i = t.name, n = 1; n < e.length; n++) {
        var o = e[n].level || 0;
        i = t.level === o - 1 ? "".concat(e[n].name, " > ").concat(i) : "".concat(e[n].name, " ").concat(i), t = e[n]
    }
    return i
}

function wt(e) {
    return e.map((e => e.penalty)).reduce(((e, t) => e + t), 0)
}

function mt(e) {
    var t = gt(e);
    switch (ut.querySelectorAll(t).length) {
        case 0:
            throw new Error("Can't select any node with this selector: ".concat(t));
        case 1:
            return !0;
        default:
            return !1
    }
}

function bt(e, t) {
    return {
        name: e.name + ":nth-child(".concat(t, ")"),
        penalty: e.penalty + 1
    }
}

function ft(e) {
    return "html" !== e.name && !e.name.startsWith("#")
}

function _t() {
    for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++) t[i] = arguments[i];
    var n = t.filter(St);
    return n.length > 0 ? n : null
}

function St(e) {
    return null != e
}

function* vt(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
    if (e.length > 0)
        for (var i of e[0]) yield* vt(e.slice(1, e.length), t.concat(i));
    else yield t
}

function yt(e) {
    return [...e].sort(((e, t) => wt(e) - wt(t)))
}

function* Et(e, t) {
    var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {
        counter: 0,
        visited: new Map
    };
    if (e.length > 2 && e.length > ct.optimizedMinLength)
        for (var n = 1; n < e.length - 1; n++) {
            if (i.counter > ct.maxNumberOfTries) return;
            i.counter += 1;
            var o = [...e];
            o.splice(n, 1);
            var r = gt(o);
            if (i.visited.has(r)) return;
            mt(o) && It(o, t) && (yield o, i.visited.set(r, !0), yield* Et(o, t, i))
        }
}

function It(e, t) {
    return ut.querySelector(gt(e)) === t
}
const Tt = "pushowl-optin-container";
var Nt;
! function(e) {
    e.CONSENT_EMAIL_COPY = "consent-email-copy", e.CONSENT_SMS_COPY = "consent-sms-copy"
}(Nt || (Nt = {}));
const Ot = {
        root: "root",
        containers: ["form_fields", "text_content", "image"],
        nodes: ["email", "phone", "image", "flyout", "consent-email-checkbox", "consent-sms-checkbox", [Nt.CONSENT_EMAIL_COPY],
            [Nt.CONSENT_SMS_COPY]
        ],
        logo: "logo",
        wheel: "wheel"
    },
    Mt = {
        email: "Enter your Email address",
        phone: "9123456789"
    },
    Ct = {
        0: 0,
        xs: 10,
        sm: 12,
        md: 16,
        lg: 20,
        xl: 26,
        "2xl": 30,
        "3xl": 36,
        "4xl": 42,
        "5xl": 48,
        "6xl": 54
    },
    At = "#0475fd",
    Lt = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2MiIgaGVpZ2h0PSIxNiIgZmlsbD0ibm9uZSI+PG1hc2sgaWQ9ImEiIHdpZHRoPSI2MiIgaGVpZ2h0PSIxNiIgeD0iMCIgeT0iMCIgbWFza1VuaXRzPSJ1c2VyU3BhY2VPblVzZSIgc3R5bGU9Im1hc2stdHlwZTpsdW1pbmFuY2UiPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik02MS44NyAwSDB2MTUuNzg2aDYxLjg3eiIvPjwvbWFzaz48ZyBmaWxsPSIjZmZmIiBtYXNrPSJ1cmwoI2EpIj48cGF0aCBkPSJNNi40MiAwYzEuNTU3IDAgMi43MTcuNjU4IDMuNzA1IDEuNDMyLjQ2LjM2LjgzNy43OTQgMS4xNzEgMS4yNy4wNDcuMDY2LjA1OS4xMi4wMTYuMTg2LS4zMzUuNTYxLS41MTQgMS4xNzctLjY1NCAxLjgwNy0uMDA0LjAyNC0uMDE1LjA0Ny0uMDIzLjA2NiAwIC4wMDQtLjAxMi4wMDgtLjAyLjAwOC0uODEzLTIuNTY2LTMuNDE2LTMuNjM1LTUuNTQtMy4wOTMtMi4yMTkuNTY1LTMuNTc3IDIuNDItMy41MjIgNC41NzYuMDU4IDIuMzQ1IDEuNzI3IDQuMTEgMy45MDMgNC40NCAyLjM0Ni4zNTIgNC40Mi0uOTcyIDUuMTUyLTMuMTQ3LjA1LjA0Ni4wNTQuMTA4LjA2Ni4xNjYuMjQxIDEuMTUuNzY2IDIuMTU2IDEuNTIxIDMuMDU0YTcuMSA3LjEgMCAwIDAgMi40MzYgMS44NjJjLjA4Mi4wMzkuMjA2LjA3LjIzNC4xMzYuMDMuMDc3LS4wODYuMTQ3LS4xMzcuMjItLjY4NC45Ni0xLjUwNSAxLjc4OS0yLjQyNCAyLjUyOC0uMDkuMDc0LS4xODMuMTQzLS4yNzIuMjI1LS4wNjMuMDU4LS4xMTMuMDYxLS4xODcuMDA3YTEzLjQgMTMuNCAwIDAgMS0yLjEyNS0yLjAxNyAxMS40IDExLjQgMCAwIDEtMS4yNDUtMS43NjljLS4wMzktLjA3LS4wNzgtLjA4OS0uMTU1LS4wNTgtLjg2NC4zNTctMS43NzUuNDM0LTIuNjkzLjM4LS43NTUtLjA0Ny0xLjQ3MS0uMjY3LTIuMTQ4LS41OTZBNi4wOCA2LjA4IDAgMCAxIC42MSA4LjgzMyA1LjggNS44IDAgMCAxIDAgNi4wODljLjAxNS0uNi4wNy0xLjE4OC4yNjQtMS43NjEuMTItLjM2LjI2NC0uNzA5LjM1NC0xLjA3NkMuODk5IDIuMTQ1LjcxNiAxLjExNS4wOTcuMTU1QTMgMyAwIDAgMSAuMDA3IDB6Ii8+PHBhdGggZD0iTTIzLjg4OCAwYy0uMTc1LjMxLS4zNzMuNi0uNDk4LjkzN2EzLjkzIDMuOTMgMCAwIDAtLjAzMSAyLjY1MWMuMTQ4LjQzOC4zMy44NjQuNDEyIDEuMzI0LjEzMy43NDcuMTgzIDEuNDk0LjA0NyAyLjI0NS0uMjM3IDEuMzEzLS44MiAyLjQ0Ny0xLjc4MiAzLjM3Ni0uOTk2Ljk2NC0yLjE5IDEuNTUyLTMuNTc2IDEuNzIzLTEuMzI3LjE2Mi0yLjU5Mi0uMDctMy43NTktLjczNi0xLjYzLS45MjktMi42NTgtMi4zLTMuMDQ3LTQuMTM0YTUuOSA1LjkgMCAwIDEtLjEyLTEuNzg5Yy4wNjYtLjY3LjIyNS0xLjMxNi41MDUtMS45MjcuNTg0LTEuMjcgMS41MDItMi4yMzQgMi43Mi0yLjkxOUMxNS41MTEuMzI5IDE2LjU4MiAwIDE3LjU3MyAwek0xMy4wOTQgNi4xNTljMCAyLjYwMSAyLjEwOSA0LjcgNC44NDUgNC41ODcgMi40MDQtLjEgNC40ODYtMi4wMzIgNC40MTItNC43NjUtLjA2Mi0yLjM0Mi0xLjk3Ny00LjQ3MS00LjcyLTQuNDMzLTIuNDA5LjAzNS00LjUzNyAxLjkyNC00LjUzNyA0LjYxWm0tNS43NC42MTVjLS4xNC4wMi0uMjY0LjAwOC0uMzkzLjAwOC0uMDc0IDAtLjExMi0uMDE2LS4xMjQtLjEwNS0uMDM5LS4zMDItLjM2Mi0uNTU3LS42NzMtLjU1M2EuNjcuNjcgMCAwIDAtLjY0Mi41NjljLS4wMDguMDYyLS4wMjguMDg1LS4wOS4wODVINC42MnEtLjA5Mi4wMDItLjA3OC0uMDg5YTEuNjYgMS42NiAwIDAgMSAxLjMwNy0xLjQ4NmMuODE0LS4xODYgMS44MjIuMzkgMS45MzggMS4zNDcuMDI4LjIyOC4wMzEuMjI4LS4yMDYuMjI4aC0uMjN6Ii8+PHBhdGggZD0iTTE4Ljg2NSA2Ljc3NGgtLjQwMWMtLjA1OCAwLS4wODItLjAxNS0uMDktLjA4MS0uMDMtLjMwMi0uMzE5LS41NTgtLjYzOC0uNTdhLjY1LjY1IDAgMCAwLS42NzMuNTQzYy0uMDE2LjA5Ny0uMDQ3LjExNi0uMTM2LjExNmEyMyAyMyAwIDAgMC0uNzI4IDBjLS4wOSAwLS4xMTctLjAzMS0uMTA5LS4xMi4wNTktLjY0My40MDUtMS4wOTYuOTgtMS4zNTEuNTgtLjI2IDEuMTQ1LS4xNzQgMS42NTQuMjE3LjM4Ni4yOTQuNTczLjY5Ni42MzUgMS4xNjUuMDA4LjA2Ni0uMDEyLjA4NS0uMDc0LjA4NWgtLjQxM3ptMTAuOTc2LTEuOTZxLjIyMy0uMzEzLjYxMS0uNTE4LjM5Ny0uMjE0LjkwMS0uMjE0YTEuOTkgMS45OSAwIDAgMSAxLjgxIDEuMTFxLjI4LjUyNi4yOCAxLjIyNCAwIC42OTktLjI4IDEuMjQyYTIuMDQgMi4wNCAwIDAgMS0uNzUyLjgzIDEuOTUgMS45NSAwIDAgMS0xLjA1OC4yOTYgMS45IDEuOSAwIDAgMS0uODkyLS4yMDYgMS45IDEuOSAwIDAgMS0uNjItLjUxOHYyLjgyaC0xLjE1N1Y0LjE1NmgxLjE1N3ptMi40MiAxLjYwMnEwLS40MTEtLjE3Mi0uNzA3YTEuMTMgMS4xMyAwIDAgMC0uNDQ3LS40NiAxLjE4IDEuMTggMCAwIDAtMS4xOS4wMDggMS4yIDEuMiAwIDAgMC0uNDQ2LjQ2cS0uMTY1LjMwNS0uMTY1LjcxNiAwIC40MS4xNjUuNzE1LjE3NC4zMDUuNDQ2LjQ2OGExLjIgMS4yIDAgMCAwIC41OTUuMTU3IDEuMTkgMS4xOSAwIDAgMCAxLjA0MS0uNjMzcS4xNzQtLjMwNC4xNzQtLjcyNFptNi4xMjEtMi4yNlY4LjcxaC0xLjE2NXYtLjU3NmExLjU1IDEuNTUgMCAwIDEtLjU4Ni40NjlxLS4zNTYuMTY0LS43NzcuMTY0LS41MzcgMC0uOTUtLjIyMmExLjY2IDEuNjYgMCAwIDEtLjY1My0uNjY2cS0uMjMxLS40NDMtLjIzMS0xLjA1MlY0LjE1NmgxLjE1N3YyLjUwN3EwIC41NDMuMjcyLjgzOC4yNzMuMjg4Ljc0NC4yODguNDggMCAuNzUyLS4yODguMjcyLS4yOTUuMjcyLS44MzhWNC4xNTZ6bTIuNjcgNC42MjhxLS41NjEgMC0xLjAwOC0uMTk4YTEuODUgMS44NSAwIDAgMS0uNzEtLjU1IDEuNCAxLjQgMCAwIDEtLjI4MS0uNzY1aDEuMTY1cS4wMzMuMjYzLjI1Ni40MzZhLjkzLjkzIDAgMCAwIC41Ny4xNzJxLjMzIDAgLjUxMi0uMTMxLjE5LS4xMzIuMTktLjMzNyAwLS4yMjItLjIzLS4zMjktLjIyNS0uMTE1LS43Mi0uMjQ2YTYgNiAwIDAgMS0uODQzLS4yNTUgMS41IDEuNSAwIDAgMS0uNTYxLS40MDNxLS4yMzItLjI3LS4yMzItLjczMiAwLS4zNzguMjE1LS42OS4yMjMtLjMxMi42MjgtLjQ5My40MTQtLjE4Ljk2Ny0uMTgxLjgxOCAwIDEuMzA1LjQxMS40ODcuNDAyLjUzOCAxLjA5M2gtMS4xMDhhLjU4LjU4IDAgMCAwLS4yMzEtLjQyN3EtLjE5OC0uMTY1LS41MzctLjE2NS0uMzE1IDAtLjQ4OC4xMTVhLjM3LjM3IDAgMCAwLS4xNjUuMzIxcTAgLjIzLjIzMS4zNTMuMjMxLjExNi43Mi4yMzkuNDk1LjEyMy44MTcuMjU1LjMyMy4xMy41NTQuNDEuMjQuMjcyLjI0OC43MjQgMCAuMzk1LS4yMjMuNzA3YTEuNDQgMS40NCAwIDAgMS0uNjI4LjQ5M3EtLjQwNS4xNzMtLjk1LjE3M1ptNS4xMDYtNC42OTRxLjUyMSAwIC45MjUuMjMuNDA1LjIyMi42MjkuNjY2LjIzLjQzNS4yMyAxLjA1MlY4LjcxaC0xLjE1NlY2LjE5NHEwLS41NDItLjI3My0uODMtLjI3Mi0uMjk2LS43NDMtLjI5Ni0uNDggMC0uNzYuMjk2LS4yNzMuMjg4LS4yNzMuODNWOC43MUg0My41OFYyLjYyN2gxLjE1N3YyLjA5NmExLjUgMS41IDAgMCAxIC41OTUtLjQ2cS4zNzItLjE3My44MjYtLjE3M200LjY5NCA0LjY5NGEyLjQ1IDIuNDUgMCAwIDEtMS4xOS0uMjg4IDIuMTcgMi4xNyAwIDAgMS0uODM0LS44MyAyLjUgMi41IDAgMCAxLS4yOTctMS4yMzNxMC0uNjk5LjMwNS0xLjIzMy4zMTUtLjUzNC44NTEtLjgyMmEyLjQ0IDIuNDQgMCAwIDEgMS4xOTgtLjI5NnEuNjYxIDAgMS4xOTkuMjk2LjUzNy4yODguODQyLjgyMi4zMTUuNTM0LjMxNCAxLjIzMyAwIC42OTktLjMyMiAxLjIzM2EyLjIgMi4yIDAgMCAxLS44Ni44M3EtLjUzNi4yODgtMS4yMDYuMjg4bTAtMS4wMDNxLjMxNCAwIC41ODctLjE0OGExLjEzIDEuMTMgMCAwIDAgLjQ0Ni0uNDZxLjE2NS0uMzA1LjE2NS0uNzQgMC0uNjUtLjM0Ny0uOTk1YTEuMSAxLjEgMCAwIDAtLjgzNC0uMzUzcS0uNDk1IDAtLjgzNS4zNTMtLjMzLjM0NS0uMzMuOTk1dC4zMjIgMS4wMDNxLjMzLjM0NS44MjYuMzQ1bTkuMzYtMy42MjVMNTguODczIDguNzFoLTEuMjQ4bC0uODM0LTMuMTgxLS44MzUgMy4xOEg1NC43bC0xLjM0Ny00LjU1M2gxLjE3NGwuODEgMy40NjkuODc1LTMuNDdoMS4yMjNsLjg2IDMuNDYxLjgxLTMuNDZ6bTEuNTU5LTEuNTI5VjguNzFoLTEuMTU3VjIuNjI3eiIvPjwvZz48L3N2Zz4=",
    Pt = 370,
    kt = 20;
var Dt, jt;
! function(e) {
    e.BOX = "BOX", e.TEXT = "TEXT", e.INPUT = "INPUT", e.IMAGE = "IMAGE", e.BUTTON = "BUTTON", e.CHECKBOX = "CHECKBOX", e.DATE = "DATE", e.HTML = "HTML", e.DISCOUNT = "DISCOUNT", e.CATEGORY = "CATEGORY", e.MULTI_SELECT = "MULTI_SELECT", e.WHEEL = "WHEEL"
}(Dt || (Dt = {})),
function(e) {
    e.CENTERED = "centered", e.BOTTOM_LEFT = "bottom_left", e.BOTTOM_CENTERED = "bottom_centered", e.BOTTOM_RIGHT = "bottom_right", e.TOP_LEFT = "top_left", e.TOP_CENTERED = "top_centered", e.TOP_RIGHT = "top_right"
}(jt || (jt = {}));
const Rt = e => {
        switch (e) {
            case "email":
                return "email";
            case "phone":
                return "tel";
            default:
                return
        }
    },
    xt = (e, t = 14) => {
        const i = {
            textOverflow: "ellipsis",
            overflow: "hidden",
            fontSize: `${t}px`,
            lineHeight: 1.2 * t + "px",
            paddingBlockEnd: "0px"
        };
        if (!e) return i;
        const n = {
                "4xl": "10px",
                "3xl": "10px",
                "2xl": "8px",
                xl: "6px",
                lg: "2px",
                md: "0px",
                sm: "0px",
                xs: "0px",
                0: "0px"
            }[e] || "0px",
            o = Ct[e] || t,
            r = o > 16 ? "bold" : "normal";
        return Object.assign(Object.assign({}, i), {
            fontSize: `${o}px`,
            lineHeight: 1.2 * o + "px",
            fontWeight: r,
            paddingBlockEnd: n
        })
    },
    Ut = e => {
        var t;
        if (!e) return 0;
        return null !== (t = {
            0: 0,
            xs: 1,
            sm: 2,
            md: 3,
            lg: 4,
            xl: 5,
            "2xl": 6,
            "3xl": 7,
            "4xl": 8,
            "5xl": 9,
            "6xl": 10
        }[e]) && void 0 !== t ? t : 0
    },
    Bt = (e, t) => e && t ? {
        border: `${Ut(t)}px solid ${e}`
    } : {},
    Yt = e => {
        if ("full" === e) return "100%";
        return `${{0:0,xs:2,sm:4,md:6,lg:8,xl:10,"2xl":12,"3xl":14,"4xl":16,"5xl":20,"6xl":26}[e]||0}px`
    },
    Ft = e => {
        var t, i;
        const n = !(null == e ? void 0 : e.type) || "auto" === (null == e ? void 0 : e.type) || !(null == e ? void 0 : e.zoom);
        return {
            backgroundPosition: `${(null===(t=null==e?void 0:e.pos)||void 0===t?void 0:t[0])||0}% ${(null===(i=null==e?void 0:e.pos)||void 0===i?void 0:i[1])||0}%`,
            backgroundSize: n ? "cover" : `${null==e?void 0:e.zoom}%`
        }
    },
    Ht = (e, t, i) => {
        var n;
        const {
            align: o,
            dir: r,
            bgUrl: s,
            pad: a,
            bgColor: c,
            css: u,
            fill: l,
            borderCol: d,
            borderWidth: p,
            radius: h,
            hidden: g,
            bgDims: w,
            bgHidden: m,
            redirectURL: b
        } = e.attr || {}, f = !Xt(e, Ot.wheel) && s && t && e.id !== Ot.root, _ = ((e, t) => {
            if (!e || 0 === (null == e ? void 0 : e.length)) return {};
            const i = {},
                n = "string" == typeof e ? ["left", e] : e;
            return "LR" === t ? (n.forEach(((e, t) => {
                switch (e) {
                    case "center":
                        i.alignItems = "center", 0 === t && (i.textAlign = "center");
                        break;
                    case "left":
                        i.justifyContent = "flex-start", 0 === t && (i.textAlign = "left");
                        break;
                    case "right":
                        i.justifyContent = "flex-end", 0 === t && (i.textAlign = "right");
                        break;
                    case "bottom":
                        i.alignItems = "flex-end";
                        break;
                    case "top":
                        i.alignItems = "flex-start";
                        break;
                    default:
                        return i
                }
                return {}
            })), i) : (n.forEach(((e, t) => {
                switch (e) {
                    case "center":
                        i.justifyContent = "center", 0 === t && (i.textAlign = "center", i.alignItems = "center");
                        break;
                    case "left":
                        i.alignItems = "flex-start", 0 === t && (i.textAlign = "left");
                        break;
                    case "right":
                        i.alignItems = "flex-end", 0 === t && (i.textAlign = "right");
                        break;
                    case "bottom":
                        i.justifyContent = "flex-end";
                        break;
                    case "top":
                        i.justifyContent = "flex-start";
                        break;
                    default:
                        return i
                }
                return {}
            })), i)
        })(o, r), S = ((e, t) => e ? {
            flexDirection: "column"
        } : {
            flexDirection: "LR" === t ? "row" : "column"
        })(t, r), v = f ? {} : (({
            url: e,
            bgColor: t,
            bgHidden: i,
            isRootNode: n,
            bgDims: o
        }) => {
            const r = n ? t || "#fff" : t || "inherit",
                s = o ? Ft(o) : {};
            return !e || i ? {
                background: r,
                backgroundImage: "unset"
            } : e ? Object.assign({
                backgroundImage: `url("${e}") ${n?`, linear-gradient(to right, ${r}, ${r})`:""}`,
                backgroundRepeat: "no-repeat",
                backgroundSize: "cover",
                backgroundPosition: "center center"
            }, s) : {}
        })({
            url: s,
            bgColor: c,
            bgHidden: m,
            isRootNode: e.id === Ot.root,
            bgDims: w
        }), y = (e => {
            var t;
            return e ? {
                padding: `${null!==(t={0:0,xs:2,sm:4,md:6,lg:8,xl:10,"2xl":12,"3xl":14,"4xl":16,"5xl":20,"6xl":26}[e])&&void 0!==t?t:6}px`
            } : {
                padding: "6px"
            }
        })(a), E = (e => "string" == typeof e ? e : "boolean" == typeof e ? e ? "50%" : "" : "50%")(l);
        let I = 0;
        const T = Bt(d || "#ffffff", p || "0");
        let N = "flex";
        const O = "boolean" == typeof g && g;
        return e.id !== Ot.root ? ((O || f) && (N = "none"), !s || (null == i ? void 0 : i.pad) && "0" === (null == i ? void 0 : i.pad) || !(null == i ? void 0 : i.radius) || "0" === (null == i ? void 0 : i.radius) ? s || (I = Yt(h || "0")) : I = ((e, t) => {
            const i = parseInt(Yt(e).split("px")[0], 10),
                n = parseInt(Yt(t).split("px")[0], 10),
                o = Math.abs(i - n);
            return 0 === o ? n / 2 : o
        })((null == i ? void 0 : i.radius) || "0", (null == i ? void 0 : i.pad) || "0")) : I = Yt(h || "0"), Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({
            position: "relative",
            borderRadius: I,
            display: N,
            flex: E,
            flexShrink: s ? 0 : 1,
            minHeight: s ? "200px" : "unset",
            minWidth: 0,
            width: "text_content" === e.id ? "100%" : "unset",
            overflow: e.id === Ot.root ? "hidden" : "unset",
            transform: `scale(${(null===(n=null==i?void 0:i.theme)||void 0===n?void 0:n.scale)/100||1})`,
            cursor: b ? "pointer" : "unset"
        }, T), S), y), _), v), u || {})
    },
    zt = e => ({
        whiteSpace: e ? "nowrap" : "normal",
        width: e ? "calc(100% - 25px)" : "unset"
    }),
    Gt = (e, t, i, n = !1) => {
        if (n) return e ? {
            width: "100%",
            alignItems: "center",
            margin: "0 auto",
            height: (null == i ? void 0 : i.fixedHeight) ? `${null==i?void 0:i.height}px` : "unset"
        } : {
            width: "100%",
            maxWidth: "600px",
            margin: "0 auto",
            height: (null == i ? void 0 : i.fixedHeight) ? `${null==i?void 0:i.height}px` : "unset"
        };
        if (e) switch (t) {
            case "step_1":
            case "step_2":
                return {
                    minWidth: "90%",
                    minHeight: "450px"
                };
            case "teaser":
                return {
                    width: (null == i ? void 0 : i.width) ? `${null==i?void 0:i.width}px` : "360px",
                    minHeight: "72px"
                };
            default:
                return {
                    minWidth: "100%",
                    minHeight: "450px"
                }
        }
        return "teaser" === t ? {
            width: (null == i ? void 0 : i.width) ? `${null==i?void 0:i.width}px` : "360px",
            minHeight: "72px"
        } : {
            maxWidth: (null == i ? void 0 : i.width) ? `${null==i?void 0:i.width}px` : "530px",
            minWidth: (null == i ? void 0 : i.width) ? `${null==i?void 0:i.width}px` : "530px",
            minHeight: (null == i ? void 0 : i.fixedHeight) ? `${null==i?void 0:i.height}px` : "500px",
            height: (null == i ? void 0 : i.fixedHeight) ? `${null==i?void 0:i.height}px` : "unset"
        }
    },
    Kt = e => {
        const t = "12px",
            i = "50%";
        switch (e) {
            case jt.CENTERED:
                return {
                    left: i,
                    top: i,
                    transform: "translate(-50%, -50%)"
                };
            case jt.BOTTOM_LEFT:
                return {
                    left: t,
                    bottom: t
                };
            case jt.BOTTOM_RIGHT:
                return {
                    right: t,
                    bottom: t
                };
            case jt.TOP_RIGHT:
                return {
                    right: t,
                    top: t
                };
            case jt.TOP_LEFT:
                return {
                    left: t,
                    top: t
                };
            case jt.TOP_CENTERED:
                return {
                    top: t,
                    left: i,
                    transform: "translateX(-50%)"
                };
            case jt.BOTTOM_CENTERED:
                return {
                    bottom: t,
                    left: i,
                    transform: "translateX(-50%)"
                };
            default:
                return {
                    left: i,
                    top: i,
                    transform: "translate(-50%, -50%)"
                }
        }
    },
    Vt = e => {
        const {
            height: t
        } = e.attr;
        return t || (e.id === Ot.logo ? 24 : 50)
    },
    qt = (e, t, i) => {
        const n = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        let o = "",
            r = t.replace(/\D/g, "");
        const s = (e, t, i, n = !1) => (e.length === (n ? 4 : 2) || !n && 1 === e.length && parseInt(e) > Math.floor(i / 10) ? (e = Math.min(parseInt(e), i).toString().padStart(n ? 4 : 2, "0"), o += e + (t < 2 ? "/" : "")) : e.length > 0 && (o += e), e.length),
            a = (e, t) => 2 === e && (e => e % 4 == 0 && e % 100 != 0 || e % 400 == 0)(t) ? 29 : n[e - 1];
        let c = [0, 0, 0];
        if ("MM/DD/YYYY" === e) {
            let e = r.slice(0, 2),
                t = r.slice(2, 4),
                i = r.slice(4, 8);
            c[0] = s(e, 0, 12), 2 === e.length ? c[1] = s(t, 1, a(parseInt(e), parseInt(i) || (new Date).getFullYear())) : (o += t, c[1] = t.length), o += i, c[2] = i.length
        } else if ("DD/MM/YYYY" === e) {
            let e = r.slice(0, 2),
                t = r.slice(2, 4),
                i = r.slice(4, 8);
            if (c[0] = s(e, 0, 31), c[1] = s(t, 1, 12), 2 === e.length && 2 === t.length) {
                let n = a(parseInt(t), parseInt(i) || (new Date).getFullYear());
                parseInt(e) > n && (e = n.toString(), o = e + "/" + o.split("/")[1] + "/", c[0] = 2)
            }
            o += i, c[2] = i.length
        } else if ("YYYY/MM/DD" === e) {
            let e = r.slice(0, 4),
                t = r.slice(4, 6),
                i = r.slice(6, 8);
            if (c[0] = s(e, 0, 9999, !0), c[1] = s(t, 1, 12), 4 === e.length && 2 === t.length) {
                let n = a(parseInt(t), parseInt(e));
                c[2] = s(i, 2, n)
            } else o += i, c[2] = i.length
        }
        let u = i;
        for (let e = 0; e < 3; e++) {
            if (i > r.length - c[2] - c[1]) {
                u = o.length;
                break
            }
            if (i > r.length - c[2] - c[1] - c[0]) {
                u = o.length - c[2];
                break
            }
            if (i > 0) {
                u = o.length - c[2] - c[1];
                break
            }
        }
        return {
            formattedValue: o,
            cursorPosition: u
        }
    },
    Wt = e => {
        const t = {},
            i = n => {
                if (n.id.startsWith("custom_field") && (t[n.id] = n.attr), n.children) {
                    if (!Array.isArray(n.children) || e.type === Dt.HTML) return t;
                    n.children.forEach((e => "string" != typeof e && i(e)))
                }
            };
        return i(e), t
    },
    $t = e => {
        switch (e) {
            case "DD/MM/YYYY":
                return "^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/([0-9]{4})$";
            case "MM/DD/YYYY":
                return "^(0[1-9]|1[0-2])/(0[1-9]|[12][0-9]|3[01])/([0-9]{4})$";
            case "YYYY/MM/DD":
                return "^([0-9]{4})/(0[1-9]|1[0-2])/(0[1-9]|[12][0-9]|3[01])$"
        }
    },
    Qt = e => {
        const t = parseInt(e.slice(1), 16);
        return .299 * (t >> 16 & 255) + .587 * (t >> 8 & 255) + .114 * (255 & t) < 128
    },
    Jt = e => e.replace(/\D/g, "");

function Zt(e) {
    return "type" in e
}
const Xt = (e, t, i = 8, n) => {
        if (!Array.isArray(e)) {
            if (n ? n(e.id, t) : e.id === t) return e;
            if (0 === i || !e.children) return null;
            const o = Array.isArray(e.children) ? e.children : [e.children];
            for (const e of o)
                if ("string" != typeof e && Zt(e)) {
                    const o = Xt(e, t, i - 1, n);
                    if (o) return o
                }
        }
        return null
    },
    ei = (e, t) => {
        if (t) {
            const t = Xt(e, Ot.wheel),
                i = Xt(e, "image");
            if (t && i && (e.attr = Object.assign(Object.assign({}, e.attr), {
                    dir: "TB"
                }), t.attr = Object.assign(Object.assign({}, t.attr), {
                    pos: "top"
                }), i.attr = Object.assign(Object.assign({}, i.attr), {
                    fill: "40%"
                }), "string" != typeof e.children)) {
                const t = e.children.filter((e => "string" != typeof e && "image" !== e.id));
                e.children = [i, ...t]
            }
        }
        return e
    },
    ti = ({
        nodeId: e,
        flowId: t,
        channelType: i,
        optinType: n
    }) => ({
        formId: o,
        event: r,
        stepType: s
    }) => {
        window.poAnalytics.track(r, {
            flowId: t,
            nodeId: e,
            formId: o,
            channelType: i,
            optinType: n,
            formStepType: s
        }, !0)
    },
    ii = ({
        event: e,
        optinType: t,
        flowId: i,
        nodeId: n,
        formId: o
    }) => {
        ti({
            optinType: t,
            channelType: ["webpush"],
            flowId: i,
            nodeId: n
        })({
            stepType: "step_1",
            event: e,
            formId: o
        })
    },
    ni = (e, t, i = !1) => {
        const n = {};
        return Object.keys(e).forEach((o => {
            t[o] && ("date" === e[o].fieldType && i ? n[e[o].mapAttribute] = (e => {
                const t = e.split("/");
                let i, n, o;
                return 4 === t[0].length ? [i, n, o] = t : 4 === t[2].length && (i = t[2], parseInt(t[1]) <= 12 ? [o, n] = t : [n, o] = t), n = n.padStart(2, "0"), o = o.padStart(2, "0"), `${i}-${n}-${o}`
            })(t[o]) : n[e[o].mapAttribute] = t[o])
        })), n
    },
    oi = e => {
        const t = (new DOMParser).parseFromString(e, "text/html");
        return null == t ? void 0 : t.body
    },
    ri = e => "HTML" === (null == e ? void 0 : e.type),
    si = (e, t) => {
        const i = e.children[t];
        if (!i) return "";
        const n = oi(i),
            o = (e => {
                const t = (new DOMParser).parseFromString(e, "text/html").head.getElementsByTagName("style");
                let i = "";
                for (const e of t) i += e.textContent;
                return i
            })(i),
            r = document.createElement("style");
        r.textContent = o, n.appendChild(r);
        const s = e.attr.button,
            a = e.attr.input;
        if (s) {
            const e = s.submit;
            if (e) {
                const t = Object.keys(e);
                n.querySelectorAll("button").forEach((e => {
                    const i = dt(e, {
                        root: n
                    });
                    if (t.includes(i)) {
                        n.querySelector(i).setAttribute("type", "submit")
                    } else e.setAttribute("type", "button")
                }))
            }
        }
        if (a) {
            let e = [],
                t = [];
            a.email && (e = Object.keys(a.email)), a.phone && (t = Object.keys(a.phone));
            const i = Object.keys(a).filter((e => "email" !== e && "phone" !== e));
            n.querySelectorAll("input:not([type=radio]), input:not([type=checkbox])").forEach((o => {
                const r = dt(o, {
                    root: n
                });
                e.includes(r) ? (o.setAttribute("type", "email"), o.setAttribute("name", "email")) : t.includes(r) ? (o.setAttribute("type", "tel"), o.setAttribute("name", "phone")) : i.forEach((e => {
                    Object.keys(a[e]).includes(r) && o.setAttribute("name", e)
                }))
            }))
        }
        return n.innerHTML
    },
    ai = ({
        event: e,
        attributes: t,
        handleDismiss: i,
        DOMTree: n,
        handleSubmit: o
    }) => {
        var r;
        if (!(null === (r = Object.keys(t || {})) || void 0 === r ? void 0 : r.length)) return;
        const s = e.target,
            a = dt(s, {
                root: n
            });
        Object.entries(t).forEach((([e, t]) => {
            switch (e) {
                case "dismiss":
                    Object.keys(t).forEach((e => {
                        e === a && i()
                    }));
                    break;
                case "submit":
                    Object.keys(t).forEach((e => {
                        if (e === a) {
                            const e = s.closest("form");
                            e && e.addEventListener("click", (function(t) {
                                t.preventDefault();
                                const i = {};
                                e.querySelectorAll("input, select, textarea").forEach((e => {
                                    const t = e.getAttribute("name");
                                    if (t) i[t] = e.value;
                                    else {
                                        const t = e.getAttribute("id");
                                        i[t] = e.value
                                    }
                                })), o(null, i)
                            }))
                        }
                    }))
            }
        }))
    },
    ci = ({
        event: e,
        attributes: t,
        DOMTree: i
    }) => {
        var n;
        if (!(null === (n = Object.keys(t || {})) || void 0 === n ? void 0 : n.length)) return;
        const o = e.target;
        if ("submit" === o.getAttribute("type")) return;
        const r = dt(o, {
            root: i
        });
        Object.entries(t).forEach((([e, t]) => {
            if ("phone" === e) Object.keys(t).forEach((e => {
                e === r && (o.value = o.value.replace(/[^0-9+]/g, ""))
            }));
            else Object.keys(t).forEach((e => {
                if (e === r) {
                    const t = i.querySelector(e);
                    if ("number" === t.type) t.value = t.value.replace(/[^0-9]/g, "")
                }
            }))
        }))
    };
var ui = e => {
        var {
            activation_rule: t
        } = e;
        return !t || new ke(t).processUrlActivationRule()
    },
    li = (e, t) => te() ? void 0 !== (null == e ? void 0 : e.mobile) ? e.mobile : t : void 0 !== (null == e ? void 0 : e.default) ? e.default : t,
    di = e => {
        e > 0 && (j.optinDeferredUntil = Date.now() + 86400 * parseInt(e, 10) * 1e3)
    },
    pi = {
        showNativePrompt(e) {
            var {
                hintScreenConfig: t,
                subscribeCallback: i,
                source: n,
                nodeId: o,
                trackWebPushDenied: r,
                trackWebPushSubmission: s
            } = e;

            function a() {
                return window.poSubscriptionSource = S, i(t, n, o, r, s)
            }
            var {
                isSafari: c,
                isFirefox: u,
                isiOS: l
            } = re();
            if (!c && !u && !l) return a();
            var d = document.querySelector("body");
            return we("This is Safari/Firefox browser. The prompt will only show after the website is clicked somewhere"), new Promise((e => {
                d.addEventListener("click", (() => {
                    a().then(e)
                }))
            }))
        },
        oldRender(e) {
            var i, {
                    config: n,
                    subscribeCallback: o
                } = e,
                r = new z;
            if (!r.isPermissionNotGranted && window.Notification && window.Notification.permission === u.NOTIFICATION_PERMISSION.DEFAULT) {
                if (n.optin.type !== t.OFF) {
                    var s = n.optin.config,
                        a = s.timeout,
                        c = a.default,
                        l = n.optin.type,
                        d = s.overlay;
                    te() && (c = a.mobile);
                    var p = r.optinSeenCount; - 1 === c ? we('🟠 Optin prompt was not shown. Reason: timeout set to "never"') : p >= s.maxCountPerSession ? we("🟠 Optin prompt was not shown. Reason: maximum count per session limit reached (".concat(p, " / ").concat(s.maxCountPerSession, ")")) : Date.now() < j.optinDeferredUntil ? we("🟠 Optin prompt was not shown. Reason: deferred till ".concat(new Date(j.optinDeferredUntil))) : setTimeout((() => {
                        Notification.permission !== u.NOTIFICATION_PERMISSION.DEFAULT || j.isPermissionGranted ? we("🟠 Optin prompt was not shown. Reason: permission not default") : l === t.TWO_STEP ? Promise.all([
                            import ("./OptinPrompt.js"),
                            import ("./NewCustomPrompt.js")
                        ]).then((e => {
                            var [{
                                OptinPromptWidget: t
                            }, {
                                NewCustomPromptWidget: i
                            }] = e, {
                                position: a
                            } = s, c = t, u = new c;
                            if (c === i) u.setState(Ee(Ee({}, s), {}, {
                                logo: n.logo
                            })), setTimeout((() => {
                                o(null), u.changeState(te() ? "mobile-fade" : "down"), setTimeout(te() ? u.destroy.bind(u) : () => {
                                    u.changeState("fade-top"), setTimeout(u.destroy.bind(u), 300)
                                }, 5e3)
                            }), 5e3);
                            else {
                                var l = document.querySelector(".pushowl-optin");
                                l && (B.logToServer({
                                    message: "duplicate custom prompt",
                                    subdomain: B.subdomain,
                                    data: {
                                        breadcrumbs: ge
                                    }
                                }), l.remove()), u.setState({
                                    multilingual_title: s.multilingual_title,
                                    multilingual_description: s.multilingual_description,
                                    yesButton: s.yesButton,
                                    noButton: s.noButton,
                                    theme: s.theme,
                                    logo: n.logo,
                                    branding: n.branding,
                                    position: a,
                                    autoFocus: n.flags.custom_prompt_screenreader_support,
                                    yesButtonListener: () => {
                                        o(d), setTimeout((() => {
                                            u.destroy()
                                        }), 100), window.poSubscriptionSource = v, n.optin_report_enabled && window.poAnalytics.track("PNOptinAllowClicked", {
                                            optinSeenCount: r.optinSeenCount
                                        })
                                    },
                                    noButtonListener: () => {
                                        setTimeout((() => {
                                            u.destroy()
                                        }), 100), r.isPermissionNotGranted = !0, n.optin_report_enabled && window.poAnalytics.track("PNOptinLaterClicked", {
                                            optinSeenCount: r.optinSeenCount
                                        })
                                    }
                                })
                            }
                            r.optinSeenCount += 1, n.optin_report_enabled && window.poAnalytics.track("PNOptinShown", {
                                optinSeenCount: r.optinSeenCount
                            }), we("Custom Prompt shown. Config: ", n.optin), di(s.deferForDays)
                        })).catch((e => {
                            we("Error encountered in loading Optin prompt: ".concat(e.message))
                        })) : (this.showNativePrompt({
                            hintScreenConfig: d,
                            subscribeCallback: o
                        }), r.optinSeenCount += 1, we("Browser Prompt shown. Config: ", n.optin), di(s.deferForDays))
                    }), 1e3 * c)
                }
            } else r.isPermissionNotGranted ? i = "prompt was dismissed in this session" : window.Notification && window.Notification.permission !== u.NOTIFICATION_PERMISSION.DEFAULT && (i = "permission already ".concat(window.Notification.permission)), we("🟠 Optin prompt was not shown. Reason: ".concat(i))
        },
        renderPopup: e => Ne((function*() {
            var {
                showNextForm: t,
                deferForDays: i,
                node: n,
                shouldIncrementFrequency: o,
                waitTime: r,
                flowId: s,
                openShadowDOM: a,
                customOptinStep: c,
                isMerchantOnFreePlan: u
            } = e;
            try {
                var {
                    OptinForm: l
                } = yield
                import ("./index.js"), d = new z, p = new l(n, t, s, ti({
                    nodeId: n.id,
                    flowId: s,
                    channelType: n.channels,
                    optinType: "popup"
                }), a, d.config.subscription_confirmation, c, u);
                setTimeout((() => p.render()), 1e3 * r), di(i), o && (d.optinSeenCount += 1)
            } catch (e) {
                we("Error encountered in loading New Optin: ".concat(e.message))
            }
        }))(),
        renderEmbeddedFormOnDOM: e => Ne((function*() {
            var {
                showNextForm: t,
                node: i,
                flowId: n,
                DOMContainer: o
            } = e;
            try {
                var {
                    EmbeddedForm: r
                } = yield
                import ("./embedded-form.js"), s = new z;
                new r(i, t, n, ti({
                    nodeId: i.id,
                    flowId: n,
                    channelType: i.channels,
                    optinType: "embedded"
                }), !0, s.config.subscription_confirmation, o).render()
            } catch (e) {
                we("Error encountered in loading New Optin: ".concat(e.message))
            }
        }))(),
        showBrowserPrompt(e) {
            var {
                subscribeCallback: t,
                hintScreenConfig: i,
                shouldIncrementFrequency: n,
                deferForDays: o,
                waitTime: r,
                flowId: s,
                nodeId: a,
                formId: c,
                onDismiss: u
            } = e;
            if (Qe()) {
                ii({
                    event: "optin_viewed",
                    optinType: "browser_webpush",
                    flowId: s,
                    nodeId: a,
                    formId: c
                });
                var l = () => ii({
                        event: "optin_submitted",
                        optinType: "browser_webpush",
                        flowId: s,
                        nodeId: a,
                        formId: c
                    }),
                    d = () => {
                        u && u(), ii({
                            event: "optin_denied",
                            optinType: "browser_webpush",
                            flowId: s,
                            nodeId: a,
                            formId: c
                        })
                    };
                if (setTimeout((() => {
                        this.showNativePrompt({
                            hintScreenConfig: i,
                            subscribeCallback: t,
                            source: "optin_flows",
                            nodeId: a,
                            trackWebPushDenied: d,
                            trackWebPushSubmission: l
                        })
                    }), 1e3 * r), n)(new z).optinSeenCount += 1;
                di(o)
            }
        },
        showCustomPrompt: e => Ne((function*() {
            var {
                waitTime: t,
                shouldIncrementFrequency: i,
                flowId: n,
                deferForDays: o,
                config: r,
                subscribeCallback: s,
                custom_prompt_screenreader_support: a,
                nodeId: c,
                formId: u,
                logo: l,
                onDismiss: d
            } = e;
            try {
                if (!Qe()) return;
                var {
                    OptinPromptWidget: p
                } = yield
                import ("./OptinPrompt.js"), h = () => ii({
                    event: "optin_submitted",
                    optinType: "custom_webpush",
                    flowId: n,
                    nodeId: c,
                    formId: u
                }), g = () => {
                    d && d(), ii({
                        event: "optin_denied",
                        optinType: "custom_webpush",
                        flowId: n,
                        nodeId: c,
                        formId: u
                    })
                }, w = new p, m = new z;
                if (setTimeout((() => w.setState(Ee(Ee({}, r), {}, {
                        autoFocus: a,
                        yesButtonListener: () => {
                            s(r.overlay, "optin_flows", c, g, h), setTimeout((() => {
                                w.destroy()
                            }), 100), window.poSubscriptionSource = v
                        },
                        noButtonListener: () => {
                            g(), setTimeout((() => {
                                w.destroy()
                            }), 100), m.isPermissionNotGranted = !0, d && d()
                        },
                        logo: l
                    }))), 1e3 * t), ii({
                        event: "optin_viewed",
                        optinType: "custom_webpush",
                        flowId: n,
                        nodeId: c,
                        formId: u
                    }), di(o), i)(new z).optinSeenCount += 1
            } catch (e) {
                we("Error encountered in loading Custom prompt: ".concat(e.message))
            }
        }))(),
        processNewConfig(e) {
            var t, i = e.find((e => "active" === e.status));
            if (!i) return [];
            for (var n = [], o = i.flow_nodes || [], r = 0; r < o.length; r += 1) {
                var s = o[r - 1];
                if (r % 2 != 0) {
                    var a = s.wait_times ? li(s.wait_times, s.wait_time) : s.wait_time;
                    o[r].wait_time = a, o[r].underlay_color = i.underlay_color, o[r].underlay_opacity = i.underlay_opacity, o[r].underlay_enabled = i.underlay_enabled, n.push(o[r])
                }
            }
            var c = new z;
            if (null != c && null !== (t = c.config) && void 0 !== t && t.subscription_confirmation) {
                var u = n.find((e => e.channels.includes("email"))),
                    l = n.find((e => e.channels.includes("sms")));
                if (u && l && n.indexOf(u) > n.indexOf(l)) {
                    var d = n.indexOf(u),
                        p = n.indexOf(l),
                        h = n[d];
                    n[d] = n[p], n[p] = h
                }
            }
            return [Ee(Ee({}, i), {}, {
                flow_nodes: n
            })]
        },
        newRenderEmbeddedForm(e) {
            var {
                config: t,
                embeddedForm: i,
                DOMContainer: n
            } = e;
            if ("active" === i.status) {
                var {
                    activation_rule: o
                } = t;
                if (ui({
                        activation_rule: o
                    }))
                    for (var r = () => {
                            this.newRenderEmbeddedForm({
                                config: t,
                                embeddedForm: i,
                                DOMContainer: n
                            })
                        }, {
                            flow_nodes: s
                        } = i, a = 0; a < s.length; a += 1) {
                        var c = s[a];
                        if ("embedded" === c.optin_type) return void this.renderEmbeddedFormOnDOM({
                            node: c,
                            DOMContainer: n,
                            showNextForm: r,
                            flowId: i.id
                        })
                    }
            }
        },
        newRender(e) {
            var t = this,
                {
                    config: i,
                    optinFlows: n,
                    shouldIncrementFrequency: o,
                    subscribeCallback: r,
                    skippedNodes: s = [],
                    customOptinStep: a = 0
                } = e,
                c = this.processNewConfig(n || []).find((e => "active" === e.status)) || {};
            if (c.flow_nodes) {
                var {
                    flow_nodes: l
                } = c, {
                    activation_rule: d
                } = i, p = new z, {
                    optinSeenCount: h
                } = p, {
                    consent: g
                } = j, w = c && l && ui({
                    activation_rule: d
                }) && (e => {
                    var {
                        deferForDays: t,
                        shouldIncrementFrequency: i
                    } = e;
                    return !(i && t > 0 && Date.now() < j.optinDeferredUntil && (we("🟠 Optin prompt was not shown. Reason: deferred till ".concat(new Date(j.optinDeferredUntil))), 1))
                })({
                    deferForDays: c.defer_for_days,
                    shouldIncrementFrequency: o
                }) && (e => {
                    var {
                        frequency: t,
                        optinSeenCount: i,
                        shouldIncrementFrequency: n
                    } = e;
                    return !n || i < t || (we("🟠 Optin prompt was not shown. Reason: Optin seen count exceeded"), !1)
                })({
                    frequency: c.frequency,
                    optinSeenCount: h,
                    shouldIncrementFrequency: o
                });
                we("Can Optin Render", w);
                for (var m = function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : void 0,
                            o = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                        t.newRender({
                            config: i,
                            optinFlows: n,
                            shouldIncrementFrequency: !1,
                            subscribeCallback: r,
                            skippedNodes: e ? [...s, e] : s,
                            customOptinStep: o ? 0 : S()
                        })
                    }, b = function(e) {
                        var n = l[e],
                            d = s.includes(n.id),
                            p = n.forms[0] && ri(n.forms[0].config),
                            h = (e => {
                                var {
                                    channels: t,
                                    consent: i
                                } = e;
                                return t.every((e => i.includes(e)))
                            })({
                                consent: g,
                                channels: n.channels
                            });
                        if (w && !d && (p || !h)) {
                            if (-1 === n.wait_time) return "continue";
                            if ("popup" === n.optin_type) return we("Can render popup"), t.renderPopup({
                                node: n,
                                shouldIncrementFrequency: o,
                                showNextForm: m,
                                deferForDays: c.defer_for_days,
                                waitTime: n.wait_time,
                                flowId: c.id,
                                openShadowDOM: "enabled" === i.flags.open_shadow_dom,
                                customOptinStep: a,
                                isMerchantOnFreePlan: i.is_free_plan && "enabled" !== i.flags.disable_pushowl_branding
                            }), {
                                v: void 0
                            };
                            if ("browser_webpush" === n.optin_type) return t.showBrowserPrompt({
                                subscribeCallback: r,
                                waitTime: n.wait_time,
                                hintScreenConfig: n.forms[0].config.oneStep.overlay,
                                shouldIncrementFrequency: o,
                                deferForDays: c.defer_for_days,
                                flowId: c.id,
                                nodeId: n.id,
                                formId: n.forms[0].id,
                                onDismiss: () => {
                                    m(n.id)
                                }
                            }), {
                                v: void 0
                            };
                            if ("custom_webpush" === n.optin_type && window.Notification && window.Notification.permission === u.NOTIFICATION_PERMISSION.DEFAULT && !j.isPermissionGranted) {
                                var b = n.forms[0];
                                return t.showCustomPrompt({
                                    config: Ee(Ee({}, b.config.twoStep), {}, {
                                        position: {
                                            default: b.desktop_position,
                                            mobile: b.mobile_position
                                        }
                                    }),
                                    waitTime: n.wait_time,
                                    flowId: c.id,
                                    shouldIncrementFrequency: o,
                                    deferForDays: c.defer_for_days,
                                    subscribeCallback: r,
                                    custom_prompt_screenreader_support: i.flags.custom_prompt_screenreader_support,
                                    nodeId: n.id,
                                    formId: n.forms[0].id,
                                    logo: i.logo,
                                    onDismiss: () => {
                                        m(n.id)
                                    }
                                }), {
                                    v: void 0
                                }
                            }
                        }
                    }, f = 0; f < l.length; f += 1) {
                    var _ = b(f);
                    if ("continue" !== _ && "object" == typeof _) return _.v
                }
            } else we("Optin is set to OFF");

            function S() {
                return a >= 1 ? 0 : a + 1
            }
        }
    };
class hi {
    constructor(e) {
        var {
            wid: t,
            websitePushId: i
        } = e;
        this.wid = t, this.subdomain = B.subdomain, this.webPushId = i || B.webPushId, this.getSubscription = this.getSubscription.bind(this)
    }
    webServiceUrl() {
        return "".concat(B.apiEndpoint, "/safari/v2/").concat(this.wid)
    }
    getSubscription() {
        return new Promise(((e, t) => {
            var i = n => {
                    we("PermissionData:", n.permission), "default" === n.permission ? setTimeout((() => window.safari.pushNotification.requestPermission(this.webServiceUrl(), this.webPushId, {
                        domain: window.location.origin
                    }, i)), 0) : "denied" === n.permission ? t(u.NOTIFICATION_PERMISSION.DENIED) : "granted" === n.permission && e(n.deviceToken)
                },
                n = window.safari.pushNotification.permission(this.webPushId);
            i(n)
        }))
    }
}
class gi {
    constructor(e) {
        var {
            vapidPublicKey: t,
            integrations: i,
            serviceWorkerConfig: n
        } = e;
        this.getSubscription = this.getSubscription.bind(this), this.vapid_public_key = t, this.integrations = i, this.serviceWorkerConfig = n
    }
    getServiceWorkerParams(e) {
        return this.serviceWorkerConfig ? {
            url: this.serviceWorkerConfig.url,
            options: {
                scope: this.serviceWorkerConfig.scope
            }
        } : {
            url: B.getServiceWorkerUrlWithIntergrations(B.serviceWorkerUrl(e), this.integrations),
            options: {}
        }
    }
    getSubscription(e) {
        return new Promise(((t, i) => {
            ("granted" === Notification.permission ? Promise.resolve("granted") : Notification.requestPermission()).then((n => {
                if (n === u.NOTIFICATION_PERMISSION.GRANTED) {
                    var o = this.getServiceWorkerParams(e),
                        r = o.options;
                    0 !== o.url.indexOf("http") && (o.url = "".concat(location.protocol, "//").concat(location.host).concat(o.url)), navigator.serviceWorker.register(o.url, o.options).then((e => {
                        var n;
                        "shopify" === B.platform && ("/" === r.scope ? navigator.serviceWorker.getRegistrations().then((function(e) {
                            e.forEach((function(e) {
                                e.scope.match(/pushowl\/sdks\//) && (e.unregister(), we("Found stale service worker on subpath scope", e))
                            }))
                        })) : navigator.serviceWorker.getRegistrations().then((function(e) {
                            e.forEach((function(e) {
                                e.active && e.active.scriptURL.match(/pushowl/) && !e.scope.match(/pushowl\//) && (e.unregister(), we("Found stale service worker on root scope", e))
                            }))
                        }))), e.installing ? n = e.installing : e.waiting ? n = e.waiting : e.active && (n = e.active), n && ("activated" === n.state ? this._serviceWorkerSubscriber(e, t, i) : n.addEventListener("statechange", (n => {
                            "activated" === n.target.state && this._serviceWorkerSubscriber(e, t, i)
                        })))
                    })).catch((e => {
                        fe(e), i(e)
                    }))
                } else n !== u.NOTIFICATION_PERMISSION.DENIED && n !== u.NOTIFICATION_PERMISSION.DEFAULT || i(n)
            }))
        }))
    }
    _serviceWorkerSubscriber(e, t, i) {
        var n = {
            userVisibleOnly: !0,
            applicationServerKey: se(this.vapid_public_key)
        };
        e.pushManager.subscribe(n).then((e => {
            t(e)
        })).catch((n => {
            n.toString().indexOf("InvalidStateError") >= 0 ? e.pushManager.getSubscription().then((n => {
                n.unsubscribe().then((n => {
                    e.pushManager.subscribe({
                        userVisibleOnly: !0,
                        applicationServerKey: se(this.vapid_public_key)
                    }).then((e => {
                        t(e)
                    })).catch((e => {
                        i(e)
                    }))
                })).catch((e => {
                    i(e)
                }))
            })) : (fe(n), i(n))
        }))
    }
}
class wi {
    constructor(e) {
        var {
            flags: t,
            vapidPublicKey: i,
            integrations: n,
            websitePushId: o,
            wid: r,
            serviceWorkerConfig: s
        } = e;
        if (this.getSubscription = null, re().isApnsSafari) {
            var a = new hi({
                websitePushId: o,
                wid: r
            });
            this.getSubscription = a.getSubscription.bind(this, t)
        } else {
            var c = new gi({
                vapidPublicKey: i,
                integrations: n,
                serviceWorkerConfig: s
            });
            this.getSubscription = c.getSubscription.bind(this, t)
        }
    }
    get isPermissionGranted() {
        return window.Notification && window.Notification.permission === u.NOTIFICATION_PERMISSION.GRANTED || j.isPermissionGranted
    }
    get isPermissionDefault() {
        return B.isWorkerAvailable.then((e => "default" === window.Notification.permission)).catch((() => !1))
    }
}
if (!window.poAnalytics) {
    var mi = {
        storeConfigGUID: B.guid,
        subdomain: B.subdomain,
        visitorToken: j.visitorToken,
        sessionToken: j.sessionToken
    };
    window.poAnalytics = new tt({
        endpoint: "".concat(B.apiEndpoint, "/event/v1/events")
    }), window.poAnalytics.setVisitorProperties(mi), we("Analytics initialized with data: ", mi)
}
class bi extends class {
    constructor() {}
    get cartId() {
        return ""
    }
} {
    constructor(e) {
        super(), this.token = e.token, this.checkout_token = e.checkout_token, this.item_count = e.item_count, this.items = e.items
    }
    get cartId() {
        const e = [this.token || this.checkout_token || ""];
        let t = [];
        const i = {};
        for (const e of this.items) t.push(e.variant_id), i[e.variant_id] = e.quantity;
        t = t.sort(((e, t) => e - t));
        for (const n of t) {
            const t = i[n];
            e.push(`${n}:${t}`)
        }
        return e.concat(e).join("-")
    }
}
var fi, _i, Si, vi = {
    decodeBase64Id(e) {
        if (e && "string" == typeof e) {
            var t = e.split("::").shift();
            return window.atob(t).replace(/\?.*/, "").split("/").pop()
        }
        return e
    },
    detectAjaxCartUpdate(e) {
        var t = window.XMLHttpRequest.prototype.open;
        window.XMLHttpRequest.prototype.open = function(i, n) {
            this.addEventListener("readystatechange", (function() {
                var t = i.toUpperCase();
                ("GET" === t && "/cart/add.js" === n || "POST" === t && ("/cart/add.js" === n || "/cart/update.js" === n || "/cart/change.js" === n)) && 4 === this.readyState && "function" == typeof e && e()
            })), t.apply(this, arguments)
        }
    },
    detectAjaxCartUpdate2: e => {
        var t = window.fetch;
        window.fetch = function() {
            var i = arguments.length <= 0 ? void 0 : arguments[0],
                n = t(...arguments);
            return i.match(/api\/.*\/graphql/) ? (n.then((e => e.clone())).then((t => {
                try {
                    t.json().then((t => {
                        var i;
                        if (t && t.data && (t.data.checkoutLineItemsUpdate && t.data.checkoutLineItemsUpdate.checkout ? i = t.data.checkoutLineItemsUpdate.checkout : t.data.checkoutLineItemsAdd && t.data.checkoutLineItemsAdd.checkout && (i = t.data.checkoutLineItemsAdd.checkout), i)) {
                            var n = i.lineItems.edges.map((e => ({
                                variant_id: parseInt(vi.decodeBase64Id(e.node.variant.id), 10),
                                product_id: parseInt(vi.decodeBase64Id(e.node.variant.product.id), 10),
                                quantity: e.node.quantity
                            })));
                            "function" == typeof e && e({
                                checkout_token: vi.decodeBase64Id(i.id),
                                item_count: n.length,
                                items: n,
                                updated_at: (new Date).toISOString()
                            })
                        }
                    }))
                } catch (e) {}
            })), n) : n
        }
    },
    detectAjaxCartUpdate3: e => {
        var t = window.fetch;
        window.fetch = function() {
            var i = arguments.length <= 0 ? void 0 : arguments[0],
                n = "string" == typeof i ? i : i instanceof URL ? i.pathname : i instanceof Request ? i.url : "",
                o = (arguments.length <= 1 ? void 0 : arguments[1]) || {},
                r = o.method || "GET",
                s = t(...arguments);
            return ("GET" === r && n.includes("/cart/add") || "POST" === r && (n.includes("/cart/add") || n.includes("/cart/update") || n.includes("/cart/change"))) && s.then((() => {
                e()
            })), s
        }
    },
    detectBigCAjaxCartUpdate: e => {
        var t = window.fetch;
        window.fetch = function() {
            var i = (arguments.length <= 0 ? void 0 : arguments[0]) || "",
                n = (arguments.length <= 1 ? void 0 : arguments[1]) || {},
                o = n.method || "GET",
                r = t(...arguments);
            return "POST" === o && (i.includes("/cart/add") || i.includes("/cart/update")) && r.then((() => {
                e()
            })), r
        }
    },
    detectBigCAjaxCartUpdate2: e => {
        var t = window.XMLHttpRequest.prototype.open;
        window.XMLHttpRequest.prototype.open = function(i, n) {
            this.addEventListener("readystatechange", (function() {
                "POST" === i.toUpperCase() && (n.includes("/cart/add") || n.includes("/cart/update")) && 4 === this.readyState && "function" == typeof e && e()
            })), t.apply(this, arguments)
        }
    }
};
class yi extends class {
    constructor() {
        var e;
        this.subdomain = B.subdomain, this.environment = B.environment, this.apiEndpoint = B.apiEndpoint, this.apiClient = new Le, this.webPushId = B.webPushId, this.config = null, this.storageManager = new j, this.sessionManager = new z, this.storeLib = new(this.getStoreLibClass()), this.subscriberTokenExists = !!j.subscriberToken, this.tokenType = this.subscriberTokenExists ? "subscriber" : "visitor", this.tokenValue = this.subscriberTokenExists ? j.subscriberToken : j.visitorToken, this.customLog = console, window.sessionStorage && navigator.serviceWorker && (e = this.getConfig()).then((e => {
            this.config = e, (({
                logoURL: e
            }) => {
                try {
                    const t = Object.assign(Object.assign({}, ot), {
                            name: document.title,
                            short_name: document.title
                        }),
                        i = document.querySelector('meta[name="theme-color"]');
                    i && (t.theme_color = i.getAttribute("content") || ot.theme_color);
                    const n = document.querySelector('meta[property="og:site_name"]');
                    if (n) {
                        const e = n.getAttribute("content") || document.title;
                        t.name = e, t.short_name = e
                    }
                    const o = document.querySelector('meta[property="og:description"]');
                    o && (t.description = o.getAttribute("content") || "");
                    const r = JSON.stringify(t),
                        s = new Blob([r], {
                            type: "application/json"
                        }),
                        a = URL.createObjectURL(s),
                        c = document.createElement("link");
                    c.rel = "manifest", c.href = a;
                    const u = document.getElementsByTagName("head")[0];
                    document.querySelector("link[rel=manifest]") || u.insertBefore(c, u.firstChild);
                    const l = document.querySelector("link[rel=apple-touch-icon]");
                    if (e && !l) {
                        const t = document.createElement("link");
                        t.rel = "apple-touch-icon", t.href = e, u.insertBefore(t, u.firstChild)
                    }
                } catch (e) {
                    we("Unable to create manifest")
                }
            })({
                logoURL: e.logo
            }), me("Status", {
                ACR: e.abandoned_cart_enabled ? "🟢" : "🔴",
                "Browse abandonment": e.browse_abandonment_enabled ? "🟢" : "🔴",
                "Price drop": e.price_drop.enabled ? "🟢" : "🔴",
                "Back in stock": e.back_in_stock.enabled ? "🟢" : "🔴",
                "optin type": {
                    off: "🔴",
                    oneStep: "Browser prompt",
                    twoStep: "Custom prompt"
                }[e.optin.type],
                "Notification permission": window.Notification ? Notification.permission : null,
                "Store section": this.getStoreLibClass().section,
                "Notification Preferences": e.privacy.notification_preference.enabled ? "🟢" : "🔴"
            }), this.handleIOS(), this.load3PIntegrations()
        })), this.ready = new Promise((t => {
            this.init(e).then((() => {
                if ((!this.config.flags || "disabled" !== this.config.flags.status) && ((this.environment !== u.ENVIRONMENT.production || !this.config.flags || !1 !== this.config.flags.console_message && "disabled" !== this.config.flags.console_message) && this.customLog.log("[PushOwl Web Push Notifications] Starting up"), this.browserHandler = new wi({
                        flags: this.config.flags,
                        vapidPublicKey: this.config.vapid_public_key,
                        integrations: this.config.integrations,
                        websitePushId: this.config.website_push_id,
                        wid: this.config.wid,
                        serviceWorkerConfig: this.config.service_worker
                    }), this.isAllowed())) {
                    var e = {
                        subdomain: this.subdomain,
                        browserHandler: this.browserHandler,
                        config: this.config,
                        storeLib: this.storeLib,
                        storageManager: this.storageManager,
                        sessionManager: this.sessionManager
                    };
                    this.context = e, this.browserHandler.isPermissionGranted || !j.subscriberToken || j.hasRaisedUnsubscriptionEvent || (this.config.optin_report_enabled && window.poAnalytics.track("Unsubscribed"), j.hasRaisedUnsubscriptionEvent = !0), this.browserHandler.isPermissionGranted ? Ze.verifySubscriber({
                        browserHandler: this.browserHandler
                    }).then((() => {
                        this.syncCustomerId(), this.onSubscriberVerifiedOnPageLoad()
                    })).catch(((e, t) => {
                        we(e), e === o.NO_SUBSCRIBER_TOKEN || e === o.INVALID_SUBSCRIBER_TOKEN ? Ze.subscribe({
                            browserHandler: this.browserHandler,
                            websitePushId: this.config.website_push_id
                        }).catch((e => {
                            fe(e)
                        })) : e === o.INVALID_STATE_ERROR && Ze.validateOrSyncSubscription({
                            subscription: t,
                            websitePushId: this.config.website_push_id
                        })
                    })) : this.isBrevoEnabled() && this.onSubscriberVerifiedOnPageLoad(), this.browserHandler.isPermissionDefault.then((e => {
                        e && this.handlePushNotificationUnsubscription()
                    })), this.customTasks(), et.subscribeButtons({
                        context: e
                    }), this.checkPushowlSession(), this.onCanRun(), t()
                }
            })).catch((e => {
                fe(e)
            }))
        })), this.debugCustomTask(), this.onScriptLoad(), U.run()
    }
    handlePushNotificationUnsubscription() {
        var {
            consent: e
        } = j;
        1 === e.length && "webpush" === e[0] && (j.subscriberToken = null, H.del("pushowl_sw_subscriber_token")), j.isPermissionGranted = !1, j.consent = j.consent.filter((e => "webpush" !== e))
    }
    isBrevoEnabled() {
        return "enabled" === this.config.flags.brevo_email && !!this.config.brevo_ma_key
    }
    handleIOS() {
        var e;
        re().isiOS && navigator.standalone && !j.subscriberToken && !j.hasLoggediOSStandaloneMode && (j.hasLoggediOSStandaloneMode = !0), this.isAllowed() && re().isiOS && !navigator.standalone && z.installPromptSeenCount < 3 && !j.installPromptDismissed && null !== (e = this.config.ios_prompt) && void 0 !== e && e.enabled && (
            import ("./IOSInstallWidget.js").then((e => {
                var t, i, n, {
                        IOSInstallWidget: o
                    } = e,
                    r = new o({
                        title: null === (t = this.config.ios_prompt) || void 0 === t ? void 0 : t.title,
                        description: null === (i = this.config.ios_prompt) || void 0 === i ? void 0 : i.description,
                        btnText: null === (n = this.config.ios_prompt) || void 0 === n ? void 0 : n.btn_text
                    });
                setTimeout((() => {
                    r.init()
                }), 2e3)
            })), z.installPromptSeenCount += 1)
    }
    get flyoutHandler() {
        return new Promise((e => {
            import ("./FlyoutWidgetHandler.js").then((t => {
                var {
                    FlyoutWidgetHandler: i
                } = t;
                e(new i(this.config.flyout_config))
            })).catch((e => {
                we("Error encountered in loading Flyout widget: ".concat(e.message))
            }))
        }))
    }
    onScriptLoad() {}
    onConfigLoaded() {}
    onCanRun() {}
    onSubscriberVerifiedOnPageLoad() {}
    onSuccessfullSubscription() {}
    getStoreLibClass() {}
    getStoreCartClass() {}
    getCurrentProduct() {}
    isAllowed() {
        var {
            activation_rule: e
        } = this.config;
        return !e || e.processUrlActivationRule()
    }
    isAutomationAllowed() {
        var {
            automation_rule: e
        } = this.config;
        return !e || e.processUrlActivationRule()
    }
    filterSKU(e) {
        var {
            automation_rule: t
        } = this.config;
        return t ? Ee(Ee({}, e), {}, {
            items: ((e || {}).items || []).filter((e => !t.processSKU(e.sku)))
        }) : e
    }
    init(e) {
        return new Promise((t => {
            this.isEnabled().then((() => {
                (e || this.getConfig()).then((e => {
                    this.config = e, "enabled" === e.flags.subscriber_tracking && j.subscriberToken && (window.poAnalytics.setVisitorProperties({
                        wid: this.config.wid,
                        pagePath: window.location.href,
                        pageURL: window.location.origin + window.location.pathname,
                        subscriberToken: j.subscriberToken,
                        browserNotificationPermission: window.Notification ? window.Notification.permission : null
                    }), window.poAnalytics.track("subscriber_page_visited")), window.poAnalytics.setVisitorProperties({
                        wid: this.config.wid,
                        optinConfig: this.config.optin
                    }), we("Analytics visitor props set: ", {
                        wid: this.config.wid,
                        optinConfig: this.config.optin
                    }), window.poAnalytics.meta.isNewVisitor && this.config.optin_report_enabled && window.poAnalytics.track("SessionCreated"), t(e)
                }))
            })).catch((e => {
                fe(e), we("🔴 Shutting down. Reason: ".concat(e))
            }))
        }))
    }
    getConfig() {
        return We.get()
    }
    isEnabled() {
        return $e({
            subdomain: this.subdomain
        })
    }
    debugCustomTask() {
        var e = oe("poTaskType");
        e === f && (we("Task type", e), this.isEnabled().then((e => {
            ! function(e) {
                var {
                    subdomain: t,
                    StoreLibClass: i,
                    isEnabled: n
                } = e, o = u.STORAGE_KEYS, r = new z, s = new j, a = new Le, c = {
                    notification_permission: window.Notification && window.Notification.permission
                };
                c.localStorage = {
                    [o.VISITOR_TOKEN]: j.visitorToken,
                    [o.SESSION_TOKEN]: j.sessionToken,
                    [o.SUBSCRIBER_TOKEN]: j.subscriberToken,
                    [o.SUBSCRIPTION]: j.subscription,
                    [o.BACK_IN_STOCK_SUBSCRIPTIONS]: s.back_in_stock.subscriptions,
                    [o.PRICE_DROP_SUBSCRIPTIONS]: s.price_drop.subscriptions,
                    [o.SYNCED_CART_JSON]: j.synced_cart_json,
                    [o.SYNCED_CUSTOMER_ID]: j.syncedCustomerId,
                    [o.SYNCED_AC_EVENTS]: j.ac_events,
                    [o.OPTIN_DEFERRED_UNTIL]: j.optinDeferredUntil
                }, c.sessionStorage = {
                    [r.subscriptionVerifiedKey]: r.subscriptionVerified,
                    [r.permissionKey]: r.isPermissionNotGranted,
                    [r.optinSeenCountKey]: r.optinSeenCount
                }, c.subdomain = t, c.debug_url = window.location.href, c.user_agent = navigator.userAgent, c.logs = ge, Promise.all([new Promise((e => {
                    navigator.serviceWorker.getRegistrations().then((function(t) {
                        e(t.map((function(e) {
                            return {
                                scope: e.scope,
                                active: e.active
                            }
                        })))
                    }))
                })), n, i ? i.getCart() : Promise.resolve()]).then((e => {
                    var [t, i, n] = e;
                    n && (c.current_cart_json = n), t && t.length && (c.serviceWorkers = t), "string" == typeof i && (c.pushowl_not_enabled_reason = i), a.debugLog(c), window.prompt("Send this to PushOwl Support", JSON.stringify(c, !1, 2))
                }))
            }({
                subdomain: this.subdomain,
                StoreLibClass: this.getStoreLibClass(),
                isEnabled: e
            })
        })))
    }
    customTasks() {
        var e = oe("poTaskType");
        e && (we("Task type", e), e === m ? Ze.subscribeIfNotAlready({
            enableHintScreen: !0,
            websitePushId: this.config.website_push_id,
            browserHandler: this.browserHandler
        }) : e === b && Ze.unsubscribe(this.browserHandler))
    }
    checkPushowlSession() {
        "pushowl" === oe("utm_source") && function(e) {
            var {
                privacy: t
            } = e.config;
            if (t.notification_preference.enabled) {
                var i = document.querySelector("body"),
                    n = {
                        subdomain: e.subdomain,
                        subscriberToken: j.subscriberToken
                    };
                Promise.all([
                    import ("./NotificationPreference.js"),
                    import ("./NotificationPreferenceToggle.js")
                ]).then((e => {
                    var [{
                        NotificationPreference: o
                    }, {
                        NotificationPreferenceToggle: r
                    }] = e, s = new o(i, n, t.notification_preference);
                    new r(i, t.notification_preference, s).render(), we("Notification Preference shown.")
                })).catch((e => {
                    we("Error encountered in loading Notif preferences: ".concat(e.message))
                }))
            }
        }(this.context)
    }
    syncCustomerId() {
        var e = this.getStoreLibClass();
        if (e.customerId && e.customerId !== j.syncedCustomerId && this.config.privacy.customer_id) {
            if (window.Shopify && !j.subscriberToken) {
                var t = de(u.STORAGE_KEYS.SUBSCRIBER_TOKEN);
                t && (j.subscriberToken = t)
            }
            this.apiClient.syncSubscriber().then((() => {
                j.syncedCustomerId = e.customerId
            })).catch((() => {
                fe("Subscriber not synced")
            }))
        }
    }
    initiateDefaultPrompt(e, t, i, n, o) {
        var r = !(!e || te()) && e.enabled;
        return B.isWorkerAvailable.then((s => {
            if (s) return Ze.subscribe({
                enableHintScreen: r,
                hintScreenData: e,
                websitePushId: this.config.website_push_id,
                browserHandler: this.browserHandler,
                source: t,
                source_id: i
            }).then((e => {
                if (e && e.subscriberToken) {
                    var {
                        consent: t
                    } = j;
                    return j.consent = [...t, "webpush"], o && o(), this.onSuccessfullSubscription(), e
                }
                return n && n(), e
            })).catch((e => {})).finally((() => {
                var e = document.querySelector(".js-custom-prompt-2");
                e && e.remove()
            }));
            var a = this.subdomain.replace(/\./g, "-");
            return "sendinblue" !== B.platform && window.open("https://".concat(a, ".powl.co/subscribe?po_url=").concat(encodeURIComponent(window.location.href), "&env=").concat(this.environment, "&subdomain=").concat(this.subdomain, "&platform=").concat(B.platform), "", "width=700,height=500"), new Promise((e => {
                window.addEventListener("message", (t => {
                    var i = t.data;
                    if (i && "subscriptionFinish" === i.type) {
                        var n = i.data;
                        n && "granted" === n.status && (j.subscriberToken = n.subscriberToken, j.isPermissionGranted = !0, e({
                            subscriberToken: n.subscriberToken
                        }))
                    }
                }))
            }))
        }))
    }
    render() {
        var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
            t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
            i = this.getStoreLibClass();
        if (!this.config) throw "Pushowl Config not initialised";
        i.section === g.HOME ? this.defaultRender(t) : i.section === g.PRODUCT ? this.storeLib.getProductDetails(e).then((e => {
            this.productSectionRender(e)
        })) : i.section === g.CHECKOUT ? we("🟠 Optin prompt was not shown. Reason: Checkout page") : this.defaultRender(t), this.renderEmbeddedForms()
    }
    optinFlows(e) {
        var t = new at(this.config);
        Object.values(this.config.optin_flows || []).forEach((i => {
            var n, o = pi.processNewConfig([i] || []).find((e => "active" === e.status)) || {};
            if (o && "active" !== !o.status) {
                t.addOptinFlow({
                    id: o.id,
                    scrollDepth: o.scroll_depth,
                    exitIntent: o.exit_intent,
                    exclusionUrls: o.exclusion_urls || [],
                    inclusionUrls: o.inclusion_urls || [],
                    exclusionUrlsEnabled: o.exclusion_urls_enabled,
                    inclusionUrlsEnabled: o.inclusion_urls_enabled,
                    scrollDepthEnabled: o.scroll_depth_enabled,
                    timeSpent: li(o.time_spent || {}, 0),
                    timeSpentEnabled: o.time_spent_enabled,
                    deviceType: o.device_type || [],
                    requireAllConditions: null !== (n = "all" === o.trigger_mode) && void 0 !== n && n,
                    exclusion_countries: o.exclusion_countries || [],
                    exclusion_countries_enabled: o.exclusion_countries_enabled || !1
                }, (() => {
                    pi.newRender({
                        config: this.config,
                        optinFlows: [i],
                        shouldIncrementFrequency: e,
                        subscribeCallback: this.initiateDefaultPrompt.bind(this)
                    })
                }))
            }
        })), t.initialize()
    }
    renderEmbeddedForms() {
        var e = this.config.embedded_forms;
        e && e.length && (null == e || e.forEach((e => {
            document.querySelectorAll('div[data-pushowl-form-id="'.concat(e.id, '"]')).forEach((t => {
                t && pi.newRenderEmbeddedForm({
                    config: this.config,
                    embeddedForm: e,
                    DOMContainer: t
                })
            }))
        })))
    }
    defaultRender() {
        var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
            t = {
                isOptinRendered: !1,
                isFlyoutRendered: !1
            };
        "sendinblue" === B.platform ? pi.oldRender({
            config: this.config,
            subscribeCallback: this.initiateDefaultPrompt.bind(this)
        }) : this.optinFlows(e), t.isOptinRendered = !0;
        var i = this.config.home.flyout;
        return Qe() && i.enabled && window.Notification.permission !== u.NOTIFICATION_PERMISSION.GRANTED ? (this.flyoutHandler.then((e => {
            nt.renderOptin({
                rootContext: {
                    config: this.config,
                    browserHandler: this.browserHandler
                },
                flyoutHandler: e
            })
        })), t.isFlyoutRendered = !0) : we("Flyout was not shown. Reason: ".concat(i.enabled ? "permission already granted" : "flyout is disabled"), "Config: ", this.config.home.flyout), t
    }
    productSectionRender(e) {
        if (Qe()) {
            var t = e.currentVariant();
            if (!t) return void we("Current variant not found");
            me("Current product", {
                id: t.id,
                name: t.name,
                "Is in stock?": t.available ? "✅" : "❌",
                price: t.price
            });
            var {
                back_in_stock: i,
                price_drop: n
            } = this.config, o = {
                config: this.config,
                browserHandler: this.browserHandler
            };
            this.flyoutHandler.then((r => {
                var s = {
                    rootContext: o,
                    flyoutHandler: r,
                    product: e,
                    variant: t
                };
                if (!t.available && i.enabled && this.isAutomationAllowed()) nt.renderBackInStock(s);
                else if (t.available && n.enabled && this.isAutomationAllowed()) nt.renderPriceDrop(s);
                else {
                    var {
                        isFlyoutRendered: a
                    } = this.defaultRender();
                    a || r.remove()
                }
            }))
        }
    }
    showBrowserPrompt() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
            overlay: {
                enabled: !1
            }
        };
        return pi.showNativePrompt({
            hintScreenConfig: e,
            subscribeCallback: e => this.initiateDefaultPrompt(e)
        })
    }
    showCustomPrompt() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
            t = arguments.length > 1 ? arguments[1] : void 0;
        import ("./OptinPrompt.js").then((i => {
            var {
                OptinPromptWidget: n
            } = i, o = this.config.optin.config, r = new n, s = {
                multilingual_title: e.title ? {
                    default: e.title
                } : o.multilingual_title,
                multilingual_description: e.description ? {
                    default: e.description
                } : o.multilingual_description,
                yesButton: e.yesButton && e.yesButton.label ? {
                    multilingual_label: {
                        default: e.yesButton.label
                    }
                } : o.yesButton,
                noButton: e.noButton && e.noButton.label ? {
                    multilingual_label: {
                        default: e.noButton.label
                    }
                } : o.noButton
            };
            r.setState(Ee(Ee({}, s), {}, {
                theme: e.theme || o.theme,
                logo: e.logo || o.logo,
                position: e.position || o.position,
                autoFocus: this.config.flags.custom_prompt_screenreader_support,
                yesButtonListener: () => {
                    t && (window.poSubscriptionSource = v, this.config.optin_report_enabled && window.poAnalytics.track("PNOptinAllowClicked", {
                        optinSeenCount: this.sessionManager.optinSeenCount
                    })), this.initiateDefaultPrompt(void 0 === e.overlay ? o.overlay : e.overlay).then((() => {
                        "function" == typeof e.yesButtonListener && e.yesButtonListener()
                    })), setTimeout((() => {
                        r.destroy()
                    }), 100)
                },
                noButtonListener: () => {
                    setTimeout((() => {
                        r.destroy()
                    }), 100), this.sessionManager.isPermissionNotGranted = !0, t && this.config.optin_report_enabled && window.poAnalytics.track("PNOptinLaterClicked", {
                        optinSeenCount: this.sessionManager.optinSeenCount
                    }), "function" == typeof e.noButtonListener && o.noButtonListener()
                }
            })), t && this.config.optin_report_enabled && window.poAnalytics.track("PNOptinShown", {
                optinSeenCount: this.sessionManager.optinSeenCount
            })
        })).catch((e => {
            we("Error encountered in loading Optin Prompt widget (API): ".concat(e.message))
        }))
    }
    load3PIntegrations() {}
    klaviyoIntegration() {
        var e = function() {
            var e = Ne((function*(e) {
                var t = e && e.detail && e.detail.metaData && e.detail.metaData.$email;
                "stepSubmit" === e.detail.type && t && (j.email = t, J.identify(t))
            }));
            return function(t) {
                return e.apply(this, arguments)
            }
        }();
        window.addEventListener("klaviyoForms", e)
    }
    trackPage(e) {
        J.viewPage(e)
    }
    loadBrevoTracker() {
        return !("enabled" !== this.config.flags.brevo_email || !this.config.brevo_ma_key || !Y()) && (J.loadTracker({
            isNewTracker: "enabled" !== this.config.flags.old_tracker,
            maKey: this.config.brevo_ma_key
        }), j.email && (J.emailId = j.email), this.trackPage(), !0)
    }
    syncAbandonedCart(e, t) {
        this.isAutomationAllowed() && (e ? Promise.resolve(e) : this.getStoreLibClass().getCart()).then((e => {
            ! function(e) {
                var {
                    cartJson: t,
                    CartClass: i,
                    options: n = {
                        pushowl: !0,
                        brevo: !1
                    }
                } = e;
                if (t) {
                    var o = new i(t),
                        r = new Le,
                        s = o.token ? "token" : "checkout_token",
                        a = ["Cart Token:", o[s], "Cart Items", o.item_count, "Last synced Cart:", j.synced_cart_json, "AC Events:", j.ac_events],
                        c = j.synced_cart_json,
                        u = c ? new i(c) : null;
                    t.updated_at = t.updated_at || (new Date).toISOString(), o.item_count > 0 && (!u || o.cartId !== u.cartId) || 0 === o.item_count && u && u[s] === o[s] && u.cartId !== o.cartId ? (n.pushowl ? r.syncCart(o).then((e => {
                        j.synced_cart_json = t, j.ac_events = e.result;
                        var {
                            token: i
                        } = e.result;
                        i && (j.subscriberToken = i), we("Cart synced successfully. Response: ", e)
                    })).catch((e => {
                        fe(e), we("🔴 Cart sync failed. Error: request failed. ", e, ...a)
                    })) : j.synced_cart_json = t, n.brevo && Se(t)) : we("Cart was not synced. Reason: No change since last sync.", ...a)
                }
            }({
                cartJson: this.filterSKU(e),
                CartClass: this.getStoreCartClass(),
                options: t
            })
        })).catch((e => {
            fe(e), we("🔴 Cart sync failed. Error: cart could not be synced.  ", e)
        }))
    }
    syncCart(e) {
        this.config.abandoned_cart_enabled && this.isAutomationAllowed() && (j.subscriberToken ? Ze.verifySubscriber({
            browserHandler: this.browserHandler
        }).then((() => {
            this.syncAbandonedCart(e, {
                pushowl: !0,
                brevo: this.isBrevoEnabled()
            })
        })).catch((e => {
            fe(e), we("🔴 Cart sync failed. Error: cart could not be synced.  ", e)
        })) : this.syncAbandonedCart(e, {
            pushowl: !1,
            brevo: this.isBrevoEnabled()
        }))
    }
    syncProductView() {
        var e = this.getStoreLibClass(),
            t = this.config.browse_abandonment_enabled,
            i = this.config.price_drop,
            n = this.config.price_drop.is_viewed;
        e.section === g.PRODUCT && this.isAutomationAllowed() && this.getCurrentProduct().then((e => {
            this.isBrevoEnabled() && this.storeLib.getProductDetails().then((t => {
                var i = t.currentVariant() || {};
                J.track({
                    eventName: a.PRODUCT_VIEWED,
                    eventData: {
                        id: "".concat(e.id),
                        data: Ee(Ee({}, e), {}, {
                            title: t.title,
                            featured_image: i.featured_image || t.featured_image,
                            price: i.price || t.price,
                            currency: window.Shopify ? window.Shopify.currency.active : "",
                            url: ve(window.location.href),
                            current_variant: i
                        })
                    }
                }), i ? J.viewProduct(String(i.id)) : J.viewProduct(String(e.id))
            })), j.subscriberToken && (t || i && n) && this.apiClient.syncProductView(e).then((e => {
                var {
                    token: t
                } = e.result;
                t && (j.subscriberToken = t), we("Product synced", e)
            })).catch((e => {
                fe(e)
            }))
        })).catch((e => {
            fe(e)
        }))
    }
    subscriberLog(e) {
        var t = Object.entries(e).map((e => {
            var [t, i] = e;
            return "".concat(encodeURIComponent(t), "=").concat(encodeURIComponent(i))
        })).join("&");
        return U.get({
            path: "/log/?".concat(t)
        })
    }
    setCustomerId(e) {
        window.pushowl.customerId = e, this.browserHandler.isPermissionGranted && Ze.verifySubscriber({
            browserHandler: this.browserHandler
        }).then((() => {
            this.syncCustomerId()
        }))
    }
    setCheckoutId(e) {
        this.browserHandler.isPermissionGranted && Ze.verifySubscriber({
            browserHandler: this.browserHandler
        }).then((() => {
            this.apiClient.syncSubscriberTokenAndCheckoutId(e)
        }))
    }
    showBackInStock(e, t) {
        this.flyoutHandler.then((i => {
            nt.renderBackInStock({
                rootContext: this.context,
                flyoutHandler: i,
                product: e,
                variant: t
            })
        }))
    }
    showPriceDrop(e, t) {
        this.flyoutHandler.then((i => {
            nt.renderPriceDrop({
                rootContext: this.context,
                flyoutHandler: i,
                product: e,
                variant: t
            })
        }))
    }
    identify() {
        return arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}
    }
} {
    onCanRun() {
        this.processBrevoEmailParam();
        var {
            context: e
        } = this;
        this.render(), et.backInStockButtons({
            context: e,
            onSuccess: e => {
                this.productSectionRender(e)
            }
        }), et.priceDropButtons({
            context: e,
            onSuccess: e => {
                this.productSectionRender(e)
            }
        }), this.initAjaxCartDetection(), this.handleVariantChange(), this.watchForAnyPageChange()
    }
    watchForAnyPageChange() {
        var {
            pageName: e
        } = $;
        return "/" === window.location.pathname ? this.trackPage("Homepage") : $.section === g.THANK_YOU ? this.trackPage("Thank you") : e ? this.trackPage(e) : this.trackPage()
    }
    watchForViewCategoryPage() {
        var {
            collectionName: e,
            collectionId: t
        } = $;
        e && "all" !== e && void 0 !== t && J.viewCategory(t)
    }
    watchForViewSearchPage() {
        try {
            if ("/search" !== window.location.path) return;
            var e = decodeURIComponent(window.location.search.replace(/\?q=/, "").replace(/\+/g, " "));
            "" !== e && J.search(e, ve(window.location.href))
        } catch (e) {
            fe(e)
        }
    }
    processBrevoEmailParam() {
        try {
            var e = new URLSearchParams(window.location.search).get("_se"),
                t = e ? window.atob(e) : null,
                i = document.querySelector('meta[name="customer-email"]'),
                n = i ? i.getAttribute("content") : null;
            t && t !== j.email ? (j.email = t, j.consent = [...j.consent, "email"]) : n && (j.email = n, j.consent = [...j.consent, "email"])
        } catch (e) {
            we("Error in processing brevo email param", e)
        }
    }
    onSubscriberVerifiedOnPageLoad() {
        this.syncAbandonedCart(null, {
            pushowl: this.config.abandoned_cart_enabled,
            brevo: "enabled" === this.config.flags.brevo_email && this.config.brevo_ma_key
        }), this.syncProductView()
    }
    onScriptLoad() {
        this.recoveredCartManager()
    }
    onSuccessfullSubscription() {
        this.render(!1, !1)
    }
    getStoreLibClass() {
        return $
    }
    getStoreCartClass() {
        return bi
    }
    getCurrentProduct() {
        return this.storeLib.getRawCurrentProductDetails()
    }
    isEnabled() {
        return $e({
            subdomain: this.subdomain
        }).then((() => "undefined" == typeof __st && void 0 === window.Shopify ? Promise.reject(n.NOT_SHOPIFY) : Promise.resolve()))
    }
    initAjaxCartDetection() {
        if (this.config.abandoned_cart_enabled || "enabled" === this.config.flags.brevo_email) {
            var e = e => {
                this.browserHandler.isPermissionGranted ? Ze.verifySubscriber({
                    browserHandler: this.browserHandler
                }).then((() => {
                    we("[AJAX CART] Detected Add to Cart"), this.syncAbandonedCart(e, {
                        brevo: this.isBrevoEnabled(),
                        pushowl: this.config.abandoned_cart_enabled
                    })
                })) : this.isBrevoEnabled() && this.syncAbandonedCart(e, {
                    brevo: !0,
                    pushowl: !1
                })
            };
            vi.detectAjaxCartUpdate(e), this.config.flags && this.config.flags.enable_cart_detection_2 && vi.detectAjaxCartUpdate2(e), vi.detectAjaxCartUpdate3(e)
        }
    }
    handleVariantChange() {
        if ($.section === g.PRODUCT && (this.config.back_in_stock.enabled || this.config.price_drop.enabled)) {
            var e = document.querySelector('form[action$="cart/add"]'),
                t = document.querySelector('select[name="id"]');
            if (!e && t && (e = t.closest("form")), !e) return;
            var i = !1,
                n = () => {
                    i || (i = !0, setTimeout((() => {
                        we("In-page variant change detected"), this.render(), i = !1
                    }), 500))
                };
            e.addEventListener("change", n), e.onchange || (e.onchange = n)
        }
    }
    load3PIntegrations() {
        Y() && this.loadBrevoTracker(), this.watchForViewCategoryPage(), this.watchForViewSearchPage(), this.klaviyoIntegration();
        var e = [];
        e.length ? window.Notification && window.Notification.permission === u.NOTIFICATION_PERMISSION.GRANTED || navigator.serviceWorker.register("".concat(B.serviceWorkerUrl(), "&integrations=").concat(e.join(","))) : window.Notification && window.Notification.permission === u.NOTIFICATION_PERMISSION.GRANTED || navigator.serviceWorker.getRegistrations().then((function(e) {
            e.forEach((e => {
                e.active && e.active.scriptURL.match(/pushowl/) && e.unregister()
            }))
        }))
    }
    recoveredCartManager() {
        var e = oe("poCartData");
        if (e) try {
            var t = JSON.parse(window.atob(e));
            $.getCart().then((e => {
                if (0 === new bi(e).item_count) {
                    var {
                        cart: i
                    } = t;
                    ae({
                        method: "POST",
                        url: "/cart/update.js",
                        payload: {
                            updates: i
                        }
                    }).then((() => {
                        we("Cart Update Done"), window.location.href = window.location.origin + window.location.pathname
                    }))
                }
            }))
        } catch (e) {
            fe(e)
        }
    }
    identify() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
            {
                email: t,
                properties: i
            } = e,
            n = new z,
            {
                subscription_confirmation: o
            } = n.config;
        t && (j.email = t, o ? J.emailId = t : J.identify(t, i || {}))
    }
}
if (window.Shopify && !window.Shopify.customerPrivacy && window.Shopify.loadFeatures && window.Shopify.loadFeatures([{
        name: "consent-tracking-api",
        version: "0.1"
    }], (e => {})), B.isDisabled()) we("Pushowl is disabled in your store");
else {
    var Ei = new yi,
        Ii = (fi = Ei, _i = {
            LOG_LEVELS: s,
            setLogLevel: e => {
                j.logLevel = e, we("Log level set to: ".concat(e))
            },
            push(e) {
                fi.ready.then((() => {
                    e()
                }))
            },
            getSubdomain: () => fi.subdomain,
            isEnabled: () => fi.isEnabled(),
            subscriberLog: e => fi.subscriberLog(e),
            subscribe() {
                var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                return Ze.subscribeIfNotAlready({
                    enableHintScreen: e,
                    websitePushId: fi.config.website_push_id,
                    browserHandler: fi.browserHandler
                })
            },
            registerForEvent(e) {
                var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
                    n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
                return new Promise(((s, a) => {
                    Ze.subscribeIfNotAlready({
                        enableHintScreen: t,
                        websitePushId: fi.config.website_push_id,
                        browserHandler: fi.browserHandler
                    }).then((() => {
                        fi.storeLib.getProductDetails(!1, n.productAlias).then((t => {
                            var c = n.productVariantId ? t.getVariant(n.productVariantId) : t.currentVariant(),
                                l = null,
                                d = null;
                            if (e === r.BACK_IN_STOCK) l = u.EVENT_API_PATH.BACK_IN_STOCK, d = fi.storageManager.back_in_stock;
                            else {
                                if (e !== r.PRICE_DROP) return void a(o.UNKNOWN_EVENT);
                                l = u.EVENT_API_PATH.PRICE_DROP, d = fi.storageManager.price_drop
                            }
                            Ze.update(l, {
                                product_id: t.id,
                                product: t,
                                variant: c,
                                source: i.PARTNER_JS_API,
                                permission: window.Notification && window.Notification.permission
                            }).then((() => {
                                fi.productSectionRender(t), d.subscribe(c);
                                var e = {};
                                e[u.STORAGE_KEYS.SUBSCRIBER_TOKEN] = j.subscriberToken, s(e)
                            })).catch((e => {
                                fe(e)
                            }))
                        }))
                    })).catch((() => {
                        a({
                            error_code: o.PERMISSION_NOT_GRANTED
                        })
                    }))
                }))
            },
            isProductVariantSubscribed: (e, t) => "price_drop" === e ? fi.storageManager.price_drop.isSubscribed({
                id: t
            }) : "back_in_stock" === e && fi.storageManager.back_in_stock.isSubscribed({
                id: t
            }),
            showBrowserPrompt() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
                    overlay: {
                        enabled: !1
                    }
                };
                return fi.showBrowserPrompt(e)
            },
            showCustomPrompt() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return e.overlay = null, fi.showCustomPrompt(e)
            },
            showWidget(e) {
                var {
                    type: t
                } = e, i = Me(e, Xe);
                switch (t) {
                    case "browserPrompt":
                        return fi.showBrowserPrompt(i);
                    case "customPrompt":
                        return fi.showCustomPrompt(i, !0);
                    case "priceDrop":
                        return i.variant.name = i.variant.title, delete i.variant.title, fi.showPriceDrop(i.product, i.variant);
                    case "backInStock":
                        return i.variant.name = i.variant.title, delete i.variant.title, fi.showBackInStock(i.product, i.variant);
                    case "optinFlows":
                        return fi.optinFlows(!0)
                }
            },
            showEmbeddedForms: () => fi.renderEmbeddedForms(),
            syncCart: e => (e.item_count = e.items.length, e.items.forEach((e => {
                e.variantId && (e.variant_id = e.variantId, delete e.variantId), e.productId && (e.product_id = e.productId, delete e.productId)
            })), e.checkoutToken && (e.checkout_token = e.checkoutToken, delete e.checkoutToken), fi.syncCart(e)),
            syncPageName: e => fi.syncPageName(e),
            syncProductView: e => (e.productId && (e.product_id = e.productId, delete e.productId), fi.syncProductView(e)),
            setCustomerId: e => fi.setCustomerId(e),
            setCheckoutId: e => fi.setCheckoutId(e),
            getCurrentPermission: () => j.isPermissionGranted ? Promise.resolve(u.NOTIFICATION_PERMISSION.GRANTED) : window && window.Notification ? Promise.resolve(Notification.permission) : void 0,
            identify: e => fi.identify(e),
            trackCategoryPage: e => fi.trackCategoryPage(e),
            track: e => J.track(e)
        }, Si = {
            get(e, t) {
                if (!e[t] && fi[t]) {
                    we("🟠 Internal property accessed: ".concat(t));
                    var i = fi[t];
                    return "function" == typeof i ? i.bind(fi) : i
                }
                return Reflect.get(...arguments)
            }
        }, new Proxy(_i, Si)),
        Ti = [];
    window.pushowl && (Array.isArray(window.pushowl) ? we("Existing PushOwl found in queue mode with following tasks queued: ", Ti = window.pushowl) : we("Existing PushOwl found and will be reused. Pushowl seems to be loading twice on this page. Please check page source.")), window.pushowl && !Array.isArray(window.pushowl) || (window.poSubscriptionSource = "", window.pushowl = Ii, we("PushOwl instance created"), z.windowVariablesForOwly = window.pushowlSubdomain), Ti.length && Ei.ready.then((() => {
        we("PushOwl ready to execute API functions."), Ti.forEach((e => e())), we("Tasks from PushOwl queue executed. No. of tasks: ".concat(Ti.length))
    }))
}
export {
    Kt as A, si as B, Nt as C, At as D, ai as E, jt as F, oi as G, ci as H, Xt as I, Le as J, Wt as K, ni as L, Jt as M, J as N, Lt as O, l as P, Ot as R, j as S, Dt as T, O as _, z as a, te as b, be as c, we as d, re as e, u as f, X as g, ri as h, he as i, Ht as j, Yt as k, Bt as l, Qt as m, xt as n, $t as o, ee as p, qt as q, Tt as r, Vt as s, Rt as t, Mt as u, zt as v, kt as w, Pt as x, ei as y, Gt as z
};