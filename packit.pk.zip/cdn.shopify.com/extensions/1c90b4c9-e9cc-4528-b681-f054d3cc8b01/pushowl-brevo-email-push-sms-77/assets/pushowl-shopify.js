(() => {
    new Promise((o => {
        window.Shopify && !window.Shopify.customerPrivacy && window.Shopify.loadFeatures ? window.Shopify.loadFeatures([{
            name: "consent-tracking-api",
            version: "0.1"
        }], (s => {
            o()
        })) : o()
    }));
    var o = () => {
        var o = document.createElement("script");
        o.type = "module";
        var s = document.querySelector('script[src*="pushowl-shopify.js"]').src;
        o.src = s.split("?")[0].replace("pushowl-shopify.js", "pushowl-shopify-main.js"), "local" === (() => {
            try {
                return new URLSearchParams(window.location.search).get("pushowl_branch") || sessionStorage.getItem("pushowl_branch")
            } catch (o) {
                return null
            }
        })() && (sessionStorage.setItem("pushowl_branch", "local"), o.src = "https://localhost:3008/latest/sdks/pushowl-shopify-main.js?environment=staging&platform=shopify"), document.querySelector('script[src*="pushowl-shopify-main.js"]') || document.body.appendChild(o)
    };
    setTimeout((() => {
        try {
            o()
        } catch (o) {
            console.error("Error initializing PushOwl script", o)
        }
    }), 1500)
})();