const getProductIdFromMeta = () => {
    if (typeof(ShopifyAnalytics) === 'undefined') {
        return
    }

    const product = ShopifyAnalytics.meta.product

    if (!product) {
        return null
    }

    return product.id
}

const getProductIdFromForm = () => {
    const form = document.querySelector('form[action*="/cart/add"]')

    if (!form) {
        return null
    }

    const formId = form.attributes.id.value
    const match = formId.match(/\d+/)

    if (!match) {
        return null
    }

    return match[0]
}

const getProductIdFromJson = async () => {
    // We need to remove the query string when user is customizing the theme
    const pageUrl = window.location.href.split('?')[0].replace(/\/+$/, '')
    if (!pageUrl.includes('/products/')) {
        return null
    }

    try {
        const response = await fetch(pageUrl + '.json')
        const json = await response.json()
        const product = json.product

        if (!product) {
            return null
        }

        return product.id
    } catch (err) {
        console.error(err)
        return null
    }
}

const getCachedBlocksUpdatedAt = () => {
    if (!document.currentScript) {
        return
    }

    const scriptUrl = document.currentScript.src
    const updated_at = new URL(scriptUrl, 'https://cdn.shopify.com').searchParams.get('updated_at')
    return updated_at
}

const fetchPageBlocks = async () => {
    const host = 'https://' + 'product-feature-icons.herokuapp.com'
    const apiUrl = host + '/storefront_api'

    let url = `${apiUrl}/page_blocks?shop_url=${window.Shopify.shop}`

    const locale = Shopify.locale || document.querySelector('html').getAttribute('lang')
    url += `&locale=${locale}`

    const productId = getProductIdFromMeta() || await getProductIdFromJson()
    if (productId) {
        url += `&product_id=${productId}`
    }

    const manualBlocks = document.querySelectorAll('.kaching-icon-block')
    manualBlocks.forEach((manualBlock) => {
        url += `&block_ids[]=${manualBlock.dataset.blockId}`
    })

    const response = await fetch(url)
    const json = await response.json()

    if (response.status === 402) {
        return null
    }

    return json
}

const createBlock = (pageBlock) => {
    const template = document.createElement('template')
    const html = pageBlock.html.trim()
    template.innerHTML = html
    const block = template.content.firstChild
    block.dataset.blockId = pageBlock.id
    return block
}

const blockExists = (blockId) => (!!document.querySelector(`.kaching-icon-block--container[data-block-id="${blockId}"]`))

const addManualBlock = (pageBlock) => {
    const manualBlocks = document.querySelectorAll(`.kaching-icon-block[data-block-id="${pageBlock.id}"]`)

    manualBlocks.forEach((manualBlock) => {
        manualBlock.innerHTML = pageBlock.html
    })

    return manualBlocks.length > 0
}

const addProductBlock = (pageBlock) => {
    if (blockExists(pageBlock.id)) {
        return false
    }

    const forms = [...document.querySelectorAll('form[action*="/cart/add"]')]
    const productId = getProductIdFromMeta()
    const form = forms.find(x => x.attributes.id ? .value.includes(productId)) || forms[0]
    if (!form) {
        return false
    }

    const block = createBlock(pageBlock)

    form.parentElement.insertBefore(block, form.nextSibling)

    return true
}

const addCartBlock = (pageBlock) => {
    if (blockExists(pageBlock.id)) {
        return false
    }

    const forms = [...document.querySelectorAll('form[action*="/cart"]')] // /cart, /lt/cart
    const form = forms.find(form => !form.action.includes('/cart/add'))
    if (!form) {
        return false
    }

    const block = createBlock(pageBlock)

    form.appendChild(block)

    return true
}

const addFooterBlock = (pageBlock) => {
    if (blockExists(pageBlock.id)) {
        return false
    }

    const footer = document.querySelector('#shopify-section-footer footer')
    if (!footer) {
        return false
    }

    const block = createBlock(pageBlock)

    footer.insertBefore(block, footer.firstChild)

    return true
}

const addPageBlocks = (pageBlocks) => {
    let blocksAdded = false

    if (pageBlocks.manual.length) {
        pageBlocks.manual.forEach((pageBlock) => {
            if (addManualBlock(pageBlock)) {
                blocksAdded = true
            }
        })
    }

    if (pageBlocks.product.length) {
        if (addProductBlock(pageBlocks.product[0])) {
            blocksAdded = true
        }
    }

    if (pageBlocks.cart.length) {
        if (addCartBlock(pageBlocks.cart[0])) {
            blocksAdded = true
        }
    }

    if (pageBlocks.footer.length) {
        if (addFooterBlock(pageBlocks.footer[0])) {
            blocksAdded = true
        }
    }

    return blocksAdded
}

const addCustomCss = (customCss) => {
    if (!customCss) {
        return
    }

    const style = document.createElement('style')
    style.innerHTML = customCss
    document.head.appendChild(style)
}

const trackBlockViews = async () => {
    const url = 'https://' + 'product-feature-icons.herokuapp.com' + `/storefront_api/block_views?shop_url=${window.Shopify.shop}`
    const response = await fetch(url, {
        method: 'POST'
    })
    const json = await response.json()

    return json
}

const displayIconBlock = async () => {
    const pageBlocks = await fetchPageBlocks()
    if (!pageBlocks) {
        return
    }

    let blocksAdded = false

    addCustomCss(pageBlocks.custom_css)

    if (addPageBlocks(pageBlocks)) {
        blocksAdded = true
    }

    if (blocksAdded) {
        trackBlockViews()
    }

    // If manual blocks used with other apps (f.e. product tabs)
    setTimeout(() => addPageBlocks(pageBlocks), 300)
    setTimeout(() => addPageBlocks(pageBlocks), 1000)
    setTimeout(() => addPageBlocks(pageBlocks), 2500)
}

window.addEventListener('shopify:section:load', displayIconBlock)

displayIconBlock()