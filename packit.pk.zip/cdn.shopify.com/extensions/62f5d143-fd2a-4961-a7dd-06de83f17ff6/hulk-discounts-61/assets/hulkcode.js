if (!window.is_hulk_load_js) {
    window.is_hulk_load_js = !0;
    var checkout_selectors = "input[name='checkout']:not(.hulkapps-ignore), input[value='Checkout']:not(.hulkapps-ignore), button[name='checkout']:not(.hulkapps-ignore), [href$='checkout']:not(.hulkapps-ignore), button[value='Checkout']:not(.hulkapps-ignore), input[name='goto_pp'], button[name='goto_pp'], input[name='goto_gc'], button[name='goto_gc'],.hulkapps_checkout";
    if ("product" == window.hulkapps.page_type) {
        var variants = window.hulkapps.product.variants;
        window.hulkapps.product.selected_variant = null;
        var product_price = "",
            currency_symbol = "",
            display_price_setting = "";

        function updateSelectedVariant() {
            var t = document.querySelector('script[type="application/json"][data-variant]'),
                e = t.textContent && JSON.parse(t.textContent);
            window.hulkapps.product.selected_variant = e.id, product_price = e.price, window.hulkapps.product.selected_variant_price = e.price, hulkapps_jQuery("#hulkapps_options_" + window.hulkapps.product_id).closest("form").find(":submit").addClass("hulkapps_submit_cart"), window.$first_add_to_cart_el && window.$first_add_to_cart_el.removeClass("hulkapps_submit_cart").addClass("hulkapps_submit_cart")
        }
        window.buy_now_wrap = function() {
            if (window.dynamic_checkout_button_integration && window.eligible_product && !0 == window.legacy_vd) {
                var t = !1;
                let e = hulkapps_jQuery("[name='quantity']").val(),
                    i = window.hulkapps.product.selected_variant_price / 100 * e;
                if ("cart" != window.eligible_offer_type && parseInt(e) >= parseInt(window.qty_array[0]) && !window.bulk_exact_discount || window.bulk_exact_discount && window.qty_array.includes(e) || "cart" == window.eligible_offer_type && parseFloat(i) >= parseFloat(window.qty_array[0]) || window.is_hulkpo_installed && window.po_option_total > 0) {
                    let a = setInterval(function() {
                        hulkapps_jQuery(".shopify-payment-button").length > 0 && (hulkapps_jQuery(".shopify-payment-button").html().includes("ShopifyPay-button") || hulkapps_jQuery(".shopify-payment-button").html().includes("Checkout-button") || hulkapps_jQuery(".shopify-payment-button").html().includes("payment-button")) && (hulkapps_jQuery(".hulk_buy_now_handle").length <= 0 ? (hulkapps_jQuery(".shopify-payment-button").html().includes("ShopifyPay-button") ? hulkapps_jQuery(".shopify-payment-button").wrap("<a class='hulk-buy_now hulk_buy_now_handle' data-testid='ShopifyPay-button'></div>") : hulkapps_jQuery(".shopify-payment-button").html().includes("payment-button") ? hulkapps_jQuery(".shopify-payment-button").wrap("<a class='hulk-buy_now hulk_buy_now_handle' data-testid='payment-button'></div>") : hulkapps_jQuery(".shopify-payment-button").wrap("<a class='hulk-buy_now hulk_buy_now_handle' data-testid='Checkout-button'></div>"), hulkapps_jQuery(".shopify-payment-button").css({
                            "pointer-events": "none"
                        })) : (hulkapps_jQuery(".hulk_buy_now_handle").addClass("hulk-buy_now"), hulkapps_jQuery(".shopify-payment-button").css({
                            "pointer-events": "none"
                        }))), t = !0, clearInterval(a)
                    }, 1e3)
                } else hulkapps_jQuery(".shopify-payment-button").css({
                    "pointer-events": "inherit"
                }), hulkapps_jQuery(".hulk_buy_now_handle").removeClass("hulk-buy_now")
            } else hulkapps_jQuery(".shopify-payment-button").css({
                "pointer-events": "inherit"
            }), hulkapps_jQuery(".hulk_buy_now_handle").removeClass("hulk-buy_now")
        }, window.product_page_btn_condition = function() {
            var t = [];
            if (document.querySelectorAll(".single-option-selector,.swatch-element input[type='radio'],.single-option-selector__radio:checked, select[data-option='option1'], select[data-option='option1']:checked, select[data-option='option2'], select[data-option='option1']:checked, select[data-option='option3'], select[data-option='option3']:checked, select[data-index='option1'], select[data-index='option1']:checked, select[data-index='option2'], select[data-index='option1']:checked, select[data-index='option3'], select[data-index='option3']:checked, ul li div[swatch-option='option1'], input[type='radio']:not([name='card_group']):checked").forEach(function(e) {
                    t.push(e.value)
                }), 1 == (t = function(t, e) {
                    for (var i = [], a = t.length, o = 0; o < a; o++) {
                        var n = t[o];
                        e(n) && i.push(n)
                    }
                    return i
                }(t, function(t) {
                    return t
                })).length) var e = t;
            else var e = t.join(" / ");
            if (null != document.querySelector(".selected_variant span") ? document.querySelector(".selected_variant span").textContent : Object.keys(variants).forEach(function(t) {
                    var i = variants[t];
                    e = e.toString().toLowerCase(), i.title.toString().toLowerCase().trim() == e.trim() && (i.id, window.hulkapps.product.selected_variant = i.id, product_price = i.price, window.hulkapps.product.selected_variant_price = product_price), document.querySelector('script[type="application/json"][data-variant]') && document.querySelector('script[type="application/json"][data-variant]').textContent.trim() && updateSelectedVariant()
                }), null == window.hulkapps.product.selected_variant) try {
                let i = variants[0],
                    a = window.hulkapps.selected_or_first_available_variant_id ? .toString().trim(),
                    o = a ? variants.find(t => t ? .id ? .toString() === a) : i;
                window.hulkapps.product.selected_variant = parseInt(o.id), window.hulkapps.product.selected_variant_price = o.price, product_price = o.price
            } catch (n) {
                let l = variants[0];
                window.hulkapps.product.selected_variant = l.id, window.hulkapps.product.selected_variant_price = l.price, product_price = l.price
            }
        }
    }
    window.hulkLoadScript = function(t, e) {
        var i = document.createElement("script");
        i.type = "text/javascript", i.readyState ? i.onreadystatechange = function() {
            ("loaded" == i.readyState || "complete" == i.readyState) && (i.onreadystatechange = null, e())
        } : i.onload = function() {
            e()
        }, i.src = t, document.getElementsByTagName("head")[0].appendChild(i)
    }, window.checkAppInstalled = function(t) {
        window.hulkapps.is_volume_discount = !0, window.hulkapps.is_product_option || window.is_hulkpo_installed ? hulkLoadScript("https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/18.3.4/js/intlTelInput.min.js", function() {
            commonJS(t), cartPageJS(t), productPageJS(t), productPage_functionJS(t)
        }) : (commonJS(t), cartPageJS(t), productPageJS(t), productPage_functionJS(t))
    }, window.commonJS = function(t) {
        var e, i;

        function a(t) {
            var e, i;
            XMLHttpRequest.callbacks ? XMLHttpRequest.callbacks.push(t) : (XMLHttpRequest.callbacks = [t], e = XMLHttpRequest.prototype.send, XMLHttpRequest.prototype.send = function() {
                if (XMLHttpRequest.callbacks)
                    for (i = 0; i < XMLHttpRequest.callbacks.length; i++) XMLHttpRequest.callbacks[i](this);
                e.apply(this, arguments)
            })
        }
        window.getCartInfo(), window.fetch = new Proxy(window.fetch, {
            apply(t, e, i) {
                let a = t.apply(e, i);
                return a.then(t => {
                    var e = window.hulkappsParseURL(i[0]),
                        a = !1;
                    if (["/cart/change", "/cart/clear", "/cart/update", "/cart/add"].forEach(async function(e) {
                            if (i[0] && i[0].includes(e)) {
                                a = !0;
                                var o = await t.clone().json();
                                i[0].includes("/cart/add") && (o = void 0), window.getCartInfo(0, o)
                            }
                        }), !a && e && e.query) {
                        if (e.query.get("section_id") && e.query.get("section_id").includes("cart")) a = !0, window.getCartInfo();
                        else {
                            if (e.query.get("view") && e.query.get("view").includes("hulkapps_cart_collections")) return;
                            e.query.get("view") && e.path.includes("/cart") && !e.path.includes("/cart.js") && (a = !0, window.getCartInfo())
                        }
                    }!a && e && "/cart" === e.path && window.getCartInfo()
                }).catch(t => {}), a
            }
        }), a(function(t) {
            var e = !1,
                i = window.hulkappsParseURL(t._url);
            let a = ["/cart/change", "/cart/clear", "/cart/update", "/cart/add"];
            var o = !1;
            let n = function() {
                    if (t.readyState === XMLHttpRequest.DONE) {
                        if (o = !0, a.forEach(function(i) {
                                if (t._url && t._url.includes(i)) {
                                    e = !0;
                                    var a = t.status;
                                    if (0 === a || a >= 200 && a < 400) {
                                        var o = JSON.parse(t.response);
                                        t._url.includes("/cart/add") && (o = void 0), window.getCartInfo(0, o)
                                    }
                                }
                            }), !e && i && i.query) {
                            if (i.query.get("section_id") && i.query.get("section_id").includes("cart")) e = !0, window.getCartInfo();
                            else {
                                if (i.query.get("view") && i.query.get("view").includes("hulkapps_cart_collections")) return;
                                i.query.get("view") && i.path.includes("/cart") && !i.path.includes("/cart.js") && (e = !0, window.getCartInfo())
                            }
                        }!e && i && "/cart" === i.path && window.getCartInfo()
                    }
                },
                l = setInterval(function() {
                    o || (n(), o = !0), o && clearInterval(l)
                }, 1e3)
        }), e = hulkapps_jQuery, Document.prototype._hulkappsAddEventListener = Document.prototype.addEventListener, Document.prototype._hulkappsRemoveEventListener = Document.prototype.removeEventListener, Document.prototype._hulkappsAddEventListener = function(t, e, i = !1) {
            this._hulkappsAddEventListener(t, e, i), this.hulkappsEventListenerList || (this.hulkappsEventListenerList = {}), this.hulkappsEventListenerList[t] || (this.hulkappsEventListenerList[t] = []), this.hulkappsEventListenerList[t].push({
                type: t,
                listener: e,
                useCapture: i
            })
        }, Document.prototype._hulkappsRemoveEventListener = function(t, e, i = !1) {
            this._hulkappsRemoveEventListener(t, e, i), this.hulkappsEventListenerList || (this.hulkappsEventListenerList = {}), this.hulkappsEventListenerList[t] || (this.hulkappsEventListenerList[t] = []);
            for (let a = 0; a < this.hulkappsEventListenerList[t].length; a++)
                if (this.hulkappsEventListenerList[t][a].listener === e && this.hulkappsEventListenerList[t][a].useCapture === i) {
                    this.hulkappsEventListenerList[t].splice(a, 1);
                    break
                }
            0 == this.hulkappsEventListenerList[t].length && delete this.hulkappsEventListenerList[t]
        }, Document.prototype.hulkappsGetEventListeners = function(t) {
            return (this.hulkappsEventListenerList || (this.hulkappsEventListenerList = {}), void 0 === t) ? this.hulkappsEventListenerList : this.hulkappsEventListenerList[t]
        }, e("body").on("click", ".edit_cart_option", function(t) {
            t.preventDefault();
            var i = e(this).data("key"),
                a = window.hulkapps.cart,
                o = window.hulkapps.store_id,
                n = e(this).data("product_id"),
                l = e(this).data("variant_id");
            e("[name^='properties']").each(function() {
                "" == e(this).val() && e(this).attr("disabled", !0)
            });
            var s = e(this);
            e.ajax({
                type: "POST",
                url: window.hulkapps.po_url + "/api/v2/store/edit_cart_extension",
                data: {
                    cart_data: a,
                    item_key: i,
                    store_id: o,
                    variant_id: l,
                    customer_tags: null != window.hulkapps.customer ? window.hulkapps.customer.tags.split(",") : "",
                    cart_collections: JSON.stringify(window.hulkapps.cart_collections)
                },
                cache: !1,
                crossDomain: !0,
                success: function(t) {
                    if ("ok" == t) location.reload();
                    else {
                        window.currentEditOptionSelector = s, e("body").addClass("body_fixed"), e("body").find(".edit_popup").remove(), e("body").append('<div class="edit_popup" style="display: none;"><form method="post" data-action="/cart/add" id="edit_cart_popup" class="edit_form" enctype="multipart/form-data"></form></div>'), e("#edit_cart_popup").last().html(t), e(".edit_popup").show(), "undefined" != typeof jQuery && jQuery(document).off("focusin");
                        let i = document.hulkappsGetEventListeners("focusin");
                        if (i)
                            for (let a in i) document.removeEventListener("focusin", i[a].listener);
                        requireInventory(n, "hulkapps_edit_product_options"), calc_options_total(n, "hulkapps_edit_product_options"), conditional_rules(n, "hulkapps_edit_product_options")
                    }
                }
            })
        }), (i = hulkapps_jQuery).fn.fontselect = function(t, e) {
            var a = function(t, e) {
                    return function() {
                        return t.apply(e, arguments)
                    }
                },
                o = {
                    style: "font-select",
                    placeholder: "Select a font",
                    lookahead: 2,
                    api: "https://fonts.googleapis.com/css?family="
                };
            if (t.google_font)
                for (var n = Object.keys(t.google_font), l = Math.ceil(n.length / 3), s = 0; s < n.length; s += l) {
                    var p = n.slice(s, s + l).join("|"),
                        d = o.api + p;
                    0 === i("link[href*='" + p + "']").length && i("head").append('<link href="' + d + '" rel="stylesheet" type="text/css">')
                }
            if (t.custom_font) var u = t.custom_font;
            var c = function() {
                function e(t, e) {
                    this.$original = i(t), this.options = e, this.active = !1, this.setupHtml(), this.getVisibleFonts(), this.bindEvents(), this.$original.val() && this.updateSelected()
                }
                return e.prototype.bindEvents = function() {
                    var t = this;
                    i(document).click(function(e) {
                        t.active && !i(e.target).parents("#fontSelect-" + t.$original[0].id).length && t.toggleDrop()
                    }), i("li", this.$results).click(a(this.selectFont, this)).mouseenter(a(this.activateFont, this)).mouseleave(a(this.deactivateFont, this)), i("span", this.$select).click(a(this.toggleDrop, this)), this.$arrow.click(a(this.toggleDrop, this))
                }, e.prototype.toggleDrop = function(t) {
                    this.active ? (this.$element.removeClass("font-select-active"), this.$drop.hide(), clearInterval(this.visibleInterval)) : (this.$element.addClass("font-select-active"), this.$drop.show(), this.moveToSelected(), this.visibleInterval = setInterval(a(this.getVisibleFonts, this), 500)), this.active = !this.active
                }, e.prototype.selectFont = function() {
                    var t = i("li.active", this.$results).data("value");
                    this.$original.val(t).change(), this.updateSelected(), this.toggleDrop()
                }, e.prototype.moveToSelected = function() {
                    var t, e = this.$original.val();
                    t = e ? i("li[data-value='" + e + "']", this.$results) : i("li", this.$results).first(), this.$results.scrollTop(t.addClass("active")[0].offsetTop)
                }, e.prototype.activateFont = function(t) {
                    i("li.active", this.$results).removeClass("active"), i(t.currentTarget).addClass("active")
                }, e.prototype.deactivateFont = function(t) {
                    i(t.currentTarget).removeClass("active")
                }, e.prototype.updateSelected = function() {
                    var t = this.$original.val();
                    i("span", this.$element).text(this.toReadable(t)).css(this.toStyle(t))
                }, e.prototype.setupHtml = function() {
                    this.$original.empty().hide(), this.$element = i("<div>", {
                        id: "fontSelect-" + this.$original[0].id,
                        class: this.options.style
                    }), this.$arrow = i("<div><b></b></div>"), this.$select = i('<a><span tabindex="0">' + this.options.placeholder + "</span></a>"), this.$drop = i("<div>", {
                        class: "fs-drop"
                    }), this.$results = i("<ul>", {
                        class: "fs-results"
                    }), this.$original.after(this.$element.append(this.$select.append(this.$arrow)).append(this.$drop)), this.$drop.append(this.$results.append(this.fontsAsHtml())).hide()
                }, e.prototype.fontsAsHtml = function() {
                    if (h = "", t.google_font)
                        for (var e, a, o = n.length, l = "", s = 0; s < o; s++) e = this.toReadable(n[s]), a = this.toStyle(n[s]), h += '<li tabindex="0" aria-label="' + n[s] + '" data-is-custom="false" data-value="' + n[s] + '" style="font-family: ' + a["font-family"] + "; font-weight: " + a["font-weight"] + '">' + e + "</li>";
                    if (t.custom_font) {
                        for (var p = Object.keys(u).length, s = 0; s < p; s++) {
                            var d = Object.keys(u)[s];
                            e = this.toReadable(d), a = this.toStyle(d);
                            var c = u[d];
                            l += '@font-face {font-family: "' + d + '";src: url(' + c + ");} ", h += '<li tabindex="0" aria-label="' + d + '"  data-is-custom="true"  data-value="' + d + '" style="font-family: ' + d + '">' + e + "</li>"
                        }
                        i("head").append("<style>" + l + "</style>")
                    }
                    return h
                }, e.prototype.toReadable = function(t) {
                    return t.replace(/[\+|:]/g, " ")
                }, e.prototype.toStyle = function(t) {
                    var e = t.split(":");
                    return {
                        "font-family": this.toReadable(e[0]),
                        "font-weight": e[1] || 400
                    }
                }, e.prototype.getVisibleFonts = function() {
                    if (!this.$results.is(":hidden")) {
                        var t, e = this,
                            a = this.$results.scrollTop() + this.$results.height();
                        if (this.options.lookahead) {
                            var o = i("li", this.$results).first().height();
                            a += o * this.options.lookahead
                        }
                    }
                }, e
            }();
            return this.each(function() {
                return e && i.extend(o, e), new c(this, o)
            })
        }, window.hulkDraftOrder = function() {
            return window.is_draft_order
        }, window.hulkappsDoActions = function(e) {
            e && (e.discounts.discount_show ? t(".discount_code_box").css("display", "block") : t(".discount_code_box").css("display", "none"), window.hulk_eligible_options && window.hulk_eligible_options.length > 0 && e.discounts.display && e.discounts.display.enable_payment_setting && (e.discounts.is_draft_order ? t("#hulk-payment-settings").css("display", "block") : t("#hulk-payment-settings").css("display", "none")), e.discounts.plan && t(".edit_cart_option").css("display", "block"), "object" == typeof e.discounts && "object" == typeof e.discounts.cart && "object" == typeof e.discounts.cart.items && hulkappsShowCartDiscounts(e.discounts))
        }, t(document).on("click", checkout_selectors, function(e) {
            if (e.preventDefault(), window.hulk_inventory_arr && window.hulk_inventory_arr.length > 0) {
                var i = '<div class="hulkapps_summary inventory_validation_hulkapps">';
                return window.hulk_inventory_arr.forEach(function(t) {
                    i += t
                }), i += "</div>", t(".inventory_validation_hulkapps").remove(), t(this).parent().after(i), !1
            }
            if (t(".inventory_validation_hulkapps").remove(), t("#hulk-vd-payment-options").is(":visible") && window.hulk_eligible_options && window.hulk_eligible_options.length > 0) {
                if (t("#hulk-vd-payment-options").val()) t(".hulk_vd_net_payment").remove();
                else {
                    var i = "<div class='hulkapps_summary hulk_vd_net_payment'>Please select payment option</div>";
                    return t(".hulk_vd_net_payment").remove(), t("#hulk-payment-settings").after(i), !1
                }
                if ("Fixed" == t("#hulk-vd-payment-options").val()) {
                    if (t("#hulk-vd-fixed-date").val()) t(".hulk_vd_net_payment").remove();
                    else {
                        var i = `<div class='hulkapps_summary hulk_vd_net_payment'>${window.payment_validation_message}</div>`;
                        return t(".hulk_vd_net_payment").remove(), t("#hulk-payment-settings").after(i), !1
                    }
                    if (t("#hulk-vd-fixed-date").is(":invalid")) {
                        var i = "<div class='hulkapps_summary hulk_vd_net_payment'>" + t("#hulk-vd-fixed-date")[0].validationMessage + "</div>";
                        return t(".hulk_vd_net_payment").remove(), t("#hulk-payment-settings").after(i), !1
                    }
                }
            } else t(".hulk_vd_net_payment").remove();
            if (window.is_draft_order && window.hulk_inventory_arr && window.hulk_inventory_arr.length <= 0) {
                if ("function" != typeof hulkappsCheckout && (window.location = "/checkout"), "undefined" == typeof IntegrationCheckoutClick) hulkappsCheckout(null);
                else {
                    var a = IntegrationCheckoutClick();
                    !0 == a.required ? hulkappsCheckout(a) : !1 != a.required && hulkappsCheckout(a)
                }
            } else {
                let o = "dodoskin.myshopify.com" === window.hulkapps.store_id ? "en" : Shopify.locale,
                    n = "auroliv.myshopify.com" === window.hulkapps.store_id ? "" : "?locale=" + o;
                if ("undefined" == typeof IntegrationCheckoutClick) window.location = "/checkout" + n;
                else {
                    var a = IntegrationCheckoutClick();
                    if (!0 == a.required) window.location = "/checkout" + n;
                    else if (!1 != a.required) window.location = "/checkout" + n;
                    else if (!1 == a.required) return !1
                }
            }
        }), window.hulkappsShowCartDiscounts = function(e) {
            window.hulkapps.discounts = e;
            var i = 0;
            e.cart.items.forEach(function(a, o) {
                a.fomo_reminder_message_html ? (t(".hulkapps-reminder[data-key='" + a.key + "']").html(a.fomo_reminder_message_html), t("[data-hulkapps-reminder][data-key='" + a.key + "']").html(a.fomo_reminder_message_html)) : (t(".hulkapps-reminder[data-key='" + a.key + "']").html(""), t("[data-hulkapps-reminder][data-key='" + a.key + "']").html("")), !0 == e.legacy_vd && (a.discounted_price < a.original_price ? (i = 1, t(".hulkapps-cart-item-price[data-key='" + a.key + "']").html("<span class='original_price' style='text-decoration:line-through;'>" + a.original_price_format + "</span><br/><span class='discounted_price'>" + a.discounted_price_format + "</span>"), t(".hulkapps-cart-item-line-price[data-key='" + a.key + "']").html("<span class='original_price' style='text-decoration:line-through;'>" + a.original_line_price_format + "</span><br/><span class='discounted_price'>" + a.discounted_line_price_format + "</span>"), t("[data-hulkapps-line-price][data-key='" + a.key + "']").html("<span class='original_price' style='text-decoration:line-through;'>" + a.original_line_price_format + "</span><br/><span class='discounted_price'>" + a.discounted_line_price_format + "</span>"), t("[data-hulkapps-ci-price][data-key='" + a.key + "']").html("<span class='original_price' style='text-decoration:line-through;'>" + a.original_price_format + "</span><br/><span class='discounted_price'>" + a.discounted_price_format + "</span>")) : 0 == window.hulkapps.cart.items[o].discounts.length && (t(".hulkapps-cart-item-price[data-key='" + a.key + "']").html("<span class='original_price'>" + a.original_price_format + "</span>"), t(".hulkapps-cart-item-line-price[data-key='" + a.key + "']").html("<span class='original_price'>" + a.original_line_price_format + "</span>"), t("[data-hulkapps-line-price][data-key='" + a.key + "']").html("<span class='original_price'>" + a.original_line_price_format + "</span>"), t("[data-hulkapps-ci-price][data-key='" + a.key + "']").html("<span class='original_price'>" + a.original_price_format + "</span>")))
            }), t(".hulkapps-discount-bar").html(""), t(".hulkapps-cart-total,.hulkapps-discount-reminder-msg").remove(), t(".hulkapps-cart-original-total").css("text-decoration", "none"), 1 == i || e.cart_discount_msg_html || e.is_draft_order ? (null == e.final_with_discounted_price && e.discounted_price_total != e.original_price_total && e.legacy_vd ? (t("[data-hulkapps-cart-total]").length > 0 ? (t("[data-hulkapps-cart-total]").html(e.original_price_total).css("text-decoration", "line-through"), t("<span class='hulkapps-cart-total'>" + e.discounted_price_total + "</span>").insertAfter("[data-hulkapps-cart-total]")) : (t(".hulkapps-cart-original-total").html(e.original_price_total).css("text-decoration", "line-through"), t("<span class='hulkapps-cart-total'>" + e.discounted_price_total + "</span>").insertAfter(".hulkapps-cart-original-total")), parseFloat(e.discounted_line_price_total) > parseFloat(e.original_line_price_total) && t("[data-hulkapps-cart-total], .hulkapps-cart-original-total").css("text-decoration", "none")) : null != e.final_with_discounted_price && e.legacy_vd && (t("[data-hulkapps-cart-total]").length > 0 ? (t("[data-hulkapps-cart-total]").html(e.original_price_total).css("text-decoration", "line-through"), t("<span class='hulkapps-cart-total'>" + e.final_with_discounted_price + "</span>").insertAfter("[data-hulkapps-cart-total]")) : (t(".hulkapps-cart-original-total").html(e.original_price_total).css("text-decoration", "line-through"), t("<span class='hulkapps-cart-total'>" + e.final_with_discounted_price + "</span>").insertAfter(".hulkapps-cart-original-total"))), t(".hulkapps-discount-bar").length > 0 ? t(".hulkapps-discount-bar").html(e.cart_discount_msg_html) : (t(".hulkapps-discount-bar-msg").remove(), t('form[action="/cart"]').prepend(e.cart_discount_msg_html))) : t(".hulkapps-discount-bar-msg").remove(), e.cart_discount_reminder_msg_html ? t(".hulkapps-cart-reminder").length > 0 ? t(".hulkapps-cart-reminder").html(e.cart_discount_reminder_msg_html) : (t(".hulkapps-discount-reminder-msg").remove(), t('form[action="/cart"]').prepend(e.cart_discount_reminder_msg_html)) : t(".hulkapps-discount-reminder-msg").remove(), hulkapps_jQuery(".hulkapps_summary").remove();
            var a = parseFloat(e.discount_cut_price);
            e.legacy_vd && (e.discount_code && "null" !== e.discount_code && 1 == e.discount_error ? (t(".hulkapps-cart-original-total").html(e.original_price_total), t("[data-hulkapps-cart-total]").html(e.original_price_total), t(".hulkapps_discount_hide").after("<span class='hulkapps_summary'>Discount code does not match</span>"), localStorage.removeItem("discount_code"), t(".hulkapps-summary-line-discount-code").html(""), t(".after_discount_price").html("")) : e.is_free_shipping ? (t(".hulkapps_summary").remove(), t(".hulkapps-summary-line-discount-code").html(""), t(".after_discount_price").html(""), t(".hulkapps_discount_hide").after("<span class='hulkapps-summary-line-discount-code'><span class='discount-tag'>" + e.discount_code + "<span class='close-tag'></span></span>Free Shipping")) : e.discount_code && "null" !== e.discount_code && a <= 0 && e.discount_show ? (t(".hulkapps-cart-original-total").html(e.original_price_total), t("[data-hulkapps-cart-total]").html(e.original_price_total), t(".hulkapps_discount_hide").after("<span class='hulkapps_summary'> Discount code isn’t valid for the items in your cart</span>"), t(".hulkapps-summary-line-discount-code").html(""), t(".after_discount_price").html(""), t(".hulkapps_discount_code").val(""), localStorage.removeItem("discount_code")) : e.discount_code && "null" !== e.discount_code && e.discount_show ? (t(".hulkapps-summary-line-discount-code,.after_discount_price").remove(), t(".hulkapps_discount_hide").after("<span class='hulkapps-summary-line-discount-code'><span class='discount-tag'>" + e.discount_code + "<span class='close-tag'></span></span><span class='hulkapps_with_discount'> -" + e.with_discount + "</span></span><span class='after_discount_price'><span class='final-total'>Total</span>" + e.final_with_discounted_price + "</span>"), 1 == i || e.cart_discount_msg_html ? t("[data-hulkapps-cart-total]").html(e.discounted_price_total) : t("[data-hulkapps-cart-total]").html(e.original_price_total), t(".hulkapps-cart-total").remove()) : (localStorage.removeItem("discount_code"), t("[data-hulkapps-cart-total]").html(e.original_price_total), t("[data-hulkapps-cart-total]") || t(".hulkapps-cart-original-total").html(e.original_price_total), t(".hulkapps-summary-line-discount-code").html(""), t(".after_discount_price").html(""), t(".discount_code_box").find(".hulkapps_summary").html(""))), parseFloat(e.original_line_price_total) != parseFloat(e.discounted_line_price_total) || e.final_with_discounted_price || t("[data-hulkapps-cart-total], .hulkapps-cart-original-total").css("text-decoration", "none")
        }, window.hulkappsCheckout = function(e) {
            if (window.hulk_inventory_arr && window.hulk_inventory_arr.length > 0) return !1;
            var i = t("#hulk-vd-payment-options").val(),
                a = t("#hulk-vd-fixed-date").val();
            "other" == i ? (i = "", a = "") : "Fixed" != i && (a = new Date().toISOString().split("T")[0]);
            var o = {};
            null != e && 1 == e.shipping_status && (o = {
                price: e.shipping_price,
                title: e.shipping_method
            });
            for (var n = 0; n < window.hulkapps.cart.items.length; n++) {
                var l = window.hulkapps.cart.items[n],
                    s = document.querySelectorAll("[id='updates_" + l.key + "']");
                1 != s.length && (s = document.querySelectorAll("[id='updates_" + l.variant_id + "']")), 1 == s.length && (window.hulkapps.cart.items[n].quantity = s[0].value)
            }
            var p = "";
            window.hulkapps.is_volume_discount ? p = window.hulkapps.vd_url + "/shop/create_draft_order" : window.hulkapps.is_product_option && (p = window.hulkapps.po_url + "/store/create_draft_order");
            var d = localStorage.getItem("discount_code"),
                u = window.hulkapps.customer ? window.hulkapps.customer.tags : "",
                c = Shopify.locale;
            t.getJSON("/cart.js", {
                _: new Date().getTime()
            }, function(e) {
                e && e.item_count > 0 && (window.hulkapps.cart = e, new Promise((e, i) => {
                    t.ajax({
                        url: "/cart?view=hulkapps_cart_collections.json",
                        success: function(i) {
                            try {
                                if (i) {
                                    var a = JSON.parse(i);
                                    if (a) {
                                        var o = a.items;
                                        t.each(o, function(t, e) {
                                            window.hulkapps.cart_collections[e.variant_id] = e.product_collections, window.hulkapps.product_tags[e.product_id] = e.product_tags
                                        })
                                    }
                                }
                                e({
                                    cart_collections: window.hulkapps.cart_collections,
                                    product_tags: window.hulkapps.product_tags
                                })
                            } catch (n) {
                                e({
                                    cart_collections: window.hulkapps.cart_collections,
                                    product_tags: window.hulkapps.product_tags
                                })
                            }
                        },
                        error: function(t) {
                            e({
                                cart_collections: window.hulkapps.cart_collections,
                                product_tags: window.hulkapps.product_tags
                            })
                        }
                    })
                }).then(function(e) {
                    cart_collections = e.cart_collections, cart_product_tags = e.product_tags, window.hulkapps.cart_collections = cart_collections, window.hulkapps.product_tags = cart_product_tags, t.ajax({
                        type: "POST",
                        url: p,
                        data: {
                            cart_json: window.hulkapps,
                            store_id: window.hulkapps.store_id,
                            discount_code: d,
                            cart_collections: JSON.stringify(window.hulkapps.cart_collections),
                            cart_product_tags: JSON.stringify(window.hulkapps.product_tags),
                            ctags: u,
                            order_app: o,
                            draft_order_language: void 0 != c ? c : "",
                            payment_option: i,
                            payment_date: a
                        },
                        crossDomain: !0,
                        success: function(t) {
                            "string" == typeof t ? window.location.href = t : window.location.href = "/checkout"
                        }
                    })
                }).catch(function(t) {
                    console.error(t)
                }))
            })
        }, window.eligible_offer = function(e) {
            var i = e.eligible_offer,
                a = i.main_offer_type,
                o = e.store_currency,
                n = window.hulkapps.money_format,
                l = e.store_currency.length,
                s = n.slice(n.indexOf("{{") - l, n.indexOf("{{")),
                p = n.slice(n.indexOf("}}") + 2, n.indexOf("}}") + 2 + l);
            s = s == e.store_currency ? s : "", p = p == e.store_currency ? p : "", "" == s && "" == p && (s = o), window.prefix_symbol = s, window.suffix_symbol = p, e.p_id, e.is_date_validate;
            var d = e.charges_applied,
                u = e.display_setting,
                c = e.collection_object,
                f = i.offer_type;
            let v = i.offer_title ? i.offer_title : "",
                m = i.offer_description ? i.offer_description : "";
            i.discount_type && i.discount_type;
            let k = u.free_field ? u.free_field : "Free",
                g = u.list_total ? u.list_total : "Total",
                $ = u.list_button_text ? u.list_button_text : "GRAB THIS DEAL",
                b = u.is_widget_buynow_btn,
                y = u.widget_buynow_btn_color,
                x = u.widget_buynow_btn_text,
                _ = u.widget_buynow_bg_color,
                w = Shopify.currency.rate || 1;
            if (!d) return "";
            if ("volume" == a || "cart" == a) {
                var q, C, S, j, A, z = "each_qty" == i.discount_type ? JSON.parse(i.offer_levels) : JSON.parse(i.fix_quantity_level);
                if ("grid" === i.display_offer_table_or_banner || "list" === i.display_offer_table_or_banner) return get_offer_table_layout(i.offer_layout_id, u, z, o, s, p, f, v, m, i);
                if (i.banner_msg) {
                    C = z[0][0], S = z[0][1], j = z[0][2];
                    let O = S * w;
                    O = currency_conversion(O);
                    let E = z[0][4] ? z[0][4] : "",
                        L = "none",
                        F = "",
                        T = "";
                    "1" == E && (L = "inline-block", F = JSON.parse('{"pop_offer_text":"Most Popular","pop_offer_text_size":"12","pop_offer_background_color":"#161212","pop_offer_font_color":"#ffffff"}'), u.popular_offer_setting && (F = JSON.parse(u.popular_offer_setting)), T = "<span style='margin-left: 10px; padding: 4px; font-weight: 600; display: " + L + "; font-size: " + F.pop_offer_text_size + "px; color: " + F.pop_offer_font_color + "; background: " + F.pop_offer_background_color + "; '>" + F.pop_offer_text + "</span>"), A = "price_discount" == j ? "<span class=money>" + O + "</span> " + u.off_text : "fix_price" == j ? u.get_at_text + " " + O : S + "% " + u.off_text;
                    let I = "";
                    return !0 == u.is_theme_inherit && t(".button").length > 0 && (I = `border-radius: ${t(".button").css("border-radius")}`), q = "<div class='offer-options-title'>" + v + "</div><div class='offer-options-des'>" + m + "</div><div class='alert hulkapps-banner-msg'>" + i.banner_msg + T + " </div><style>.hulkapps-banner-msg {font-size:" + i.banner_font_size + "px;color: " + i.banner_font_color + "; background-color: " + i.banner_bg_color + ";min-height: 50px;padding: 6px 30px 6px 15px;position: relative;margin-top:15px;" + I + "}.offer-options-title{font-family:inherit;font-size:16px;font-weight:700;line-height:inherit;letter-spacing:inherit;color:inherit;margin-top:30px}.offer-options-des{font-family:inherit;font-size:14px;line-height:inherit;letter-spacing:inherit;color:inherit;margin-top:5px}" + u.custom_css + "</style><script>" + u.custom_js + "</script>", c = c || "", q.replace("{{qty}}", C).replace("{{offer_type}}", c + " " + i.offer_type).replace("{{discount}}", A)
                }
            } else if ("bundle" == a) {
                let P = `<div class='offer-options-title'>${v}</div><div class='offer-options-des'>${m}</div><div class="offer-options-list bundle_offer_layout">`,
                    D = i.bundle_offer_type,
                    B = i.bundle_discount_type,
                    N = i.bundle_discount_val,
                    M = i.bundle_gift_products,
                    U = 0,
                    J = 0,
                    X = [],
                    Y = [];
                if ("variant" == f) return new Promise(function(i, a) {
                    let o = e.offer_data,
                        n = {};
                    t.each(o, function(t, e) {
                        let i = e.bundle_group_id;
                        n[i] || (n[i] = []), n[i].push(e)
                    }), t.each(n, function(e, i) {
                        let a = new Promise(function(e, a) {
                            t.getJSON(i[0].p_handle, function(t) {
                                e(t)
                            }).fail(function(t) {
                                a(t)
                            })
                        }).then(function(a) {
                            let o = "",
                                l = a.product,
                                s = "",
                                p = "",
                                d = [];
                            t.each(i, function(t, e) {
                                let i = e.v_name.split(" / ");
                                d = d.concat(i)
                            }), d = d.filter(function(t, e) {
                                return d.indexOf(t) === e
                            }), t.each(l.variants, function(t, e) {
                                s += "<option value='" + e.id + "' data-variant='" + JSON.stringify(e) + "'>" + e.title + "</option>"
                            }), p = '<select style="display: none;"  class="hulk-variant-selection-dropdown ' + l.id + '_variants">' + s + "</select>";
                            let u = "";
                            "Default Title" != l.variants[0].title && t.each(l.options, function(e, i) {
                                let a = "";
                                u += '<div class="pt-2">';
                                let o = "<label class='preview_lable'>" + i.name + "</label>";
                                t.each(i.values, function(e, i) {
                                    d && -1 != t.inArray(i, d) && (a += '<option value="' + i + '">' + i + "</option>")
                                });
                                u += o + '<select class="grid_name form-control">' + a + "</select>", u += "</div>"
                            });
                            let c = i[0].v_id,
                                f = l.variants.find(t => t.id === c),
                                v = (f = f || l.variants[0]) ? f.price : l.variants[0].price,
                                m = currency_conversion(v),
                                g = f ? f.image_id : l.images[0].id,
                                $ = l.images.find(t => t.id === g),
                                b = $ ? $.src : l.images[0] ? .src;
                            (null == b || void 0 == b) && (b = `${window.hulkapps.vd_url}/images/no_image.jpg`), U += parseFloat(v);
                            let y = "none";
                            "discount" == D ? "% Off" == B ? (y = parseFloat(v) - parseFloat(v) * N / 100, J += y, y = parseFloat(y).toFixed(2), y = currency_conversion(y)) : "price_discount" == B && (y = "none", J += parseFloat(v)) : M.includes(i[0].p_id + "_" + e) ? y = k : J += parseFloat(v), o += `<div class="offer-option-item d-flex offer-option-wrap" id=${i[0].p_id+"_"+e} data-discount_type='${B}' data-discount_val='${N}' data-offer_type='${D}' data-free_products="${M}" data-add='${JSON.stringify({variant_id:f.id,quantity:1})}' data-image='${JSON.stringify(l.images)}'>${p}<div class="offer-option_txt align-center"><img src=${b} width="65" height="65"><div class="offer-option_price"><p class="preview_title"><a class="product_link" href="https://${window.hulkapps.store_id}/products/${l.handle}" target="_blank">${l.title}</a></p><div class="option-item-price"><div class="item-regular_price" style="display: ${"none"==y?"none":"block"}"><span class=money>${y}</span></div><div class="item-compare_price" style="text-decoration: ${"none"==y?"unset":"line-through"}"><span class=money>${m}</span></div></div></div></div><div class="offer-option">${u}</div></div>`, parseInt(e) !== Object.keys(n).length - 1 && (o += '<div class="text-center"><svg viewBox="0 0 20 20" style="width:20px;height:20px"><path d="M10 4a1 1 0 0 0-1 1v4h-4a1 1 0 1 0 0 2h4v4a1 1 0 1 0 2 0v-4h4a1 1 0 1 0 0-2h-4v-4a1 1 0 0 0-1-1Z"></path></svg></div>'), Y[e] = o
                        });
                        X.push(a)
                    }), Promise.all(X).then(() => {
                        P += Y.join(""), "discount" == D && "price_discount" == B && (J = U - N * w), U = parseFloat(U).toFixed(2), J = parseFloat(J).toFixed(2);
                        let e = !0 == u.is_theme_inherit ? u.theme_button_class + " mr-top offer-option-btn" : "offer-option-btn",
                            a = !0 == u.is_theme_inherit ? "" : `button.offer-option-btn{margin:15px 0 0;cursor:pointer;border-radius:${u.list_card_radius}px;font-size:14px;font-weight:700;text-transform:uppercase;text-align:center;display:inline-block;width:100%;background:${u.button_color};border:none;color:${u.button_text_color};padding:12px 18px}`,
                            o = !0 == u.is_theme_inherit ? u.theme_buy_button_class + " mr-top offer-option-btn buynow" : "offer-option-btn buynow",
                            n = !0 == u.is_theme_inherit ? "" : `style="color:${y};background-color:${_};border: 1px  solid ${y}"`;
                        if (!0 == u.is_theme_inherit && t(".product-form__buttons").length > 0) {
                            var l = t(".product-form__buttons").outerWidth();
                            t(".hulkapps-volumes").css("width", l + "px")
                        }
                        let s = b ? `<button class="${o}" ${n}>${x}</button>` : "",
                            p = currency_conversion(U),
                            d = currency_conversion(J);
                        P += `<hr class="hr_line_offer"><div class="bundle_total d-flex offer-option-wrap"><div>${g}</div><div class="offer-option_price"><div class="option-item-price"><div class="item-regular_price"><span class=money>${d}</span></div><div class="item-compare_price"><span class=money>${p}</span></div></div></div></div><button class="${e}">${$}</button>${s}`, i(P += `<style>.offer-option select.grid_name {background-image: url("${window.hulkapps.vd_url}/images/select_arrow1_result.svg") !important;background-repeat: no-repeat !important;background-position: right 10px center !important;background-size: 10px !important;}.offer-options-des,.offer-options-title{font-family:inherit;font-size:16px;margin-bottom:15px;color:inherit}.offer-options-des,.offer-options-list .offer-option p,.offer-options-title,button.offer-option-btn{letter-spacing:inherit;line-height:inherit}.offer-options-title{font-weight:700}.offer-options-list .offer-option_txt{position:relative;z-index:1;display:flex}.offer-options-list .offer-option p{font-size:14px;font-weight:400;color:inherit;margin:0;padding:0}.offer-options-list .offer-option{display:block}.offer-options-list .option-item-price,.offer-options-list .option-total-price{display:flex;align-items:center;font-size:14px;font-weight:500;line-height:inherit;color:inherit;letter-spacing:inherit;justify-content:end}.offer-option_price{padding-left:15px}.total-regular_price{padding-left:5px}.offer-options-list .option-item-price{margin-bottom:8px}.offer-options-list .item-regular_price{font-weight:700}.offer-options-list .item-compare_price,.offer-options-list .total-compare_price{font-weight:400;text-decoration:line-through;margin-left:5px}.offer-options-list div.offer-option-item{margin-bottom:10px}.offer-options-list div.offer-option-item:last-of-type{margin-bottom:0}${a}.offer-option-wrap{display:flex;align-items:center;position:relative;color:inherit;padding:12px 16px;width:100%;justify-content:space-between}.offer-option-wrap:before{content:'';border-radius:${u.list_card_radius}px;border:1px solid #dfe3e8;position:absolute;top:0;right:0;left:0;bottom:0;padding:0 16px;z-index:0}.bundle_offer_type_discount_block .bundle_discount_type,.bxgy_offer_type_discount_block .bxgy_discount_type{width:170px;border-left:0;background:#ebeff4;border-radius:0 4px 4px 0;font-size:13px}.bundle_offer_type_discount_block .input-group-addon,.bxgy_offer_type_discount_block .input-group-addon{padding:0;margin:0;border:0}.bundle_offer_type_discount_block .bundle_discount_val,.bxgy_offer_type_discount_block .bxgy_discount_val{width:100px;appearance:auto!important}.bundle_offer_layout .offer-option{min-width:85%;width:100%!important;z-index:1}.bundle_offer_layout .offer-option-wrap{flex-direction:column;align-items:flex-start}.bundle_offer_layout .pb-7.offer-option_price{padding-bottom:0}.bundle_offer_layout .offer-option-item .option-item-price{display:flex;margin-bottom:0;justify-content:flex-start}.bundle_offer_layout .offer-option .pt-2{display:flex;align-items:center;padding-top: 10px;}.bundle_offer_layout p.preview_title{padding-bottom:10px;display:inline-flex}.bundle_offer_layout .pt-2 label,.bundle_offer_layout .pt-2 select{display:inline-flex}.bundle_offer_layout .pt-2 label{width:22%;word-break: break-all}.bundle_total.d-flex.offer-option-wrap{flex-direction:row}.text-center{text-align:center;text-align-last:center}.align-center{align-items:center}.offer-option .form-control{font-weight:400;text-transform:none;letter-spacing:inherit;flex:1 1;width:100%;min-width:0;min-height:36px;margin:0;padding:5px 12px;font-family:inherit;font-size:inherit;font-weight:inherit;background-color:#fff;border:1px solid #c9cccf;appearance:none;box-shadow:none;height:34px;line-height:1.42857143;color:#555;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075);box-shadow:inset 0 1px 1px rgba(0,0,0,.075);-webkit-transition:border-color .15s ease-in-out,-webkit-box-shadow .15s ease-in-out;-o-transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out}hr.hr_line_offer{border-top:1px solid #eee;margin-top:20px!important;margin-bottom:20px!important;border:0}.offer-options-list.bundle_offer_layout{margin:20px 0;border:1px solid #dfe3e8;padding:10px;border-radius:6px}.preview_title a{color:unset!important;text-decoration:none}.preview_title a:hover{text-decoration:underline}.mr-top{margin-top:10px;}${u.custom_css}</style><script>${u.custom_js}</script>`)
                    }).catch(t => {
                        console.error("Error while fetching data:", t)
                    })
                })
            } else if ("bxgy" == a) {
                let R = i.bxgy_discount_type,
                    Q = i.bxgy_discount_val,
                    K = 0,
                    H = 0,
                    V = 0,
                    W = "";
                if ("variant" == f) return new Promise(function(i, a) {
                    let n = e.offer_data,
                        l = {};
                    t.each(n, function(t, e) {
                        let i = e.bxgy_group;
                        l[i] || (l[i] = {});
                        let a = e.p_handle;
                        l[i][a] || (l[i][a] = []), l[i][a].push(e)
                    });
                    let s = {};

                    function p(t, e) {
                        let i = s[t];
                        return i && i.hasOwnProperty(e) ? i[e] : null
                    }
                    t.each(l, function(e, i) {
                        let a = {},
                            o = 0;
                        t.each(i, function(e, i) {
                            a[e] = o, t.each(i, function(t, e) {
                                o++
                            })
                        }), s[e] = a
                    });
                    let d = '<div class="x_offer_layout">',
                        c = '<div class="y_offer_layout">',
                        f = [],
                        w = [],
                        q = [];
                    t.each(l, function(e, i) {
                        let a = e,
                            l = i,
                            s = 0;
                        t.each(l, function(e, i) {
                            f.push(new Promise(function(l, d) {
                                t.getJSON(e, function(d) {
                                    let u = d.product,
                                        c = "",
                                        f = "",
                                        v = [];
                                    t.each(i, function(t, e) {
                                        let i = e.v_name.split(" / ");
                                        v = v.concat(i)
                                    }), v = v.filter(function(t, e) {
                                        return v.indexOf(t) === e
                                    }), t.each(u.variants, function(t, e) {
                                        c += "<option value='" + e.id + "' data-variant='" + JSON.stringify(e) + "'>" + e.title + "</option>"
                                    }), f = '<select style="display: none;"  class="hulk-variant-selection-dropdown ' + u.id + '_variants">' + c + "</select>";
                                    let m = "";
                                    "Default Title" != u.variants[0].title && t.each(u.options, function(e, i) {
                                        let a = "";
                                        m += '<div class="pt-2">';
                                        let o = "<label class='preview_lable'>" + i.name + "</label>";
                                        t.each(i.values, function(e, i) {
                                            v && -1 != t.inArray(i, v) && (a += '<option value="' + i + '">' + i + "</option>")
                                        });
                                        m += o + '<select class="grid_name form-control">' + a + "</select>", m += "</div>"
                                    });
                                    let g = n[0].v_id,
                                        $ = u.variants.find(t => t.id === g),
                                        b = ($ = $ || u.variants[0]) ? $.price : u.variants[0].price,
                                        y = $ ? $.image_id : u.images[0].id,
                                        x = u.images.find(t => t.id === y),
                                        _ = x ? x.src : u.images[0] ? .src;
                                    (null == _ || void 0 == _) && (_ = `${window.hulkapps.vd_url}/images/no_image.jpg`);
                                    let C = "",
                                        S = p(a, e);
                                    "Y" == a && ("% Off" == R ? H += parseFloat(b) * (Q / 100) * parseInt(i[0].bxgy_qty) : "price_discount" == R ? H = Q : "free_gift" == R && (H += parseFloat(b) * parseInt(i[0].bxgy_qty), V += parseFloat(b)));
                                    let j = parseFloat(b) - (parseFloat(b) * (Q / 100)).toFixed(2);
                                    C = "Y" === a ? "% Off" === R ? o + j.toFixed(2) : "free_gift" === R ? k : "" : "", K += parseFloat(b) * parseInt(i[0].bxgy_qty);
                                    let A = `<div class="d-flex offer-option-item offer-option-wrap" id="${i[0].p_id}_${i[0].bxgy_group}" data-discount_type='${R}' data-discount_val='${Q}' data-add='${JSON.stringify({variant_id:$.id,quantity:i[0].bxgy_qty})}' data-image='${JSON.stringify(u.images)}'>${f}<div class="align-center offer-option_txt"><img src="${_}" width="65" height="65"><div class="offer-option_price pb-7"><p class=preview_title><a class="product_link" href="https://${window.hulkapps.store_id}/products/${e}" target="_blank">${i[0].p_name}</a></p><div class=option-item-price><div class=item-regular_price><span class="money">${C}</span> </div><div class="item-compare_price mr-auto"style=${"Y"==a&&("free_gift"===R||"% Off"===R)?"text-decoration:line-through":"text-decoration:unset"}><span class=money>${o}${b}</span></div><div class=${a}_qty_box_${S} style="display: ${parseInt(i[0].bxgy_qty)>1?"block":"none"}">${i[0].bxgy_qty}X</div></div></div></div><div class=offer-option>${m}</div></div>`;
                                    "X" === a ? w[s] = A : "Y" === a && (q[s] = A), s++, l(A)
                                }).fail(function(t) {
                                    d(t)
                                })
                            }))
                        })
                    }), Promise.all(f).then(() => {
                        d += w.join(""), c += q.join(""), d += "</div>", c += "</div>", W = `<div class='offer-options-title'>${v}</div><div class='offer-options-des'>${m}</div>${d}<div class="text-center"><svg viewBox="0 0 20 20" class="" style="width: 20px; height: 20px;"><path d="M10 4a1 1 0 0 0-1 1v4h-4a1 1 0 1 0 0 2h4v4a1 1 0 1 0 2 0v-4h4a1 1 0 1 0 0-2h-4v-4a1 1 0 0 0-1-1Z"></path></svg></div>${c}`;
                        let e = !0 == u.is_theme_inherit ? u.theme_button_class + " mr-top offer-option-btn" : "offer-option-btn",
                            a = !0 == u.is_theme_inherit ? "" : `button.offer-option-btn{margin:15px 0 0;cursor:pointer;border-radius:${u.list_card_radius}px;font-size:14px;font-weight:700;text-transform:uppercase;text-align:center;display:inline-block;width:100%;background:${u.button_color};border:none;color:${u.button_text_color};padding:12px 18px}`,
                            n = !0 == u.is_theme_inherit ? u.theme_buy_button_class + " mr-top offer-option-btn buynow" : "offer-option-btn buynow",
                            l = !0 == u.is_theme_inherit ? "" : `style="color:${y};background-color:${_};border: 1px  solid ${y}"`;
                        if (!0 == u.is_theme_inherit && t(".product-form__buttons").length > 0) {
                            var s = t(".product-form__buttons").outerWidth();
                            t(".hulkapps-volumes").css("width", s + "px")
                        }
                        let p = b ? `<button class="${n}" ${l}>${x}</button>` : "";
                        W += '<hr class="hr_line_offer">';
                        let f = o + K.toFixed(2);
                        parseFloat(K);
                        W += `<div class="bxgy_total d-flex offer-option-wrap"><div>${g}</div><div class="offer-option_price"><div class="option-item-price"><div class="item-regular_price"><span class="money">${o+(K.toFixed(2)-H).toFixed(2)}</span></div><div class="item-compare_price" style="text-decoration:line-through"><span class="money">${f}</span></div></div></div></div><button class="${e}">${$}</button>${p}`, W = '<div class="offer-options-list bxgy_offer_layout">' + W + "</div>", i(W += `<style>.offer-option select.grid_name {background-image: url("${window.hulkapps.vd_url}/images/select_arrow1_result.svg") !important;background-repeat: no-repeat !important;background-position: right 10px center !important;background-size: 10px !important;}.offer-options-des,.offer-options-title{font-family:inherit;font-size:16px;margin-bottom:15px;color:inherit}.offer-options-des,.offer-options-list .offer-option p,.offer-options-title,button.offer-option-btn{letter-spacing:inherit;line-height:inherit}.offer-options-title{font-weight:700}.offer-options-list .offer-option_txt{position:relative;z-index:1;display:flex}.offer-options-list .offer-option p{font-size:14px;font-weight:400;color:inherit;margin:0;padding:0}.offer-options-list .offer-option{display:block}.offer-options-list .option-item-price,.offer-options-list .option-total-price{display:flex;align-items:center;font-size:14px;font-weight:500;line-height:inherit;color:inherit;letter-spacing:inherit;justify-content:end}.offer-option_price{padding-left:15px}.total-regular_price{padding-left:5px}.offer-options-list .option-item-price{margin-bottom:8px}.offer-options-list .item-regular_price{font-weight:700}.offer-options-list .item-compare_price,.offer-options-list .total-compare_price{font-weight:400;text-decoration:line-through;margin-left:5px}.offer-options-list div.offer-option-item{margin-bottom:10px}.offer-options-list div.offer-option-item:last-of-type{margin-bottom:0}${a}.offer-option-wrap{display:flex;align-items:center;position:relative;color:inherit;padding:12px 16px;width:100%;justify-content:space-between}.offer-option-wrap:before{content:'';border-radius:${u.list_card_radius}px;border:1px solid #dfe3e8;position:absolute;top:0;right:0;left:0;bottom:0;padding:0 16px;z-index:0}.bundle_offer_type_discount_block .bundle_discount_type,.bxgy_offer_type_discount_block .bxgy_discount_type{width:170px;border-left:0;background:#ebeff4;border-radius:0 4px 4px 0;font-size:13px}.bundle_offer_type_discount_block .input-group-addon,.bxgy_offer_type_discount_block .input-group-addon{padding:0;margin:0;border:0}.bundle_offer_type_discount_block .bundle_discount_val,.bxgy_offer_type_discount_block .bxgy_discount_val{width:100px;appearance:auto!important}.bundle_offer_layout .offer-option{min-width:85%;width:100%!important;z-index:1}.bundle_offer_layout .offer-option-wrap{flex-direction:column;align-items:flex-start}.bundle_offer_layout .pb-7.offer-option_price{padding-bottom:0}.bundle_offer_layout .offer-option-item .option-item-price{display:flex;margin-bottom:0;justify-content:flex-start}.bundle_offer_layout .offer-option .pt-2{display:flex;align-items:center}.bxgy_offer_layout p.preview_title{padding:0 0 10px;display:inline-flex;margin:0}.bundle_offer_layout .pt-2 label,.bundle_offer_layout .pt-2 select{display:inline-flex}.bundle_offer_layout .pt-2 label{width:25%}.bundle_total.d-flex.offer-option-wrap{flex-direction:row}.text-center{text-align:center;text-align-last:center}.align-center{align-items:center}.bxgy_offer_layout .offer-option{width:100%!important;z-index:1}.bxgy_offer_layout .offer-option-wrap,.bxgy_offer_layout .offer-option-wrap{flex-direction:column;align-items:flex-start}.bxgy_offer_layout .pb-7.offer-option_price{padding-bottom:0}.bxgy_offer_layout p.preview_title{padding:0 0 10px;display:inline-flex;margin:0}.bxgy_offer_layout .offer-option-item .option-item-price{display:flex;margin-bottom:0;justify-content:flex-start}[class^=X_qty_box],[class^=Y_qty_box]{width:30px;height:30px;border:1px solid ${u.button_color};border-radius:50%;display:none;line-height:30px;text-align:center;background:${u.button_color};color:#fff;float:right;position:absolute;right:0}.bxgy_offer_layout .offer-option{width:100%!important;z-index:1}.bxgy_offer_layout .offer-option .pt-2{display:flex;align-items:center;padding-top: 10px;}.bxgy_offer_layout .pt-2 label{width:22%;word-break: break-all}.bxgy_offer_layout .pt-2 label,.bxgy_offer_layout .pt-2 select{display:inline-flex}.bxgy_total.d-flex.offer-option-wrap{flex-direction:row}.offer-option .form-control{font-weight:400;text-transform:none;letter-spacing:inherit;flex:1 1;width:100%;min-width:0;min-height:36px;margin:0;padding:5px 12px;font-family:inherit;font-size:inherit;font-weight:inherit;background-color:#fff;border:1px solid #c9cccf;appearance:none;box-shadow:none;height:34px;line-height:1.42857143;color:#555;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075);box-shadow:inset 0 1px 1px rgba(0,0,0,.075);-webkit-transition:border-color .15s ease-in-out,-webkit-box-shadow .15s ease-in-out;-o-transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out}hr.hr_line_offer{border-top:1px solid #eee;margin-top:20px!important;margin-bottom:20px!important;border:0}.offer-options-list.bxgy_offer_layout{margin:20px 0;border:1px solid #dfe3e8;padding:10px;border-radius:6px}.text-center{text-align:center;text-align-last:center;position:relative;height:32px}.text-center svg{width:20px;height:20px;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%)}.preview_title a{color:unset!important;text-decoration:none}.preview_title a:hover{text-decoration:underline}.mr-top{margin-top:10px;}.offer-options-list .offer-option_txt{justify-content: flex-start;align-items: flex-start;width: -webkit-fill-available;}${u.custom_css}</style><script>${u.custom_js}</script>`)
                    }).catch(t => {
                        console.error("Error while fetching data:", t)
                    })
                });
                if ("collection" == f) {
                    let Z = e.eligible_offer.bxgy_col_banner_msg,
                        G = e.eligible_offer.bxgy_col_banner_settings,
                        tt = e.offer_data,
                        te = {};
                    t.each(tt, function(t, e) {
                        let i = e.bxgy_group;
                        te[i] || (te[i] = []), te[i].push(e)
                    });
                    let ti = te.X.map(t => t.c_name).join("/ "),
                        ta = te.Y.map(t => t.c_name).join("/ "),
                        to = te.X[0].bxgy_qty,
                        tn = te.Y[0].bxgy_qty,
                        tl = "";
                    if ("% Off" == R) tl = `${Q}% Off`;
                    else if ("price_discount" == R) {
                        let tr = Q * w;
                        tl = `${tr=currency_conversion(tr)} Off`
                    } else tl = "free";
                    return W += `<div class="bxgy_banner">${Z=Z.replace("{{x_collections}}",ti).replace("{{y_collections}}",ta).replace("{{x_qty}}",to).replace("{{y_qty}}",tn).replace("{{discount}}",tl)}</div></div>`, W += `<style>.bxgy_banner{background: ${G.background_color};color: ${G.font_color};border: 1px solid ${G.border_color};border-radius: ${G.border_radius}px;padding: 10px;margin-top: 10px;}${u.custom_css}</style><script>${u.custom_js}</script>`
                }
                if ("collection_variant" == f) return new Promise(function(a, n) {
                    let l = '<div class="x_offer_layout">',
                        s = '<div class="y_offer_layout">',
                        p = e.offer_data,
                        d = {};
                    t.each(p, function(t, e) {
                        let i = e.bxgy_group;
                        d[i] || (d[i] = []), d[i].push(e)
                    });
                    let c = d.X.map(t => t.c_name).join("/ "),
                        f = d.X[0].bxgy_qty,
                        g = i.col_var_x_msg;
                    l += `<div class="x_col_preview">${g=g.replace("{{x_qty}}",f).replace("{{x_collections}}",c)}</div></div>`;
                    let $ = "",
                        b = i.col_var_y_msg;
                    if ("% Off" === R) $ = `${Q}% Off`;
                    else if ("price_discount" === R) {
                        let y = Q * w;
                        $ = `${y=currency_conversion(y)} Off`
                    } else $ = "free";
                    s += `<div class="mb-2">${b=b.replace("{{discount}}",$)}</div>`, d = {}, t.each(p, function(t, e) {
                        let i = e.bxgy_group;
                        if ("Y" == i) {
                            d[i] || (d[i] = {});
                            let a = e.p_handle;
                            d[i][a] || (d[i][a] = []), d[i][a].push(e)
                        }
                    });
                    let x = {};

                    function _(t, e) {
                        let i = x[t];
                        return i && i.hasOwnProperty(e) ? i[e] : null
                    }
                    t.each(d, function(e, i) {
                        let a = {},
                            o = 0;
                        t.each(i, function(e, i) {
                            a[e] = o, t.each(i, function(t, e) {
                                o++
                            })
                        }), x[e] = a
                    });
                    let q = [],
                        C = [];
                    t.each(d, function(e, i) {
                        let a = e,
                            n = i,
                            l = 0;
                        t.each(n, function(e, i) {
                            q.push(new Promise(function(n, s) {
                                t.getJSON(e, function(s) {
                                    let d = s.product,
                                        u = "",
                                        c = "",
                                        f = [];
                                    t.each(i, function(t, e) {
                                        let i = e.v_name.split(" / ");
                                        f = f.concat(i)
                                    }), f = f.filter(function(t, e) {
                                        return f.indexOf(t) === e
                                    }), t.each(d.variants, function(t, e) {
                                        u += "<option value='" + e.id + "' data-variant='" + JSON.stringify(e) + "'>" + e.title + "</option>"
                                    }), c = '<select style="display: none;"  class="hulk-variant-selection-dropdown ' + d.id + '_variants">' + u + "</select>";
                                    let v = "";
                                    "Default Title" != d.variants[0].title && t.each(d.options, function(e, i) {
                                        let a = "";
                                        v += '<div class="pt-2">';
                                        let o = "<label class='preview_lable'>" + i.name + "</label>";
                                        t.each(i.values, function(e, i) {
                                            f && -1 != t.inArray(i, f) && (a += '<option value="' + i + '">' + i + "</option>")
                                        });
                                        v += o + '<select class="grid_name form-control">' + a + "</select>", v += "</div>"
                                    });
                                    let m = p[0].v_id,
                                        g = d.variants.find(t => t.id === m),
                                        $ = (g = g || d.variants[0]) ? g.price : d.variants[0].price,
                                        b = g ? g.image_id : d.images[0].id,
                                        y = d.images.find(t => t.id === b),
                                        x = y ? y.src : d.images[0] ? .src;
                                    (null == x || void 0 == x) && (x = `${window.hulkapps.vd_url}/images/no_image.jpg`);
                                    let w = "",
                                        q = _(a, e),
                                        S = parseFloat($) - (parseFloat($) * (Q / 100)).toFixed(2);
                                    w = "Y" === a ? "% Off" === R ? o + S.toFixed(2) : "free_gift" === R ? k : "" : "", K += parseFloat($) * parseInt(i[0].bxgy_qty);
                                    let j = `<div class="d-flex offer-option-item offer-option-wrap" id="${i[0].p_id}_${i[0].bxgy_group}" data-discount_type='${R}' data-discount_val='${Q}' data-add='${JSON.stringify({variant_id:g.id,quantity:i[0].bxgy_qty})}' data-image='${JSON.stringify(d.images)}'>${c}<div class="align-center offer-option_txt"><img src="${x}" width="65" height="65"><div class="offer-option_price pb-7"><p class=preview_title><a class="product_link" href="https://${window.hulkapps.store_id}/products/${e}" target="_blank">${i[0].p_name}</a></p><div class=option-item-price><div class=item-regular_price><span class="money">${w}</span> </div><div class="item-compare_price mr-auto"style=${"Y"==a&&("free_gift"===R||"% Off"===R)?"text-decoration:line-through":"text-decoration:unset"}><span class=money>${o}${$}</span></div><div class=${a}_qty_box_${q} style="display: ${parseInt(i[0].bxgy_qty)>1?"block":"none"}">${i[0].bxgy_qty}X</div></div></div></div><div class=offer-option>${v}</div></div>`;
                                    "Y" === a && (C[l] = j), l++, n(j)
                                }).fail(function(t) {
                                    s(t)
                                })
                            }))
                        })
                    }), Promise.all(q).then(() => {
                        if (s += C.join(""), s += "", W = `<div class="bxgy_col_variant_layout offer-options-list outer-border"><div class='offer-options-title'>${v}</div><div class='offer-options-des'>${m}</div>${l}<div class="text-center"><svg viewBox="0 0 20 20" class="" style="width: 20px; height: 20px;"><path d="M10 4a1 1 0 0 0-1 1v4h-4a1 1 0 1 0 0 2h4v4a1 1 0 1 0 2 0v-4h4a1 1 0 1 0 0-2h-4v-4a1 1 0 0 0-1-1Z"></path></svg></div>${s}</div>`, !0 == u.is_theme_inherit && t(".product-form__buttons").length > 0) {
                            var e = t(".product-form__buttons").outerWidth();
                            t(".hulkapps-volumes").css("width", e + "px")
                        }
                        a(W += `<style>.offer-option select.grid_name {background-image: url("${window.hulkapps.vd_url}/images/select_arrow1_result.svg") !important;background-repeat: no-repeat !important;background-position: right 10px center !important;background-size: 10px !important;}.offer-options-des,.offer-options-title{font-family:inherit;font-size:16px;margin-bottom:15px;color:inherit}.offer-options-des,.offer-options-list .offer-option p,.offer-options-title,button.offer-option-btn{letter-spacing:inherit;line-height:inherit}.offer-options-title{font-weight:700}.offer-options-list .offer-option_txt{position:relative;z-index:1;display:flex}.offer-options-list .offer-option p{font-size:14px;font-weight:400;color:inherit;margin:0;padding:0}.offer-options-list .offer-option{display:block}.offer-options-list .option-item-price,.offer-options-list .option-total-price{display:flex;align-items:center;font-size:14px;font-weight:500;line-height:inherit;color:inherit;letter-spacing:inherit;justify-content:end}.offer-option_price{padding-left:15px}.total-regular_price{padding-left:5px}.offer-options-list .option-item-price{margin-bottom:8px}.offer-options-list .item-regular_price{font-weight:700}.offer-options-list .item-compare_price,.offer-options-list .total-compare_price{font-weight:400;text-decoration:line-through;margin-left:5px}.offer-options-list div.offer-option-item{margin-bottom:10px}.offer-options-list div.offer-option-item:last-of-type{margin-bottom:0}.offer-option-wrap{display:flex;align-items:center;position:relative;color:inherit;padding:12px 16px;width:100%;justify-content:space-between}.offer-option-wrap:before{content:'';border-radius:${u.list_card_radius}px;border:1px solid #dfe3e8;position:absolute;top:0;right:0;left:0;bottom:0;padding:0 16px;z-index:0}.bxgy_col_variant_layout p.preview_title{padding:0 0 10px;display:inline-flex;margin:0}.text-center{text-align:center;text-align-last:center}.align-center{align-items:center}.bxgy_col_variant_layout .offer-option{width:100%!important;z-index:1}.bxgy_col_variant_layout .offer-option-wrap{flex-direction:column;align-items:flex-start}.bxgy_col_variant_layout .pb-7.offer-option_{padding-bottom:0}.bxgy_col_variant_layout p.preview_title{padding:0 0 10px;display:inline-flex;margin:0}.bxgy_col_variant_layout .offer-option-item .option-item-price{display:flex;margin-bottom:0;justify-content:flex-start}[class^=X_qty_box],[class^=Y_qty_box]{width:30px;height:30px;border:1px solid ${u.button_color};border-radius:50%;display:none;line-height:30px;text-align:center;background:${u.button_color};color:#fff;float:right;position:absolute;right:0}.bxgy_col_variant_layout .offer-option{width:100%!important;z-index:1}.bxgy_col_variant_layout .offer-option .pt-2{display:flex;align-items:center;padding-top: 10px;}.bxgy_col_variant_layout .pt-2 label{width:22%;word-break: break-all}.bxgy_col_variant_layout .pt-2 label,.bxgy_col_variant_layout .pt-2 select{display:inline-flex}.offer-option .form-control{font-weight:400;text-transform:none;letter-spacing:inherit;flex:1 1;width:100%;min-width:0;min-height:36px;margin:0;padding:5px 12px;font-family:inherit;font-size:inherit;font-weight:inherit;background-color:#fff;border:1px solid #c9cccf;appearance:none;box-shadow:none;height:34px;line-height:1.42857143;color:#555;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075);box-shadow:inset 0 1px 1px rgba(0,0,0,.075);-webkit-transition:border-color .15s ease-in-out,-webkit-box-shadow .15s ease-in-out;-o-transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out}hr.hr_line_offer{border-top:1px solid #eee;margin-top:20px!important;margin-bottom:20px!important;border:0}.offer-options-list.bxgy_col_variant_layout{margin:20px 0;border:1px solid #dfe3e8;padding:10px;border-radius:6px}.text-center{text-align:center;text-align-last:center;position:relative;height:32px}.text-center svg{width:20px;height:20px;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%)}.preview_title a{color:unset!important;text-decoration:none}.preview_title a:hover{text-decoration:underline}.mr-top{margin-top:10px;}.offer-options-list .offer-option_txt{justify-content: flex-start;align-items: flex-start;width: -webkit-fill-available;}${u.custom_css}</style><script>${u.custom_js}</script>`)
                    }).catch(t => {
                        console.error("Error while fetching data:", t)
                    })
                });
                else if ("variant_collection" == f) return new Promise(function(a, n) {
                    let l = '<div class="x_offer_layout">',
                        s = '<div class="y_offer_layout">',
                        p = e.offer_data,
                        d = {};
                    t.each(p, function(t, e) {
                        let i = e.bxgy_group;
                        d[i] || (d[i] = []), d[i].push(e)
                    });
                    let c = d.Y.map(t => t.c_name).join("/ "),
                        f = d.Y[0].bxgy_qty,
                        k = "";
                    if ("% Off" === R) k = `${Q}% Off`;
                    else if ("price_discount" === R) {
                        let g = Q * w;
                        k = `${g=currency_conversion(g)} Off`
                    } else "free_gift" === R && (k = "free");
                    let $ = i.var_col_y_msg;
                    s += `<div class="y_col_preview">${$=$.replace("{{y_qty}}",f).replace("{{y_collections}}",c).replace("{{discount}}",k)}</div></div>`;
                    l += `<div class="mb-1">${i.var_col_x_msg}</div>`, d = {}, t.each(p, function(t, e) {
                        let i = e.bxgy_group;
                        if ("X" == i) {
                            d[i] || (d[i] = {});
                            let a = e.p_handle;
                            d[i][a] || (d[i][a] = []), d[i][a].push(e)
                        }
                    });
                    let b = {};

                    function y(t, e) {
                        let i = b[t];
                        return i && i.hasOwnProperty(e) ? i[e] : null
                    }
                    t.each(d, function(e, i) {
                        let a = {},
                            o = 0;
                        t.each(i, function(e, i) {
                            a[e] = o, t.each(i, function(t, e) {
                                o++
                            })
                        }), b[e] = a
                    });
                    let x = [],
                        _ = [];
                    t.each(d, function(e, i) {
                        let a = e,
                            n = i,
                            l = 0;
                        t.each(n, function(e, i) {
                            x.push(new Promise(function(n, s) {
                                t.getJSON(e, function(s) {
                                    let d = s.product,
                                        u = "",
                                        c = "",
                                        f = [];
                                    t.each(i, function(t, e) {
                                        let i = e.v_name.split(" / ");
                                        f = f.concat(i)
                                    }), f = f.filter(function(t, e) {
                                        return f.indexOf(t) === e
                                    }), t.each(d.variants, function(t, e) {
                                        u += "<option value='" + e.id + "' data-variant='" + JSON.stringify(e) + "'>" + e.title + "</option>"
                                    }), c = '<select style="display: none;"  class="hulk-variant-selection-dropdown ' + d.id + '_variants">' + u + "</select>";
                                    let v = "";
                                    "Default Title" != d.variants[0].title && t.each(d.options, function(e, i) {
                                        let a = "";
                                        v += '<div class="pt-2">';
                                        let o = "<label class='preview_lable'>" + i.name + "</label>";
                                        t.each(i.values, function(e, i) {
                                            f && -1 != t.inArray(i, f) && (a += '<option value="' + i + '">' + i + "</option>")
                                        });
                                        v += o + '<select class="grid_name form-control">' + a + "</select>", v += "</div>"
                                    });
                                    let m = p[0].v_id,
                                        k = d.variants.find(t => t.id === m),
                                        g = (k = k || d.variants[0]) ? k.price : d.variants[0].price,
                                        $ = k ? k.image_id : d.images[0].id,
                                        b = d.images.find(t => t.id === $),
                                        x = b ? b.src : d.images[0] ? .src;
                                    (null == x || void 0 == x) && (x = `${window.hulkapps.vd_url}/images/no_image.jpg`);
                                    let w = `<div class="d-flex offer-option-item offer-option-wrap" id="${i[0].p_id}_${i[0].bxgy_group}" data-discount_type='${R}' data-discount_val='${Q}' data-add='${JSON.stringify({variant_id:k.id,quantity:i[0].bxgy_qty})}' data-image='${JSON.stringify(d.images)}'>${c}<div class="align-center offer-option_txt"><img src="${x}" width="65" height="65"><div class="offer-option_price pb-7"><p class=preview_title><a class="product_link" href="https://${window.hulkapps.store_id}/products/${e}" target="_blank">${i[0].p_name}</a></p><div class=option-item-price><div class=item-regular_price><span class="money"></span> </div><div class="item-compare_price mr-auto" style="text-decoration:unset"><span class=money>${o}${g}</span></div><div class=${a}_qty_box_${y(a,e)} style="display: ${parseInt(i[0].bxgy_qty)>1?"block":"none"}">${i[0].bxgy_qty}X</div></div></div></div><div class=offer-option>${v}</div></div>`;
                                    "X" === a && (_[l] = w), l++, n(w)
                                }).fail(function(t) {
                                    s(t)
                                })
                            }))
                        })
                    }), Promise.all(x).then(() => {
                        if (l += _.join(""), W = `<div class="bxgy_variant_col_layout offer-options-list outer-border"><div class='offer-options-title'>${v}</div><div class='offer-options-des'>${m}</div>${l}<div class="text-center"><svg viewBox="0 0 20 20" class="" style="width: 20px; height: 20px;"><path d="M10 4a1 1 0 0 0-1 1v4h-4a1 1 0 1 0 0 2h4v4a1 1 0 1 0 2 0v-4h4a1 1 0 1 0 0-2h-4v-4a1 1 0 0 0-1-1Z"></path></svg></div>${s}</div>`, !0 == u.is_theme_inherit && t(".product-form__buttons").length > 0) {
                            var e = t(".product-form__buttons").outerWidth();
                            t(".hulkapps-volumes").css("width", e + "px")
                        }
                        a(W += `<style>.offer-option select.grid_name {background-image: url("${window.hulkapps.vd_url}/images/select_arrow1_result.svg") !important;background-repeat: no-repeat !important;background-position: right 10px center !important;background-size: 10px !important;}.offer-options-des,.offer-options-title{font-family:inherit;font-size:16px;margin-bottom:15px;color:inherit}.offer-options-des,.offer-options-list .offer-option p,.offer-options-title,button.offer-option-btn{letter-spacing:inherit;line-height:inherit}.offer-options-title{font-weight:700}.offer-options-list .offer-option_txt{position:relative;z-index:1;display:flex}.offer-options-list .offer-option p{font-size:14px;font-weight:400;color:inherit;margin:0;padding:0}.offer-options-list .offer-option{display:block}.offer-options-list .option-item-price,.offer-options-list .option-total-price{display:flex;align-items:center;font-size:14px;font-weight:500;line-height:inherit;color:inherit;letter-spacing:inherit;justify-content:end}.offer-option_price{padding-left:15px}.total-regular_price{padding-left:5px}.offer-options-list .option-item-price{margin-bottom:8px}.offer-options-list .item-regular_price{font-weight:700}.offer-options-list .item-compare_price,.offer-options-list .total-compare_price{font-weight:400;text-decoration:line-through;margin-left:5px}.offer-options-list div.offer-option-item{margin-bottom:10px}.offer-options-list div.offer-option-item:last-of-type{margin-bottom:0}.offer-option-wrap{display:flex;align-items:center;position:relative;color:inherit;padding:12px 16px;width:100%;justify-content:space-between}.offer-option-wrap:before{content:'';border-radius:${u.list_card_radius}px;border:1px solid #dfe3e8;position:absolute;top:0;right:0;left:0;bottom:0;padding:0 16px;z-index:0}.bxgy_variant_col_layout p.preview_title{padding:0 0 10px;display:inline-flex;margin:0}.text-center{text-align:center;text-align-last:center}.align-center{align-items:center}.bxgy_variant_col_layout .offer-option{width:100%!important;z-index:1}.bxgy_variant_col_layout .offer-option-wrap{flex-direction:column;align-items:flex-start}.bxgy_variant_col_layout .pb-7.offer-option_{padding-bottom:0}.bxgy_variant_col_layout p.preview_title{padding:0 0 10px;display:inline-flex;margin:0}.bxgy_variant_col_layout .offer-option-item .option-item-price{display:flex;margin-bottom:0;justify-content:flex-start}[class^=X_qty_box],[class^=Y_qty_box]{width:30px;height:30px;border:1px solid ${u.button_color};border-radius:50%;display:none;line-height:30px;text-align:center;background:${u.button_color};color:#fff;float:right;position:absolute;right:0}.bxgy_variant_col_layout .offer-option{width:100%!important;z-index:1}.bxgy_variant_col_layout .offer-option .pt-2{display:flex;align-items:center;padding-top: 10px;}.bxgy_variant_col_layout .pt-2 label{width:22%;word-break: break-all}.bxgy_variant_col_layout .pt-2 label,.bxgy_variant_col_layout .pt-2 select{display:inline-flex}.offer-option .form-control{font-weight:400;text-transform:none;letter-spacing:inherit;flex:1 1;width:100%;min-width:0;min-height:36px;margin:0;padding:5px 12px;font-family:inherit;font-size:inherit;font-weight:inherit;background-color:#fff;border:1px solid #c9cccf;appearance:none;box-shadow:none;height:34px;line-height:1.42857143;color:#555;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075);box-shadow:inset 0 1px 1px rgba(0,0,0,.075);-webkit-transition:border-color .15s ease-in-out,-webkit-box-shadow .15s ease-in-out;-o-transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out}hr.hr_line_offer{border-top:1px solid #eee;margin-top:20px!important;margin-bottom:20px!important;border:0}.offer-options-list.bxgy_variant_col_layout{margin:20px 0;border:1px solid #dfe3e8;padding:10px;border-radius:6px}.text-center{text-align:center;text-align-last:center;position:relative;height:32px}.text-center svg{width:20px;height:20px;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%)}.preview_title a{color:unset!important;text-decoration:none}.preview_title a:hover{text-decoration:underline}.mr-top{margin-top:10px;}.offer-options-list .offer-option_txt{justify-content: flex-start;align-items: flex-start;width: -webkit-fill-available;}${u.custom_css}</style><script>${u.custom_js}</script>`)
                    }).catch(t => {
                        console.error("Error while fetching data:", t)
                    })
                })
            }
        }, window.get_set_country_local_storage = function(e) {
            var i = localStorage.getItem("country");
            if (null !== e && null !== e.country && "undefined" !== e.country) "" != i && i != e.country && (t.ajax({
                type: "POST",
                url: "/cart/update.js",
                data: "attributes[country]=" + e.country,
                dataType: "json"
            }), localStorage.setItem("country", e.country));
            else {
                var i = localStorage.getItem("country");
                "nil" != e.country && i != e.country && (t.ajax({
                    type: "POST",
                    url: "/cart/update.js",
                    data: "attributes[country]=",
                    dataType: "json"
                }), localStorage.setItem("country", "nil"))
            }
        }, window.get_offer_table_layout = function(e, i, a, o, n, l, s, p, d, u) {
            let c = Shopify.currency.rate || 1,
                f = JSON.parse('{"button_text":"Add to Cart","button_text_size":"11","button_background_color":"#161212","button_font_color":"#ffffff","button_border_color":"#171515","button_border_width":"2"}');
            i.atc_button_setting && (f = JSON.parse(i.atc_button_setting));
            let v = window.hulkapps.product.variants,
                m = window.hulkapps.product.selected_variant,
                k = v.map(t => t.id).indexOf(m),
                g = i.enable_atc_setting && "cart" !== s && !0 === window.hulkapps.product.variants[k].available ? "" : "none",
                $ = i.list_button_text ? i.list_button_text : "GRAB THIS DEAL",
                b = "<div class='offer-options-title'>" + p + "</div><div class='offer-options-des'>" + d + "</div>",
                y = "cart" !== s ? `${i.min_qty_before_text} ` : `${i.list_before_quantity_cart} ${o}`;
            if (1 == e || 2 == e || 4 == e || 5 == e || 6 == e ? "cart" !== s ? b += "<div class='hulkapps-volume-discount-tiers'><table class='hulkapps-table table'><thead><tr><th>" + i.min_qty_text + "</th><th>" + i.discount_text + "</th><th style='display: " + g + "'>Add to Cart</th></tr></thead><tbody>" : b += "<div class='hulkapps-volume-discount-tiers'><table class='hulkapps-table table'><thead><tr><th>" + i.cart_min_price + "</th><th>" + i.discount_text + "</th><th style='display: " + g + "'>Add to Cart</th></tr></thead><tbody>" : 7 == e ? b += '<div class="hulkapps-volume-discount-tiers offer-options-list offer_layout_7" style="margin-top: 15px;">' : 8 == e ? b += '<div class="hulkapps-volume-discount-tiers offer-table-list offer_layout_8"><ul class="table-list">' : b += "<div class='hulkapps-volume-discount-tiers'><table class='hulkapps-table table'><thead><tr><th>" + i.min_qty_text + "</th><th>" + i.max_qty_text + "</th><th>" + i.discount_text + "</th><th style='display: " + g + "'>Add to Cart</th></tr></thead><tbody>", a.length > 0) {
                "" != product_price && void 0 != product_price || (product_price = window.hulkapps.product.price);
                var x, _, w, q, C, S, j = [];
                t.each(a, function(t, o) {
                    x = o[0];
                    var n = "<td style='display: " + g + ";' ><button type='button' " + (!0 == i.is_theme_inherit ? `class='AddToCart_${t} ${i.theme_button_class}'` : "class='AddToCart_" + t + "' style='cursor: pointer; font-weight: 600; letter-spacing: .08em; font-size: " + f.button_text_size + "px; padding: 5px 15px; border-color: " + f.button_border_color + "; border-width: " + f.button_border_width + "px; color: " + f.button_font_color + "; background: " + f.button_background_color + ";'") + " onclick='add_to_cart(" + x + ")'>" + f.button_text + "</button></td>";
                    _ = i.include_decimal_in_offer_table ? o[1] : parseInt(o[1]), w = o[2], C = o[3] ? o[3] : "";
                    let l = o[4] ? o[4] : "";
                    j.push(l);
                    let s = "none",
                        p = "",
                        d = "",
                        v = "",
                        m = "";
                    if ("1" == l && (s = "inline-block", p = JSON.parse('{"pop_offer_text":"Most Popular","pop_offer_text_size":"12","pop_offer_background_color":"#161212","pop_offer_font_color":"#ffffff"}'), i.popular_offer_setting && (p = JSON.parse(i.popular_offer_setting)), d = "<span style='margin-left: 10px; padding: 4px; font-weight: 600; display: " + s + "; font-size: " + p.pop_offer_text_size + "px; color: " + p.pop_offer_font_color + "; background: " + p.pop_offer_background_color + "; '>" + p.pop_offer_text + "</span>"), "% Off" == w && (S = product_price * _ / 100, S = ((product_price - S) / 100).toFixed(2)), each_val = (product_price / 100 - _).toFixed(2), (5 == e || 6 == e || e < 5 && "fix_price" == w || 8 == e && "fix_price" == w) && (v = "price_discount" == w ? each_val : "fix_price" == w ? _ : S, i.include_decimal_in_offer_table && u.is_round_off_prices && null !== u.round_off_price)) {
                        var k = u.round_off_price;
                        switch (k) {
                            case 0:
                                v = Math.round(parseFloat(v)) + parseFloat(u.round_off_price);
                                break;
                            case .49:
                            case .5:
                                v = parseInt(v) + parseFloat(u.round_off_price);
                                break;
                            case .95:
                            case .99:
                                v = Math.round(parseFloat(v)) - 1 + parseFloat(u.round_off_price)
                        }
                        v = v.toFixed(2), "price_discount" == w ? each_val = v : "fix_price" == w ? _ = v : S = v
                    }
                    let $ = currency_conversion(each_val),
                        A = currency_conversion(S),
                        z = _ * c,
                        O = currency_conversion(z);
                    if (1 == e) q = "price_discount" == w ? "<span class=money>" + O + "</span> " + i.off_text : "fix_price" == w ? i.get_at_text + " <span class=money>" + O + "</span>" : _ + "% " + i.off_text, b += "<tr><td>" + y + x + " " + i.min_qty_after_text + "   <span class='hulk-offer-text'>" + C + "</span></td><td><span class='hulkapps-price'>" + q + "</span>" + d + "</td>" + n + "</tr>";
                    else if (2 == e) q = "price_discount" == w ? "<span class=money>" + O + "</span>" : "fix_price" == w ? i.get_at_text + " <span class=money>" + O + "</span>" : _ + "%", b += "<tr><td>" + x + " " + i.min_qty_after_text + "   <span class='hulk-offer-text'>" + C + "</span></td><td><span class='hulkapps-price'>" + q + "</span>" + d + "</td>" + n + "</tr>";
                    else if (3 == e) {
                        q = "price_discount" == w ? "<span class=money>" + O + "</span>" : "fix_price" == w ? i.get_at_text + " <span class=money>" + O + "</span>" : _ + "%";
                        var E = x ? a[t + 1] ? a[t + 1][0] - 1 : "+" : "";
                        b += "<tr><td>" + x + "</td><td>" + E + "   <span class='hulk-offer-text'>" + C + "</span></td><td><span class='hulkapps-price'>" + q + "</span>" + d + "</td>" + n + "</tr>"
                    } else if (4 == e) {
                        if (q = "price_discount" == w ? "<span class=money>" + O + "</span>" : "fix_price" == w ? i.get_at_text + "  <span class=money>" + O + "</span>" : _ + "% " + i.off_text, o == a[t - 1]) b += "<tr><td>" + x + " + </td><td><span class='hulkapps-price'>" + q + "</span>" + d + "</td>" + n + "</tr>";
                        else {
                            var E = x ? a[t + 1] ? a[t + 1][0] - 1 : "+" : "";
                            b += "<tr><td>" + x + ("+" === E ? "" : "-") + E + "   <span class='hulk-offer-text'>" + C + "</span></td><td><span class='hulkapps-price'>" + q + "</span>" + d + "</td>" + n + "</tr>"
                        }
                    } else if (5 == e) q = "price_discount" == w ? "<span class=money>" + O + "</span> " + i.off_text + " (<span class=money>" + $ + "</span> " + i.get_at_text + ")" : "fix_price" == w ? i.get_at_text + " <span class=money>" + O + "</span>" : _ + "% " + i.off_text + " (<span class=money>" + A + "</span> " + i.get_at_text + ")", b += "<tr><td>" + y + x + " " + i.min_qty_after_text + "   <span class='hulk-offer-text'>" + C + "</span></td><td><span class='hulkapps-price'>" + q + "</span>" + d + "</td>" + n + "</tr>";
                    else if (6 == e) {
                        if (q = "price_discount" == w ? "<span class=money>" + O + "</span> (<span class=money>" + $ + "</span> " + i.get_at_text + ")" : "fix_price" == w ? i.get_at_text + " <span class=money>" + O + "</span>" : _ + "% (<span class=money>" + A + "</span> " + i.get_at_text + ")", o == a[t - 1]) b += "<tr><td>" + x + " + </td><td><span class='hulkapps-price'>" + q + "</span>" + d + "</td>" + n + "</tr>";
                        else {
                            var E = x ? a[t + 1] ? a[t + 1][0] - 1 : "+" : "";
                            b += "<tr><td>" + x + ("+" === E ? "" : "-") + E + "   <span class='hulk-offer-text'>" + C + "</span></td><td><span class='hulkapps-price'>" + q + "</span>" + d + "</td>" + n + "</tr>"
                        }
                    } else if (7 == e) {
                        var L = "each_qty" == u.discount_type ? i.get_at_text : "";
                        q = "price_discount" == w ? "<span class=money>" + O + "</span> " + i.off_text : "fix_price" == w ? "<span class=money>" + O + "</span> " + L : _ + "% " + i.off_text, m = product_price / 100, m = i.include_decimal_in_offer_table ? parseFloat(m).toFixed(2) : parseInt(m), v = "price_discount" == w ? m - z : "fix_price" == w ? z : m - m * _ / 100, "each_qty" == u.discount_type && (v = i.include_decimal_in_offer_table ? parseFloat(v).toFixed(2) : parseInt(v));
                        let F = i.include_decimal_in_offer_table ? (m * x).toFixed(2) : m * x,
                            T = "price_discount" == w || "fix_price" == w ? v * x : F - F * _ / 100;
                        if ("each_qty" == u.discount_type && (T = i.include_decimal_in_offer_table ? T.toFixed(2) : parseInt(T)), i.include_decimal_in_offer_table && u.is_round_off_prices && null !== u.round_off_price) {
                            var k = u.round_off_price;
                            switch (k) {
                                case 0:
                                    v = Math.round(parseFloat(v)) + parseFloat(u.round_off_price);
                                    break;
                                case .49:
                                case .5:
                                    v = parseInt(v) + parseFloat(u.round_off_price);
                                    break;
                                case .95:
                                case .99:
                                    v = Math.round(parseFloat(v)) - 1 + parseFloat(u.round_off_price)
                            }
                            T = (v * x).toFixed(2), v = v.toFixed(2)
                        }
                        var I = "1" == l ? "checked" : "";
                        if (a.length - 1 == t && (I = j.includes("1") && "1" != l ? "" : "checked"), "bulk_qty" == u.discount_type) {
                            if ("fix_price" == w) T = v;
                            else if ("% Off" == w) {
                                var P = F * _ / 100;
                                T = F - (P = Math.floor(P * (multiplier = 100)) / multiplier)
                            }
                            v = T / x, T = i.include_decimal_in_offer_table ? parseFloat(T).toFixed(2) : parseInt(T), v = i.include_decimal_in_offer_table ? parseFloat(v).toFixed(2) : parseInt(v);
                            var D = "" != i.bulk_qty_pro_text_msg ? i.bulk_qty_pro_text_msg.replace("{{ quantity }}", x).replace("{{ amount }}", q) : "Buy" + x + " for " + q
                        } else var D = y + " " + x + " " + i.list_after_quantity + " " + q;
                        let B = currency_conversion(v),
                            N = currency_conversion(m),
                            M = currency_conversion(T),
                            U = currency_conversion(F);
                        b += '<div class="offer-option-item" tabindex="0" role="button"> <input type="radio" id="card_' + t + '" name="card_group" value="' + x + '" aria-labelledby="label_card_' + t + '" ' + I + '/> <label for="card_' + t + '" id="label_card_' + t + '"> <div class="offer-option_txt"> <div class="option-radio"> </div><div class="offer-option"> <p>' + D + '</p><a class="offer-badge" style="display: ' + s + "; font-size: " + p.pop_offer_text_size + "px; color: " + p.pop_offer_font_color + "; background: " + p.pop_offer_background_color + ';">' + p.pop_offer_text + '</a><span style="display: ' + ("inline-block" === s ? "none" : C ? "inline-block" : "none") + '" class="offer_help_text">' + C + '</span> </div></div><div class="offer-option_price"> <div class="option-item-price"> <div class="item-regular_price"> <span class="money">' + B + '</span> </div><div class="item-compare_price"> <span class="money">' + N + '</span> </div></div><div class="option-total-price">' + i.list_total + '<div class="total-regular_price"> <span class="money">' + M + '</span> </div><div class="total-compare_price"> <span class="money">' + U + "</span> </div></div></div></label> </div>"
                    } else if (8 == e) {
                        var L = "each_qty" == u.discount_type ? i.get_at_text : "";
                        if (q = "price_discount" == w ? "<span class=money>" + O + "</span> " + i.off_text : "fix_price" == w ? "<span class=money>" + O + "</span> " + L : _ + "% " + i.off_text, "bulk_qty" == u.discount_type) var D = "" != i.bulk_qty_pro_text_msg ? i.bulk_qty_pro_text_msg.replace("{{ quantity }}", "<span>" + x + "</span>").replace("{{ amount }}", "<span>" + q + "</span>") : "Buy" + x + " for " + q;
                        else var D = y + "<span>" + x + "</span> " + i.list_after_quantity + " <span>" + q + "</span>";
                        b += '<li class="table-list-item">' + D + '<a class="offer-badge" style="display: ' + s + "; font-size: " + p.pop_offer_text_size + "px; color: " + p.pop_offer_font_color + "; background: " + p.pop_offer_background_color + ';">' + p.pop_offer_text + '</a><div class="offer_help_text">' + C + "</div></li>"
                    }
                })
            }
            if (1 == e || 2 == e || 3 == e || 4 == e || 5 == e || 6 == e) {
                let A = `hulkapps_jQuery('.hulkapps-table th').first().css('border-top-left-radius', '${i.table_radius}px');hulkapps_jQuery('.hulkapps-table th:visible').last().css('border-top-right-radius', '${i.table_radius}px');hulkapps_jQuery('.hulkapps-table td:visible').last().css('border-bottom-right-radius', '${i.table_radius}px');hulkapps_jQuery('.hulkapps-table tr:last td').first().css('border-bottom-left-radius', '${i.table_radius}px');`;
                return b += "</tbody></table></div><style>.hulkapps-table thead {background-color: " + i.header_bg_color + ";font-size: " + i.header_font_size + "px;color: " + i.header_text_color + ";}.hulkapps-table tbody {background-color: " + i.body_bg_color + ";font-size: " + i.body_font_size + "px;color: " + i.body_text_color + "}.hulkapps-table th,.hulkapps-table td{border: " + i.grid_border_width + "px solid " + i.border_color + " !important;padding: " + i.top_bottom_padding + "px " + i.right_left_padding + "px !important; }.hulkapps-table .hulkapps-price{color: " + i.discount_text_color + "}.hulkapps-table .hulk-offer-text{color: " + i.offer_help_text + "}.hulkapps-volumes {width: 100%;margin-top: 10px;}.offer-options-title{font-family:inherit;font-size:16px;font-weight:700;line-height:inherit;letter-spacing:inherit;color:inherit;margin-top:30px}.offer-options-des{font-family:inherit;font-size:14px;line-height:inherit;letter-spacing:inherit;color:inherit;margin-top:5px}.hulkapps-volume-discount-tiers{margin-top:15px;}" + i.custom_css + "</style><script>" + A + i.custom_js + "</script>"
            }
            if (7 == e) {
                let z = !0 == i.is_theme_inherit ? i.theme_button_class + " mr-top offer-option-btn" : "offer-option-btn",
                    O = !0 == i.is_theme_inherit ? "" : "button.offer-option-btn{margin:15px 0;cursor:pointer;border-radius:" + i.list_card_radius + "px;font-size:14px;font-weight:700;text-transform:uppercase;text-align:center;display:inline-block;width:100%;background:" + i.button_color + ";border:none;color:" + i.button_text_color + ";padding:12px 18px;letter-spacing:inherit;line-height:inherit}";
                return b += '<button type="button" class="' + z + '" id="card-list-button" onclick="grab_deal(event)">' + $ + "</button> </div><style>.offer-options-list [type=radio]:checked,.offer-options-list [type=radio]:not(:checked){position:absolute;left:-9999px}.offer-options-list [type=radio]+label{cursor:pointer;display:flex;align-items:center;position:relative;color:inherit;padding:12px 16px;width:100%;justify-content:space-between}.offer-options-list [type=radio]+label:after,.offer-options-list [type=radio]+label:before{content:'';border-radius:" + i.list_card_radius + "px;border:1px solid #dfe3e8;position:absolute;top:0;right:0;left:0;bottom:0;padding:0 16px;z-index:0}.offer-options-list [type=radio]:checked+label:after{background-color:" + i.button_color + ";opacity:.15}.offer-options-list [type=radio]:checked+label:before{border-color:" + i.button_color + '}.offer-options-list [type=radio]:checked+label div.option-radio:after,.offer-options-list [type=radio]:not(:checked)+label div.option-radio:after{content:"";width:8px;height:8px;background:' + i.button_color + ";position:absolute;top:50%;left:50%;border-radius:50px;transform:translate(-50%,-50%);transition:all .2s ease}.option-radio{display:inline-block;position:relative;margin:0px 10px 0 0;vertical-align:middle;cursor:pointer;box-shadow:0 0 0 1px transparent,0 1px 0 0 rgb(22 29 37 / 5%);background:0 0;width:20px;height:20px;border-radius:50px;border:2px solid " + i.button_color + "}.offer-options-list [type=radio]:not(:checked)+label div.option-radio:after{opacity:0}.offer-options-list [type=radio]:checked+label div.option-radio:after{opacity:1}.offer-options-title{font-family:inherit;font-size:16px;font-weight:700;line-height:inherit;letter-spacing:inherit;color:inherit;margin-top:30px}.offer-options-des{font-family:inherit;font-size:14px;line-height:inherit;letter-spacing:inherit;color:inherit;margin-top:5px}.offer-options-list .offer-option_txt{position:relative;z-index:1;display:flex}.offer-options-list .offer-option p{font-size:14px;font-weight:400;letter-spacing:inherit;line-height:20px;color:inherit;margin:0;padding:0;}a.offer-badge{font-size:10px;font-weight:500;line-height:12px;color:" + i.button_text_color + ";letter-spacing:inherit;background-color:" + i.button_color + ";text-align:center;border-radius:100px;padding:4px 12px;margin-top:13px;display:inline-block;text-decoration:none}.offer-options-list .offer-option{display:block;max-width:calc(100% - 30px);}.offer-options-list .option-item-price,.offer-options-list .option-total-price{display:flex;align-items:center;font-size:14px;font-weight:500;line-height:inherit;color:inherit;letter-spacing:inherit;justify-content:end}.offer-option_price{z-index:1;padding-left:15px}.total-regular_price{padding-left:5px}.offer-options-list .option-total-price{margin-top:8px}.offer-options-list .item-regular_price{font-weight:700}.offer-options-list .total-compare_price{font-weight:400}.offer-options-list .item-compare_price{font-weight:400}.offer-options-list .item-compare_price,.offer-options-list .total-compare_price{text-decoration:line-through;margin-left:5px}.offer-options-list div.offer-option-item{margin-bottom:10px}.offer-options-list div.offer-option-item:last-of-type{margin-bottom:0}" + O + ".offer_help_text{font-size:12px;line-height:18px;}.mr-top{margin-top:10px;}" + i.custom_css + "</style><script>" + i.custom_js + "</script>"
            }
            if (8 == e) return b += "</ul> </div><style>.offer-table-list ul.table-list{border:1px solid " + i.list_border_color + ";border-radius:" + i.list_card_radius + "px;text-align:center;list-style:none;width:100%;padding:0;max-width:500px}.offer-table-list li.table-list-item{padding:10px 15px;border-bottom:1px solid " + i.list_border_color + "}.offer-table-list li.table-list-item:last-child{border-bottom:0}.offer-table-list li.table-list-item span{color:" + i.button_color + "}.offer-table-list li.table-list-item a.offer-badge{margin-left:15px}a.offer-badge{font-size:10px;font-weight:500;line-height:12px;color:" + i.button_text_color + ";letter-spacing:inherit;background-color:" + i.button_color + ";text-align:center;border-radius:100px;padding:4px 12px;margin-top:8px;display:inline-block;text-decoration:none}.offer_help_text{font-size:14px}.offer-options-title{font-family:inherit;font-size:16px;font-weight:700;line-height:inherit;letter-spacing:inherit;color:inherit;margin-top:30px}.offer-options-des{font-family:inherit;font-size:14px;line-height:inherit;letter-spacing:inherit;color:inherit;margin-top:5px}" + i.custom_css + "</style><script>" + i.custom_js + "</script>"
        }, window.productPageAjax = function(t, e = "product") {
            var i = e;
            t.ajax({
                type: "POST",
                url: window.hulkapps.po_url + "/api/v2/store/get_all_relationships",
                data: {
                    hpage_type: i,
                    pid: window.hulkapps.product_id,
                    store_id: window.hulkapps.store_id,
                    tags: window.hulkapps.product.tags,
                    vendor: window.hulkapps.product.vendor,
                    ptype: window.hulkapps.product.type,
                    customer_tags: null != window.hulkapps.customer ? window.hulkapps.customer.tags.split(",") : "",
                    product_collections: window.hulkapps.product_collections
                },
                sync: !1,
                crossDomain: !0,
                success: function(e) {
                    if (window.$first_add_to_cart_el && window.$first_add_to_cart_el.removeAttr("disabled"), "string" != t.type(e)) {
                        var a = "";
                        let o = {};
                        if (window.store_created_date = e.created_at_date, window.hulk_po_plan_id = e.plan_id, window.hulk_po_plans_features = e.plans_features, window.hulk_po_is_on_trial_period = e.is_on_trial_period, (checkPlan("conditional_logic", "boolean") || !1 == checkPlan("conditional_logic", "boolean") && !0 == oldStore()) && void 0 != e.condition) {
                            a += "<div id='conditional_rules' style='display:none'>";
                            var n = "";
                            t.each(e.condition, function(i, l) {
                                var s = l.id,
                                    p = hulkapps_jQuery.parseJSON(l.conditions);
                                if ("OR" == p.apply_rule) var d = "0";
                                else var d = "1";
                                a = a + "<div id='conditional_logic_" + s + "' name='conditional_logic_" + s + "' data-verify-all='" + d + "' style='display:none'>", t.each(p.rules, function(t, i) {
                                    var o = parseInt(i.option);
                                    if (e.option_id_array.indexOf(o) >= 0) {
                                        if (1 == parseInt(i.rule_type)) var n = "==";
                                        else var n = "!=";
                                        a = a + "<div name='conditional_logic_" + s + "' data-field-num='" + o + "' data-verify-all='" + d + "' class='step_1'>**value11**" + n + i.option_val + "</div>"
                                    }
                                }), a += "</div>";
                                let u = [];
                                t.each(p.actions, function(t, i) {
                                    var a = parseInt(i.option);
                                    if (u.push(a), e.option_id_array.indexOf(a) >= 0) {
                                        if (1 == parseInt(i.action_type)) var o = "show";
                                        else var o = "hide";
                                        n += " conditional_logic_" + s + "_" + o;
                                        var l = "condition_" + o + " conditional";
                                        e.hide_show_array[a] = l
                                    }
                                }), o[s] = u
                            }), a += "</div>"
                        }
                        var l = e.cart_selectors,
                            s = 0 != e.options_title.title_text.length ? e.options_title.title_text : "Choose Your Product Options:",
                            p = ".hulkapps_option_title{";
                        p += 0 != e.options_title.title_padding.length ? "padding: " + e.options_title.title_padding + "px;" : "padding: 15px;", p += 0 != e.options_title.title_font_size.length ? "font-size: " + e.options_title.title_font_size + "px;" : "font-size: 16px;", p += 0 != e.options_title.title_text_align.length ? "text-align: " + e.options_title.title_text_align + ";" : "text-align: left;", p += 0 != e.options_title.title_background.length ? "background-color: " + e.options_title.title_background + ";" : "background-color: #ffffff;", p += 0 != e.options_title.title_border.length ? "border: 1px solid " + e.options_title.title_border + ";" : "border: 1px solid #000000;", p += 0 != e.options_title.title_font_color.length ? "color: " + e.options_title.title_font_color + ";" : "color:#000000;", p += 1 == parseInt(e.options_title.title_bold) ? "font-weight:bold;" : "font-weight:normal;", p += 1 == parseInt(e.options_title.title_display) ? "" : "display:none;", p += "border-bottom: none;", p += "}", e.options_container_style.enable_tooltip;
                        var d = e.options_container_style.enable_helptext,
                            u = "#hulkapps_option_list_" + e.pid + "{";
                        u += 0 != e.options_container_style.background_color.length ? "background-color: " + e.options_container_style.background_color + ";" : "background-color: #fff;", u += 0 != e.options_container_style.border_color.length ? "border: 1px solid " + e.options_container_style.border_color + ";" : "border: 0 none;", u += 0 != e.options_container_style.padding.length ? "padding: " + e.options_container_style.padding + "px;" : "padding: 10px;", u += "}.hulkapps_option {width: 100%;display: block;transition: 0.3s all;", u += 0 != e.options_container_style.spacing_between_options.length ? "padding-bottom: 0px; margin-bottom: " + e.options_container_style.spacing_between_options + "px;" : "padding-bottom: 0; margin-bottom: 6px;", u += 0 != e.options_container_style.line_between_options.length ? "border-bottom: 1px solid " + e.options_container_style.line_between_options + ";" : "", u += "}";
                        var c = e.options_name_style.option_name_inline,
                            f = e.display_settings.formula_option_name_inline;
                        window.change_button_text = e.display_settings.change_button_text, window.select_button_text = e.display_settings.select_button_text;
                        var v = ".hulkapps_option_name {";
                        v += 0 != e.options_name_style.option_name_width.length ? "width: " + e.options_name_style.option_name_width + "px;" : "width: 180px;", v += 0 != e.options_name_style.option_name_font_size.length ? "font-size: " + e.options_name_style.option_name_font_size + "px;" : "font-size: 14px;", v += 0 != e.options_name_style.option_name_text_align.length ? "text-align: " + e.options_name_style.option_name_text_align + ";" : "text-align: left;", v += 0 != e.options_name_style.font_color.length ? "color: " + e.options_name_style.font_color + ";" : "color: #424242;", v += 1 == parseInt(e.options_name_style.on_title_bold) ? "font-weight: bold;" : "font-weight: normal;", v = v + "min-width: " + e.options_name_style.option_name_width + "px;padding-right: 15px;box-sizing: border-box;-webkit-box-sizing: border-box;-moz-box-sizing: border-box;-ms-box-sizing: border-box;vertical-align: top;}", e.option_values_style.ov_padding, e.option_values_style.ov_width, e.option_values_style.spacing_left_of_values;
                        var m = e.option_values_style.single_line,
                            k = ".hulkapps_option_value {";
                        k += "width:100%;min-width: 100%;text-align: left;vertical-align: top;}", k += ".hulkapps_option .hulkapps_option_value, .pn_render .hulkapps_option_child, .et_render .hulkapps_option_child, .tb_render .hulkapps_option_child, .ta_render .hulkapps_option_child, .fu_render .hulkapps_option_child, .dd_render .hulkapps_option_child, .dd_multi_render .hulkapps_option_child, .nf_render .hulkapps_option_child, .dp_render .hulkapps_option_child, .dt_render .hulkapps_option_child{", k += 0 != e.option_values_style.ov_font_size.length ? "font-size: " + e.option_values_style.ov_font_size + "px !important;" : "", k += 0 != e.option_values_style.ov_font_color.length ? "color: " + e.option_values_style.ov_font_color + " !important;" : "", k += void 0 != e.option_values_style.ov_font_weight && 1 == parseInt(e.option_values_style.ov_font_weight) ? "font-weight:bold;" : "font-weight:normal;", k += void 0 != e.option_values_style.ov_text_align ? "text-align: " + e.option_values_style.ov_text_align + " !important;" : "", k += "}";
                        var g = ".recommended_btn, recommended_btn a{";
                        g += void 0 != e.recomodation_setting && void 0 != e.recomodation_setting.recomodation_font_size ? "font-size: " + e.recomodation_setting.recomodation_font_size + "px !important;" : "", g += void 0 != e.recomodation_setting && void 0 != e.recomodation_setting.recomodation_font_color ? "color: " + e.recomodation_setting.recomodation_font_color + " !important;" : "", g += "}";
                        var $ = ".hulkapps_helptext,.hulkapps_helptext a{";
                        $ += void 0 != e.option_help_text_style && void 0 != e.option_help_text_style.option_help_text_font_size ? "font-size: " + e.option_help_text_style.option_help_text_font_size + "px !important;" : "", $ += void 0 != e.option_help_text_style && void 0 != e.option_help_text_style.option_help_text_font_color ? "color: " + e.option_help_text_style.option_help_text_font_color + "!important;" : "", $ += void 0 != e.option_help_text_style && 1 == parseInt(e.option_help_text_style.on_help_text_bold) ? "font-weight: bold;" : "font-weight: normal;", $ += "}";
                        var b = ".hulkapps-tooltip .hulkapps-tooltip-inner,.hulkapps-tooltip .hulkapps-tooltip-inner a{";
                        b += void 0 != e.option_tooltip_style && void 0 != e.option_tooltip_style.option_tooltip_font_size ? "font-size: " + e.option_tooltip_style.option_tooltip_font_size + "px !important;" : "", b += void 0 != e.option_tooltip_style && void 0 != e.option_tooltip_style.option_tooltip_font_color ? "color: " + e.option_tooltip_style.option_tooltip_font_color + "!important;" : "", b += void 0 != e.option_tooltip_style && void 0 != e.option_tooltip_style.option_tooltip_background_color ? "background-color: " + e.option_tooltip_style.option_tooltip_background_color + "!important;" : "", b += "}", b += ".hulkapps-tooltip .hulkapps-tooltip-inner:after{", b += void 0 != e.option_tooltip_style && void 0 != e.option_tooltip_style.option_tooltip_background_color ? "border-color: " + e.option_tooltip_style.option_tooltip_background_color + " transparent transparent transparent !important;" : "", b += "}", b += ".hulkapps-tooltip .hulkapps-tooltip-inner.swatch-tooltip p,.hulkapps-tooltip .hulkapps-tooltip-inner.multiswatch-tooltip p{", b += void 0 != e.option_tooltip_style && void 0 != e.option_tooltip_style.option_tooltip_font_color ? "color: " + e.option_tooltip_style.option_tooltip_font_color + "!important;" : "", b += "}";
                        var y = 0 != e.option_values_style.ov_font_size.length ? parseInt(e.option_values_style.ov_font_size) - 2 : 14,
                            x = ".has-float-label .floating_label{";
                        x += 0 != e.option_values_style.ov_font_size.length ? "font-size: " + e.option_values_style.ov_font_size + "px;" : "font-size: 14px;", x += 0 != e.option_values_style.ov_font_color.length ? "color: " + e.option_values_style.ov_font_color + ";" : "color: #424242;", x += void 0 != parseInt(e.option_values_style.ov_font_weight) && 1 == parseInt(e.option_values_style.ov_font_weight) ? "font-weight: bold;" : "font-weight: normal;", x += "}", x += ".has-float-label .hulkapps_option_value input:focus-visible ~ .floating_label, .has-float-label .hulkapps_option_value textarea:focus ~ .floating_label, .has-float-label .hulkapps_option_value textarea:focus-visible ~ .floating_label, .has-float-label .hulkapps_option_value input:focus ~ .floating_label, .has-float-label .hulkapps_option_value textarea:focus-within ~ .floating_label, .has-float-label .hulkapps_option_value input:focus-within ~ .floating_label,  .has-float-label .hulkapps_option_value textarea:active ~ .floating_label, .has-float-label .hulkapps_option_value input:active ~ .floating_label,.has-float-label .hulkapps_option_value input.textbox_selected ~ .floating_label, .has-float-label .hulkapps_option_value input.numberfield_selected ~ .floating_label,.has-float-label .hulkapps_option_value input.emailbox_selected ~ .floating_label,.has-float-label .hulkapps_option_value textarea.textbox_selected ~ .floating_label, .has-float-label .hulkapps_option_value textarea.textarea_selected ~ .floating_label, .has-float-label,.hulkapps_option_value select ~ label.floating_label{", x += 0 != e.option_values_style.ov_font_size.length ? "font-size: " + y + "px !important;" : "font-size: 14px;", x += "}";
                        var _ = e.advanced_users.custom_js,
                            w = e.advanced_users.custom_css,
                            q = parseInt(e.swatch_settings.swatch_width),
                            C = parseInt(e.swatch_settings.swatch_height),
                            S = e.swatch_settings.tooltip_position,
                            j = e.swatch_settings.tooltip_contains,
                            A = parseInt(e.swatch_settings.tooltip_display),
                            z = parseInt(e.swatch_settings.round_corners),
                            O = parseInt(e.swatch_settings.enable_swatch_images),
                            E = parseInt(e.swatch_settings.enable_swatch_with_text),
                            q = "" == q || q < 0 ? "width:35px;" : "width:" + q + "px;",
                            C = "" == C || C < 0 ? "height:35px;" : "height:" + C + "px;",
                            S = "top" == S ? "top" : "bottom",
                            z = 1 == z ? "-webkit-border-radius: 50%;-moz-border-radius: 50%;border-radius: 50%;" : "",
                            L = e.swatch_settings.swatch_selected_border,
                            F = void 0 != L ? "border-color: " + L + " !important" : " #000000 !important",
                            T = 0 != e.button_option_settings.button_option_background.length ? "background-color: " + e.button_option_settings.button_option_background + ";" : "#ffffff",
                            I = 0 != e.button_option_settings.button_option_font_color.length ? "color: " + e.button_option_settings.button_option_font_color + ";" : "#777777",
                            P = 0 != e.button_option_settings.button_option_border_color.length ? "border-color: " + e.button_option_settings.button_option_border_color + ";" : "#777777",
                            D = void 0 != e.label_setting && "blocklable" == e.label_setting.lable_display ? "" : void 0 == e.label_setting ? "" : e.label_setting.lable_display;
                        if ("floatingLabels" == D) var B = "has-float-label";
                        if ("inlineLabels" == D) var B = "has-inline-label";
                        var N = e.premium_option_settings.update_total_text,
                            M = void 0 == e.premium_option_settings.amount_note_display ? 1 : e.premium_option_settings.amount_note_display;
                        if (void 0 != e.premium_option_settings.price_setting) var M = "price_addtional_charge" == e.premium_option_settings.price_setting || "price_total_charge" == e.premium_option_settings.price_setting ? "1" : "0";
                        var U = void 0 == e.premium_option_settings.disabled_option_price ? 0 : e.premium_option_settings.disabled_option_price;
                        currency_symbol = e.currency_symbol, window.hulk_po_currency_symbol = e.currency_symbol, display_price_setting = e.premium_option_settings;
                        var J = e.premium_option_settings.post_total_text,
                            X = e.premium_option_settings.total_container_background_color,
                            Y = e.premium_option_settings.total_container_border_color,
                            R = e.premium_option_settings.total_container_font_color,
                            Q = e.premium_option_settings.total_container_price_color,
                            K = "#option_total {";
                        K += "" !== X ? "background: none repeat scroll 0 0 " + X + ";" : "background: none repeat scroll 0 0 #fff;", K += "" !== Y ? "border:1px solid " + Y + ";" : "border:1px solid #000000;", K += "" !== R ? "color: " + R + ";" : "color: #000;", K += "}#formatted_option_total {", K += "" !== Q ? "color: " + Q + ";" : "color: #000;", K += "}";
                        var H = 0 == parseInt(m) ? "0px" : "10px",
                            V = e.popup_button_settings,
                            W = ".hulkSaveBtn { background-color: " + V.button1_background_color + "; color: " + V.button1_font_color + ";border: " + V.button1_border_width + "px solid " + V.button1_border_color + "}",
                            Z = ".hulkCancelBtn { background-color: " + V.button2_background_color + "; color: " + V.button2_font_color + ";border: " + V.button2_border_width + "px solid " + V.button2_border_color + "} .hulkresetBtn { background-color: " + V.button2_background_color + "; color: " + V.button2_font_color + ";border: " + V.button2_border_width + "px solid " + V.button2_border_color + "} ";
                        t(".hulkSaveBtn").text(V.button1_text), t(".hulkCancelBtn").text(V.button2_text);
                        var G = void 0 != e.image_thumbnail_parents_selector ? e.image_thumbnail_parents_selector : "",
                            tt = "";
                        void 0 != G && "" != G && (image_parent_selector = G.split(",")).forEach(function(t, e, i) {
                            e === i.length - 1 ? tt += t + "  img" : tt += t + "  img,"
                        }), window.image_parent = tt;
                        var te = e.button_option_settings.button_option_selected_background,
                            ti = e.button_option_settings.button_option_selected_border_color,
                            ta = e.button_option_settings.button_option_selected_font_color,
                            to = p + u + v + k + K + ("#hulkapps_custom_options_" + e.pid + "{clear: both}#hulkapps_options_" + e.pid + "{margin:15px 0;}#hulkapps_option_list_" + e.pid + " select{width:100%;padding-top: 12px;padding-bottom: 12px}.popup_detail{position: fixed;background-color: #F7F7F7;padding: 15px;top: 50%;left: 50%;transform: translate(-50%, -50%);justify-content: space-between;z-index: 3;min-width: 300px;max-width: fit-content;overflow-y: auto;max-height: 300px;}.popup_detail a{cursor: pointer;}.popup_detail img{width: 15px;height: 15px;margin: 5px;}.popup_detail p{margin:0;}.overlay-popup{position: fixed;display: none;width: 100%;height: 100%;top: 0;left: 0;bottom: 0;background-color: rgba(0,0,0,0.5);z-index: 2;}.popup_render{margin-bottom:0!important;display:flex;align-items:center!important}.popup_render .hulkapps_option_value{min-width:auto!important}.popup_render a{margin-left: 4px;text-decoration:underline!important;transition:all .3s!important;font-weight: normal !important;}.popup_render a:hover{color:#6e6e6e}.cut-popup-icon{display:inline-flex;align-items:center}.cut-popup-icon-span{display:inline-flex}.des-detail{font-weight: normal;}#hulkapps_option_list_" + e.pid + " input[type='text']{width:100%;border-radius:0}#hulkapps_option_list_" + e.pid + " input,#hulkapps_option_list_" + e.pid + " textarea,#hulkapps_option_list_" + e.pid + " select{border:1px solid #DADADA;box-shadow: none;-webkit-appearance: none;padding:10px;min-height: 36px;}#hulkapps_option_list_" + e.pid + " .validation_error{color:#FF0808;background-color:#FFF8F7;border-style:solid;border-width:1px;border-color:#FFCBC9;border-bottom: 1px solid #ffcbc9;padding: 8px 8px ;display: inline-block;margin-top: 2px;}#hulkapps_option_list_" + e.pid + " .validation_error .hulkapps_option_value{color:#FF0808}#hulkapps_option_list_" + e.pid + " .validation_error .hulkapps_option_name{color:#FF0808}.hulkapps_option_value:first-child{display:flex;align-items: center;} .hulkapps_option_value:first-child span{display: flex;padding-right: 10px;}.hulkapps_option_value:first-child a{cursor: pointer;} .hulkapps_helptext{color: #000 !important;}.hulkapps_full_width{width:100%;display:block;}.hulkapps_check_option,.hulkapps_radio_option{display:block;margin-right:0;font-weight:normal !important;}.single_line .hulkapps_option_value .hulkapps_check_option,.single_line .hulkapps_option_value .hulkapps_radio_option{display:inline-flex;margin-right:20px;font-weight:normal; align-items: center; }#hulkapps_option_list_" + e.pid + " input[type='checkbox']{margin-right: 5px;vertical-align: baseline;min-height:auto; height: auto;display: none;-webkit-appearance: checkbox;-moz-appearance: checkbox;appearance: checkbox;}.hulkapps_check_option input[type='checkbox']{margin-right:5px;}#hulkapps_option_list_" + e.pid + " input[type='radio']{margin-right:5px;vertical-align:baseline;display: none;}i.hulkapps_tooltip_identifier{color:rgb(255, 255, 255);border-radius:12px;font-size:10px;margin-right:6px;margin-left:4px;padding:0px 4px;background:#000000}span.hulkapps_option_name_additional_info{position:relative}span.hulkapps_option_name_additional_info .hulkapps_tool_tip{display:none}span.hulkapps_option_name_additional_info:hover .hulkapps_tool_tip{content:attr(data-additional-info);padding:4px 8px;color:#fff;position:absolute;left:0;bottom:160%;z-index:20px;-moz-border-radius:5px;-webkit-border-radius:5px;border-radius:5px;display:block;background:#000000;width:150px}span.hulkapps_option_name_additional_info:hover:after{display:block}i.hulkapps_tooltip_identifier:before{content:'?';font-style:normal}#formatted_option_total{font-weight:bold;margin:0 7px}.td_render .hulkapps_option_name.full_name{float:none;width:auto}.hulkapps_option.full_width .hulkapps_option_name{width:100%;}.hulkapps_option.full_width .hulkapps_option_value{width:100%;display:block;}.hulkapps_option.full_width .hulkapps_option_name{padding-bottom:5px}.hulkapps_option:after{content:'';clear:both;display:block}.hulkapps_option_name a:link {color: grey;text-decoration: none;font-weight: normal;}.hulkapps_option_name a:hover {color: rgb(93, 156, 236);background: transparent;}.hulkapps_swatch_option .hulkapps_option_child:after{border: 1px solid #DADADA;cursor: pointer;content:'';position:absolute;top:-4px;right:-4px;bottom:-4px;left:-4px;" + z + "}.hulkapps_mswatch_option .hulkapps_option_child:after{border: 1px solid #DADADA;cursor: pointer;content:'';position:absolute;top:-4px;right:-4px;bottom:-4px;left:-4px; " + z + "}.hulkapps_radio_option .radio_selected{border: 2px solid #0090FA;background:#0090FA;color:#fff;}.radio_div{border: 2px solid #eee;padding: 8px 20px;padding: 6px 12px;}.radio_div:hover{border: 2px solid #0090FA;cursor:pointer;}.tooltip.in{opacity:1 !important;}#option_display_total_format{padding-left:5px;}.hulkapps_swatch_option .tooltip-inner{padding: 0px 5px !important;}.hulkapps_check_option,.hulkapps_radio_option{margin-right:" + H + "}.hulkapps_swatch_option,.hulkapps_mswatch_option{ margin-right:10px !important; display: inline-block;vertical-align: middle;}.hulkapps-tooltip.tooltip-left-pos .hulkapps-tooltip-inner.swatch-tooltip{left: 0 !important;right: auto !important;}.hulkapps-tooltip.tooltip-left-pos .hulkapps-tooltip-inner.swatch-tooltip:after{right: auto !important;left: 10px !important;}.hulkapps-tooltip.tooltip-right-pos .hulkapps-tooltip-inner.swatch-tooltip{right: 0 !important;left: auto !important;}.hulkapps-tooltip.tooltip-right-pos .hulkapps-tooltip-inner.swatch-tooltip:after{left: auto !important;right: 10px !important;}.hulkapps-tooltip.tooltip-center-pos .hulkapps-tooltip-inner.swatch-tooltip{left: 50% !important;transform: translateX(-50%);}.hulkapps-tooltip.tooltip-center-pos .hulkapps-tooltip-inner.swatch-tooltip:after{left: 50% !important;transform: translateX(-50%);}.hulkapps_mswatch_option .swatch_selected:after, .hulkapps_swatch_option .swatch_selected:after{" + F + "}.phone_number{padding-left: 50px !important;}#option_total{padding:3px 6px;}.hulkapps-tooltip.tooltip-left-pos .hulkapps-tooltip-inner.multiswatch-tooltip{left: 0 !important;right: auto !important;}.hulkapps-tooltip.tooltip-left-pos .hulkapps-tooltip-inner.multiswatch-tooltip:after{right: auto !important;left: 10px !important;}.hulkapps-tooltip.tooltip-right-pos .hulkapps-tooltip-inner.multiswatch-tooltip{right: 0 !important;left: auto !important;}.hulkapps-tooltip.tooltip-right-pos .hulkapps-tooltip-inner.multiswatch-tooltip:after{left: auto !important;right: 10px !important;}.hulkapps-tooltip.tooltip-center-pos .hulkapps-tooltip-inner.multiswatch-tooltip{left: 50% !important;transform: translateX(-50%);}.hulkapps-tooltip.tooltip-center-pos .hulkapps-tooltip-inner.multiswatch-tooltip:after{left: 50% !important;transform: translateX(-50%);}.hulkapps_swatch_option, .hulkapps_mswatch_option{margin-bottom: 10px !important;}.hulkapps_buton_option .hulkapps_option_child{ width: auto;min-height: 36px;padding: 15px;border: 1px solid;border-radius: 0;line-height: 1.13;font-weight: 400;display: flex;justify-content: center;align-items: center;margin-right: 0;margin-bottom: 8px;}.button_selected {color: " + ta + " !important;background-color: " + te + " !important;border-color: " + ti) + " !important;font-weight: 400 !important;}.hulkapps_option_set input::placeholder,.hulkapps_option_set textarea::placeholder  {color: #a9a9a9;font-size: 16px !important;font-weight: 700;font-family: sans-serif;}.conditional, .is_hulk_hide{display:none !important}.has-float-label .hulkapps_option_name{display: none !important}.has-float-label .hulkapps_option_value{display: block;width: 100%}.has-inline-label .hulkapps_option_name{display: none !important}.has-inline-label .hulkapps_option_value{display: block;width: 100%}.has-float-label .hulkapps_option_value{ position: relative;}.has-float-label .hulkapps_option_value .floating_label{position: absolute;top: 24%;left: 10px;}input:focus .floating_label { position: absolute;top: 30%;left: 10px;}.has-float-label .hulkapps_option_value textarea,.has-float-label .hulkapps_option_value input,.has-float-label .hulkapps_option_value select{ position: relative;z-index: 1;background-color: transparent;}.has-float-label .hulkapps_option_value .floating_label {position: absolute;top: 24%;left: 10px;transition: all .2s;}.has-float-label .hulkapps_option_value select ~ label.floating_label {cursor: text;opacity: 1;transition: all .2s;top: -0.5em !important;z-index: 3;line-height: 1;padding: 0 1px;left: 10px;position: absolute; z-index: 2;}.has-float-label .hulkapps_option_value input:not(:focus) ~ .floating_label,.has-float-label .hulkapps_option_value textarea:not(:focus) ~ .floating_label {opacity: 1;top: 0.3em;}.has-float-label .hulkapps_option_value input:focus ~ .floating_label,.has-float-label .hulkapps_option_value textarea:focus ~ .floating_label{top: -0.9em !important;z-index: 2;}.has-float-label .hulkapps_option_value .floating_label:after,.has-float-label .hulkapps_option_value input:focus ~ .floating_label:after,.has-float-label .hulkapps_option_value textarea:focus ~ .floating_label:after {content: '';display: block; position: absolute; background: #F7F7F7;height: 2px;top: 50%;left: -0.2em;right: -0.2em;z-index: -1;}.recommended_detail{    position: fixed;z-index: 9999;padding-top: 100px;left: 0;top: 0;width: 100%;height: 100%;background-color: rgba(0,0,0,0.4);overflow: auto;}.recomodation-title { display: flex;padding:20px;}.recomodation_option_desc{ background-color: #fefefe;margin: auto;border: 1px solid #888;max-width: 600px;width: 100%;padding: 20px}.recommended_close_link{ color: #aaaaaa;font-size: 28px;line-height: 18px;float: left;font-weight: lighter;}.recomodation_option_detail{ padding: 10px;padding: 10px;background-color: #f7f7f7;border: 1px solid #d1d1d1;padding: 20px;} #recommended_detail .hulkapps-tooltip-inner,#recommended_detail .hulkapps_option_name .hulkapps-tooltip{display:none;}#recommended_detail input[type='checkbox'],#recommended_detail input[type='radio'] {display: none;}#recommended_detail label,#recommended_detail ul {pointer-events: none;}.font_preview{padding-top: 20px;}.font_preview textarea{ font-size: 40px;}" + w + $ + b + x + g + W + Z,
                            _ = "<script>(function($) {$('.hulkapps_swatch_option, .hulkapps_mswatch_option').mouseover(function() {var x = $(this).find('.hulkapps-tooltip ').position();var right = $(window).width() - x.left - $(this).find('.hulkapps-tooltip ').width();if(x.left < 205){$(this).find('.hulkapps-tooltip ').addClass('tooltip-left-pos');}if(right < 160){$(this).find('.hulkapps-tooltip ').addClass('tooltip-right-pos');}});$(window).width()<=768&&$('.hulkapps-tooltip').each(function(){var t=$(this).position(),i=$(window).width()-t.left-$(this).width(),o=t.left-i;o<50&&o>-50?$(this).addClass('tooltip-center-pos'):t.left<i?$(this).addClass('tooltip-left-pos'):i<t.left&&$(this).addClass('tooltip-right-pos')});" + e.advanced_users.custom_js + "}(hulkapps_jQuery))</script>",
                            tn = void 0 != e.recomodation_setting && void 0 != e.recomodation_setting.recomodation_text ? e.recomodation_setting.recomodation_text : "",
                            tl = void 0 != e.recomodation_setting && void 0 != e.recomodation_setting.recomodation_background_color ? e.recomodation_setting.recomodation_background_color : "",
                            tr = void 0 != e.recomodation_setting && void 0 != e.recomodation_setting.recomodation_font_size ? e.recomodation_setting.recomodation_font_size : "",
                            ts = "<div id='hulkapps_options_" + e.pid + "' class='hulkapps_product_options'>";
                        ts = ts + "" + a + "<style>" + to + "</style>" + _, window.hulk_inventory_text = void 0 != e.display_settings && void 0 != e.display_settings.inventory_text ? e.display_settings.inventory_text : "In stock", window.hulk_out_of_stock_text = void 0 != e.display_settings && void 0 != e.display_settings.out_of_stock_text ? e.display_settings.out_of_stock_text : "Out of stock", ts = (ts = ts + "<div class='hulkapps_option_title'>" + s + "</div>") + "<div id='hulkapps_option_list_" + e.pid + "' >", "" !== M || 1 == parseInt(M) ? ts += "<input type='hidden' id='hulk_amount_dis' value='1'>" : ts += "<input type='hidden' id='hulk_amount_dis' value='0'>", e.relationship;
                        var tp = e.recomodation_options,
                            td = "";
                        window.opt_with_otc = {}, window.is_hulk_required_options = !1;
                        var t8 = [],
                            tu = "";
                        if (0 != e.relationship_option.length) {
                            e.recomodation_options.length > 0 && (ts += "<div class='recommended_btn'><a class='recommended-link'><svg width='" + tr + "' height='" + tr + "' viewBox='0 0 9 8' fill='none' xmlns='http://www.w3.org/2000/svg'><path d='M4.06442 0.772788C4.25568 0.433466 4.74432 0.433465 4.93558 0.772787L5.81595 2.33474C5.8873 2.46132 6.0102 2.55061 6.15264 2.57935L7.91019 2.93397C8.29201 3.01101 8.443 3.47573 8.17939 3.76248L6.96594 5.08244C6.8676 5.18942 6.82066 5.33389 6.83734 5.47824L7.04319 7.25935C7.08791 7.64629 6.69259 7.9335 6.33841 7.7714L4.70808 7.02523C4.57595 6.96476 4.42405 6.96476 4.29192 7.02523L2.66159 7.7714C2.30741 7.9335 1.91209 7.64629 1.95681 7.25935L2.16266 5.47824C2.17934 5.33389 2.1324 5.18942 2.03406 5.08244L0.82061 3.76249C0.556997 3.47573 0.707994 3.01101 1.08981 2.93397L2.84736 2.57935C2.9898 2.55061 3.1127 2.46132 3.18405 2.33474L4.06442 0.772788Z' fill='" + tl + "'/></svg>" + tn + "</a></div>");
                            var tc = "<span class='hulkapps-required'> * </span>";
                            if (ts += "<div class='hulkapps_option_set'>", window.is_hulk_option_block) {
                                var th = null,
                                    tf = 0;
                                ["input[name='add']", "button[name='add']", "#add-to-cart", "#AddToCartText", "#AddToCart", 'form[action$="/cart/add"] input[type="submit"]'].forEach(function(t) {
                                    var e = document.querySelectorAll(t);
                                    tf += e.length, null === th && e.length > 0 && (th = e[0])
                                }), th && (window.product_form_id = th.closest("form").getAttribute("id"))
                            }
                            var tv = window.product_form_id ? 'form="' + window.product_form_id + '"' : "";
                            t.each(e.relationship_option, function(i, a) {
                                var n = parseInt(a[0]);
                                let l = [];
                                for (let [s, p] of Object.entries(o)) p.includes(n) && l.push(s);
                                var u = 3 == a.length ? a[1] : "required" == a[1] ? a[1] : "";
                                if ("true" == (3 == a.length ? a[2] : "true" == a[1] ? a[1] : "") && t8.push(parseInt(a[0])), e.option_id_array.indexOf(n) >= 0) {
                                    var v = t.trim(e.option_associative_array[n].option_name),
                                        k = t.trim(e.option_associative_array[n].is_one_time_charge),
                                        g = t.trim(e.option_associative_array[n].option_unique_name),
                                        $ = t.trim(e.image_color_position_class),
                                        b = t.trim(e.image_color_shape_class),
                                        y = t.trim(e.option_associative_array[n].is_multi_qty_popup),
                                        x = e.option_associative_array[n].is_font_preview,
                                        _ = t.trim(e.option_associative_array[n].font_preview_lable),
                                        w = e.option_associative_array[n].is_view_inventory;
                                    !0 == w && (window.hulk_multi_qty_selector = !0);
                                    var L = t.trim(e.option_associative_array[n].tooltip),
                                        F = t.trim(e.option_associative_array[n].helptext),
                                        N = t.trim(e.option_associative_array[n].id_name),
                                        M = "" != N ? 'id="' + N + '"' : "",
                                        J = t.trim(e.option_associative_array[n].class_name),
                                        X = t.trim(e.option_associative_array[n].placeholder),
                                        Y = t.trim(e.option_associative_array[n].tooltip_hyperlink),
                                        R = t.trim(e.option_associative_array[n].helptext_hyperlink);
                                    if (L.length > 0) {
                                        var Q = "<div class='hulkapps-tooltip'><span aria-describedby='tooltip_" + n + "' aria-label='" + L + "' tabindex='0' ><img src='" + window.hulkapps.po_url + "/tooltip.svg' style='width:15px;'></span><div class='hulkapps-tooltip-inner' id='tooltip_" + n + "' role='tooltip'>";
                                        if (Y.length > 0) var Q = Q + '<a href="' + Y + '" target="_blank"> ' + L + "</a></div></div>";
                                        else var Q = Q + L + "</div></div>"
                                    } else var Q = "";
                                    if (F.length > 0) {
                                        if (R.length > 0) var K = '<span aria-label="' + F + '" tabindex="0" class="hulkapps_helptext"><a href="' + R + '" target="_blank"> ' + F + "</a></span>";
                                        else var K = "<span  aria-label='" + F + "' tabindex='0'  class='hulkapps_helptext'>" + F + "</span>"
                                    } else var K = "";
                                    var H = e.option_associative_array[n].extra_field,
                                        V = e.option_associative_array[n].option_type,
                                        W = e.option_associative_array[n].restrict_past_date,
                                        Z = e.option_associative_array[n].is_quantity_selector,
                                        G = e.option_associative_array[n].is_thumbnail_change,
                                        te = e.option_associative_array[n].google_fonts,
                                        ti = e.option_associative_array[n].google_font_with_price,
                                        ta = e.option_associative_array[n].default_selection_google_font,
                                        to = e.option_associative_array[n].default_selection_google_price,
                                        tn = n,
                                        tl = t.parseJSON(e.option_associative_array[n].values_json),
                                        tr = e.hide_show_array[tn] ? e.hide_show_array[tn] : "";
                                    let ts = "",
                                        th = "";
                                    var tf = {};
                                    let tm = "",
                                        tk = "";
                                    l.forEach(i => {
                                        t.each(e.condition, function(e, a) {
                                            let o = a.id;
                                            var n = hulkapps_jQuery.parseJSON(a.conditions);
                                            o == i && (t.each(n.actions, function(t, e) {
                                                1 == parseInt(e.action_type) && tr.includes("condition_show") ? th = "show" : tr.includes("condition_hide") && (th = "hide"), th && checkPlan("enhanced_conditional_logic", "boolean") && e.action_option_value && (tf["conditional_logic_" + i + "_" + th] ? tf["conditional_logic_" + i + "_" + th].push(e.action_option_value.toString().trim()) : tf["conditional_logic_" + i + "_" + th] = [e.action_option_value.toString().trim()])
                                            }), t.each(n.actions, function(t, e) {
                                                return 1 == parseInt(e.action_type) && tr.includes("condition_show") ? (ts += " conditional_logic_" + i + "_" + (th = "show"), !1) : tr.includes("condition_hide") ? (ts += " conditional_logic_" + i + "_" + (th = "hide"), !1) : void 0
                                            }))
                                        })
                                    }), Object.keys(tf).length > 0 && (tm = ts, tk = tr, ts = "", tr = "");
                                    var tg = "",
                                        t$ = "",
                                        tb = "required" == u ? "required" : "",
                                        ty = "required" == u;
                                    "required" == u && (window.is_hulk_required_options = !0);
                                    var tx = 0 == parseInt(c) ? "full_width" : "",
                                        t_ = "required" == u ? tc : "",
                                        tw = "1" == e.options_container_style.enable_tooltip ? Q : "",
                                        t9 = "1" == d && K.length > 0 ? "<div class='hulkapps_helptext_div'>" + K + "</div>" : "";
                                    let tq = "_hin_" + g + "_hin_" + v;
                                    window.opt_with_otc[tq] = k, "multi_qty_selector" == V && (window.opt_with_otc[tq] = !0);
                                    var tC = t8.includes(n),
                                        t0 = "";
                                    if (checkPlan("image_change_based_on_multiple_option_value", "boolean") && !0 == tC && (t0 = "image_change_with_multiple"), "dropdown" == V) {
                                        var tS = "";
                                        tz = "<div class='hulkapps_option dd_render " + t0 + " " + B + " " + ts + " " + tb + " " + tx + " option_type_id_" + tn + " " + tr + " " + J + "' " + M + " data-parent-id= " + tn + ">", tz += "<div role='textbox' aria-label='" + v + "' tabindex='0' aria-required='" + ty + "' class='hulkapps_option_name'>" + v + " " + t_ + " " + tw + " " + t9 + "</div>", tz += "<div class='hulkapps_option_value'>", tp.includes(n) && (tS += tz + (recommended_select_html = "<select multiple='true' class='hulkapps_option_child hulkapps_option_" + tn + "_visible hulkapps_full_width hulkapps_dd hulk_po_dropdown' data-parent='hulkapps_product_options' data-pid='" + e.pid + "' data-option-key='dd_" + tn + "' id='" + tn + "' >")), tz += "<select aria-label='" + v + "' class='hulkapps_option_child hulkapps_option_" + tn + "_visible hulkapps_full_width hulkapps_dd hulk_po_dropdown' data-parent='hulkapps_product_options' data-pid='" + e.pid + "' data-option-key='dd_" + tn + "' id='" + tn + "' >", "inlineLabels" == D && (X = v), "" == X ? tz += "<option value='' class=" + ts + ">Choose " + v + "</option>" : tz += "<option value='' class=" + ts + ">" + X + "</option>";
                                        var t3 = !1,
                                            t2 = "none",
                                            t1 = "",
                                            t5 = "",
                                            t4 = "";
                                        t.each(tl, function(t, i) {
                                            var a = i[1],
                                                o = i[9];
                                            "percentage_charge" == o && null != a && "" != a ? (a = parseFloat(product_price) / 100 * a / 100, a = parseFloat(a.toFixed(2))) : "create_mulitplication_charge" == o && null != a && "" != a && (a = parseFloat(product_price) / 100 * a, a = parseFloat(a.toFixed(2)));
                                            var n = null != a && "" != a ? " [ " + e.currency_symbol + a + " ]" : "",
                                                l = null != a && "" != a && 0 == U ? " (+" + e.currency_symbol + a + ")" : "",
                                                s = null != a && "" != a ? a : "0.00",
                                                p = i[4];
                                            !0 == p && (t5 = i[0].toString().trim() + n, t2 = "block");
                                            var d = !0 == p ? "selected" : "",
                                                u = "" != s ? "price-change" : "",
                                                c = "",
                                                f = "";
                                            let m = "" != i[5] && null != i[5] ? i[5] : "",
                                                k = parseInt(i[6]);
                                            var $ = "";
                                            let b = "" != i[7] && null != i[7] ? i[7] : "",
                                                y = "" != i[8] && null != i[8] ? i[8] : "";
                                            var x = "" != i[10] && null != i[10] ? i[10] : "",
                                                _ = "" != i[11] && null != i[11] && i[11],
                                                q = "",
                                                C = "",
                                                S = "disabled";
                                            if (checkPlan("inventory_and_sku_management", "boolean") && ("true" == m.toString() && "true" != b.toString() && k <= 0 && ("true" == y.toString() ? (c = "disabled", d = "") : (f = "is_hulk_hide", c = "disabled", d = "")), "true" == m.toString() && (t3 = !0), "true" == m.toString() && "true" != b.toString() && ($ = k, !0 == p && "" == c && (t1 = i[0].toString().trim() + n + "_hin_" + $), !0 == w && k > -1 && (C = `_hin_${g}_hin_${v}${i[0].toString().trim()}`, q = 0 == k ? " / " + window.hulk_out_of_stock_text : " / " + k + " " + window.hulk_inventory_text)), (!0 == p && k > 0 && "true" != b.toString() || !0 == p && k <= 0 && "true" == b.toString()) && (S = ""), "" != x && (t4 = t4 + "<input type='hidden' " + tv + "  name='properties[_SKU_" + v + "(" + i[0].toString().trim() + ")]' value='" + x + "' class='hulk_unique_sku' data-sku-identifier='" + i[0].toString().trim() + "' " + S + ">")), tg = "", t$ = "", Object.keys(tf).length > 0)
                                                for (let j in tf) tf.hasOwnProperty(j) && Array.isArray(tf[j]) && tf[j].includes(i[0].toString().trim()) && (tg += ` ${j} `, t$ = tk);
                                            dropdown_html = "<option  class='" + u + " " + tg + " " + t$ + " " + f + "' " + d + " data-hinventory='" + $ + "' " + c + " data-uid='" + C + "' data-display-val='" + i[0].toString().trim() + l + "' data-price='" + s + "' data-variant-id= '" + i[12] + "'  data-conditional-value='" + i[0].toString().trim() + "' value='" + i[0].toString().trim() + n + "'>" + i[0].toString().trim() + l + q + "</option>", !0 == _ && (tS += dropdown_html), tz += dropdown_html
                                        });
                                        var t7 = "";
                                        t3 && (t7 = "<input type='hidden' " + tv + "  name='properties[_hin_" + g + "_hin_" + v + "]' value='" + t1 + "' class='hulk_unique_prop' data-unique_prop_name='_hin_" + g + "_hin_" + v + "'/>"), tz += "</select>" + t4 + t7, checkPlan("quantity_selector", "boolean") && Z && (tz += "<input style='display: " + t2 + "' type='number' min='1' value='1' class='hulk_options_quantity hulk_po_dropdown_quantity' data-parent='hulkapps_product_options' data-pid='" + e.pid + "' id='quantity_" + tn + "'/>"), tz += "<input type='hidden' " + tv + "  name='properties[" + v + "]' value='" + t5 + "' class='hulk_dropdown_hidden_prop'/>", "floatingLabels" == D && (tz += "<label class='floating_label'>" + v + "</label>"), tp.includes(n) && (tS += "</select></div></div>"), tz += "</div></div>", checkPlan("image_change_based_on_option_value", "boolean") && !0 == G && "" != tt && (tz += "<script>(function($) {$(document).on('change','.hulkapps_product_options #hulkapps_option_list_" + e.pid + " #" + tn + "', function()  { var option_val  = $(this).find(':selected').data('conditional-value');$('" + tt + "').each(function(){data_title = $(this).attr('alt');if(option_val === data_title){$(this).click();}});});;}(hulkapps_jQuery))</script>"), tu += tS, td += tz
                                    } else if ("dropdown_multiple" == V) {
                                        var tS = "",
                                            t6 = void 0 != H && "" != H && "" != H.minimum_selection && void 0 != H.minimum_selection ? H.minimum_selection.toString() : "0",
                                            tj = void 0 != H && "" != H && "" != H.maximum_selection && void 0 != H.maximum_selection ? H.maximum_selection.toString() : "0",
                                            tA = "0" != t6 && "0" != tj && checkPlan("validation_for_min_max_option_selection", "boolean") ? '<span class="selection-text">[Choose from ' + t6 + " to " + tj + " values]</span>" : "0" != t6 && checkPlan("validation_for_min_max_option_selection", "boolean") ? '<span class="selection-text">[Choose at least ' + t6 + " values]</span>" : "0" != tj && checkPlan("validation_for_min_max_option_selection", "boolean") ? '<span class="selection-text">[Choose upto ' + tj + " values]</span>" : "",
                                            tz = "<div class='hulkapps_option dd_multi_render " + B + " " + ts + " " + tb + " " + tx + "  option_type_id_" + tn + " " + tr + " " + J + "' " + M + " data-parent-id='" + tn + "'>";
                                        tz += "<div aria-label='" + v + "' tabindex='0' aria-required='" + ty + " ' class='hulkapps_option_name'>" + v + " " + t_ + " " + tw + " " + tA + t9 + "</div>", tz += "<div class='hulkapps_option_value'>", tz += "<select multiple class='hulkapps_option_child hulkapps_option_" + tn + "_visible hulkapps_full_width hulkapps_dd hulk_po_dropdown_multiple' data-parent='hulkapps_product_options' data-pid='" + e.pid + "' data-option-key='dd_" + tn + "' id='" + tn + "' name='hulkapps_multiple_dropdown' style='background:none;' data-min='" + t6 + "' data-max='" + tj + "'>", tp.includes(n) && (tS += tz);
                                        var t5 = [],
                                            t1 = [],
                                            tO = 0;
                                        "inlineLabels" == D && (X = v), "" != X && (tz += "<option value='' class=" + ts + ">" + X + "</option>");
                                        var t4 = "";
                                        t.each(tl, function(t, i) {
                                            var a = "",
                                                o = "";
                                            if (tg = "", t$ = "", Object.keys(tf).length > 0)
                                                for (let n in tf) tf.hasOwnProperty(n) && Array.isArray(tf[n]) && tf[n].includes(i[0].toString().trim()) && (tg += ` ${n} `, t$ = tk);
                                            var l = i[1],
                                                s = i[9];
                                            "percentage_charge" == s && null != l && "" != l ? (l = parseFloat(product_price) / 100 * l / 100, l = parseFloat(l.toFixed(2))) : "create_mulitplication_charge" == s && null != l && "" != l && (l = parseFloat(product_price) / 100 * l, l = parseFloat(l.toFixed(2)));
                                            var p = null != l && "" != l ? " [ " + e.currency_symbol + l + " ]" : "",
                                                d = null != l && "" != l && 0 == U ? " (+" + e.currency_symbol + l + ")" : "",
                                                u = null != l && "" != l ? l : "0.00",
                                                c = i[4];
                                            !0 == c && (tO += 1, t5.push(i[0].toString().trim() + p));
                                            var f = !0 == c ? "selected" : "",
                                                m = "" != u ? "price-change" : "",
                                                k = "",
                                                $ = "";
                                            let b = "" != i[5] && null != i[5] ? i[5] : "",
                                                y = parseInt(i[6]);
                                            var x = "";
                                            let _ = "" != i[7] && null != i[7] ? i[7] : "",
                                                q = "" != i[8] && null != i[8] ? i[8] : "";
                                            var C = "" != i[10] && null != i[10] ? i[10] : "",
                                                S = "" != i[11] && null != i[11] && i[11],
                                                j = "disabled";
                                            checkPlan("inventory_and_sku_management", "boolean") && ("true" == b.toString() && "true" != _.toString() && y <= 0 && ("true" == q.toString() ? (k = "disabled", f = "", m = "", !0 == c && t5.pop(i[0].toString().trim() + p)) : ($ = "is_hulk_hide", k = "disabled", f = "", m = "", !0 == c && t5.pop(i[0].toString().trim() + p))), "true" == b.toString() && (t3 = !0), "true" == b.toString() && "true" != _.toString() && (x = y, !0 == c && "" == $ && "" == k && t1.push(i[0].toString().trim() + p + "_hin_" + x), !0 == w && y > -1 && (o = `_hin_${g}_hin_${v}${i[0].toString().trim()}`, a = 0 == y ? " / " + window.hulk_out_of_stock_text : " / " + y + " " + window.hulk_inventory_text)), (!0 == c && y > 0 && "true" != _.toString() || !0 == c && y <= 0 && "true" == _.toString()) && (j = ""), "" != C && (t4 = t4 + "<input type='hidden' " + tv + "  name='properties[_SKU_" + v + "(" + i[0].toString().trim() + ")]' value='" + C + "' class='hulk_unique_sku' data-sku-identifier='" + i[0].toString().trim() + "' " + j + ">")), html_drop_multi = "<option class='" + tg + " " + t$ + " " + m + " " + $ + "' " + f + " data-hinventory='" + x + "' " + k + "  data-uid='" + o + "' data-display-val='" + i[0].toString().trim() + d + "'  data-price='" + u + "' data-variant-id= '" + i[12] + "'  data-conditional-value='" + i[0].toString().trim() + "' value='" + i[0].toString().trim() + p + "'>" + i[0].toString().trim() + d + a + "</option>", !0 == S && (tS += html_drop_multi), tz += html_drop_multi
                                        }), tO > 0 && ("0" != t6 && "0" != tj && checkPlan("validation_for_min_max_option_selection", "boolean") ? (parseInt(tO) < parseInt(t6) || parseInt(tO) > parseInt(tj)) && (tz += '</select><span class="validation_error error_span">Choose from ' + t6 + " to " + tj + " values</span>") : "0" != t6 && "0" == tj && checkPlan("validation_for_min_max_option_selection", "boolean") ? parseInt(tO) < parseInt(t6) && (tz += '</select><span class="validation_error error_span">Choose at least ' + t6 + " values</span>") : "0" == t6 && "0" != tj && checkPlan("validation_for_min_max_option_selection", "boolean") && parseInt(tO) > parseInt(tj) && (tz += '</select><span class="validation_error error_span">Choose upto ' + tj + " values</span>")), "floatingLabels" == D && (tz += "</select><label class='floating_label'>" + v + "</label>");
                                        var t7 = "";
                                        t3 && (t7 = "<input type='hidden' " + tv + "  name='properties[_hin_" + g + "_hin_" + v + "]' value='" + t1 + "' class='hulk_unique_prop' data-unique_prop_name='_hin_" + g + "_hin_" + v + "' data-selection-multi='true'/>"), tz += t4 + t7, tz += "<input class='hulkapps_option_child' type='hidden' value='" + t5.join(", ") + "' id='hulkapps_option_" + tn + "_hidden' " + tv + "  name='properties[" + v + "]'></div></div>", tp.includes(n) && (tS += "</select></div></div>"), tu += tS, td += tz
                                    } else if ("swatch" == V) {
                                        var tE = 0,
                                            tS = "",
                                            tz = "<div class='hulkapps_option swatch_render " + t0 + " " + ts + " " + tb + " " + tx + " option_type_id_" + tn + " " + tr + " " + J + "' " + M + " data-parent-id='" + tn + "' >";
                                        tz += "<div aria-label='" + v + "' tabindex='0' aria-required='" + ty + " ' class='hulkapps_option_name'>" + v + " " + t_ + " " + tw + " " + t9 + "</div>", tz += "<div class='hulkapps_option_value'>", tp.includes(n) && (tS += tz);
                                        var t3 = !1,
                                            t1 = "",
                                            t5 = "",
                                            t2 = "none",
                                            tL = !1;
                                        t.each(tl, function(t, i) {
                                            if (tg = "", t$ = "", Object.keys(tf).length > 0)
                                                for (let a in tf) tf.hasOwnProperty(a) && Array.isArray(tf[a]) && tf[a].includes(i[0].toString().trim()) && (t$ = tk, tg += ` ${a} `);
                                            var o = i[1],
                                                n = i[9];
                                            "percentage_charge" == n && null != o && "" != o ? (o = parseFloat(product_price) / 100 * o / 100, o = parseFloat(o.toFixed(2))) : "create_mulitplication_charge" == n && null != o && "" != o && (o = parseFloat(product_price) / 100 * o, o = parseFloat(o.toFixed(2)));
                                            var l = "" != i[0] ? i[0] : "",
                                                s = "" != i[2] ? i[2] : "",
                                                p = "" != i[3] ? i[3] : "",
                                                d = null != o && "" != o ? " [ " + e.currency_symbol + o + " ]" : "",
                                                u = null != o && "" != o && 0 == U ? " (+" + e.currency_symbol + o + ")" : "",
                                                c = null != o && "" != o ? o : "0.00",
                                                f = "" != c ? "price-change" : "",
                                                m = i[4];
                                            !0 == m && (t5 = i[0].toString().trim() + d, t2 = "block");
                                            var k = !0 == m ? "swatch_selected" : "",
                                                $ = !0 == m ? "checked" : "",
                                                b = "",
                                                y = "",
                                                x = "";
                                            let _ = "" != i[5] && null != i[5] ? i[5] : "",
                                                O = parseInt(i[6]);
                                            var L = "";
                                            let F = "" != i[7] && null != i[7] ? i[7] : "",
                                                T = "" != i[8] && null != i[8] ? i[8] : "";
                                            var I = "" != i[10] && null != i[10] ? i[10] : "",
                                                P = "",
                                                D = "disabled",
                                                B = "" != i[11] && null != i[11] && i[11],
                                                N = "",
                                                M = "",
                                                J = "<p>" + i[0] + " <br> " + u + "</p>";
                                            if (checkPlan("inventory_and_sku_management", "boolean")) {
                                                "true" == _.toString() && "true" != F.toString() && O <= 0 && ("true" == T.toString() ? (y = "is_hulk_disabled", b = "disabled", k = " ", f = " ") : (x = "is_hulk_hide", b = "disabled", k = "", f = "")), "true" == _.toString() && (t3 = !0), "true" == _.toString() && "true" != F.toString() && (L = O, !0 == m && "" == x && "" == b && (t1 = i[0].toString().trim() + d + "_hin_" + L), !0 == w && O > -1 && (M = `_hin_${g}_hin_${v}${i[0].toString().trim()}`, N = 0 == O ? " / " + window.hulk_out_of_stock_text : null != o && "" != o ? " / <p class='hulk_stock' data-uid='" + M + "' data-hinventory='" + L + "'>" + O + " " + window.hulk_inventory_text + "</p>" : "<p class='hulk_stock' data-uid='" + M + "' data-hinventory='" + L + "'>" + O + " " + window.hulk_inventory_text + "</p>"));
                                                var J = "<p>" + i[0] + " <br> " + u + N + "</p>";
                                                (!0 == m && O > 0 && "true" != F.toString() || !0 == m && O <= 0 && "true" == F.toString()) && (D = ""), "" != I && (P = "<input type='hidden' " + tv + "  name='properties[_SKU_" + v + "(" + i[0].toString().trim() + ")]' value='" + I + "' class='hulk_unique_sku' " + D + ">")
                                            }
                                            var X = "";
                                            if ("image" == s) Q = "background-image:url(" + p + "); background-size:cover;background-position: center center;" + z, K = "data-image='" + p + "'", X = p;
                                            else {
                                                try {
                                                    var Y = p.split(",")
                                                } catch (R) {
                                                    Y = null
                                                }
                                                if (null != Y) {
                                                    if (void 0 != Y[1]) var Q = swatch_color_dual_ton = "background: linear-gradient(to bottom, " + Y[0] + " 0%, " + Y[0] + " 50%, " + Y[1] + " 50%, " + Y[1] + " 100%); " + z,
                                                        K = "data-image=''";
                                                    else var Q = "background-color:" + Y[0] + ";" + z,
                                                        K = "data-image=''"
                                                }
                                            }
                                            if (void 0 != J) {
                                                if (void 0 != p) {
                                                    if ("both" == j) var H = "<div style='text-align:center;'><div class='swatch_tooltip_title'> " + J + "</div><div class='swatch_tooltip_data' style='width:100%;padding-top:100%;display: block !important;" + Q + "'></div></div>";
                                                    else H = "image_only" == j ? "<div style='text-align:center;'><div class='swatch_tooltip_data' style='width:100%;padding-top:100%;display: block !important;" + Q + "'></div></div>" : "<div style='text-align:center;'><div class='swatch_tooltip_title'> " + J + "</div></div>"
                                                } else H = "<div style='text-align:center;'><div class='swatch_tooltip_title'> " + J + "</div></div>"
                                            } else H = "<div style='text-align:center;'><div class='swatch_tooltip_title'></div></div>";
                                            if (tooltip_val = "<div class='hulkapps-tooltip-inner swatch-tooltip' style='width:200px;'><div>" + H + "</div></div>", tooltip_display_html = 1 == parseInt(A) ? tooltip_val : "", swatch_with_text = 1 == parseInt(E) ? l : "", "0" == t && "" == x) {
                                                var V = 0;
                                                tL = !0
                                            } else if ("0" != t && !1 == tL) {
                                                var V = 0;
                                                tL = !0
                                            } else var V = -1;
                                            var W = "<label aria-label='" + i[0].toString().trim() + " " + u + "' tabindex='" + V + "' class='hulkapps_swatch_option " + x + " " + tg + " " + t$ + " " + y + "' ><div class='hulkapps-tooltip " + S + "'>" + tooltip_display_html + "<div class='  '><div id='" + tn + "_" + tE + "' data-single_valid-class='swatch_render' data-val-selected-class='swatch_selected' data-radio-class='swatch_radio' data-hidden-class='hulk_swatch_hidden_prop' data-oid='" + tn + "' data-option-key='rb_" + tn + "_" + tE + "' class='hulk_po_radio hulkapps_option_child " + k + " hulkapps_option_" + tn + " " + f + " '  data-price='" + c + "' data-variant-id= '" + i[12] + "' data-conditional-value='" + i[0].toString().trim() + "' data-parent='hulkapps_product_options' data-pid='" + e.pid + "' value='" + i[0].toString().trim() + "' style='" + q + C + Q + "' " + S + "><input name='hulk_swatch_" + tn + "' type='radio'  data-hinventory='" + L + "' " + b + " value='" + i[0].toString().trim() + d + "' class=' swatch_radio' " + $ + " style='display:none;' " + K + " ></div></div></div><div style='display: inline-block;vertical-align: middle;margin-left: 10px;'>" + swatch_with_text + "</div>" + P + "</label>";
                                            !0 == B && (tS += W), tz += W, tE += 1
                                        });
                                        var t7 = "";
                                        t3 && (t7 = "<input type='hidden' " + tv + "  name='properties[_hin_" + g + "_hin_" + v + "]' value='" + t1 + "' class='hulk_unique_prop' data-unique_prop_name='_hin_" + g + "_hin_" + v + "' />"), tz += t7, checkPlan("quantity_selector", "boolean") && Z && (tz += "<input style='display: " + t2 + "'type='number' min='1' value='1' data-parent='hulkapps_product_options' data-pid='" + e.pid + "' class='hulk_options_quantity hulk_po_swatch_quantity'  id='quantity_" + tn + "'/>"), tz += "<input type='hidden' " + tv + "  name='properties[" + v + "]' value='" + t5 + "' class='hulk_swatch_hidden_prop'/></div></div>", tp.includes(n) && (tS += "</div></div>"), checkPlan("image_change_based_on_option_value", "boolean") && !0 == G && "" != tt && (tz += "<script>(function($) {$('.hulkapps_product_options').on('click change', '.hulkapps_option_" + tn + "', function() { var option_val  = $(this).data('conditional-value');$('" + tt + "').each(function(){data_title = $(this).attr('alt');if(option_val === data_title){$(this).click();}});});;}(hulkapps_jQuery))</script>"), tu += tS, td += tz
                                    } else if ("color_image_dropdown" == V) {
                                        if (checkPlan("color_image_dropdown", "boolean")) {
                                            var tS = "";
                                            tz = "<div class='hulkapps_option ci_render dd_render " + t0 + " " + ts + " " + tb + " " + tx + " option_type_id_" + tn + " " + tr + " " + J + "' " + M + " data-parent-id= " + tn + ">", tz += "<div aria-label='" + v + "' tabindex='0' aria-required='" + ty + " ' class='hulkapps_option_name' data-option-name='" + v + "'>" + v + " " + t_ + " " + tw + " " + t9 + "</div>", tz += "<div class='hulkapps_option_value hulkapps_product_options_ul_parent'>", tz += "<ul data-parent='hulkapps_product_options' data-pid='" + e.pid + "'  data-val-selected-class='dropdown_selected' class='hulkapps_option_child hulkapps_product_options_ul hulkapps_option_" + tn + "_visible hulkapps_full_width hulkapps_dd ' data-option-key='dd_" + tn + "' id='" + tn + "' >", tp.includes(n) && (tS += tz);
                                            var tF = "";
                                            tF = "" == X ? "<li tabindex='0' value='' class='init'>Choose " + v + "</li>" : "<li value='' tabindex='0' class='init'>" + X + "</li>";
                                            var tT = "",
                                                t3 = !1,
                                                t1 = "",
                                                t5 = "",
                                                t2 = "none",
                                                tL = !1;
                                            t.each(tl, function(t, i) {
                                                var a = "image";
                                                "color" == i[2] && (a = "color");
                                                var o = i[3],
                                                    n = i[1],
                                                    l = i[9];
                                                "percentage_charge" == l && null != n && "" != n ? (n = parseFloat(product_price) / 100 * n / 100, n = parseFloat(n.toFixed(2))) : "create_mulitplication_charge" == l && null != n && "" != n && checkPlan("multiplication_charge", !0) && (n = parseFloat(product_price) / 100 * n, n = parseFloat(n.toFixed(2)));
                                                var s = null != n && "" != n ? " [ " + e.currency_symbol + n + " ]" : "",
                                                    p = null != n && "" != n && 0 == U ? " (+" + e.currency_symbol + n + ")" : "",
                                                    d = null != n && "" != n ? n : "0.00",
                                                    u = i[4],
                                                    c = !0 == u ? "selected" : "",
                                                    f = !0 == u ? "dropdown_selected" : "",
                                                    m = "" != d ? "price-change" : "",
                                                    k = "",
                                                    y = "",
                                                    x = "";
                                                let _ = "" != i[5] && null != i[5] ? i[5] : "",
                                                    q = parseInt(i[6]);
                                                var C = "";
                                                let S = "" != i[7] && null != i[7] ? i[7] : "",
                                                    j = "" != i[8] && null != i[8] ? i[8] : "";
                                                var A = "" != i[10] && null != i[10] ? i[10] : "",
                                                    z = "" != i[11] && null != i[11] && i[11],
                                                    O = "",
                                                    E = "disabled",
                                                    L = "",
                                                    F = "";
                                                if (checkPlan("inventory_and_sku_management", "boolean") && ("true" == _.toString() && "true" != S.toString() && q <= 0 && ("true" == j.toString() ? (y = "disabled", k = "is_hulk_disabled", c = "") : (x = "is_hulk_hide", y = "disabled", c = "")), "true" == _.toString() && (t3 = !0), "true" == _.toString() && "true" != S.toString() && (C = q, !0 == u && "" == y && (t1 = i[0].toString().trim() + s + "_hin_" + C), !0 == w && q > 0 ? (F = `_hin_${g}_hin_${v}${i[0].toString().trim()}`, L = 0 == q ? " / " + window.hulk_out_of_stock_text : " / " + q + " " + window.hulk_inventory_text) : (F = `_hin_${g}_hin_${v}${i[0].toString().trim()}`, L = " / " + window.hulk_out_of_stock_text)), (!0 == u && q > 0 && "true" != S.toString() || !0 == u && q <= 0 && "true" == S.toString()) && (E = ""), "" != A && (O = "<input type='hidden' " + tv + "  name='properties[_SKU_" + v + "(" + i[0].toString().trim() + ")]' value='" + A + "' class='hulk_unique_sku' " + E + ">")), tg = "", t$ = "", Object.keys(tf).length > 0)
                                                    for (let T in tf) tf.hasOwnProperty(T) && Array.isArray(tf[T]) && tf[T].includes(i[0].toString().trim()) && (tg += ` ${T} `, t$ = tk);
                                                if ("0" == t && "" == x) {
                                                    var I = 0;
                                                    tL = !0
                                                } else if ("0" != t && !1 == tL) {
                                                    var I = 0;
                                                    tL = !0
                                                } else var I = -1;
                                                !0 == u && (t5 = i[0].toString().trim() + s, t2 = "block", tF = "<li aria-label='" + i[0].toString().trim() + "' tabindex='" + I + "' value='' class='init'><span class='dropdown-text'>" + i[0].toString().trim() + p + "</span>", tF = "image" == a ? tF + "<span class='dropdown_img " + b + "'><img class='' src=" + o + "></span></li>" : tF + "<span class='dropdown_color " + b + "' style='background-color: " + o + "'></span></li>"), li_html = "<li aria-label='" + i[0].toString().trim() + s + "' tabindex='" + I + "'  class='dropdown_swatch " + $ + " " + k + " " + m + " " + tg + " " + t$ + " " + x + " " + f + "' " + c + " data-hinventory='" + C + "' data-uid='" + F + "' data-display-val='" + i[0].toString().trim() + p + "' " + y + " data-price='" + d + "' data-variant-id= '" + i[12] + "' data-conditional-value='" + i[0].toString().trim() + "' data-value='" + i[0].toString().trim() + s + "' value='" + i[0].toString().trim() + s + "'><span class='dropdown-text'>" + i[0].toString().trim() + p + L + "</span>", tT += li_html = "image" == a ? li_html + "<span class='dropdown_img " + b + "'><img class='' src=" + o + "></span>" + O + "</li>" : li_html + "<span class='dropdown_color " + b + "' style='background-color: " + o + "'></span>" + O + "</li>", !0 == z && (tS += li_html)
                                            }), tz = tz + tF + tT;
                                            var t7 = "";
                                            t3 && (t7 = "<input type='hidden' " + tv + "  name='properties[_hin_" + g + "_hin_" + v + "]' value='" + t1 + "' class='hulk_unique_prop' data-unique_prop_name='_hin_" + g + "_hin_" + v + "'/>"), tz += "<input class='hulk_opt_prop' type='hidden' " + tv + "  name='properties[" + v + "]'  value='" + t5 + "'/></ul>", tp.includes(n) && (tS += "</ul></div></div>"), checkPlan("quantity_selector", "boolean") && Z && (tz += "<input style='display: " + t2 + "' type='number' min='1' value='1' class='hulk_options_quantity' id='quantity_" + tn + "'/>"), tz += t7 + "</div></div>", tu += tS, td += tz
                                        }
                                    } else if ("button" == V) {
                                        if (checkPlan("button_option", "boolean")) {
                                            var tI = 0,
                                                tS = "",
                                                tz = "<div class='hulkapps_option button_render " + t0 + " " + ts + " " + tb + " " + tx + " option_type_id_" + tn + " " + tr + " " + J + "' " + M + " data-parent-id='" + tn + "' >";
                                            tz += "<div aria-label='" + v + "' tabindex='0' aria-required='" + ty + " ' class='hulkapps_option_name'>" + v + " " + t_ + " " + tw + " " + t9 + "</div>", tz += "<div class='hulkapps_option_value'>", tp.includes(n) && (tS += tz);
                                            var t3 = !1,
                                                t1 = "",
                                                t5 = "",
                                                t2 = "none",
                                                tL = !1;
                                            t.each(tl, function(t, i) {
                                                if (tg = "", t$ = "", Object.keys(tf).length > 0)
                                                    for (let a in tf) tf.hasOwnProperty(a) && Array.isArray(tf[a]) && tf[a].includes(i[0].toString().trim()) && (tg += ` ${a} `, t$ = tk);
                                                var o = i[1],
                                                    n = i[9];
                                                "percentage_charge" == n && null != o && "" != o ? (o = parseFloat(product_price) / 100 * o / 100, o = parseFloat(o.toFixed(2))) : "create_mulitplication_charge" == n && null != o && "" != o && (o = parseFloat(product_price) / 100 * o, o = parseFloat(o.toFixed(2))), "" != i[0] && i[0];
                                                var l = "" != i[2] ? i[2] : "",
                                                    s = null != o && "" != o ? " [ " + e.currency_symbol + o + " ]" : "",
                                                    p = null != o && "" != o && 0 == U ? " (+" + e.currency_symbol + o + ")" : "",
                                                    d = null != o && "" != o ? o : "0.00",
                                                    u = "" != d ? "price-change" : "",
                                                    c = i[4];
                                                !0 == c && (t5 = i[0].toString().trim() + s, t2 = "block");
                                                var f = !0 == c ? "button_selected" : "",
                                                    m = !0 == c ? "checked" : "",
                                                    k = "",
                                                    $ = "",
                                                    b = "";
                                                let y = "" != i[5] && null != i[5] ? i[5] : "",
                                                    x = parseInt(i[6]);
                                                var _ = "";
                                                let q = "" != i[7] && null != i[7] ? i[7] : "",
                                                    C = "" != i[8] && null != i[8] ? i[8] : "";
                                                var S = "" != i[10] && null != i[10] ? i[10] : "",
                                                    j = "" != i[11] && null != i[11] && i[11],
                                                    z = "",
                                                    O = "disabled",
                                                    E = "",
                                                    L = "";
                                                checkPlan("inventory_and_sku_management", "boolean") && ("true" == y.toString() && "true" != q.toString() && x <= 0 && ("true" == C.toString() ? (k = "is_hulk_disabled", $ = "disabled", u = "", f = "") : (b = "is_hulk_hide", $ = "disabled", u = "", f = "")), "true" == y.toString() && (t3 = !0), "true" == y.toString() && "true" != q.toString() && (_ = x, !0 == c && "" == b && "" == $ && (t1 = i[0].toString().trim() + s + "_hin_" + _), !0 == w && x > -1 && (L = `_hin_${g}_hin_${v}${i[0].toString().trim()}`, E = 0 == x ? " / " + window.hulk_out_of_stock_text : null != o && "" != o ? " / <p class='hulk_stock' data-uid='" + L + "' data-hinventory='" + _ + "'>" + x + " " + window.hulk_inventory_text + "</p>" : "<p class='hulk_stock' data-uid='" + L + "' data-hinventory='" + _ + "'>" + x + " " + window.hulk_inventory_text + "</p>")), (!0 == c && x > 0 && "true" != q.toString() || !0 == c && x <= 0 && "true" == q.toString()) && (O = ""), "" != S && (z = "<input type='hidden' " + tv + "  name='properties[_SKU_" + v + "(" + i[0].toString().trim() + ")]' value='" + S + "' class='hulk_unique_sku'" + O + " />"));
                                                var F = i[0] + " <br> " + p + E;
                                                if (titlee = void 0 != F ? "<div style='text-align:center;'><div class='button_tooltip_title'> " + F + "</div></div>" : "<div style='text-align:center;'><div class='button_tooltip_title'></div></div>", tooltip_val = "<div class='hulkapps-tooltip-inner button-tooltip'>" + F + "</div>", tooltip_display_html = 1 == parseInt(A) ? tooltip_val : "", "0" == t && "" == b) {
                                                    var D = 0;
                                                    tL = !0
                                                } else if ("0" != t && !1 == tL) {
                                                    var D = 0;
                                                    tL = !0
                                                } else var D = -1;
                                                html_btn = "<label aria-label='" + i[0].toString().trim() + " " + p + "'  tabindex='" + D + "' class='hulkapps_buton_option " + b + " " + k + "'><div class='hulkapps-tooltip'>" + tooltip_display_html + "<div class='" + tg + " " + t$ + " '><div id='" + tn + "_" + tI + "' data-option-key='rb_" + tn + "_" + tI + "' class='hulkapps_option_child " + f + " hulkapps_option_" + tn + " " + u + " hulk_po_radio'  data-hidden-class='hulk_button_hidden_prop'  data-single_valid-class='button_render' data-val-selected-class='button_selected' data-radio-class='button_radio' data-oid='" + tn + "' data-pid='" + e.pid + "' data-parent='hulkapps_product_options' data-price='" + d + "'  data-variant-id=' " + i[12] + "' data-conditional-value='" + i[0].toString().trim() + "' value='" + i[0].toString().trim() + "' style='" + T + I + P + "'><input name='hulk_button_" + tn + "' type='radio' " + $ + " data-hinventory='" + _ + "' value='" + i[0].toString().trim() + s + "' class=' button_radio' " + m + " style='display:none;'><span>" + l + "</span></div></div></div>" + z + "</label>", !0 == j && (tS += html_btn), tz += html_btn, tI += 1
                                            });
                                            var t7 = "";
                                            t3 && (t7 = "<input type='hidden' " + tv + "  name='properties[_hin_" + g + "_hin_" + v + "]' value='" + t1 + "' class='hulk_unique_prop' data-unique_prop_name='_hin_" + g + "_hin_" + v + "'/>"), tz += t7, checkPlan("quantity_selector", "boolean") && Z && (tz += "<input style='display: " + t2 + "' type='number' min='1' value='1' class='hulk_options_quantity hulk_po_button_quantity' data-parent='hulkapps_product_options' data-pid='" + e.pid + "' id='quantity_" + tn + "'/>"), tz += "<input type='hidden' " + tv + "  name='properties[" + v + "]' value='" + t5 + "' class='hulk_button_hidden_prop'/></div></div>", tp.includes(n) && (tS += "</div></div>"), checkPlan("image_change_based_on_option_value", "boolean") && !0 == G && "" != tt && (tz += "<script>(function($) {$('.hulkapps_product_options .hulkapps_option_" + tn + "').change(function() { var option_val  = $(this).data('conditional-value');$('" + tt + "').each(function(){data_title = $(this).attr('alt');if(option_val === data_title){$(this).click();}});});;}(hulkapps_jQuery))</script>"), tu += tS, td += tz
                                        }
                                    } else if ("swatch_multiple" == V) {
                                        if (checkPlan("multiple_swatch_select_option", "boolean") || !1 == checkPlan("multiple_swatch_select_option", "boolean") && !0 == oldStore()) {
                                            var tS = "",
                                                t6 = void 0 != H && void 0 != H.minimum_selection && "" != H && "" != H.minimum_selection ? H.minimum_selection.toString() : "0",
                                                tj = void 0 != H && void 0 != H.maximum_selection && "" != H && "" != H.maximum_selection ? H.maximum_selection.toString() : "0",
                                                tE = 0,
                                                tA = "0" != t6 && "0" != tj && checkPlan("validation_for_min_max_option_selection", "boolean") ? '<span aria-label="Choose from ' + t6 + " to " + tj + ' values" tabindex="0" class="selection-text">[Choose from ' + t6 + " to " + tj + " values]</span>" : "0" != t6 && checkPlan("validation_for_min_max_option_selection", "boolean") ? '<span aria-label="Choose at least ' + t6 + ' values" tabindex="0" class="selection-text">[Choose at least ' + t6 + " values]</span>" : "0" != tj && checkPlan("validation_for_min_max_option_selection", "boolean") ? '<span aria-label="Choose upto ' + tj + ' values" tabindex="0" class="selection-text">[Choose upto ' + tj + " values]</span>" : "",
                                                tz = "<div class='hulkapps_option multiswatch_render " + ts + " " + tb + " " + tx + " option_type_id_" + tn + " " + tr + " " + J + "' " + M + " data-parent-id='" + tn + "' >";
                                            tz += "<div aria-label='" + v + "' tabindex='0' aria-required='" + ty + " ' class='hulkapps_option_name'><div>" + v + " " + t_ + " " + tw + " </div> " + tA + " " + t9 + "</div>", tz += "<div class='hulkapps_option_value'>", tp.includes(n) && (tS += tz);
                                            var t5 = [],
                                                tO = 0,
                                                t1 = [],
                                                tL = !1;
                                            t.each(tl, function(t, i) {
                                                if (tg = "", t$ = "", Object.keys(tf).length > 0)
                                                    for (let a in tf) tf.hasOwnProperty(a) && Array.isArray(tf[a]) && tf[a].includes(i[0].toString().trim()) && (tg += ` ${a} `, t$ = tk);
                                                var o = i[1],
                                                    n = i[9];
                                                "percentage_charge" == n && null != o && "" != o ? (o = parseFloat(product_price) / 100 * o / 100, o = parseFloat(o.toFixed(2))) : "create_mulitplication_charge" == n && null != o && "" != o && (o = parseFloat(product_price) / 100 * o, o = parseFloat(o.toFixed(2)));
                                                var l = "" != i[0] ? i[0] : "",
                                                    s = "" != i[2] ? i[2] : "",
                                                    p = "" != i[3] ? i[3] : "",
                                                    d = null != o && "" != o ? " [ " + e.currency_symbol + o + " ]" : "",
                                                    u = null != o && "" != o && 0 == U ? " (+" + e.currency_symbol + o + ")" : "",
                                                    c = null != o && "" != o ? o : "0.00",
                                                    f = "" != c ? "price-change" : "",
                                                    m = i[4];
                                                !0 == m && (tO += 1, t5.push(i[0].toString().trim() + d));
                                                var k = !0 == m ? "swatch_selected" : "",
                                                    $ = !0 == m ? "checked" : "",
                                                    b = "",
                                                    y = "",
                                                    x = "";
                                                let _ = "" != i[5] && null != i[5] ? i[5] : "",
                                                    O = parseInt(i[6]);
                                                var L = "";
                                                let F = "" != i[7] && null != i[7] ? i[7] : "",
                                                    T = "" != i[8] && null != i[8] ? i[8] : "";
                                                var I = "" != i[10] && null != i[10] ? i[10] : "",
                                                    P = "" != i[11] && null != i[11] && i[11],
                                                    D = "",
                                                    B = "disabled",
                                                    N = "",
                                                    M = "";
                                                checkPlan("inventory_and_sku_management", "boolean") && ("true" == _.toString() && "true" != F.toString() && O <= 0 && ("true" == T.toString() ? (y = "disabled", b = "is_hulk_disabled", f = "", k = "", t5.pop(i[0].toString().trim() + d)) : (x = "is_hulk_hide", y = "disabled", f = "", k = "", t5.pop(i[0].toString().trim() + d))), "true" == _.toString() && (t3 = !0), "true" == _.toString() && "true" != F.toString() && (L = O, !0 == m && "" == x && "" == y && t1.push(i[0].toString().trim() + d + "_hin_" + L), !0 == w && O > -1 && (M = `_hin_${g}_hin_${v}${i[0].toString().trim()}`, N = 0 == O ? " / " + window.hulk_out_of_stock_text : null != o && "" != o ? " / <p class='hulk_stock' data-uid='" + M + "' data-hinventory='" + L + "'>" + O + " " + window.hulk_inventory_text + "</p>" : "<p class='hulk_stock' data-uid='" + M + "' data-hinventory='" + L + "'>" + O + " " + window.hulk_inventory_text + "</p>")), (!0 == m && O > 0 && "true" != F.toString() || !0 == m && O <= 0 && "true" == F.toString()) && (B = ""), "" != I && (D = "<input type='hidden' " + tv + "  name='properties[_SKU_" + v + "(" + i[0].toString().trim() + ")]' value='" + I + "' class='hulk_unique_sku' " + B + "/>"));
                                                var J = "<p>" + i[0] + " <br> " + u + N + "</p>",
                                                    X = "";
                                                if ("image" == s) Q = "background-image:url(" + p + ");background-size:cover;background-position: center center;" + z, K = "data-image='" + p + "'", X = p;
                                                else {
                                                    try {
                                                        var Y = p.split(",")
                                                    } catch (R) {
                                                        Y = null
                                                    }
                                                    if (null != Y) {
                                                        if (null != Y[1]) var Q = swatch_color_dual_ton = "background: linear-gradient(to bottom, " + Y[0] + " 0%, " + Y[0] + " 50%, " + Y[1] + " 50%, " + Y[1] + " 100%); " + z,
                                                            K = "data-image=''";
                                                        else var Q = "background-color:" + Y[0] + ";" + z,
                                                            K = "data-image=''"
                                                    }
                                                }
                                                if (void 0 != J) {
                                                    if ("" != p) {
                                                        if ("both" == j) var H = "<div style='text-align:center;'><div class='multiswatch_tooltip_title'> " + J + "</div><div class='multiswatch_tooltip_data' style='width:100%;padding-top:100%;" + Q + "'></div></div>";
                                                        else H = "image_only" == j ? "<div style='text-align:center;'><div class='multiswatch_tooltip_data' style='width:100%;padding-top:100%;" + Q + "'></div></div>" : "<div style='text-align:center;'><div class='multiswatch_tooltip_title'> " + J + "</div></div>"
                                                    } else H = "<div style='text-align:center;'><div class='multiswatch_tooltip_title'> " + J + "</div></div>"
                                                } else H = "<div style='text-align:center;'><div class='swatch_tooltip_title'></div></div>";
                                                if (tooltip_val = "<div class='hulkapps-tooltip-inner multiswatch-tooltip' style='width:200px;'><div>" + H + "</div></div>", tooltip_display_html = 1 == parseInt(A) ? tooltip_val : "", swatch_with_text = 1 == parseInt(E) ? l : "", "0" == t && "" == x) {
                                                    var V = 0;
                                                    tL = !0
                                                } else if ("0" != t && !1 == tL) {
                                                    var V = 0;
                                                    tL = !0
                                                } else var V = -1;
                                                html_swatchmulti = "<label aria-label='" + i[0].toString().trim() + " " + u + "' tabindex='" + V + "' class='hulkapps_mswatch_option " + tg + " " + t$ + " " + x + " " + b + "'><div class='hulkapps-tooltip " + S + "'>" + tooltip_display_html + "<div class=''><div id='" + tn + "_" + tE + "' data-option-key='rb_" + tn + "_" + tE + "' data-oid='" + tn + "' data-min='" + t6 + "' data-single_valid-class='multiswatch_render' data-max='" + tj + "' data-parent='hulkapps_product_options' data-pid='" + e.pid + "' class='hulk_po_checkbox hulkapps_option_child  " + k + " hulkapps_option_" + tn + " " + f + "'  data-price=" + c + " data-variant-id= '" + i[12] + "' data-conditional-value='" + i[0].toString().trim() + "' value='" + i[0].toString().trim() + "' style='" + q + C + Q + "' " + S + "><input type='checkbox'  data-conditional-value='" + i[0].toString().trim() + "' data-price=" + c + " data-variant-id= '" + i[12] + "' data-hinventory='" + L + "' " + y + " id='" + tn + "' value='" + i[0].toString().trim() + d + "' class='hulk_po_swatch_multiple_checkbox swatch_checkbox hulkapps_option_child hulkapps_option_" + tn + "_visible " + f + " ' " + $ + " style='display:none !important;' " + K + " ></div></div></div><div style='display: inline-block;vertical-align: middle;margin-left: 10px;'>" + swatch_with_text + "</div>" + D + "</label>", !0 == P && (tS += html_swatchmulti), tz += html_swatchmulti, tE += 1
                                            }), 1 == O && (tz += "var swatch_image_url = " + t(this).find(".swatch_radio").attr("data-image") + "if (" + swatch_image_url + " != ''){$('.hulkapps_swatch_image_change img').attr('src'," + swatch_image_url + ");$('.hulkapps_swatch_image_change img').attr('srcset'," + swatch_image_url + ");$('.hulkapps_swatch_image_change img').attr('data-srcset'," + swatch_image_url + ");}"), tO > 0 && ("0" != t6 && "0" != tj && checkPlan("validation_for_min_max_option_selection", "boolean") ? (parseInt(tO) < parseInt(t6) || parseInt(tO) > parseInt(tj)) && (tz += '<span class="validation_error error_span">Choose from ' + t6 + " to " + tj + " values</span>") : "0" != t6 && "0" == tj && checkPlan("validation_for_min_max_option_selection", "boolean") ? parseInt(tO) < parseInt(t6) && (tz += '<span class="validation_error error_span">Choose at least ' + t6 + " values</span>") : "0" == t6 && "0" != tj && checkPlan("validation_for_min_max_option_selection", "boolean") && parseInt(tO) > parseInt(tj) && (tz += '<span class="validation_error error_span">Choose upto ' + tj + " values</span>"));
                                            var t7 = "";
                                            t3 && (t7 = "<input type='hidden' " + tv + "  name='properties[_hin_" + g + "_hin_" + v + "]'  value='" + t1 + "' class='hulk_unique_prop' data-unique_prop_name='_hin_" + g + "_hin_" + v + "' data-selection-multi='true'/>"), tz += t7, tp.includes(n) && (tS += "</div></div>"), tz += "<input class='hulkapps_option_child' value='" + t5.join(", ") + "' type='hidden' id='hulkapps_option_" + tn + "_hidden' " + tv + "  name='properties[" + v + "]'></div></div>", tu += tS, td += tz
                                        }
                                    } else if ("checkbox" == V) {
                                        var tS = "",
                                            t6 = void 0 != H && "" != H && void 0 != H.minimum_selection && "" != H.minimum_selection ? H.minimum_selection.toString() : "0",
                                            tj = void 0 != H && "" != H && void 0 != H.maximum_selection && "" != H.maximum_selection ? H.maximum_selection.toString() : "0",
                                            tP = 1 == parseInt(m) ? "single_line" : "",
                                            tA = "0" != t6 && "0" != tj && checkPlan("validation_for_min_max_option_selection", "boolean") ? '<span aria-label="Choose from ' + t6 + " to " + tj + ' values" tabindex="0" class="selection-text">[Choose from ' + t6 + " to " + tj + " values]</span>" : "0" != t6 && checkPlan("validation_for_min_max_option_selection", "boolean", e.plan_id, e.plans_features) ? '<span aria-label="Choose at least ' + t6 + ' values" tabindex="0"  class="selection-text">[Choose at least ' + t6 + " values]</span>" : "0" != tj && checkPlan("validation_for_min_max_option_selection", "boolean") ? '<span aria-label="Choose upto ' + tj + ' values" tabindex="0" class="selection-text">[Choose upto ' + tj + " values]</span>" : "",
                                            tz = "<div class='hulkapps_option cb_render " + ts + " " + tb + " " + tx + " " + tP + " option_type_id_" + tn + " " + tr + " " + J + "' " + M + " data-parent-id='" + tn + "' data-min='" + t6 + "' data-max='" + tj + "'>";
                                        tz += "<div aria-label='" + v + "' tabindex='0' aria-required='" + ty + " ' class='hulkapps_option_name'><div>" + v + " " + t_ + " " + tw + "  </div>" + tA + " " + t9 + "</div>", tz += "<div class='hulkapps_option_value hulkapps_product_page_options'>", tp.includes(n) && (tS += tz);
                                        var t5 = [],
                                            tO = 0,
                                            t1 = [],
                                            tL = !1;
                                        t.each(tl, function(t, i) {
                                            if (tg = "", t$ = "", Object.keys(tf).length > 0)
                                                for (let a in tf) tf.hasOwnProperty(a) && Array.isArray(tf[a]) && tf[a].includes(i[0].toString().trim()) && (tg += ` ${a} `, t$ = tk);
                                            var o = i[1],
                                                n = i[9];
                                            "percentage_charge" == n && null != o && "" != o ? (o = parseFloat(product_price) / 100 * o / 100, o = parseFloat(o.toFixed(2))) : "create_mulitplication_charge" == n && null != o && "" != o && (o = parseFloat(product_price) / 100 * o, o = parseFloat(o.toFixed(2)));
                                            var l = null != o && "" != o ? " [ " + e.currency_symbol + o + " ]" : "",
                                                s = null != o && "" != o && 0 == U ? " (+" + e.currency_symbol + o + ")" : "",
                                                p = null != o && "" != o ? o : "0.00",
                                                d = i[4];
                                            !0 == d && (tO += 1, t5.push(i[0].toString().trim() + l));
                                            var u = !0 == d ? "checked" : "",
                                                c = "" != p ? "price-change" : "",
                                                f = "",
                                                m = "",
                                                k = "";
                                            let $ = "" != i[5] && null != i[5] ? i[5] : "",
                                                b = parseInt(i[6]);
                                            var y = "";
                                            let x = "" != i[7] && null != i[7] ? i[7] : "",
                                                _ = "" != i[8] && null != i[8] ? i[8] : "";
                                            var q = "" != i[10] && null != i[10] ? i[10] : "",
                                                C = "" != i[11] && null != i[11] && i[11],
                                                S = "",
                                                j = "disabled",
                                                A = "",
                                                z = "";
                                            if (checkPlan("inventory_and_sku_management", "boolean") && ("true" == $.toString() && "true" != x.toString() && b <= 0 && ("true" == _.toString() ? (f = "disabled", k = "is_hulk_disabled", u = "", c = "", !0 == d && t5.pop(i[0].toString().trim() + l)) : (m = "is_hulk_hide", u = "", c = "", !0 == d && t5.pop(i[0].toString().trim() + l))), "true" == $.toString() && (t3 = !0), "true" == $.toString() && "true" != x.toString() && (y = b, !0 == d && "" == m && "" == f && t1.push(i[0].toString().trim() + l + "_hin_" + y), !0 == w && b > -1 && (z = `_hin_${g}_hin_${v}${i[0].toString().trim()}`, A = 0 == b ? " / " + window.hulk_out_of_stock_text : " /&nbsp;  <p class='hulk_stock' style='margin: 0;' data-uid='" + z + "' data-hinventory='" + y + "'>" + b + " " + window.hulk_inventory_text + "</p>")), (!0 == d && b > 0 && "true" != x.toString() || !0 == d && b <= 0 && "true" == x.toString()) && (j = ""), "" != q && (S = "<input type='hidden' " + tv + "  name='properties[_SKU_" + v + "(" + i[0].toString().trim() + ")]' value='" + q + "' class='hulk_unique_sku' " + j + "/>")), "0" == t && "" == m) {
                                                var O = 0;
                                                tL = !0
                                            } else if ("0" != t && !1 == tL) {
                                                var O = 0;
                                                tL = !0
                                            } else var O = -1;
                                            html_checkbox = "<label  aria-label='" + i[0].toString().trim() + " " + s + "' tabindex='" + O + "' class='hulkapps_check_option " + k + " " + tg + " " + t$ + " " + m + "'><input type='checkbox' " + u + " data-option-key='cbm_" + tn + "' data-hinventory='" + y + "' " + f + " data-parent='hulkapps_product_options' data-pid='" + e.pid + "' data-single_valid-class='cb_render' data-min='" + t6 + "' data-max='" + tj + "' data-oid='" + tn + "' id='" + tn + "' class='  hulk_po_checkbox hulkapps_option_child hulkapps_option_" + tn + "_visible hulkapps_product_option_" + tn + "_visible " + c + "' data-price='" + p + " ' data-variant-id= '" + i[12] + "' data-conditional-value='" + i[0].toString().trim() + "' value='" + i[0].toString().trim() + l + '\'><div class=\'hulkapps-custom-check\'><svg xmlns="http://www.w3.org/2000/svg" width="9" height="7" viewBox="0 0 9 7" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M2.46989 6.79557L0.219933 4.69527C-0.073311 4.42153 -0.073311 3.97907 0.219933 3.70533C0.513177 3.43159 0.987167 3.43159 1.28041 3.70533L2.95738 5.27075L7.68078 0.244745C7.95078 -0.049296 8.42402 -0.0829008 8.73751 0.168435C9.0525 0.42047 9.08925 0.861532 8.81926 1.15487L3.56936 6.75566C3.43362 6.90408 3.23712 6.99229 3.02863 6.99999C2.80138 7.00069 2.61013 6.92718 2.46989 6.79557Z" fill="white" style="&#10;"/></svg></div>' + i[0].toString().trim() + s + A + S + " </label>", !0 == C && (tS += html_checkbox), tz += html_checkbox
                                        }), tO > 0 && ("0" != t6 && "0" != tj && checkPlan("validation_for_min_max_option_selection", "boolean") ? (parseInt(tO) < parseInt(t6) || parseInt(tO) > parseInt(tj)) && (tz += '</select><span class="validation_error error_span">Choose from ' + t6 + " to " + tj + " values</span>") : "0" != t6 && "0" == tj && checkPlan("validation_for_min_max_option_selection", "boolean") ? parseInt(tO) < parseInt(t6) && (tz += '</select><span class="validation_error error_span">Choose at least ' + t6 + " values</span>") : "0" == t6 && "0" != tj && checkPlan("validation_for_min_max_option_selection", "boolean") && parseInt(tO) > parseInt(tj) && (tz += '</select><span class="validation_error error_span">Choose upto ' + tj + " values</span>"));
                                        var t7 = "";
                                        t3 && (t7 = "<input type='hidden' " + tv + "  name='properties[_hin_" + g + "_hin_" + v + "]' value='" + t1 + "' class='hulk_unique_prop' data-unique_prop_name='_hin_" + g + "_hin_" + v + "' data-selection-multi='true'/>"), tz += t7, tz += "<input class='hulkapps_option_child' value='" + t5.join(", ") + "' type='hidden' id='hulkapps_option_" + tn + "_hidden' " + tv + "  name='properties[" + v + "]'></div></div>", tp.includes(n) && (tS += "</div></div>"), tu += tS, td += tz
                                    } else if ("textbox" == V) {
                                        var tD = "",
                                            tB = void 0 != H && checkPlan("character_limit", "boolean") && "" != H.character_limit && void 0 != H.character_limit ? "[Maximum " + H.character_limit + " character]" : "",
                                            tz = "<div class='hulkapps_option tb_render " + B + " " + ts + " " + tb + " " + tx + " option_type_id_" + tn + " " + tr + " " + J + "' " + M + " data-parent-id='" + tn + "'>";
                                        tz += "<div aria-label='" + v + "' tabindex='0' aria-required='" + ty + " ' class='hulkapps_option_name'><div>" + v + " " + t_ + " " + tw + " </div> " + tB + " " + t9 + "</div>", "inlineLabels" == D && (X = v), "floatingLabels" == D && (X = ""), tz += "<div class='hulkapps_option_value'>", t.each(tl, function(t, i) {
                                            var a = i[1],
                                                o = i[9];
                                            "percentage_charge" == o && null != a && "" != a ? (a = parseFloat(product_price) / 100 * a / 100, a = parseFloat(a.toFixed(2))) : "create_mulitplication_charge" == o && null != a && "" != a ? (a = parseFloat(product_price) / 100 * a, a = parseFloat(a.toFixed(2))) : "character_charge" == o && null != a && "" != a && (a = parseFloat(a)), null != a && "" != a && e.currency_symbol;
                                            var n = null != a && "" != a ? a : "0.00",
                                                l = "",
                                                s = "" != n ? "price-change" : "";
                                            void 0 != H && checkPlan("character_limit", "boolean") && "" != H.character_limit && void 0 != H.character_limit && (l = "maxlength=" + H.character_limit), tz += "<input type='text' data-is-charge='" + o + "' data-single_valid-class='tb_render' data-val-selected-class='textbox_selected'  data-option-key='tb_" + tn + "' id='" + tn + "' placeholder='" + X + "' data-parent='hulkapps_product_options' data-pid='" + e.pid + "' class='hulkapps_option_child hulk_po_other_options hulkapps_full_width hulkapps_option_" + tn + " " + s + "' data-main-price='" + n + "' data-price='" + n + "' data-variant-id= '" + i[12] + "' " + l + "><input type='hidden' " + tv + "  name='properties[" + v + "]' class='tb_property_val other_options_prop_val'>", "floatingLabels" == D && (tz += "<label class='floating_label'>" + v + "</label>"), void 0 != H && checkPlan("character_limit", "boolean") && "" != H.character_limit && void 0 != H.character_limit && (tz += "<input type='hidden' value='" + H.character_limit + "' class='character_count'><div id='char_count_" + tn + "'>" + H.character_limit + " " + e.display_settings.charcter_count_message + "</div>"), void 0 != H && checkPlan("character_limit", "boolean") && "" != H.character_limit && void 0 != H.character_limit && (tD += "<script>(function($) {$(document).on('input', '.hulkapps_product_options .hulkapps_option_" + tn + "', function() { check_character_limit(" + H.character_limit + ",'" + tn + "','" + e.display_settings.charcter_count_message + "','hulkapps_product_options');});}(hulkapps_jQuery))</script>")
                                        }), td += tz = tz + tD + "</div></div>"
                                    } else if ("textarea" == V) {
                                        var tD = "",
                                            tB = void 0 != H && checkPlan("character_limit", "boolean") && "" != H.character_limit && void 0 != H.character_limit ? "[Maximum " + H.character_limit + " character]" : "",
                                            tz = "<div class='hulkapps_option ta_render " + B + " " + ts + " " + tb + " " + tx + " option_type_id_" + tn + " " + tr + " " + J + "' " + M + " data-parent-id='" + tn + "'>";
                                        tz += "<div aria-label='" + v + "' tabindex='0' aria-required='" + ty + " ' class='hulkapps_option_name'><div>" + v + " " + t_ + " " + tw + " </div> " + tB + " " + t9 + "</div>", "inlineLabels" == D && (X = v), "floatingLabels" == D && (X = ""), tz += "<div class='hulkapps_option_value'>", t.each(tl, function(t, i) {
                                            var a = i[1],
                                                o = i[9];
                                            "percentage_charge" == o && null != a && "" != a ? (a = parseFloat(product_price) / 100 * a / 100, a = parseFloat(a.toFixed(2))) : "create_mulitplication_charge" == o && null != a && "" != a ? (a = parseFloat(product_price) / 100 * a, a = parseFloat(a.toFixed(2))) : "character_charge" == o && null != a && "" != a && (a = parseFloat(a)), null != a && "" != a && e.currency_symbol;
                                            var n = null != a && "" != a ? a : "0.00",
                                                l = "",
                                                s = "" != n ? "price-change" : "";
                                            void 0 != H && checkPlan("character_limit", "boolean") && "" != H.character_limit && void 0 != H.character_limit && (l = "maxlength=" + H.character_limit), tz += "<textarea placeholder='" + X + "' data-is-charge='" + o + "' data-main-price='" + n + "' data-single_valid-class='ta_render' data-val-selected-class='textbox_selected' data-option-key='ta_" + tn + "' id='" + tn + "' data-pid='" + e.pid + "' data-parent='hulkapps_product_options' class='hulk_po_other_options hulkapps_option_child hulkapps_full_width hulkapps_option_" + tn + " " + s + "' data-price='" + n + "' data-variant-id= '" + i[12] + "' " + l + "></textarea>", "floatingLabels" == D && (tz += "<label class='floating_label'>" + v + "</label>"), tz += "<input type='hidden' " + tv + "  name='properties[" + v + "]' class='ta_property_val other_options_prop_val'>", void 0 != H && checkPlan("character_limit", "boolean") && "" != H.character_limit && void 0 != H.character_limit && (tz += "<input type='hidden' value='" + H.character_limit + "' class='character_count'><div id='char_count_" + tn + "'>" + H.character_limit + " " + e.display_settings.charcter_count_message + "</div>"), void 0 != H && checkPlan("character_limit", "boolean") && "" != H.character_limit && void 0 != H.character_limit && (tD += "<script>(function($) {$(document).on('input', '.hulkapps_product_options .hulkapps_option_" + tn + "', function() { check_character_limit(" + H.character_limit + ",'" + tn + "','" + e.display_settings.charcter_count_message + "','hulkapps_product_options');});}(hulkapps_jQuery))</script>")
                                        }), td += tz = tz + tD + "</div></div>"
                                    } else if ("radiobutton" == V) {
                                        var tN = 0,
                                            tP = 1 == parseInt(m) ? "single_line" : "",
                                            tS = "";
                                        tz = "<div class='hulkapps_option rb_render " + t0 + "  " + ts + " " + tb + " " + tx + " " + tP + "  option_type_id_" + tn + " " + tr + " " + J + "' " + M + " data-parent-id='" + tn + "' >", tz += "<div aria-label='" + v + "' tabindex='0' aria-required='" + ty + " ' class='hulkapps_option_name'>" + v + " " + t_ + " " + tw + " " + t9 + "</div>", tz += "<div class='hulkapps_option_value'>", tp.includes(n) && (tS += tz);
                                        var t1 = "",
                                            t5 = "",
                                            t2 = "none",
                                            tL = !1;
                                        t.each(tl, function(t, i) {
                                            if (tg = "", t$ = "", Object.keys(tf).length > 0)
                                                for (let a in tf) tf.hasOwnProperty(a) && Array.isArray(tf[a]) && tf[a].includes(i[0].toString().trim()) && (tg += ` ${a} `, t$ = tk);
                                            var o = i[1],
                                                n = i[9];
                                            "percentage_charge" == n && null != o && "" != o ? (o = parseFloat(product_price) / 100 * o / 100, o = parseFloat(o.toFixed(2))) : "create_mulitplication_charge" == n && null != o && "" != o && (o = parseFloat(product_price) / 100 * o, o = parseFloat(o.toFixed(2)));
                                            var l = null != o && "" != o ? " [ " + e.currency_symbol + o + " ]" : "",
                                                s = null != o && "" != o && 0 == U ? " (+" + e.currency_symbol + o + ")" : "",
                                                p = null != o && "" != o ? o : "0.00",
                                                d = i[4];
                                            !0 == d && (t5 = i[0].toString().trim() + l);
                                            var u = !0 == d ? "radio_selected" : "",
                                                c = !0 == d ? "checked" : "",
                                                f = "" != p ? "price-change" : "",
                                                m = "",
                                                k = "",
                                                $ = "";
                                            let b = "" != i[5] && null != i[5] ? i[5] : "",
                                                y = parseInt(i[6]);
                                            var x = "";
                                            let _ = "" != i[7] && null != i[7] ? i[7] : "",
                                                q = "" != i[8] && null != i[8] ? i[8] : "";
                                            var C = "" != i[10] && null != i[10] ? i[10] : "",
                                                S = "" != i[11] && null != i[11] && i[11],
                                                j = "",
                                                A = "disabled",
                                                z = "",
                                                O = "";
                                            if (checkPlan("inventory_and_sku_management", "boolean") && ("true" == b.toString() && "true" != _.toString() && y <= 0 && ("true" == q.toString() ? (m = "disabled", k = "is_hulk_disabled", u = "", c = "", f = "") : ($ = "is_hulk_hide", m = "disabled", u = "", c = "", f = "")), "true" == b.toString() && (t3 = !0), "true" == b.toString() && "true" != _.toString() && (x = y, !0 == d && "" == m && (t2 = "block", t1 = i[0].toString().trim() + l + "_hin_" + x), !0 == w && y > -1 && (O = `_hin_${g}_hin_${v}${i[0].toString().trim()}`, z = 0 == y ? " / " + window.hulk_out_of_stock_text : " / " + y + " " + window.hulk_inventory_text)), (!0 == d && y > 0 && "true" != _.toString() || !0 == d && y <= 0 && "true" == _.toString()) && (A = ""), "" != C && (j = "<input type='hidden' " + tv + "  name='properties[_SKU_" + v + "(" + i[0].toString().trim() + ")]' value='" + C + "' class='hulk_unique_sku' " + A + ">")), "0" == t && "" == $) {
                                                var E = 0;
                                                tL = !0
                                            } else if ("0" != t && !1 == tL) {
                                                var E = 0;
                                                tL = !0
                                            } else var E = -1;
                                            html_radio = "<label aria-label='" + i[0].toString().trim() + " " + s + "' aria-required='true' tabindex='" + E + "' class='hulkapps_radio_option " + tg + "  " + $ + " " + k + " " + t$ + "'><input name='hulk_radio_" + tn + "' data-val-selected-class='radio_selected'  data-oid='" + tn + "' data-pid='" + e.pid + "' data-parent='hulkapps_product_options' id='" + tn + "_" + tN + "' data-option-key='rb_" + tn + "_" + tN + "'  data-hinventory='" + x + "' type='radio' " + c + " " + m + " class='hulkapps_option_child hulk_po_radiobutton hulkapps_option_" + tn + " " + f + " ' data-price='" + p + "' data-variant-id= '" + i[12] + "' data-conditional-value='" + i[0].toString().trim() + "' value='" + i[0].toString().trim() + l + "'><div class='radio_div " + u + "' for='" + tn + "_" + tN + "' data-uid='" + O + "' data-display-val='" + i[0].toString().trim() + s + "' data-hinventory='" + x + "'>" + i[0].toString().trim() + s + z + "</div>" + j + "</label>", !0 == S && (tS += html_radio), tz += html_radio, tN += 1
                                        });
                                        var t7 = "";
                                        t3 && (t7 = "<input type='hidden' " + tv + "  name='properties[_hin_" + g + "_hin_" + v + "]' value='" + t1 + "' class='hulk_unique_prop' data-unique_prop_name='_hin_" + g + "_hin_" + v + "'/>"), tz += t7, checkPlan("quantity_selector", "boolean") && Z && (tz += "<input style='display: " + t2 + "' type='number'  min='1' value='1' class='hulk_options_quantity hulk_po_radiobutton_quanity' data-parent='hulkapps_product_options' data-pid='" + e.pid + "' id='quantity_" + tn + "'/>"), tz += "<input type='hidden' " + tv + "  name='properties[" + v + "]' value='" + t5 + "' class='hulk_radiobutton_hidden_prop'/></div></div>", tp.includes(n) && (tS += "</div></div>"), tu += tS, checkPlan("image_change_based_on_option_value", "boolean") && !0 == G && "" != tt && (tz += "<script>(function($) {$('.hulkapps_product_options .hulkapps_option_" + tn + "').change(function() { var option_val  = $(this).data('conditional-value');$('" + tt + "').each(function(){data_title = $(this).attr('alt');if(option_val === data_title){$(this).click();}});});;}(hulkapps_jQuery))</script>"), td += tz
                                    } else if ("file_upload" == V) tz = "<div class='hulkapps_option fu_render " + ts + " " + tb + " " + tx + " option_type_id_" + tn + " " + tr + " " + J + "' " + M + "  data-parent-id='" + tn + "'>", tz += "<div aria-label='" + v + "' tabindex='0' aria-required='" + ty + " ' class='hulkapps_option_name'>" + v + " " + t_ + " " + tw + " " + t9 + "</div>", tz += "<div class='hulkapps_option_value'><div class='file-upload' tabindex='0' aria-label='Choose File'> <div class='file-select'> <div class='file-select-name noFile' >No file chosen...</div><div class='file-select-button' id='fileName' >Choose File</div><input type='file' multiple data-option-key='fu_" + tn + "' id='" + tn + "' class='hulkapps_option_child hulkapps_full_width hulk_file_upload hulkapps_option_" + tn + "' " + tv + "  name='properties[" + v + "]'> </div></div><script>(function($) {$('.hulkapps_product_options #" + tn + "').change(function (){ conditional_rules(" + e.pid + ",'hulkapps_product_options');validate_single_option('option_type_id_" + tn + "','fu_render','hulkapps_product_options');})}(hulkapps_jQuery))</script></div></div>", td += tz;
                                    else if ("email" == V) {
                                        var tD = "";
                                        tz = "<div class='hulkapps_option et_render " + B + " " + ts + " " + tb + " " + tx + " option_type_id_" + tn + " " + tr + " " + J + "' " + M + " data-parent-id='" + tn + "'>", tz += "<div aria-label='" + v + "' tabindex='0' aria-required='" + ty + " ' class='hulkapps_option_name'>" + v + " " + t_ + " " + tw + " " + t9 + " </div>", "inlineLabels" == D && (X = v), "floatingLabels" == D && (X = ""), tz += "<div class='hulkapps_option_value'>", t.each(tl, function(t, i) {
                                            var a = i[1],
                                                o = i[9];
                                            "percentage_charge" == o && null != a && "" != a ? (a = parseFloat(product_price) / 100 * a / 100, a = parseFloat(a.toFixed(2))) : "create_mulitplication_charge" == o && null != a && "" != a && (a = parseFloat(product_price) / 100 * a, a = parseFloat(a.toFixed(2))), null != a && "" != a && e.currency_symbol, null != a && "" != a && e.currency_symbol;
                                            var n = null != a && "" != a ? a : "0.00",
                                                l = (i[4], "" != n ? "price-change" : "");
                                            tz += "<input type='email' placeholder='" + X + "' data-option-key='et_" + tn + "' data-parent='hulkapps_product_options' data-pid='" + e.pid + "' data-val-selected-class='emailbox_selected' data-single_valid-class='et_render' id='" + tn + "' class='hulk_po_other_options hulkapps_option_child hulkapps_full_width hulkapps_option_" + tn + " " + l + "' data-price='" + n + "' data-variant-id= '" + i[12] + "'><input type='hidden' " + tv + "  name='properties[" + v + "]' class='et_property_val other_options_prop_val'>", "floatingLabels" == D && (tz += "<label class='floating_label'>" + v + "</label>")
                                        }), td += tz = tz + tD + "</div></div>"
                                    } else if ("date_picker" == V) {
                                        if (checkPlan("date_field_option", "boolean") || !1 == checkPlan("date_field_option", "boolean") && !0 == oldStore()) {
                                            var tD = "",
                                                t6 = void 0 != H && "" != H && "" != H.minimum_selection && void 0 != H.minimum_selection ? H.minimum_selection.toString() : "",
                                                tj = void 0 != H && "" != H && "" != H.maximum_selection && void 0 != H.maximum_selection ? H.maximum_selection.toString() : "",
                                                tM = void 0 != t6 ? t6 : "",
                                                tU = void 0 != tj ? tj : "";
                                            if (!0 == W) {
                                                var tJ, tX = new Date,
                                                    tY = tX.getFullYear();
                                                tM = tY + "-" + String(tX.getMonth() + 1).padStart(2, "0") + "-" + String(tX.getDate()).padStart(2, "0")
                                            }
                                            tz = "<div class='hulkapps_option dp_render " + ts + " " + tb + " " + tx + " option_type_id_" + tn + " " + tr + " " + J + "' " + M + " data-parent-id='" + tn + "'>", tz += "<div aria-label='" + v + "' tabindex='0' aria-required='" + ty + " ' class='hulkapps_option_name'>" + v + " " + t_ + " " + tw + "   " + t9 + "</div>", tz += "<div class='hulkapps_option_value'>", t.each(tl, function(t, i) {
                                                var a = i[1],
                                                    o = i[9];
                                                "percentage_charge" == o && null != a && "" != a ? (a = parseFloat(product_price) / 100 * a / 100, a = parseFloat(a.toFixed(2))) : "create_mulitplication_charge" == o && null != a && "" != a && (a = parseFloat(product_price) / 100 * a, a = parseFloat(a.toFixed(2))), null != a && "" != a && e.currency_symbol, null != a && "" != a && e.currency_symbol;
                                                var n = null != a && "" != a ? a : "0.00",
                                                    l = (i[4], "" != n ? "price-change" : "");
                                                tz += "<input type='date' min='" + tM + "' max='" + tU + "' tabindex='0' data-parent='hulkapps_product_options' data-pid='" + e.pid + "' data-single_valid-class='dp_render'  data-val-selected-class='datepicker_selected'  data-option-key='dp_" + tn + "' id='" + tn + "' name='input' placeholder='mm/dd/yyyy' class='hulk_po_other_options hulkapps_option_child hulkapps_full_width hulkapps_option_" + tn + " " + l + "' data-price='" + n + "' data-variant-id= '" + i[12] + "'><input type='hidden' " + tv + "  name='properties[" + v + "]' class='dp_property_val other_options_prop_val'>"
                                            }), tz += "</div></div>", td += tz
                                        }
                                    } else if ("time_picker" == V) {
                                        if (checkPlan("time_picker", "boolean")) {
                                            var tD = "",
                                                t6 = void 0 != H && "" != H && "" != H.minimum_selection && void 0 != H.minimum_selection ? H.minimum_selection.toString() : "",
                                                tj = void 0 != H && "" != H && "" != H.maximum_selection && void 0 != H.maximum_selection ? H.maximum_selection.toString() : "",
                                                tA = t6 && tj && checkPlan("validation_for_min_max_option_selection", "boolean") ? '<span class="selection-text">[Select time between ' + t6 + " to " + tj + " ]</span>" : t6 && checkPlan("validation_for_min_max_option_selection", "boolean") ? '<span class="selection-text">[Select a time from ' + t6 + "]</span>" : tj && checkPlan("validation_for_min_max_option_selection", "boolean") ? '<span class="selection-text">[Select a time earlier than ' + tj + "]</span>" : "",
                                                tR = void 0 != t6 ? t6 : "",
                                                tQ = void 0 != tj ? tj : "";
                                            tz = "<div class='hulkapps_option dt_render " + ts + " " + tb + " " + tx + " option_type_id_" + tn + " " + tr + " " + J + "' " + M + " data-parent-id='" + tn + "'>", tz += "<div aria-label='" + v + "' tabindex='0' aria-required='" + ty + " ' class='hulkapps_option_name'>" + v + " " + t_ + " " + tw + " " + tA + " " + t9 + "</div>", tz += "<div class='hulkapps_option_value'>", t.each(tl, function(t, i) {
                                                var a = i[1],
                                                    o = i[9];
                                                "percentage_charge" == o && null != a && "" != a ? (a = parseFloat(product_price) / 100 * a / 100, a = parseFloat(a.toFixed(2))) : "create_mulitplication_charge" == o && null != a && "" != a && (a = parseFloat(product_price) / 100 * a, a = parseFloat(a.toFixed(2))), null != a && "" != a && e.currency_symbol, null != a && "" != a && e.currency_symbol;
                                                var n = null != a && "" != a ? a : "0.00",
                                                    l = (i[4], "" != n ? "price-change" : "");
                                                tz += "<input type='time' min='" + tR + "' max='" + tQ + "' data-parent='hulkapps_product_options' data-pid='" + e.pid + "' data-single_valid-class='dt_render'  data-val-selected-class='datetimepicker_selected'  data-option-key='dt_" + tn + "' id='" + tn + "' name='input' placeholder='mm/dd/yyyy' class='hulkapps_option_child hulkapps_full_width hulkapps_option_" + tn + " " + l + "' data-price='" + n + "' data-variant-id= '" + i[12] + "'><input type='hidden' " + tv + "  name='properties[" + v + "]' class='dp_property_val other_options_prop_val'>"
                                            }), tz += "</div></div>", td += tz
                                        }
                                    } else if ("color_picker" == V) {
                                        if (checkPlan("color_picker_option", "boolean")) {
                                            var tD = "";
                                            tz = "<div class='hulkapps_option cp_render " + ts + " " + tb + " " + tx + " option_type_id_" + tn + " " + tr + " " + J + "' " + M + " data-parent-id='" + tn + "'>", tz += "<div aria-label='" + v + "' tabindex='0' aria-required='" + ty + " ' class='hulkapps_option_name'>" + v + " " + t_ + " " + tw + " " + t9 + "</div>", tz += "<div class='hulkapps_option_value'>", t.each(tl, function(t, i) {
                                                var a = i[1],
                                                    o = i[9];
                                                "percentage_charge" == o && null != a && "" != a ? (a = parseFloat(product_price) / 100 * a / 100, a = parseFloat(a.toFixed(2))) : "create_mulitplication_charge" == o && null != a && "" != a && (a = parseFloat(product_price) / 100 * a, a = parseFloat(a.toFixed(2))), null != a && "" != a && e.currency_symbol, null != a && "" != a && e.currency_symbol;
                                                var n = null != a && "" != a ? a : "0.00",
                                                    l = "" != n ? "price-change" : "";
                                                tz += "<input type='color' data-parent='hulkapps_product_options' data-pid='" + e.pid + "' data-val-selected-class='colorpicker_selected' data-single_valid-class='cp_render'  data-option-key='cp_" + tn + "' id='" + tn + "' name='input' style='padding: 0;width: 100px;' class='hulk_po_other_options hulkapps_option_child  hulkapps_option_" + tn + " " + l + "' data-price='" + n + "' data-variant-id= '" + i[12] + "'><input type='hidden' " + tv + "  name='properties[" + v + "]' class='cp_property_val other_options_prop_val'>"
                                            }), tz += "</div></div>", td += tz
                                        }
                                    } else if ("number_field" == V) {
                                        tD = "", void 0 != H && checkPlan("character_limit", "boolean", e.plan_id, e.plans_features) && "" != H.character_limit && H.character_limit;
                                        var tB = void 0 != H && checkPlan("character_limit", "boolean") && "" != H.character_limit && void 0 != H.character_limit ? "[Maximum " + H.character_limit + " character]" : "",
                                            tz = "<div class='hulkapps_option nf_render " + B + " " + ts + " " + tb + " " + tx + " option_type_id_" + tn + " " + tr + " " + J + "' " + M + " data-parent-id='" + tn + "'>";
                                        tz += "<div aria-label='" + v + "' tabindex='0' aria-required='" + ty + " ' class='hulkapps_option_name'><div>" + v + " " + t_ + " " + tw + " </div> " + tB + " " + t9 + "</div>", "inlineLabels" == D && (X = v), "floatingLabels" == D && (X = ""), tz += "<div class='hulkapps_option_value'>", t.each(tl, function(t, i) {
                                            var a = i[1],
                                                o = i[9];
                                            "percentage_charge" == o && null != a && "" != a ? (a = parseFloat(product_price) / 100 * a / 100, a = parseFloat(a.toFixed(2))) : "create_mulitplication_charge" == o && null != a && "" != a ? (a = parseFloat(product_price) / 100 * a, a = parseFloat(a.toFixed(2))) : "character_charge" == o && null != a && "" != a && (a = parseFloat(a)), null != a && "" != a && e.currency_symbol;
                                            var n = null != a && "" != a ? a : "0.00",
                                                l = "",
                                                s = "",
                                                p = "" != n ? "price-change" : "";
                                            void 0 != H && checkPlan("character_limit", "boolean") && "" != H.character_limit && void 0 != H.character_limit && (l = "maxlength=" + H.character_limit, s = "onKeyPress='if(this.value.length==" + H.character_limit + ") return false;'"), tz += "<input type='number' " + s + " pattern='d*' min=0 step='any' data-parent='hulkapps_product_options' data-is-charge='" + o + "' data-main-price='" + n + "' data-pid='" + e.pid + "' data-val-selected-class='numberfield_selected' data-single_valid-class='nf_render' data-option-key='nf_" + tn + "' id='" + tn + "' placeholder='" + X + "'  class='hulk_po_other_options hulkapps_option_child hulkapps_full_width hulkapps_option_" + tn + " " + p + "' data-price='" + n + "' " + l + " data-variant-id= '" + i[12] + "'><input type='hidden' " + tv + "  name='properties[" + v + "]' class='nf_property_val other_options_prop_val'>", "floatingLabels" == D && (tz += "<label class='floating_label'>" + v + "</label>"), void 0 != H && checkPlan("character_limit", "boolean") && "" != H.character_limit && void 0 != H.character_limit && (tz += "<input type='hidden' value='" + H.character_limit + "' class='character_count'><div id='char_count_" + tn + "'>" + H.character_limit + " " + e.display_settings.charcter_count_message + "</div>"), void 0 != H && checkPlan("character_limit", "boolean") && "" != H.character_limit && void 0 != H.character_limit && (tD += "<script>(function($) {$(document).on('input', '.hulkapps_product_options .hulkapps_option_" + tn + "', function() { if(this.value.length > Number($(this).attr('maxlength'))){val=this.value.slice(0, $(this).attr('maxlength'));$(this).val(val);}check_character_limit(" + H.character_limit + ",'" + tn + "','" + e.display_settings.charcter_count_message + "','hulkapps_product_options');});}(hulkapps_jQuery))</script>")
                                        }), td += tz = tz + tD + "</div></div>"
                                    } else if ("phone_number" == V) {
                                        var tD = "",
                                            tz = "<div class='hulkapps_option pn_render " + ts + " " + tb + " " + tx + " option_type_id_" + tn + " " + tr + " " + J + "' " + M + " data-parent-id='" + tn + "'>";
                                        tz += "<div aria-label='" + v + "' tabindex='0' aria-required='" + ty + " ' class='hulkapps_option_name'>" + v + " " + t_ + " " + tw + " " + t9 + "</div>", tz += "<div class='hulkapps_option_value'>", t.each(tl, function(t, i) {
                                            var a = i[1],
                                                o = i[9];
                                            "percentage_charge" == o && null != a && "" != a ? (a = parseFloat(product_price) / 100 * a / 100, a = parseFloat(a.toFixed(2))) : "create_mulitplication_charge" == o && null != a && "" != a && (a = parseFloat(product_price) / 100 * a, a = parseFloat(a.toFixed(2))), null != a && "" != a && e.currency_symbol;
                                            var n = null != a && "" != a ? a : "0.00";
                                            tz += "<input type='textbox' data-option-key='tb_" + tn + "' id='" + tn + "' class='phone_number phone_number" + tn + " hulkapps_option_child hulkapps_full_width hulkapps_option_" + tn + " " + ("" != n ? "price-change" : "") + "' data-price='" + n + "' data-variant-id= '" + i[12] + "'><input type='hidden' " + tv + "  name='properties[" + v + "]' class='tb_property_val '><span id='valid-msg' class='hide'>✓ Valid</span><span id='error-msg' class='hide' tabindex='0' aria-label='Invalid number'>Invalid number</span>", tD += "<script>(function($) {$(document).ready(function(){$('.hulkapps_product_options .phone_number" + tn + "').keypress(function (e) {if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {return false;}});var telInput = $('.hulkapps_product_options').find('.phone_number" + tn + "');var errorMsg = $('.hulkapps_product_options').find('.phone_number" + tn + "').closest('.hulkapps_option_value').find('#error-msg');var validMsg = $('.hulkapps_product_options').find('.phone_number" + tn + "').closest('.hulkapps_option_value').find('#valid-msg');var iti = window.intlTelInput(telInput.get(0), {initialCountry: 'auto',geoIpLookup: function(callback) {var countryCode = '" + e.country + "';callback(countryCode);},customPlaceholder: function(selectedCountryPlaceholder, selectedCountryData) {return 'e.g. ' + selectedCountryPlaceholder;}, utilsScript: 'https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/18.3.4/js/utils.min.js'});var reset = function() {telInput.removeClass('error');errorMsg.innerHTML = '';errorMsg.addClass('hide');validMsg.addClass('hide');};telInput.blur(function() {reset();if ($.trim($('.phone_number" + tn + "').val())) {if(iti.isValidNumber()){validMsg.removeClass('hide');$('.hulkapps_product_options').find('.phone_number" + tn + "').parents('.hulkapps_option_value').find('#error-msg').css('cssText', 'display: none !important');telInput.val(iti.getNumber(intlTelInputUtils.numberFormat.E164));var tb_val = $('.hulkapps_product_options').find('.phone_number" + tn + "').val();var price = $(this).data('price');if(price != '0.00'){var res = tb_val + ' [ " + e.currency_symbol + "' + price + ' ]';}else{var res = tb_val}$(this).parents('.hulkapps_option_value').find('.tb_property_val').val(res);$(this).addClass('textbox_selected');} else {telInput.addClass('error');$('.hulkapps_product_options').find('.phone_number" + tn + "').parents('.hulkapps_option_value').find('#error-msg').css('cssText', 'display: block !important');$(this).parents('.hulkapps_option_value').find('.tb_property_val').val(res);$(this).removeClass('textbox_selected');}}else{$('.hulkapps_product_options').find('.phone_number').parents('.hulkapps_option_value').find('#error-msg').css('cssText', 'display: none !important');$(this).parents('.hulkapps_option_value').find('.tb_property_val').val(res);$(this).removeClass('textbox_selected');}conditional_rules(" + e.pid + ",'hulkapps_product_options');if($('#hulk_amount_dis').val() == '1'){calc_options_total(" + e.pid + ",'hulkapps_product_options');}validate_single_option('option_type_id_" + tn + "', 'pn_render','hulkapps_product_options');});});}(hulkapps_jQuery))</script>"
                                        }), td += tz = tz + tD + "</div></div>"
                                    } else if ("hidden" == V) checkPlan("hidden_field_option", "boolean") && (t.each(tl, function(t, e) {
                                        tz = "<input type='hidden' " + tv + "  name='properties[" + v + "]' class='hf_property_val   hulkapps_option_" + tn + " " + ts + " " + tr + "' value='" + e[0] + "'>"
                                    }), td += tz);
                                    else if ("popup" == V) checkPlan("popup_option", "boolean") && (tz = "<div class='hulkapps_option popup_render " + ts + " " + tb + " " + tx + " option_type_id_" + tn + " " + tr + " " + J + "' " + M + " data-parent-id='" + tn + "'>", tz += "<div class='hulkapps_option_name' style='display: none !important;'>" + v + " " + t_ + " " + tw + " " + t9 + "</div>", tz += "<div class='hulkapps_option_value'>", t.each(tl, function(t, e) {
                                        var i = e[0],
                                            a = null != e[3] ? e[3] : "";
                                        "" != a ? tz += "<div  class='cut-popup-icon'><span class='cut-popup-icon-span'><img src='" + a + "' style='width: 24px;'></span><a  tabindex='0' aria-label='" + i + "' style='cursor: pointer;' data-id='" + tn + "' data-option-key='popup_" + tn + "' id='" + tn + "' class='hulkapps_option_child hulkapps_full_width popup_open_link hulkapps_option_" + tn + "'>" + i + "</a></div>" : tz += "<div style='display: flex; align-items: center;'><a  tabindex='0' aria-label='" + i + "'  style='cursor: pointer;' data-id='" + tn + "' data-option-key='popup_" + tn + "' id='" + tn + "' class='hulkapps_option_child hulkapps_full_width popup_open_link hulkapps_option_" + tn + "'>" + i + "</a></div>", tz += "<div class='popup_detail'  id='popupdetailsdesing_" + tn + "' style='display: none'><div><div class='des-title'></div><div tabindex='0' aria-label='" + e[2] + "'class='des-detail' style='padding: 10px;'>" + e[2] + "</div></div><a class='popup_close_link' tabindex='0' aria-label='close popup' data-id='" + tn + "'><img src='" + window.hulkapps.po_url + "/images/close.png' alt='close-icon'></a></div><div class='overlay-popup'></div>"
                                    }), tz += "</div></div>", td += tz);
                                    else if ("information" == V) tz = "<div class='hulkapps_option information_render " + ts + " " + tb + " " + tx + " option_type_id_" + tn + " " + tr + " " + J + "' " + M + " data-parent-id='" + tn + "'>", tz += "<div class='hulkapps_option_value'>", t.each(tl, function(t, e) {
                                        e[0], tz += "<div tabindex='0' aria-label='" + e[2].replace(/<\/?p>/g, "") + "'>" + e[2] + "</div>"
                                    }), tz += "</div></div>", td += tz;
                                    else if ("google_font" == V) {
                                        if (checkPlan("google_font_option", "boolean")) {
                                            var tK, tD = "";
                                            if (tz = "<div class='hulkapps_option gf_render " + ts + " " + tb + " " + tx + " option_type_id_" + tn + " " + tr + " " + J + "' " + M + " data-parent-id='" + tn + "'>", tz += "<div aria-label='" + v + "' tabindex='0' aria-required='" + ty + " ' class='hulkapps_option_name'>" + v + " " + t_ + " " + tw + " " + t9 + " </div>", tz += "<div class='hulkapps_option_value'>", tW = "", option_charge_type = to.option_charge_type, to = to.price, "percentage_charge" == option_charge_type && null != to && "" != to && checkPlan("percentage_charge", "boolean") ? (to = parseFloat(product_price) / 100 * to / 100, to = parseFloat(to.toFixed(2))) : "multiplication_charge" == option_charge_type && null != to && "" != to && (to = parseFloat(product_price) / 100 * to, to = parseFloat(to.toFixed(2))), null != to && "" != to) var tH = "price-change",
                                                tV = "googlefont_selected",
                                                tW = " [ " + e.currency_symbol + to + " ]";
                                            else {
                                                to = "0.00";
                                                var tH = "price-change"
                                            }
                                            tz += "<input type='text' tabindex='0' data-option-key='gf_" + tn + "' id='" + tn + "' value='" + ta + "' class='hulkapps_option_child hulkapps_full_width hulkapps_option_" + tn + " " + tH + " " + tV + " ' data-price='" + to + "'>", "" == tW ? tz += "<input type='hidden' " + tv + "  name='properties[" + v + "]' class='gf_property_val'>" : tz += "<input type='hidden' " + tv + "  name='properties[" + v + "]' class='gf_property_val' value='" + ta + " " + tW + "'>", tz += "</div>", !0 == x && (tz += "<div class='font_preview " + tx + " font_preview_" + tn + " " + J + "' " + M + " data-parent-id='" + tn + "'><div aria-label='preview your font' tabindex='0' aria-required='false' class='hulkapps_option_name'>" + _ + "</div><div class='hulkapps_option_value'><textarea placeholder='" + X + "'  class='hulkapps_full_width' >" + X + "</textarea></div></div>"), tD += "<script>(function($) {var google_font_with_price_format = " + JSON.stringify(ti) + ";var google_fonts_data = " + JSON.stringify(te) + ";$('.hulkapps_option_" + tn + "').fontselect(google_fonts_data).change(function(){var font = $(this).val().replace('/+/g', ' ');font = font.split(':')[0];var option_charge_type = google_font_with_price_format[font]['option_charge_type'];var price=google_font_with_price_format[font]['price'];var variant_id=google_font_with_price_format[font]['variant_id'];if(option_charge_type == 'percentage_charge' && price != null && price != ''){price = ((parseFloat(product_price)/100)*price)/100;price = parseFloat(price.toFixed(2));}if(option_charge_type == 'create_mulitplication_charge' && price != null && price != ''){price = ((parseFloat(product_price)/100)*price);price = parseFloat(price.toFixed(2));}if(price == null){price = '0.00'};$('.hulkapps_option_" + tn + "').attr('data-variant-id',variant_id);$('.hulkapps_option_" + tn + "').attr('data-price',price)});$(document).on('change','.hulkapps_product_options .hulkapps_option_" + tn + "',function() {var price = $(this).attr('data-price');var gf_val = $(this).val();$('.font_preview_" + tn + " textarea').css('font-family', gf_val);if (gf_val != '') {if(price != '0.00'){var res = gf_val + ' [ " + e.currency_symbol + "' + price + ' ]';}else{var res = gf_val}$(this).parent().find('.gf_property_val').val(res);$(this).addClass('googlefont_selected');}else{ $(this).parent().find('.gf_property_val').val('');$(this).removeClass('googlefont_selected');}conditional_rules(" + e.pid + ",'hulkapps_product_options');if($('#hulk_amount_dis').val() == '1'){calc_options_total(" + e.pid + ",'hulkapps_product_options');}validate_single_option('option_type_id_" + tn + "', 'gf_render','hulkapps_product_options');});}(hulkapps_jQuery))</script>", td += tz = tz + tD + "</div>"
                                        }
                                    } else if ("formula_based_options" == V) {
                                        if (checkPlan("formula_based_options", "boolean")) {
                                            tz = "<div class='hulkapps_option fm_render required " + tb + " " + ts + "  " + (!0 == f ? "" : "full_width") + " option_type_id_" + tn + " " + tr + " " + J + "' " + M + " data-parent-id= " + tn + " ><div class='hulkapps_option_name'  aria-label='" + v + "' tabindex='0' >" + v + " " + t_ + " " + tw + " " + t9 + "</div><div class='hulkapps_option_value fm_option_val' data-parent='hulkapps_product_options' data-pid='" + e.pid + "'>";
                                            var t5 = "",
                                                tZ = !1;
                                            t.each(tl, function(t, e) {
                                                if (i = "", e[4]) var i = "<div class='hulkapps-tooltip'><span aria-describedby='tooltip_" + n + "' aria-label='" + e[4] + "' tabindex='0' ><img src='" + window.hulkapps.po_url + "/tooltip.svg' style='width:15px;'></span><div class='hulkapps-tooltip-inner' id='tooltip_" + n + "' role='tooltip'>" + e[4] + "</div></div>";
                                                if ("plus" == e[3]) var a = "+";
                                                else if ("minus" == e[3]) var a = "-";
                                                else if ("divide" == e[3]) var a = "/";
                                                else if ("multiple" == e[3]) var a = "*";
                                                var o = "";
                                                "default_value" == e[0] ? o = "<div class='hulk-form-field'><div class='hulkapps_option_name' tabindex='0' aria-label='" + e[1] + "' >" + e[1] + "</div><div class='hulkapps_option_value'><input type='number'   value='" + parseFloat(e[2]) + "' data-oid='" + tn + "' class='po_changed_formula' data-arithmatic='" + a + "' readonly data-name='" + e[1] + "' min='" + e[5] + "' max='" + e[6] + "'>" + i + "</div></div>" : (tZ = !0, o = "<div class='hulk-form-field'><div class='hulkapps_option_name' tabindex='0' aria-label='" + e[1] + "'>" + e[1] + "</div><div class='hulkapps_option_value'><input type='number'  data-oid='" + tn + "'  data-arithmatic='" + a + "' class='po_changed_formula hulkapps_option_child' data-name='" + e[1] + "'  min='" + e[5] + "' max='" + e[6] + "' >" + i + "</div></div>"), tz += o
                                            }), tz += "<input type='hidden' " + tv + "  name='properties[" + v + "]'  class='hulk_formula_hidden_prop hulkapps_option_child'/>", tz += `<script>(function($) {if(${tZ} != true){$('.option_type_id_${tn}').find('.po_changed_formula').change();}}(hulkapps_jQuery))</script></div></div>`, td += tz
                                        }
                                    } else if ("short_text_group" == V) {
                                        if (checkPlan("short_text_group", "boolean")) {
                                            var tD = "";
                                            tz = "<div class='hulkapps_option stg_render " + ts + " " + tb + " " + tx + " option_type_id_" + tn + " " + tr + " " + J + "' " + M + " data-parent-id='" + tn + "'>", tz += "<div aria-label='" + v + "' tabindex='0' aria-required='" + ty + " ' class='hulkapps_option_name'>" + v + " " + t_ + " " + tw + " " + t9 + " </div>", tz += "<div class='hulkapps_option_value'>", t.each(tl, function(t, i) {
                                                var a = i[0],
                                                    o = i[1],
                                                    n = i[9];
                                                "percentage_charge" == n && null != o && "" != o ? (o = parseFloat(product_price) / 100 * o / 100, o = parseFloat(o.toFixed(2))) : "create_mulitplication_charge" == n && null != o && "" != o && (o = parseFloat(product_price) / 100 * o, o = parseFloat(o.toFixed(2))), null != o && "" != o && e.currency_symbol;
                                                var l = null != o && "" != o ? o : "0.00";
                                                if (tg = "", t$ = "", Object.keys(tf).length > 0)
                                                    for (let s in tf) tf.hasOwnProperty(s) && Array.isArray(tf[s]) && tf[s].includes(i[0].toString().trim()) && (tg += ` ${s} `, t$ = tk);
                                                "none" != a ? (tz += "<div class='hulkapps_short_option_value " + tg + " " + t$ + "' ><div class='hulkapps_option_name' tabindex='0' aria-label='" + i[0] + "'>" + i[0] + " </div>", tz = tz + "<input type='text' placeholder='" + X + "' data-option-key='stg_" + tn + "' id='" + tn + "' class='hulkapps_option_child hulkapps_full_width hulkapps_option_" + tn + " " + tH + "' data-price='" + l + "' data-variant-id= '" + i[12] + "' data-pid='" + e.pid + "'  data-oid='" + tn + "' data-parent='hulkapps_product_options' data-key-name='" + a + "' data-single_valid-class='stg_render' data-val-selected-class='stg_selected'></div>") : tz = tz + "<input type='hidden' placeholder='" + X + "' data-option-key='stg_" + tn + "' id='" + tn + "' class='hulkapps_option_child stg_hidden stg_hidden_" + tn + " hulkapps_full_width hulkapps_option_" + tn + " " + tH + "' data-price='" + l + "' data-variant-id= '" + i[12] + "' data-currency-symbol='" + e.currency_symbol + "' data-pid='" + e.pid + "' data-oid='" + tn + "' data-parent='hulkapps_product_options' data-single_valid-class='stg_render' data-val-selected-class='stg_selected'>"
                                            }), tz = tz + "<input type='hidden' " + tv + "  name='properties[" + v + "]' class='stg_property_val'>", tz += "</div></div>", td += tz
                                        }
                                    } else if ("multi_qty_selector" == V && (window.hulk_multi_qty_selector = !0, checkPlan("multi_qty_selector", "boolean"))) {
                                        var tG = "",
                                            et = "",
                                            ee = "",
                                            ei = "",
                                            t6 = void 0 != H && "" != H && void 0 != H.minimum_selection && "" != H.minimum_selection ? H.minimum_selection.toString() : "0",
                                            tj = void 0 != H && "" != H && void 0 != H.maximum_selection && "" != H.maximum_selection ? H.maximum_selection.toString() : "0",
                                            tA = "0" != t6 && "0" != tj && checkPlan("validation_for_min_max_option_selection", "boolean") ? '<span aria-label="Choose from ' + t6 + " to " + tj + ' values" tabindex="0" class="selection-text">[Choose from ' + t6 + " to " + tj + " values]</span>" : "0" != t6 && checkPlan("validation_for_min_max_option_selection", "boolean", e.plan_id, e.plans_features) ? '<span aria-label="Choose at least ' + t6 + ' values" tabindex="0"  class="selection-text">[Choose at least ' + t6 + " values]</span>" : "0" != tj && checkPlan("validation_for_min_max_option_selection", "boolean") ? '<span aria-label="Choose upto ' + tj + ' values" tabindex="0" class="selection-text">[Choose upto ' + tj + " values]</span>" : "";
                                        if ("true" == y) var tG = '<div class="hulk-custom-values-display prop_display_' + tn + ' "  data-option-id="' + tn + '"><p><span class="hulkselectedValue"></span><a href="javascript:void(0);" id="hulkModalBtn" class="hulkModalBtn hulkModalBtnSelect" data-prop-class="hulkapps_option_' + tn + '_hidden" data-update-div-class="prop_display_' + tn + '"  data-render-class="option_type_id_' + tn + '" >' + select_button_text + "</a></p></div>",
                                            et = "is_hulk_hide",
                                            ei = "hulk_quantity_popup",
                                            tx = "";
                                        var tz = ee + "<div class='hulkapps_option mq_render " + ei + " " + ts + " " + tb + " " + tx + " " + tP + " option_type_id_" + tn + " " + tr + " " + J + "' " + M + " data-parent-id='" + tn + "'" + (checkPlan("validation_for_min_max_option_selection", "boolean") ? " data-min='" + t6 + "' data-max='" + tj + "'" : "") + ">";
                                        tz += "<div aria-label='" + v + "' tabindex='0' aria-required='" + ty + " ' class='hulkapps_option_name'><div>" + v + " " + t_ + " " + tw + "  </div> " + tA + " " + t9 + "</div>", tz += "<div class='hulkapps_option_value hulkapps_product_page_options " + et + "'><div class='hulk_multi_qty_main'>";
                                        var t5 = [],
                                            tO = 0,
                                            t1 = [],
                                            tL = !1;
                                        t.each(tl, function(t, i) {
                                            if (tg = "", t$ = "", Object.keys(tf).length > 0)
                                                for (let a in tf) tf.hasOwnProperty(a) && Array.isArray(tf[a]) && tf[a].includes(i[0].toString().trim()) && (tg += ` ${a} `, t$ = tk);
                                            var o = i[1],
                                                n = i[9];
                                            "percentage_charge" == n && null != o && "" != o ? (o = parseFloat(product_price) / 100 * o / 100, o = parseFloat(o.toFixed(2))) : "create_mulitplication_charge" == n && null != o && "" != o && (o = parseFloat(product_price) / 100 * o, o = parseFloat(o.toFixed(2)));
                                            var l = null != o && "" != o ? " [ " + e.currency_symbol + o + " ]" : "",
                                                s = null != o && "" != o && 0 == U ? " (+" + e.currency_symbol + o + ")" : "",
                                                p = null != o && "" != o ? o : "0.00",
                                                d = i[4];
                                            !0 == d && (tO += 1, t5.push(i[0].toString().trim() + l));
                                            var u = "" != p ? "price-change" : "",
                                                c = "",
                                                f = "";
                                            let m = "" != i[5] && null != i[5] ? i[5] : "",
                                                k = parseInt(i[6]);
                                            var $ = "";
                                            let b = "" != i[7] && null != i[7] ? i[7] : "";
                                            "" != i[8] && null != i[8] && i[8];
                                            var x = "" != i[10] && null != i[10] ? i[10] : "";
                                            "" != i[11] && null != i[11] && i[11];
                                            var _ = "",
                                                w = "disabled";
                                            "true" == m.toString() && (t3 = !0), "true" == m.toString() && "true" != b.toString() && ($ = k, !0 == d && "" == f && "" == c && t1.push(i[0].toString().trim() + l + "_hin_" + $)), (!0 == d && k > 0 && "true" != b.toString() || !0 == d && k <= 0 && "true" == b.toString()) && (w = ""), "" != x && (_ = "<input type='hidden' " + tv + "  name='properties[_SKU_" + v + "(" + i[0].toString().trim() + ")]' value='" + x + "' class='hulk_unique_sku' " + w + "/>"), "0" == t && "" == f ? tL = !0 : "0" != t && !1 == tL && (tL = !0), "true" == m.toString() && "true" != b.toString() && k <= 0 || ((html_checkbox = "<div class='muti-qty-div hulk_quantity_info' ><div class='hulk_swatch_Image is_hulk_hide '><img src='" + i[3] + "'></div>", "true" == y && (html_checkbox += "<div class='hulk_merge_qty'>"), html_checkbox += "<div class='hulk_quantity_left'><h5 class='qty-val hulk_size' data-qty-val='" + i[0].toString().trim() + s + "'>" + i[0].toString().trim() + s + _ + "</h5></div><div class='hulk_swatch_desciption is_hulk_hide '><p class='hulk-limited-height'>" + i[12] + "</p><a href='javascript:void(0);' class='hulk-content-display'>See more</a></div><div class='hulk_quantity_div'><div class='hulk_quantity_right'>", $ > 0 && "true" != b.toString()) ? html_checkbox += `<div class='hulk_stock' data-uid='_hin_${g}_hin_${v}${i[0].toString().trim()}' data-hinventory='` + $ + "'> " + $ + " " + window.hulk_inventory_text + " </div>" : html_checkbox += "<div class='hulk_stock' > " + window.hulk_inventory_text + " </div>", html_checkbox += "</div><div class='quantity_selector'><button type='button' data-htype='decrement' class='hulk_quantity_button multi-qty-option  hulkapps_option_child hulkapps_option_" + tn + "_visible hulkapps_product_option_" + tn + "_visible " + u + " ' >-</button><input  data-min='" + t6 + "' data-max='" + tj + "' step='1' data-htype='number_input' type='number' class='hulk_quantity_amount multi-qty-option' data-qval='0' id='multy_options_quantity'  data-hinventory='" + $ + "' " + c + " data-parent='hulkapps_product_options' data-pid='" + e.pid + "' data-single_valid-class='mq_render' data-min='" + t6 + "' data-max='" + tj + "' data-oid='" + tn + "' id='" + tn + "' value='0' data-price='" + p + " '  data-conditional-value='" + i[0].toString().trim() + "' data-value='" + i[0].toString().trim() + l + "' ></input><button type='button' data-htype='increment' class='hulk_quantity_button multi-qty-option  hulkapps_option_child hulkapps_option_" + tn + "_visible hulkapps_product_option_" + tn + "_visible " + u + " '>+</button></div></div>", "true" == y && (html_checkbox += "</div>"), html_checkbox += "</div>", tz += html_checkbox)
                                        }), "required" == tb && (0 != t6 || 0 != tj) && ("0" != t6 && "0" != tj && checkPlan("validation_for_min_max_option_selection", "boolean") ? (parseInt(tO) < parseInt(t6) || parseInt(tO) > parseInt(tj)) && (tz += '</select><span class="validation_error error_span">Choose from ' + t6 + " to " + tj + " values</span>") : "0" != t6 && "0" == tj && checkPlan("validation_for_min_max_option_selection", "boolean") ? parseInt(tO) < parseInt(t6) && (tz += '</select><span class="validation_error error_span">Choose at least ' + t6 + " values</span>") : "0" == t6 && "0" != tj && checkPlan("validation_for_min_max_option_selection", "boolean") && parseInt(tO) > parseInt(tj) && (tz += '</select><span class="validation_error error_span">Choose upto ' + tj + " values</span>"));
                                        var t7 = "";
                                        tz += t7 = "<input type='hidden' " + tv + "  name='properties[_hin_" + g + "_hin_" + v + "]' value='" + t1 + "' class='hulk_unique_prop hulk_mqty_session'  data-unique_prop_name='_hin_" + g + "_hin_" + v + "' data-selection-multi='true'/>", tz += "<input class='hulkapps_option_child hulk_mutli_qty' value='" + t5.join(", ") + "' type='hidden' id='hulkapps_option_" + tn + "_hidden' " + tv + "  name='properties[" + v + "]'></div>", tz += "</div>", tz += tG, tz += "</div>", td += tz
                                    }
                                }
                            });
                            var tm = "<div class=''  id='recommended_detail' style='display: none'><div class='recommended_detail'><div class='recomodation_option_desc'><div class='recomodation-title'><span class='hulkapp_close close recommended_close_link' tabindex='0' aria-label='close recommended popup' >x</span></div><div tabindex='0' class='recomodation_option_detail' style='padding: 10px;'>" + tu + "</div></div></div><div class='overlay-popup'></div></div>",
                                tk = "<input type='hidden' name='currency_symbol' value='" + e.currency_symbol + "'>";
                            "" !== td && (ts = ts + td + tk), t("body").append(tm), ts += "</div>", (1 == parseInt(M) || "" == M) && (ts += "<div id='option_total' style='display: none;'><input type='hidden' id='raw_option_total' value='0'><div id='option_display_total_format' tabindex='0'>" + N + "<span id='formatted_option_total'>" + e.currency_symbol + "<span id='calculated_option_total'>0.00</span></span>" + J + "</div></div>"), ts += "<div id='error_text'></div>", ts += "</div></div>"
                        }
                        if (0 == t("#hulkapps_custom_options_" + window.hulkapps.product_id).length) {
                            let tg = 0;
                            l.split(",").forEach(function(e) {
                                tg += t(e).length, null == window.hulk_add_to_cart_ele && tg && (window.hulk_add_to_cart_ele = t(e).first())
                            });
                            var t$ = window.hulk_add_to_cart_ele;
                            t$.parent().is("div") && (t$ = t$.parent()), t$.before('<div id="hulkapps_custom_options_' + window.hulkapps.product_id + '"></div><div class="product-hulkapps-discount-code-html"></div>')
                        }
                        "is_collection_page" == i ? (t("body").addClass("body_fixed"), ts = `<div class="col_hulkapp_popupOverlay"><div class="col_hulkapp_popupBox"><div class="col_hulkapp_mainHead"><p class="col_hulkapp_popup-heading">Midi dress ( $ 20.0)</p><span class="col_hulkapp_close close">\xd7</span></div><div class="col_hulkapp_mainContent">${ts}</div><div class="co_hulkapp_popup-footer">
                               <button class="col_hulkapp_close btn btn--secondary button hulkapps_btn_cancel" type="button">Cancel</button>
                               <button class=" btn btn--primary button hulkapps_btn_save co_options_save" data-quantity="1" data-product_id='${window.hulkapps.product_id}'>Save changes</button>
                             </div></div></div>`, t(`.hulkapps-po-main_parent_${window.hulkapps.product_id}`).find(".col_hulkapp_popupOverlay").remove(), t(`.hulkapps-po-main_parent_${window.hulkapps.product_id}`).append(ts)) : t("#hulkapps_custom_options_" + window.hulkapps.product_id).html(ts), requireInventory(window.hulkapps.product_id, "hulkapps_product_options"), keybordAccess(), window.dynamic_checkout_button_integration = e.display_settings.dynamic_checkout_button_integration, window.ignore_min_max_validation = e.display_settings.ignore_min_max_validation, window.is_product_page_doscount_code = e.display_settings.dynamic_checkout_discount_code, conditional_rules(window.hulkapps.product_id, "hulkapps_product_options"), t("#hulkapps_options_" + window.hulkapps.product_id).closest("form").find(":submit").addClass("hulkapps_submit_cart"), window.$first_add_to_cart_el ? .removeClass("hulkapps_submit_cart").addClass("hulkapps_submit_cart"), "" == t("#hulkapps_option_list_" + window.hulkapps.product_id + " .hulkapps_option_set").html() && t("#hulkapps_options_" + window.hulkapps.product_id).css("display", "none"), window.hulk_multi_qty_selector && window.hulkUpdateStockStatus(t)
                    }
                },
                error: function(t, e) {
                    window.$first_add_to_cart_el && window.$first_add_to_cart_el.removeAttr("disabled")
                }
            })
        }, window.hulkappsStart = function(t) {
            setTimeout(function() {
                window.$first_add_to_cart_el = null;
                var e = ["#zakeke-product-button", "input[name='add']", "button[name='add']", "#add-to-cart", "#AddToCartText", "#AddToCart", 'form[action="/cart/add"] :input[type="submit"]', 'form[action*="/cart/add"] :input[type="submit"]', 'form[action*="/cart/add"] button[type="submit"]'],
                    i = 0;
                if (e.forEach(function(e) {
                        i += t(e).length, null == window.$first_add_to_cart_el && i && (window.$first_add_to_cart_el = t(e).first())
                    }), "product" == window.hulkapps.page_type && null != window.$first_add_to_cart_el) {
                    var a = window.$first_add_to_cart_el;
                    a.parent().is("div") && (a = a.parent()), 0 == t(".hulkapps-volumes").length && a.after('<div class="hulkapps-volumes"></div><div class="product-hulkapps-discount-code-html"></div>'), 0 == t("#hulkapps_custom_options_" + window.hulkapps.product_id).length && a.before('<div id="hulkapps_custom_options_' + window.hulkapps.product_id + '"></div>')
                }
                if ("product" == window.hulkapps.page_type && window.hulkapps.product_id && window.hulkapps.store_id) {
                    if (window.hulkapps.is_volume_discount) {
                        window.eligible_product = !1, product_page_btn_condition(), document.addEventListener("change", function(t) {
                            let e = ".single-option-selector,.swatch-element input[type='radio'],.single-option-selector__radio, select[data-option='option1'], select[data-option='option1']:checked, select[data-option='option2'], select[data-option='option1']:checked, select[data-option='option3'], select[data-option='option3']:checked, select[data-index='option1'], select[data-index='option1']:checked, select[data-index='option2'], select[data-index='option1']:checked, select[data-index='option3'], select[data-index='option3']:checked, ul li div[swatch-option='option1'], input[type='radio']:not([name='card_group'])";
                            t.target.matches(e) && l(t)
                        }), t(document).on("click", ".close_banner", function(e) {
                            t(".hulkapps-banner-msg").remove()
                        });
                        var o = {
                            pid: window.hulkapps.product_id,
                            store_id: window.hulkapps.store_id,
                            ctags: window.hulkapps.customer ? window.hulkapps.customer.tags : null,
                            product_variants: window.hulkapps.product.selected_variant,
                            product_collections: window.hulkapps.product_collections,
                            product_tags: window.hulkapps.product ? window.hulkapps.product.tags : null
                        };

                        function n(a, o) {
                            if (0 == t(".hulkapps-volumes").length) {
                                var n;
                                e.forEach(function(e) {
                                    i += t(e).length, t(e).length > 0 && (n = t(e).first())
                                }), n.parent().is("div") && (n = n.parent()), n.after('<div class="hulkapps-volumes"></div><div class="product-hulkapps-discount-code-html"></div>')
                            }
                            if (t(".hulkapps-volumes").html(a), window.dynamic_checkout_button_integration = o.display_setting.dynamic_checkout_button_integration, window.is_product_page_doscount_code = o.display_setting.dynamic_checkout_discount_code, window.legacy_vd = o.legacy_vd, window.eligible_product = !0, window.eligible_offer_type = o.eligible_offer.offer_type, window.main_offer_type = o.eligible_offer.main_offer_type, window.bulk_exact_discount = "bulk_qty" == o.eligible_offer.discount_type && !0 == o.eligible_offer.bulk_checkbox, "volume" == window.main_offer_type || "cart" == window.main_offer_type) {
                                let l = "each_qty" == o.eligible_offer.discount_type ? JSON.parse(o.eligible_offer.offer_levels) : JSON.parse(o.eligible_offer.fix_quantity_level);

                                function s(e) {
                                    try {
                                        let i = t(document).find(".offer-options-list .offer-option-item .offer-option").eq(e).width(),
                                            a = .9 * i;
                                        t(document).find(".offer-options-list  .offer-option-item .offer-option").eq(e).css("width", a), t(document).find(".offer-option-item .offer-option_price").eq(e).css("width", "100%")
                                    } catch (o) {
                                        console.error(`Error adjusting width at index ${e}:`, o)
                                    }
                                }

                                function p(e) {
                                    try {
                                        for (let i = 0; i < 12; i++) {
                                            s(e);
                                            let a = t(document).find(".hulkapps-volumes .offer-option-item .total-regular_price").eq(e),
                                                o = a.height(),
                                                n = parseInt(a.css("line-height"));
                                            if (!(parseInt(o) > parseInt(n))) break
                                        }
                                    } catch (l) {
                                        console.error(`Error checking and adjusting width at index ${e}:`, l)
                                    }
                                }
                                l.length > 0 && (window.qty_array = l.map(function(t) {
                                    return t[0]
                                }));
                                try {
                                    t(".hulkapps-volumes .offer-option-item").each(function(t) {
                                        p(t)
                                    })
                                } catch (d) {
                                    console.error("Error in main loop:", d)
                                }
                            }
                            if ("" != a && null != a) {
                                ("bxgy" == window.main_offer_type || "bundle" == window.main_offer_type && "variant" == o.eligible_offer.offer_type) && bundle_bxgy_variant_logic();
                                let u = o.eligible_offer.unique_name;
                                u = u.replace(/\s+/g, "-"), t(".hulkapps-volume-discount-tiers").addClass(u)
                            }
                            if (!0 == o.display_setting.is_theme_inherit) {
                                if (t(".product-form__buttons").length > 0) {
                                    var c = t(".product-form__buttons").outerWidth();
                                    t(".hulkapps-volumes").css("width", c + "px"), t(".hulkapps-table").css("width", c + "px")
                                } else t(".hulkapps-table").css("width", "100%")
                            }
                            pixelTracking(o.display_setting), window.get_set_country_local_storage(o)
                        }

                        function l(e) {
                            var i = [];
                            document.querySelectorAll(".single-option-selector,.swatch-element input[type='radio'],.single-option-selector__radio, select[data-option='option1'], select[data-option='option1']:checked, select[data-option='option2'], select[data-option='option1']:checked, select[data-option='option3'], select[data-option='option3']:checked, select[data-index='option1'], select[data-index='option1']:checked, select[data-index='option2'], select[data-index='option1']:checked, select[data-index='option3'], select[data-index='option3']:checked, ul li div[swatch-option='option1'], input[type='radio']:not([name='card_group'])").forEach(function(t) {
                                var e = !!t.options && t.options[t.options.selectedIndex].selected;
                                (t.checked || e) && i.push(t.value)
                            }), i = i.join(" / "), Object.keys(variants).forEach(function(t) {
                                var a = variants[t];
                                if (a.options.length < 2) {
                                    selected_variant_title = e.target.value.toString().toLowerCase();
                                    var o = a.title.toString().toLowerCase();
                                    o.trim() == selected_variant_title.trim() && (a.id, window.hulkapps.product.selected_variant = a.id, product_price = a.price, window.hulkapps.product.selected_variant_price = product_price)
                                } else {
                                    selected_variant_title = i.toString().toLowerCase();
                                    var o = a.title.toString().toLowerCase();
                                    selected_variant_title.includes(o) && (a.id, window.hulkapps.product.selected_variant = a.id, product_price = a.price, window.hulkapps.product.selected_variant_price = product_price)
                                }
                                document.querySelector('script[type="application/json"][data-variant]') && document.querySelector('script[type="application/json"][data-variant]').textContent.trim() && updateSelectedVariant()
                            }), product_page_btn_condition();
                            var a = {
                                pid: window.hulkapps.product_id,
                                store_id: window.hulkapps.store_id,
                                ctags: window.hulkapps.customer ? window.hulkapps.customer.tags : null,
                                product_variants: window.hulkapps.product.selected_variant,
                                product_collections: window.hulkapps.product_collections,
                                product_tags: window.hulkapps.product_tags
                            };
                            t.ajax({
                                type: "POST",
                                url: window.hulkapps.vd_url + "/api/v2/shop/get_offer_table",
                                data: a,
                                crossDomain: !0,
                                success: function(e) {
                                    if (e) {
                                        let i = "";
                                        e.eligible_offer.is_display_offer_table && (i = eligible_offer(e)), i instanceof Promise ? i.then(function(t) {
                                            n(t, e)
                                        }).catch(function(t) {
                                            console.error("Error in eligible_offer promise:", t)
                                        }) : n(i, e)
                                    } else t(".hulkapps-volumes").html("");
                                    window.eligible_product && window.dynamic_checkout_button_integration || t(".shopify-payment-button").css({
                                        "pointer-events": "inherit"
                                    }), buy_now_wrap()
                                },
                                error: function(e, i) {
                                    t(".shopify-payment-button").css({
                                        "pointer-events": "inherit"
                                    })
                                }
                            }), (window.hulkapps.is_product_option || window.is_hulkpo_installed) && setTimeout(function() {
                                calc_options_total(window.hulkapps.product_id, "hulkapps_product_options")
                            }, 500)
                        }
                        t.ajax({
                            type: "POST",
                            url: window.hulkapps.vd_url + "/api/v2/shop/get_offer_table",
                            data: o,
                            crossDomain: !0,
                            success: function(e) {
                                if (e) {
                                    let i = "";
                                    e.eligible_offer.is_display_offer_table && (i = eligible_offer(e)), i instanceof Promise ? i.then(function(t) {
                                        n(t, e)
                                    }).catch(function(t) {
                                        console.error("Error in eligible_offer promise:", t)
                                    }) : n(i, e)
                                } else t(".hulkapps-volumes").html("");
                                window.eligible_product && window.dynamic_checkout_button_integration || t(".shopify-payment-button").css({
                                    "pointer-events": "inherit"
                                }), buy_now_wrap()
                            },
                            error: function(e, i) {
                                t(".shopify-payment-button").css({
                                    "pointer-events": "inherit"
                                })
                            }
                        }), t(document).on("change", "[name='quantity']", function() {
                            t(".shopify-payment-button").css({
                                "pointer-events": "none"
                            }), buy_now_wrap()
                        }), t(document).on("keyup", ".hulkapps_discount_code", function(e) {
                            "" != t.trim(t(this).val()) ? (t(".hulkapps_product_discount_button").removeAttr("disabled"), t(".hulkapps_product_discount_button").removeClass("hulkapps_product_discount_disabled_button")) : (t(".hulkapps_product_discount_button").attr("disabled", "disabled"), t(".hulkapps_product_discount_button").addClass("hulkapps_product_discount_disabled_button"))
                        }), t(document).on("click", ".hulkapps_product_discount_button", function(e) {
                            t(".hulkapps_product_discount_button").attr("disabled", "disabled"), t(".hulkapps_product_discount_button").addClass("hulkapps_product_discount_disabled_button"), new Promise((t, e) => {
                                var i = validate_options(window.hulkapps.product_id, "hulkapps_product_options");
                                t(i)
                            }).then(function(e) {
                                if (e) {
                                    var i = "";
                                    window.hulkapps.is_volume_discount ? i = window.hulkapps.vd_url + "/shop/get_cart_details" : window.hulkapps.is_product_option && (i = window.hulkapps.po_url + "/store/get_cart_details");
                                    var a = {};
                                    a[window.hulkapps.product.selected_variant] = window.hulkapps.product_collection;
                                    var o = {};
                                    o[window.hulkapps.product.id] = window.hulkapps.product_tags, t.ajax({
                                        type: "POST",
                                        url: i,
                                        data: {
                                            cart_data: window.hulk_cjson,
                                            store_id: window.hulkapps.store_id,
                                            discount_code: t("input[name=checkout_discount]").val(),
                                            cart_collections: JSON.stringify(a),
                                            cart_product_tags: JSON.stringify(o),
                                            ctags: window.hulkapps.customer ? window.hulkapps.customer.tags : ""
                                        },
                                        crossDomain: !0,
                                        success: function(e) {
                                            var i = e.discounts,
                                                a = parseFloat(i.discount_cut_price);
                                            i.discount_code && 1 == i.discount_error ? (hulkapps_jQuery(".hulkapps_summary_product").remove(), t(".discount_code_box_product .hulkapps_discount_hide").after("<span class='hulkapps_summary_product'>Discount code does not match</span>"), t(".hulkapps-summary-product-line-discount-code").html(""), t(".product_after_discount_price").html("")) : i.is_free_shipping ? (t(".hulkapps_summary_product").remove(), t(".hulkapps-summary-product-line-discount-code").html(""), t(".product_after_discount_price").html(""), t(".discount_code_box_product .hulkapps_discount_hide").after("<span class='hulkapps-summary-product-line-discount-code'><span class='discount-tag'>" + i.discount_code + "<span class='product-close-tag close-tag'></span></span>Free Shipping")) : i.discount_code && a <= 0 ? (t(".discount_code_box_product .hulkapps_discount_hide").after("<span class='hulkapps_summary_product'>Discount code isn’t valid for the items in your cart</span>"), t(".hulkapps_discount_code").val(""), t(".hulkapps-summary-product-line-discount-code").html(""), t(".product_after_discount_price").html("")) : i.discount_code ? (t(".discount_code_box_product").find(".hulkapps_summary_product").html(""), t(".hulkapps-summary-product-line-discount-code,.product_after_discount_price").remove(), t(".discount_code_box_product .hulkapps_discount_hide").after("<span class='hulkapps-summary-product-line-discount-code'><span class='discount-tag'>" + i.discount_code + "<span class='product-close-tag close-tag'></span></span><span class='hulkapps_with_discount'> -" + i.with_discount + "</span></span><span class='product_after_discount_price'><span class='final-total'>Total</span>" + i.final_with_discounted_price + "</span>"), t(".hulkapps-cart-total").remove()) : (t(".hulkapps-summary-product-line-discount-code").html(""), t(".product_after_discount_price").html(""), t(".discount_code_box_product").find(".hulkapps_summary_product").html("")), t(".hulkapps_product_discount_button").removeAttr("disabled"), t(".hulkapps_product_discount_button").removeClass("hulkapps_product_discount_disabled_button")
                                        }
                                    })
                                }
                            }).catch(function(t) {})
                        }), t(document).on("click", ".hulkapps_product_discount_modal .modal_close_btn", function(e) {
                            t(".hulkapps_product_discount_modal").hide()
                        });
                        var s = 0;
                        t(document).on("click", ".hulk-buy_now,#hulkapps_buy_now_continue", function(e) {
                            var i = t(this),
                                a = t(this).attr("data-hulk-btn-type");
                            e.cancelBubble = !0, e.stopPropagation(), e.preventDefault(), e.stopImmediatePropagation(), new Promise((t, e) => {
                                var i = validate_options(window.hulkapps.product_id, "hulkapps_product_options");
                                t(i)
                            }).then(function(e) {
                                if (e) {
                                    if (window.is_product_page_doscount_code && "hulkapps_buy_now_continue" != a && t(".product-hulkapps-discount-code-html").length > 0) {
                                        var o, n = "";
                                        n = t(".shopify-payment-button").html().includes("ShopifyPay-button") ? "ShopifyPay-button" : t(".shopify-payment-button").html().includes("payment-button") ? "payment-button" : "Checkout-button", t(".product-hulkapps-discount-code-html").html('<div class="hulkapps_product_discount_modal"><div class="product_discount_modal_wrapper"><span class="modal_close_btn"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0_2361_7248)"><path d="M1.23998 24.0001C0.923838 24.0001 0.607699 23.8798 0.367506 23.6378C-0.114689 23.1556 -0.114689 22.3739 0.367506 21.8917L21.8975 0.361646C22.3797 -0.120549 23.1615 -0.120549 23.6437 0.361646C24.1259 0.843841 24.1259 1.6256 23.6437 2.1081L2.11396 23.6378C1.87195 23.8783 1.55582 24.0001 1.23998 24.0001Z" fill="#AAAAAA"/><path d="M22.7715 24.0001C22.4554 24.0001 22.1395 23.8798 21.899 23.6378L0.367506 2.1081C-0.114689 1.6256 -0.114689 0.843841 0.367506 0.361646C0.849701 -0.120549 1.63146 -0.120549 2.11396 0.361646L23.6437 21.8917C24.1259 22.3739 24.1259 23.1556 23.6437 23.6378C23.4017 23.8783 23.0858 24.0001 22.7715 24.0001Z" fill="#AAAAAA"/></g><defs><clipPath id="clip0_2361_7248"><rect width="24" height="24" fill="white"/></clipPath></defs></svg></span><div class="product_discount_modal_body"><div id="hulkapps_discount_code"><div class="discount_code_box_product"><div class="hulkapps_discount_hide"><input placeholder="Discount code" class="hulkapps_discount_code" autocomplete="off" aria-required="true" size="30" type="text" name="checkout_discount"><button type="button" class="btn btn--primary btn-primary button hulkapps_product_discount_button hulkapps_product_discount_disabled_button" disabled >Apply</button></div></div></div><p class="hulkapps_discount_notetxt"><b>Note:</b> Proceed with Checkout button if no discount code available.</p></div><div class="product_discount_modal_footer"><button id="" class="btn btn-secondary button button--secondary modal_close_btn" type="button"  >Cancel</button><button id="hulkapps_buy_now_continue" class="btn btn--secondary btn-primary button button--primary" type="button" data-testid="' + n + '" data-hulk-btn-type="hulkapps_buy_now_continue">Checkout</button></div></div></div>')
                                    }
                                    var l = "hulkapps_product_options",
                                        p = 0,
                                        d = t("." + l + " #hulkapps_option_list_" + window.hulkapps.product_id + ":visible .price-change:checked, ." + l + " #hulkapps_option_list_" + window.hulkapps.product_id + ":visible .price-change:selected, ." + l + " .hulkapps_swatch_option .swatch_selected,." + l + " .textarea_selected,." + l + " .textbox_selected,." + l + " .emailbox_selected,." + l + " .datepicker_selected,." + l + " .numberfield_selected,." + l + " .colorpicker_selected,." + l + " .button_selected,." + l + " .googlefont_selected, ." + l + " .ci_render .hulkapps_option_value .hulkapps_option_child .dropdown_selected, ." + l + " .formula_selected,." + l + " .stg_selected");
                                    for (o = 0; o < d.length; o++) t(d[o]).parents(".hulkapps_option").hasClass("conditional") || (p = Number(t(d[o]).attr("data-price")) + Number(p));
                                    if (0 == s && ("Checkout-button" == i.attr("data-testid") || "ShopifyPay-button" == i.attr("data-testid") || "payment-button" == i.attr("data-testid"))) {
                                        t(".shopify-payment-button").css({
                                            "pointer-events": "none"
                                        });
                                        var u = {},
                                            c = i.attr("data-testid"),
                                            f = !1,
                                            v = [];
                                        t("[name^='properties']").each(function() {
                                            var e;
                                            "" == t(this).val() && t(this).remove(), "radio" == this.type ? this.checked && (e = this.name.replace("properties[", "").replace("]", ""), t.trim(this.value).length > 0 && (u[e] = this.value)) : "file" == this.type ? (e = this.name.replace("properties[", "").replace("]", ""), t.trim(this.value).length > 0 && (u[e] = this.value, f = !0, v.push(e))) : (e = this.name.replace("properties[", "").replace("]", ""), t.trim(this.value).length > 0 && (u[e] = this.value))
                                        }), window.hulk_cjson = {};
                                        let m = [];
                                        var k = {};
                                        k[window.hulkapps.product.selected_variant] = window.hulkapps.product_collection;
                                        var g = window.hulkapps.product.price;
                                        window.hulkapps.product.selected_variant_price && (g = window.hulkapps.product.selected_variant_price);
                                        var $ = 1;
                                        t("input[name=quantity]").val() && ($ = parseInt(t("input[name=quantity]").val())), new Promise((e, i) => {
                                            if (f && v.length > 0) {
                                                var a = null,
                                                    o = null,
                                                    n = 0;
                                                if (["input[name='add']", "button[name='add']", "#add-to-cart", "#AddToCartText", "#AddToCart", 'form[action$="/cart/add"] input[type="submit"]'].forEach(function(t) {
                                                        var e = document.querySelectorAll(t);
                                                        n += e.length, null === a && e.length > 0 && (a = e[0])
                                                    }), a) var o = a.closest("form").getAttribute("id");
                                                if (o) {
                                                    var l = new FormData(t(`#${o}`)[0]);
                                                    t.ajax({
                                                        type: "POST",
                                                        url: "/cart/add.js",
                                                        data: l,
                                                        dataType: "json",
                                                        contentType: !1,
                                                        processData: !1,
                                                        success: function(i) {
                                                            v.length > 0 && v.forEach(function(t) {
                                                                u[t] = i.properties[t]
                                                            }), e(u);
                                                            let a = i.key;
                                                            t.ajax({
                                                                type: "POST",
                                                                url: "/cart/change.js",
                                                                data: {
                                                                    quantity: 0,
                                                                    id: a
                                                                },
                                                                dataType: "json",
                                                                success: function(t) {},
                                                                error: function(t, e, i) {}
                                                            })
                                                        }
                                                    })
                                                } else e(u)
                                            } else e(u)
                                        }).then(function(e) {
                                            var i = Shopify.locale;
                                            if (m.push({
                                                    product_id: window.hulkapps.product.id,
                                                    variant_id: window.hulkapps.product.selected_variant,
                                                    quantity: $,
                                                    original_price: g,
                                                    price: g,
                                                    original_line_price: g * $,
                                                    line_price: g * $,
                                                    tags: window.hulkapps.product.tags,
                                                    vendor: window.hulkapps.product.vendor,
                                                    product_type: window.hulkapps.product.product_type,
                                                    properties: e,
                                                    title: window.hulkapps.product.title
                                                }), hulk_cjson.cart = {
                                                    items: m,
                                                    original_total_price: window.hulkapps.product.price * $,
                                                    item_count: $
                                                }, hulk_cjson.money_format = window.hulkapps.money_format, !window.is_product_page_doscount_code || "hulkapps_buy_now_continue" == a) {
                                                var o = "";
                                                window.hulkapps.is_volume_discount ? o = window.hulkapps.vd_url + "/shop/create_draft_order" : window.hulkapps.is_product_option && (o = window.hulkapps.po_url + "/store/create_draft_order"), t.ajax({
                                                    type: "POST",
                                                    url: o,
                                                    data: {
                                                        cart_json: hulk_cjson,
                                                        store_id: window.hulkapps.store_id,
                                                        cart_collections: JSON.stringify(k),
                                                        customer_tags: window.hulkapps.customer ? window.hulkapps.customer.tags : "",
                                                        discount_code: t(".discount_code_box_product .hulkapps_discount_code").val(),
                                                        hulk_btn_type: c,
                                                        draft_order_language: void 0 != i ? i : ""
                                                    },
                                                    crossDomain: !0,
                                                    success: function(t) {
                                                        "string" == typeof t ? window.location.href = t : "ShopifyPay-button" == c ? window.location.href = "/checkout?payment=shop_pay" : window.location.href = "/checkout", localStorage.removeItem("discount_code")
                                                    }
                                                })
                                            }
                                        }).catch(function(t) {
                                            console.log("error", t)
                                        })
                                    }
                                }
                            }).catch(function(t) {})
                        })
                    }(window.hulkapps.is_product_option || window.is_hulkpo_installed) && productPageAjax(t)
                }
                t("body").on("change", 'input[name="updates[]"]', function(e) {
                    t('[name="update"]').click()
                })
            }, 1), window.hulkappsParseURL = function(t) {
                if (t) {
                    var e = RegExp("^(([^:/?#]+):)?(//([^/?#]*))?([^?#]*)(\\?([^#]*))?(#(.*))?"),
                        i = t.match(e),
                        a = i[7];
                    return a && (a = new URLSearchParams(a)), {
                        scheme: i[2],
                        authority: i[4],
                        path: i[5],
                        query: a,
                        fragment: i[9]
                    }
                }
            }
        }, (window.hulkapps.is_product_option || window.hulkapps.is_volume_discount) && hulkappsStart(t)
    }, window.hulkUpdateStockStatus = function(t) {
        let e = {};
        new Promise((i, a) => {
            t.getJSON("/cart.js", {
                _: new Date().getTime()
            }, function(a) {
                a && a.item_count > 0 && a.items.forEach(function(i) {
                    var a = i.quantity;
                    null != i.properties && i.properties != {} && t.each(i.properties, function(i, o) {
                        if (i.startsWith("_hin") && o) {
                            if ((!0 == window.opt_with_otc[i] || "true" == window.opt_with_otc[i]) && (a = 1), o.includes(",")) o.split(",").forEach(function(o) {
                                let n = o.split("_hin_")[0];
                                var l = t.trim(o.split("_hin_")[1].split("|")[1]);
                                l.includes(")") && (l = parseInt(l.split(")"))), l <= 0 && (l = 1), e[n = i + t.trim(n.split("[")[0])] ? e[n] = e[n] + a * l : e[n] = a * l
                            });
                            else {
                                var n = t.trim(o.split("_hin_")[1].split("|")[1]);
                                n.includes(")") && (n = parseInt(n.split(")"))), n <= 0 && (n = 1);
                                let l = i + t.trim(o.split("_hin_")[0].split("[")[0]);
                                e[l] ? e[l] = e[l] + a * n : e[l] = a * n
                            }
                        }
                    })
                }), i(e)
            })
        }).then(function(e) {
            for (let i in e)
                if (e.hasOwnProperty(i)) {
                    let a = t(`[data-uid='${i}']`);
                    if (a.length > 0) {
                        let o = parseInt(a.attr("data-hinventory")) - parseInt(e[i]);
                        if (a.hasClass("hulk_stock")) o > 0 ? a.hasClass("dropdown_swatch") ? a.find(".dropdown-text").text(`${o} ${window.hulk_inventory_text}`) : a.text(`${o} ${window.hulk_inventory_text}`) : a.hasClass("dropdown_swatch") ? a.find(".dropdown-text").text(`${window.hulk_out_of_stock_text}`) : a.text(`${window.hulk_out_of_stock_text}`);
                        else {
                            let n = a.attr("data-display-val") + " / ";
                            o > 0 ? a.hasClass("dropdown_swatch") ? a.find(".dropdown-text").text(`${n} ${o} ${window.hulk_inventory_text}`) : a.text(`${n} ${o} ${window.hulk_inventory_text}`) : a.hasClass("dropdown_swatch") ? a.find(".dropdown-text").text(`${n} ${window.hulk_out_of_stock_text}`) : a.text(`${n} ${window.hulk_out_of_stock_text}`)
                        }
                    }
                }
        })
    }, window.getCartInfo = function(t = 0, e = "", i = hulkapps_jQuery) {
        var e = e;
        if (0 != t) {
            var a = t.key;
            let o = t.properties;
            if (o) {
                var n = "";
                Object.keys(o).forEach(function(t) {
                    if (o[t].includes("uploads")) {
                        var e = o[t].split("/"),
                            i = e[e.length - 1];
                        n += '<div class="product-option"><dt>' + t + ': </dt><dd>  <a href="' + o[t] + '" class="link" target="_blank">' + i + "</a></dd></div>"
                    } else t.startsWith("_hin") || t.startsWith("_SKU") || (n += '<div class="product-option"><dt>' + t + ": </dt><dd>" + o[t] + "</dd></div>")
                }), window.currentEditOptionSelector.parents("[data-hulkapps-lineitem]").find("[data-hulkapps-line-properties]").html(n)
            } else window.currentEditOptionSelector.parents("[data-hulkapps-lineitem]").find("[data-hulkapps-line-properties]").html("")
        } else i(".hulkapps-discount-reminder-msg").remove(), i(".hulkapps-discount-bar-msg").remove();
        new Promise(function(t, a) {
            e ? t(e) : i.getJSON("/cart.js", {
                _: new Date().getTime()
            }, function(e) {
                t(e)
            })
        }).then(function(t) {
            if (t && t.item_count > 0) {
                var e = localStorage.getItem("discount_code");
                window.hulkapps.cart = t;
                var o = window.hulkapps.customer ? window.hulkapps.customer.tags : "";
                window.hulkapps.product_tags = {}, new Promise((t, e) => {
                    i.ajax({
                        url: "/cart?view=hulkapps_cart_collections.json",
                        success: function(e) {
                            try {
                                if (e) {
                                    var a = JSON.parse(e);
                                    if (a) {
                                        var o = a.items;
                                        i.each(o, function(t, e) {
                                            window.hulkapps.cart_collections[e.variant_id] = e.product_collections, window.hulkapps.product_tags[e.product_id] = e.product_tags
                                        })
                                    }
                                }
                                t({
                                    cart_collections: window.hulkapps.cart_collections,
                                    product_tags: window.hulkapps.product_tags
                                })
                            } catch (n) {
                                t({
                                    cart_collections: window.hulkapps.cart_collections,
                                    product_tags: window.hulkapps.product_tags
                                })
                            }
                        },
                        error: function(e) {
                            t({
                                cart_collections: window.hulkapps.cart_collections,
                                product_tags: window.hulkapps.product_tags
                            })
                        }
                    })
                }).then(function(n) {
                    if (cart_collections = n.cart_collections, cart_product_tags = n.product_tags, window.hulkapps.product_tags = cart_product_tags, window.hulkapps.cart_collections = cart_collections, "" != e) {
                        i(".hulkapps_discount_code").val(e);
                        var l = {
                            cart_data: window.hulkapps,
                            store_id: window.hulkapps.store_id,
                            discount_code: e,
                            cart_collections: JSON.stringify(window.hulkapps.cart_collections),
                            cart_product_tags: JSON.stringify(window.hulkapps.product_tags),
                            ctags: o
                        }
                    } else var l = {
                        cart_data: window.hulkapps,
                        store_id: window.hulkapps.store_id,
                        cart_collections: JSON.stringify(window.hulkapps.cart_collections),
                        cart_product_tags: JSON.stringify(window.hulkapps.product_tags),
                        ctags: o
                    };
                    var s = 0;
                    t.items.forEach(function(t) {
                        null != t.properties && t.properties != {} && s++
                    }), s > 1 ? i(checkout_selectors).attr("disabled", !0) : i(checkout_selectors).attr("disabled", !1), i(checkout_selectors).attr("disabled", !0);
                    var p = "";
                    window.hulkapps.is_volume_discount ? p = window.hulkapps.vd_url + "/shop/get_cart_details" : window.hulkapps.is_product_option && (p = window.hulkapps.po_url + "/store/get_cart_details"), i.ajax({
                        type: "POST",
                        url: p,
                        data: l,
                        crossDomain: !0,
                        success: function(t) {
                            i(checkout_selectors).attr("disabled", !1), t.discounts ? (t.discounts.cart.items.forEach(function(e, i) {
                                setTimeout(function() {
                                    a && t.discounts.legacy_vd && e.key == a && (parseFloat(e.discounted_price) < parseFloat(e.original_price) ? (window.currentEditOptionSelector.parents("[data-hulkapps-lineitem]").find(".hulkapps-cart-item-line-price").html("<span class='original_price' style='text-decoration:line-through;'>" + e.original_line_price_format + "</span><br/><span class='discounted_price'>" + e.discounted_line_price_format + "</span>"), window.currentEditOptionSelector.parents("[data-hulkapps-lineitem]").find("[data-hulkapps-line-price]").html("<span class='original_price' style='text-decoration:line-through;'>" + e.original_line_price_format + "</span><br/><span class='discounted_price'>" + e.discounted_line_price_format + "</span>"), window.currentEditOptionSelector.parents("[data-hulkapps-lineitem]").find(".hulkapps-cart-item-price").html("<span class='original_price' style='text-decoration:line-through;'>" + e.original_price_format + "</span><br/><span class='discounted_price'>" + e.discounted_price_format + "</span>"), window.currentEditOptionSelector.parents("[data-hulkapps-lineitem]").find("[data-hulkapps-ci-price]").html("<span class='original_price' style='text-decoration:line-through;'>" + e.original_price_format + "</span><br/><span class='discounted_price'>" + e.discounted_price_format + "</span>")) : (window.currentEditOptionSelector.parents("[data-hulkapps-lineitem]").find(".hulkapps-cart-item-line-price").html("<span class='original_price' >" + e.original_line_price_format + "</span>"), window.currentEditOptionSelector.parents("[data-hulkapps-lineitem]").find("[data-hulkapps-line-price]").html("<span class='original_price' >" + e.original_line_price_format + "</span>"), window.currentEditOptionSelector.parents("[data-hulkapps-lineitem]").find(".hulkapps-cart-item-price").html("<span class='original_price' >" + e.original_price_format + "</span>"), window.currentEditOptionSelector.parents("[data-hulkapps-lineitem]").find("[data-hulkapps-ci-price]").html("<span class='original_price' >" + e.original_price_format + "</span>")))
                                }, 500)
                            }), hulkappsDoActions(t), t.discounts.is_draft_order ? (window.is_draft_order = !0, pixelTracking(t.discounts.display)) : window.is_draft_order = !1, window.hulk_inventory_arr = t.discounts.inventory_arr, window.is_draft_order && window.hulk_inventory_arr && window.hulk_inventory_arr.length <= 0 && i(".inventory_validation_hulkapps").remove()) : (i("[data-hulkapps-cart-total], .hulkapps-cart-original-total").css("text-decoration", "none"), i(".hulkapps-cart-total").remove(), localStorage.removeItem("discount_code"), i(".hulkapps-summary-line-discount-code").html(""), i(".after_discount_price").html(""), i(".hulkapps_discount_code").val(""))
                        },
                        error: function(t, e) {
                            i(checkout_selectors).attr("disabled", !1)
                        }
                    })
                }).catch(function(t) {
                    console.error(t)
                })
            } else t && 0 == t.item_count && localStorage.removeItem("discount_code")
        }).catch(function(t) {
            console.error(t)
        })
    }, window.cartPageJS = function(t) {
        t(document).on("keypress", ".hulkapps_discount_code", function(e) {
            13 == e.which && t(".hulkapps_discount_button").click()
        }), hulkapps_jQuery(document).on("blur", ".hulkapps_option_value [type='time']", function(e) {
            var i = t(this).attr("id"),
                a = t(this).attr("data-parent"),
                o = t(this).attr("data-pid"),
                n = t(this).attr("data-single_valid-class"),
                l = t(this).attr("data-val-selected-class"),
                s = t(this).data("price"),
                p = hulkapps_jQuery(this).val(),
                d = hulkapps_jQuery(this).attr("min"),
                u = hulkapps_jQuery(this).attr("max"),
                c = new Date("1970-01-01T" + p + ":00");
            if ("" != d) var f = new Date("1970-01-01T" + d + ":00");
            if ("" != u) var v = new Date("1970-01-01T" + u + ":00");
            if ("" != p) {
                if (c < f || c > v) {
                    hulkapps_jQuery(this).val("");
                    var m = "";
                    t(this).parent().find(".other_options_prop_val").val(""), t(this).removeClass(l), m = f && v ? "Please select a time between " + f.toLocaleTimeString([], {
                        timeStyle: "short"
                    }) + " and " + v.toLocaleTimeString([], {
                        timeStyle: "short"
                    }) + "." : f ? "Please select a time from " + f.toLocaleTimeString([], {
                        timeStyle: "short"
                    }) + "." : "Please select a time earlier than " + v.toLocaleTimeString([], {
                        timeStyle: "short"
                    }) + ".", hulkapps_jQuery(this).parent(".hulkapps_option_value").append("<span class='validation_error error_span' tabindex='0' aria-label='" + m + "'>" + m + "</span>");
                    var k = hulkapps_jQuery(this);
                    setTimeout(function() {
                        k.parent(".hulkapps_option_value").find(".validation_error").remove()
                    }, 3e3)
                } else {
                    if ("0.00" != s) var g = `${p} [ ${window.hulk_po_currency_symbol}${s} ]`;
                    else var g = p;
                    t(this).parent().find(".other_options_prop_val").val(g), t(this).addClass(l)
                }
            } else t(this).parent().find(".other_options_prop_val").val(""), t(this).removeClass(l);
            conditional_rules(parseInt(o), a), "1" == t("#hulk_amount_dis").val() && calc_options_total(parseInt(o), a), validate_single_option(`option_type_id_${i}`, n, a)
        }), hulkapps_jQuery(document).on("blur", ".hulkapps_option_value [type='date']", function(e) {
            var i = t(this).attr("id"),
                a = t(this).attr("data-parent"),
                o = t(this).attr("data-pid"),
                n = t(this).attr("data-single_valid-class"),
                l = t(this).attr("data-val-selected-class"),
                s = t(this).data("price"),
                p = hulkapps_jQuery(this).val(),
                d = hulkapps_jQuery(this).attr("min"),
                u = hulkapps_jQuery(this).attr("max"),
                c = new Date(p);
            if ("" != d) {
                var f = new Date(d).toISOString().split("T")[0];
                f = new Date(f)
            }
            if ("" != u) {
                var v = new Date(u).toISOString().split("T")[0];
                v = new Date(u)
            }
            if ("" != p) {
                if (c < f || c > v) {
                    hulkapps_jQuery(this).val("");
                    var m = "";
                    t(this).parent().find(".other_options_prop_val").val(""), t(this).removeClass(l), m = f && v ? "Please select a date between " + f.toISOString().split("T")[0] + " and " + v.toISOString().split("T")[0] + "." : f ? "Please select a time from " + f.toISOString().split("T")[0] + "." : "Please select a time earlier than " + v.toISOString().split("T")[0] + ".", hulkapps_jQuery(this).parent(".hulkapps_option_value").append("<span class='validation_error error_span' tabindex='0' aria-label='" + m + "'>" + m + "</span>");
                    var k = hulkapps_jQuery(this);
                    setTimeout(function() {
                        k.parent(".hulkapps_option_value").find(".validation_error").remove()
                    }, 3e3)
                } else {
                    if ("0.00" != s) var g = `${p} [ ${window.hulk_po_currency_symbol}${s} ]`;
                    else var g = p;
                    t(this).parent().find(".other_options_prop_val").val(g), t(this).addClass(l)
                }
            } else t(this).parent().find(".other_options_prop_val").val(""), t(this).removeClass(l);
            conditional_rules(parseInt(o), a), "1" == t("#hulk_amount_dis").val() && calc_options_total(parseInt(o), a), validate_single_option(`option_type_id_${i}`, n, a)
        }), t(document).on("click", ".hulkapps_discount_button", function(e) {
            e.preventDefault();
            var i = t(this).parents(".discount_code_box").find(".hulkapps_discount_code").val();
            "" == (i = t.trim(i)) ? t(".hulkapps_discount_code").addClass("discount_error"): (localStorage.setItem("discount_code", i), t(".hulkapps_discount_code").removeClass("discount_error")), window.getCartInfo()
        }), t(document).on("click", ".close-tag", function(e) {
            localStorage.removeItem("discount_code"), t(this).hasClass("product-close-tag") ? (t(".hulkapps-summary-product-line-discount-code, .product_after_discount_price").hide(), t(".hulkapps_discount_code").val("")) : window.getCartInfo()
        }), t(document).on("click", ".hulkapp_save", function(e) {
            e.preventDefault();
            var i = parseInt(t(this).parents(".hulkapp_popupBox").find(".hulkapp_mainContent").find(".h_index").val()) + 1,
                a = t(this).attr("data-quantity"),
                o = t(this).parents(".hulkapp_popupBox").find(".hulkapp_mainContent").find(".h_variant_id").val(),
                n = {};
            new Promise((e, i) => {
                var a = validate_options(t(this).data("product_id"), "hulkapps_edit_product_options", t(this).attr("data-quantity"));
                e(a)
            }).then(function(e) {
                if (e) {
                    if (t(checkout_selectors).attr("disabled", !0), t("#edit_cart_popup [name^='properties']").each(function(e, i) {
                            var a;
                            "" == t(this).val() && t(this).remove(), "radio" == this.type ? this.checked && (a = this.name.replace("properties[", "").replace("]", ""), t.trim(this.value).length > 0 && (n[a] = this.value)) : (this.type, a = this.name.replace("properties[", "").replace("]", ""), t.trim(this.value).length > 0 && (n[a] = this.value))
                        }), t.isEmptyObject(n)) "" != t(".upload_cls").val() ? t(".upload_h_cls").remove() : t(".upload_cls").remove(), t("#edit_cart_popup .conditional").each(function(e, i) {
                        t(this).find('.hulkapps_option_value input[type="hidden"]').val("")
                    }), t("[name^='properties']").each(function(e, i) {
                        "" == t(this).val() && t(this).remove()
                    }), t.ajax({
                        type: "POST",
                        url: "/cart/change.js",
                        data: {
                            quantity: 0,
                            line: i
                        },
                        dataType: "json",
                        success: function(e) {
                            "" != t(".upload_cls").val() ? t(".upload_h_cls").remove() : t(".upload_cls").remove(), t("#edit_cart_popup .conditional").each(function(e, i) {
                                t(this).find('.hulkapps_option_value input[type="hidden"]').val("")
                            }), t("[name^='properties']").each(function(e, i) {
                                "" == t(this).val() && t(this).remove()
                            }), t.ajax({
                                type: "POST",
                                url: "/cart/add.js",
                                data: {
                                    quantity: a,
                                    id: o
                                },
                                dataType: "json",
                                success: function(e) {
                                    window.currentEditOptionSelector.data("key", e.key), window.getCartInfo(e), t(".hulkapp_close").click()
                                }
                            })
                        }
                    });
                    else {
                        var l = new FormData(t("#edit_cart_popup")[0]);
                        l.append("quantity", a), l.append("line", i), "" != t(".upload_cls").val() ? t(".upload_h_cls").remove() : t(".upload_cls").remove(), t("#edit_cart_popup .conditional").each(function(e, i) {
                            t(this).find('.hulkapps_option_value input[type="hidden"]').val("")
                        }), t("[name^='properties']").each(function(e, i) {
                            "" == t(this).val() && t(this).remove()
                        }), t.ajax({
                            type: "POST",
                            url: "/cart/change.js",
                            data: {
                                quantity: 0,
                                line: i
                            },
                            dataType: "json",
                            success: function(e) {
                                "" != t(".upload_cls").val() ? t(".upload_h_cls").remove() : t(".upload_cls").remove(), t("#edit_cart_popup .conditional").each(function(e, i) {
                                    t(this).find('.hulkapps_option_value input[type="hidden"]').val("")
                                }), t("[name^='properties']").each(function(e, i) {
                                    "" == t(this).val() && t(this).remove()
                                }), t.ajax({
                                    type: "POST",
                                    url: "/cart/add.js",
                                    data: l,
                                    dataType: "json",
                                    contentType: !1,
                                    processData: !1,
                                    success: function(e) {
                                        window.currentEditOptionSelector.data("key", e.key), window.getCartInfo(e), t(".hulkapp_close").click()
                                    }
                                })
                            }
                        })
                    }
                }
            }).catch(function(t) {
                console.log(t)
            })
        }), t(document).on("click touchstart", ".hulkapp_close", function(e) {
            t(".edit_popup").hide(), t("body").removeClass("body_fixed")
        }), t(document).on("click touchstart", ".col_hulkapp_close", function(e) {
            t(".col_hulkapp_popupOverlay").hide(), t("body").removeClass("body_fixed")
        }), t(document).on("click touchstart", ".co_options_save", function(e) {
            var i = t(this).closest(".co_hulkapp_popup-footer").parents(".col_hulkapp_popupBox").find(".col_hulkapp_mainContent").find('input[name^="properties"][value!=""]');
            t(`.hulkapps-po-main_form_${window.hulkapps.product_id}`).find(`.hulkapps_po_properties_${window.hulkapps.product_id}`).remove(), t(`.hulkapps-po-main_form_${window.hulkapps.product_id}`).append(`<div class="hulkapps_po_properties_${window.hulkapps.product_id}"></div>`), i.each(function() {
                t(`.hulkapps_po_properties_${window.hulkapps.product_id}`).append(t(this).clone())
            }), t(".col_hulkapp_popupOverlay").hide(), t("body").removeClass("body_fixed")
        })
    }, window.productPageJS = function($) {
        function resolveInventory(t, e, i = "") {
            var i = i,
                a = {},
                o = !1;
            return !1 == e && (o = !0), new Promise((t, e) => {
                $.getJSON("/cart.js", {
                    _: new Date().getTime()
                }, function(e) {
                    e && e.item_count > 0 && e.items.forEach(function(t) {
                        var e = t.quantity;
                        null != t.properties && t.properties != {} && $.each(t.properties, function(t, i) {
                            if (t.startsWith("_hin") && i) {
                                if ((!0 == window.opt_with_otc[t] || "true" == window.opt_with_otc[t]) && (e = 1), i.includes(",")) i.split(",").forEach(function(i) {
                                    let o = i.split("_hin_")[0];
                                    var n = $.trim(i.split("_hin_")[1].split("|")[1]);
                                    n.includes(")") && (n = parseInt(n.split(")"))), n <= 0 && (n = 1), a[o = t + $.trim(o.split("[")[0])] ? a[o] = a[o] + e * n : a[o] = e * n
                                });
                                else {
                                    var o = $.trim(i.split("_hin_")[1].split("|")[1]);
                                    o.includes(")") && (o = parseInt(o.split(")"))), o <= 0 && (o = 1);
                                    let n = t + $.trim(i.split("_hin_")[0].split("[")[0]);
                                    a[n] ? a[n] = a[n] + e * o : a[n] = e * o
                                }
                            }
                        })
                    }), t(a)
                })
            }).then(function(a) {
                return $("." + t).find(".inventory_error").remove(), $("." + t).find(".hulk_unique_prop").each(function() {
                    var t = $(this).data("selection-multi"),
                        n = $(this).attr("data-inventory-record");
                    if (n && (n = n.split(",")), void 0 != t && !0 == t) {
                        var l = $(this),
                            s = $(this).val().split(", "),
                            p = e;
                        $.each(s, function(t, s) {
                            if ("" != s) {
                                var d = s.split("_hin_")[1];
                                d = parseInt(d);
                                var u = 1;
                                if ($("input[name=quantity]").val() && (u = parseInt($("input[name=quantity]").val())), !0 == window.opt_with_otc[l.data("unique_prop_name")] || "true" == window.opt_with_otc[l.data("unique_prop_name")]) var c = 1;
                                else if ("" != i) var c = parseInt(i);
                                else var c = u;
                                var f = 1;
                                n && (c = 1, $.each(n, function(t, e) {
                                    (e = e.split("_hin_"))[0] == s.split("_hin_")[0] && (f = parseInt(e[1]))
                                })), f <= 0 && (f = 1), c *= f;
                                let v = s.split("_hin_")[0];
                                if (a[v = l.attr("data-unique_prop_name") + $.trim(v.split("[")[0])]) {
                                    var m = a[v];
                                    c += parseInt(m)
                                }
                                if (m) var k = parseInt(d) - parseInt(m);
                                else var k = parseInt(d);
                                let g = $(".hulkapps_edit_product_options").find(`[data-uid='${v}']`);
                                g.length > 0 && (d += parseInt(g.attr("data-used_hinventory"))), d < c ? (p = !1, $(l).parents(".hulkapps_option").addClass("validation_error"), k > 0 ? $(l).parents(".hulkapps_option").append(`<p class="inventory_error" tabindex="0" aria-label="Only ${k} inventory available for this ${s.split("_hin_")[0]} option. </p>">Only ${k} inventory available for this ${s.split("_hin_")[0]} option. </p>`) : $(l).parents(".hulkapps_option").append(`<p class="inventory_error" tabindex="0" aria-label="Not enough items in the inventory for ${s.split("_hin_")[0]}.">Not enough items in the inventory for ${s.split("_hin_")[0]}. </p>`), o = !0, e = !1) : p && ($(l).parents(".hulkapps_option").removeClass("validation_error"), $(l).parents(".hulkapps_option").find(".inventory_error").remove(), o = !1, e = !0)
                            }
                        })
                    } else if ("" != $(this).val()) {
                        var d = $(this).val().split("_hin_")[1];
                        d = parseInt(d);
                        var u = 1;
                        if ($("input[name=quantity]").val() && (u = parseInt($("input[name=quantity]").val())), !0 == window.opt_with_otc[$(this).data("unique_prop_name")] || "true" == window.opt_with_otc[$(this).data("unique_prop_name")]) var c = 1;
                        else if ("" != i) var c = parseInt(i);
                        else var c = u;
                        var f = 1;
                        $(this).parents(".hulkapps_option_value").find(".hulk_options_quantity").length > 0 && (f = parseInt($(this).parents(".hulkapps_option_value").find(".hulk_options_quantity").val())) <= 0 && (f = 1), c *= f;
                        let v = $(this).val().split("_hin_")[0];
                        if (a[v = $(this).attr("data-unique_prop_name") + $.trim(v.split("[")[0])] && "" == i) {
                            var m = a[v];
                            c += parseInt(m)
                        }
                        if (m) var k = parseInt(d) - parseInt(m);
                        else var k = parseInt(d);
                        d < c ? ($(this).parents(".hulkapps_option").addClass("validation_error"), $(this).parents(".hulkapps_option").find(".inventory_error").remove(), k > 0 ? $(this).parents(".hulkapps_option").append(`<p class="inventory_error" tabindex="0" aria-label="Only ${k} inventory available for this ${$(this).val().split("_hin_")[0]} option.">Only ${k} inventory available for this ${$(this).val().split("_hin_")[0]} option. </p>`) : $(this).parents(".hulkapps_option").append(`<p class="inventory_error" tabindex="0" aria-label="Not enough items in the inventory for ${$(this).val().split("_hin_")[0]}">Not enough items in the inventory for ${$(this).val().split("_hin_")[0]}. </p>`), o = !0, e = !1) : !1 == e ? o = !0 : ($(this).parents(".hulkapps_option").find(".inventory_error").remove(), $(this).parents(".hulkapps_option").removeClass("validation_error"), e = !0, o = !1)
                    }
                }), !0 != o && e
            }).catch(function(t) {
                return !0
            })
        }
        $(document).on("click", ".hulkModalBtnSelect", function(t) {
            var e = $(this).attr("data-render-class"),
                i = $(this).attr("data-update-div-class"),
                a = $(this).attr("data-prop-class"),
                o = $(`.${e}`).html();
            if ($("body").find("#hulk_form_modal").remove(), $("body").prepend('<div id="hulk_form_modal" class="hulk_form_modal" data-option-id="multi_qty" style="display:none"><div class="hulk-modal-content"><div class="hulk-modal-header"><h6></h6><span class="close hulkcloseBtn">\xd7</span></div><div class="hulk-modal-body"></div><div class="hulk-modal-footer"><button class="hulkresetBtn">Reset</button><button class="hulkcloseBtn hulkCancelBtn">Cancel</button><button class="hulkSaveBtn">Continue</button></div></div></div>'), $(".hulk_form_modal").show(), $(".muti-qty-div").length > 0) {
                $(".hulk_form_modal").find(".hulk-modal-body").html(o), $(".hulk_form_modal").find(".hulk-modal-body").find(".hulkapps_option_value").removeClass("is_hulk_hide"), $(".hulk_form_modal").find(".hulk-modal-body").find(".hulkapps_option_value").find(".hulk_swatch_Image").removeClass("is_hulk_hide"), $(".hulk_form_modal").find(".hulk-modal-body").find(".hulk_swatch_desciption").removeClass("is_hulk_hide");
                var n = $(".hulk_form_modal").find(".hulk-modal-body").find(".hulkapps_option_name").find("div").text().trim(),
                    l = $(this).attr("data-selected-val");
                if (l && l.length > 0) {
                    var s = l.split(",");
                    $.each(s, function(t, e) {
                        var i = e.trim().split("|");
                        if (2 === i.length) {
                            var a = i[0].trim(),
                                o = i[1].trim(),
                                n = $(".hulk_form_modal").find('.hulk_quantity_amount[data-value="' + a + '"]');
                            n.length > 0 && (n.attr("data-qval", o), n.val(o))
                        }
                    })
                } else $(".hulk_quantity_amount").each(function(t, e) {
                    $(this).attr("data-qval", 0), $(this).val(0)
                });
                $(`#${a}`).val(l), $(".hulk_form_modal").find(".hulk-modal-header").find("h6").text(n), $(".hulk_form_modal").find(".hulk-modal-body").find(".hulkapps_option_name").hide(), $(".hulkSaveBtn").attr("data-get-class", a), $(".hulkSaveBtn").attr("data-prop-class", i), $(".hulk_form_modal").find(".hulk-modal-body").find(".hulk-custom-values-display").hide(), $(".hulk_swatch_desciption").each(function() {
                    var t = $(this),
                        e = t.find("p"),
                        i = t.find(".hulk-content-display");
                    e.prop("scrollHeight") > e.innerHeight() && i.show()
                })
            } else $(".hulk_form_modal").find(".hulk-modal-body").html("<p style='text-align: center;'>All products are out of stock</p>"), $(".hulkresetBtn").hide(), $(".hulkSaveBtn").hide()
        }), $(document).on("click", ".hulkresetBtn", function(t) {
            var e = $(".hulk_quantity_amount");
            e.attr("data-qval", 0), e.text(0), $(".hulk_unique_prop").val(""), $(".hulk_mutli_qty").val(""), $(".hulk_multi_qty_main").find(".hulk_unique_prop").removeClass("mqty_selected"), $(".hulk_multi_qty_main").find(".hulk_unique_prop").attr("data-price", 0)
        }), $(document).on("click", ".hulkcloseBtn", function(t) {
            $(".hulk_form_modal").hide(), $(".hulk_form_modal").find(".hulk-modal-body").html(""), $(".hulk_form_modal").find(".hulk-modal-header").find("h6").text("")
        }), $(document).on("click", ".hulk-content-display", function(t) {
            $(this).parent(".hulk_swatch_desciption").find("p").toggleClass("hulk-limited-height");
            var e = $(this).parent(".hulk_swatch_desciption").find("p").hasClass("hulk-limited-height") ? "See more" : "See less";
            $(this).parent(".hulk_swatch_desciption").find("a").text(e)
        }), $(document).on("click", ".hulkSaveBtn", function(t) {
            $(".hulk_form_modal").hide();
            var e = $(this).attr("data-get-class"),
                i = $(`#${e}`).val(),
                a = i.split(","),
                o = "";
            a.length > 0 && a.forEach(function(t) {
                o += `<span>${t=t.trim()}</span>`
            });
            var n = $(`#${e}`).parent(".hulk_multi_qty_main").find(".hulk_unique_prop").val(),
                l = $(`#${e}`).parent(".hulk_multi_qty_main").find(".hulk_unique_prop").attr("data-inventory-record"),
                s = $(`#${e}`).parent(".hulk_multi_qty_main").find(".hulk_unique_prop").attr("data-price"),
                p = $(this).attr("data-prop-class");
            $(`.${p}`).find(".hulkselectedValue").html(o), n.length > 0 ? $(`.${p}`).find("a").text(window.change_button_text) : $(`.${p}`).find("a").text(window.select_button_text), $(`.${p}`).find("a").attr("data-selected-val", i), $(".hulk_form_modal").find(".hulk-modal-body").html(""), $(`#${e}`).val(i), $(`#${e}`).parent(".hulk_multi_qty_main").find(".hulk_unique_prop").val(n), $(`#${e}`).parent(".hulk_multi_qty_main").find(".hulk_unique_prop").attr("data-inventory-record", l), parseFloat(s) > 0 ? ($(`#${e}`).parent(".hulk_multi_qty_main").find(".hulk_unique_prop").addClass("mqty_selected"), $(`#${e}`).parent(".hulk_multi_qty_main").find(".hulk_unique_prop").attr("data-price", s)) : ($(`#${e}`).parent(".hulk_multi_qty_main").find(".hulk_unique_prop").removeClass("mqty_selected"), $(`#${e}`).parent(".hulk_multi_qty_main").find(".hulk_unique_prop").attr("data-price", s)), "1" == $("#hulk_amount_dis").val() && calc_options_total(parseInt(window.hulkapps.product_id), "hulkapps_product_options"), conditional_rules(parseInt(window.hulkapps.product_id), "hulkapps_product_options")
        }), $(document).on("click", ".popup_open_link", function(t) {
            var e = $(this).attr("data-id");
            $("#popupdetailsdesing_" + e).css("display", "flex"), $(".overlay-popup").css("display", "block")
        }), $(document).on("click", ".popup_close_link", function(t) {
            var e = $(this).attr("data-id");
            $("#popupdetailsdesing_" + e).css("display", "none"), $(".overlay-popup").css("display", "none")
        }), $(document).on("click", ".recommended-link", function(t) {
            $("#recommended_detail select,#recommended_detail input[type='radio'],#recommended_detail input[type='checkbox'],.dropdown_swatch").prop("disabled", !0), $("#recommended_detail").css("display", "flex"), $(".overlay-popup").css("display", "block")
        }), $(document).on("click", ".recommended_close_link", function(t) {
            $("#recommended_detail").css("display", "none"), $(".overlay-popup").css("display", "none")
        }), window.conditional_rules = function(prod_id, hulkapps_parents = "") {
            var hulkapps_parents = hulkapps_parents;
            if ("" == hulkapps_parents && (hulkapps_parents = "hulkapps_product_options"), window.dynamic_checkout_button_integration && "hulkapps_product_options" == hulkapps_parents) {
                var i, total = 0,
                    is_variant_id_present = !1;
                for (window.hulkapps.money_format, checked_variant = $("." + hulkapps_parents + " #hulkapps_option_list_" + window.hulkapps.product_id + ":visible .price-change:checked, ." + hulkapps_parents + " #hulkapps_option_list_" + window.hulkapps.product_id + ":visible .price-change:selected, ." + hulkapps_parents + " .hulkapps_swatch_option .swatch_selected,." + hulkapps_parents + " .textarea_selected,." + hulkapps_parents + " .textbox_selected,." + hulkapps_parents + " .emailbox_selected,." + hulkapps_parents + " .datepicker_selected,." + hulkapps_parents + " .numberfield_selected,." + hulkapps_parents + " .colorpicker_selected,." + hulkapps_parents + " .button_selected,." + hulkapps_parents + " .googlefont_selected, ." + hulkapps_parents + " .ci_render .hulkapps_option_value .hulkapps_option_child .dropdown_selected, ." + hulkapps_parents + " .formula_selected,." + hulkapps_parents + " .stg_selected, ." + hulkapps_parents + " .mqty_selected"), i = 0; i < checked_variant.length; i++) $(checked_variant[i]).parents(".hulkapps_option").hasClass("conditional") || (total = Number($(checked_variant[i]).attr("data-price")) + Number(total), void 0 === $(checked_variant[i]).attr("data-variant-id") || null === $(checked_variant[i]).attr("data-variant-id") || (is_variant_id_present = !0));
                if (total > 0 || window.is_hulk_required_options || $(".fm_render").is(":visible") || is_variant_id_present || $(".file-upload.hulk-active").length > 0) {
                    var is_hulk_payment_set = !1;
                    let hulk_shopify_button = setInterval(function() {
                        $(".shopify-payment-button").length > 0 && ($(".shopify-payment-button").html().includes("ShopifyPay-button") || $(".shopify-payment-button").html().includes("Checkout-button") || $(".shopify-payment-button").html().includes("payment-button")) && ($(".hulk_buy_now_handle").length <= 0 ? ($(".shopify-payment-button").html().includes("ShopifyPay-button") ? $(".shopify-payment-button").wrap("<a class='hulk-buy_now hulk_buy_now_handle' data-testid='ShopifyPay-button'></div>") : $(".shopify-payment-button").html().includes("payment-button") ? $(".shopify-payment-button").wrap("<a class='hulk-buy_now hulk_buy_now_handle' data-testid='payment-button'></div>") : $(".shopify-payment-button").wrap("<a class='hulk-buy_now hulk_buy_now_handle' data-testid='Checkout-button'></div>"), $(".shopify-payment-button").css({
                            "pointer-events": "none"
                        })) : ($(".hulk_buy_now_handle").addClass("hulk-buy_now"), $(".shopify-payment-button").css({
                            "pointer-events": "none"
                        }))), is_hulk_payment_set = !0, clearInterval(hulk_shopify_button)
                    }, 1e3);
                    $(".shopify-payment-button").length > 0 && ($(".shopify-payment-button").html().includes("ShopifyPay-button") || $(".shopify-payment-button").html().includes("Checkout-button") || $(".shopify-payment-button").html().includes("payment-button")) && ($(".hulk_buy_now_handle").length <= 0 ? ($(".shopify-payment-button").html().includes("ShopifyPay-button") ? $(".shopify-payment-button").wrap("<a class='hulk-buy_now hulk_buy_now_handle' data-testid='ShopifyPay-button'></div>") : $(".shopify-payment-button").html().includes("payment-button") ? $(".shopify-payment-button").wrap("<a class='hulk-buy_now hulk_buy_now_handle' data-testid='payment-button'></div>") : $(".shopify-payment-button").wrap("<a class='hulk-buy_now hulk_buy_now_handle' data-testid='Checkout-button'></div>"), $(".shopify-payment-button").css({
                        "pointer-events": "none"
                    })) : ($(".hulk_buy_now_handle").addClass("hulk-buy_now"), $(".shopify-payment-button").css({
                        "pointer-events": "none"
                    })))
                } else $(".shopify-payment-button").css({
                    "pointer-events": "inherit"
                }), $(".hulk_buy_now_handle").removeClass("hulk-buy_now")
            }
            pass = !1, verify_all = [], verify_any = [], verified_condition = [], pass_array = [], $("." + hulkapps_parents).find(".condition_hide").removeClass("conditional"), $("." + hulkapps_parents).find(".condition_show").addClass("conditional"), $("." + hulkapps_parents + "  #conditional_rules").children().each(function() {
                pass_array = [], pass = !1;
                var conditional_count = $(this).children().length;
                $(this).children().each(function() {
                    pass = !1;
                    var field_value, condition_rule = $(this).text();
                    if (!0 == $("." + hulkapps_parents).find(".option_type_id_" + $(this).attr("data-field-num")).hasClass("dd_multi_render")) {
                        var aa = condition_rule;
                        aa.indexOf("!=") >= 0 && (pass = !0);
                        var count = $("." + hulkapps_parents).find(".hulkapps_option_" + $(this).attr("data-field-num") + "_visible:visible :selected").length,
                            ct = 1,
                            selected_array = [];
                        $("." + hulkapps_parents).find(".hulkapps_option_" + $(this).attr("data-field-num") + "_visible:visible :selected").length > 0 ? $("." + hulkapps_parents).find(".hulkapps_option_" + $(this).attr("data-field-num") + "_visible:visible :selected").each(function() {
                            var condition_rule = aa;
                            if (field_value = $(this).data("conditional-value"), (condition_rule = condition_rule.replace("**value11**", field_value)).indexOf("==") >= 0) {
                                var condition_rule = condition_rule.split("==");
                                pass = condition_rule[0] == condition_rule[1]
                            } else {
                                var condition_rule = condition_rule.split("!=");
                                pass = condition_rule[0] != condition_rule[1]
                            }
                            if (selected_array.push(pass), ct == count && count > 1) {
                                var result = selected_array.join(" || ");
                                result = eval(result), pass_array.push(result)
                            } else 1 == count && pass_array.push(pass);
                            ct += 1
                        }) : pass_array.push(!1)
                    } else if (!0 == $(".option_type_id_" + $(this).attr("data-field-num")).hasClass("cb_render")) {
                        var aa = condition_rule;
                        aa.indexOf("!=") >= 0 && (pass = !0);
                        var ctt = 1,
                            checked_array = [],
                            countt = $("." + hulkapps_parents).find(".hulkapps_option_" + $(this).attr("data-field-num") + "_visible:checked").length;
                        $("." + hulkapps_parents).find(".hulkapps_option_" + $(this).attr("data-field-num") + "_visible:checked").each(function() {
                            var condition_rule = aa;
                            if (field_value = $(this).data("conditional-value"), (condition_rule = condition_rule.replace("**value11**", field_value)).indexOf("==") >= 0) {
                                var condition_rule = condition_rule.split("==");
                                pass = condition_rule[0] == condition_rule[1]
                            } else {
                                var condition_rule = condition_rule.split("!=");
                                pass = condition_rule[0] != condition_rule[1]
                            }
                            if (checked_array.push(pass), ctt == countt && countt > 1) {
                                var result = checked_array.join(" || ");
                                result = eval(result), pass_array.push(result)
                            } else 1 == countt && pass_array.push(pass);
                            ctt += 1
                        })
                    } else if (!0 == $("." + hulkapps_parents).find("#hulkapps_option_list_" + prod_id + " .option_type_id_" + $(this).attr("data-field-num")).hasClass("multiswatch_render")) {
                        var aa = condition_rule;
                        aa.indexOf("!=") >= 0 && (pass = !0);
                        var ctt = 1,
                            checked_array = [],
                            countt = $("." + hulkapps_parents).find("#hulkapps_option_list_" + prod_id + " .hulkapps_option_" + $(this).attr("data-field-num") + "_visible:checked").length;
                        $("." + hulkapps_parents).find("#hulkapps_option_list_" + prod_id + " .hulkapps_option_" + $(this).attr("data-field-num") + "_visible:checked").each(function() {
                            var condition_rule = aa;
                            if (field_value = $(this).data("conditional-value"), (condition_rule = condition_rule.replace("**value11**", field_value)).indexOf("==") >= 0) {
                                var condition_rule = condition_rule.split("==");
                                pass = condition_rule[0] == condition_rule[1]
                            } else {
                                var condition_rule = condition_rule.split("!=");
                                pass = condition_rule[0] != condition_rule[1]
                            }
                            if (checked_array.push(pass), ctt == countt && countt > 1) {
                                var result = checked_array.join(" || ");
                                result = eval(result), pass_array.push(result)
                            } else 1 == countt && pass_array.push(pass);
                            ctt += 1
                        })
                    } else {
                        if (pass = !1, !0 == $("." + hulkapps_parents).find(".option_type_id_" + $(this).attr("data-field-num")).hasClass("ci_render")) field_value = $("." + hulkapps_parents).find("#" + $(this).attr("data-field-num")).find(".dropdown_selected").attr("data-conditional-value");
                        else if (!0 == $("." + hulkapps_parents).find(".option_type_id_" + $(this).attr("data-field-num")).hasClass("dd_render")) field_value = $("." + hulkapps_parents).find("#" + $(this).attr("data-field-num") + " option:selected").attr("data-conditional-value");
                        else if (!0 == $("." + hulkapps_parents).find(".option_type_id_" + $(this).attr("data-field-num")).hasClass("rb_render")) field_value = $("." + hulkapps_parents).find(".hulkapps_option_" + $(this).attr("data-field-num") + ":checked").data("conditional-value");
                        else if (!0 == $("." + hulkapps_parents).find(".option_type_id_" + $(this).attr("data-field-num")).hasClass("swatch_render")) field_value = $("." + hulkapps_parents).find(".hulkapps_option_" + $(this).attr("data-field-num") + ".swatch_selected").data("conditional-value");
                        else if (!0 == $("." + hulkapps_parents).find(".option_type_id_" + $(this).attr("data-field-num")).hasClass("button_render")) field_value = $("." + hulkapps_parents).find(".hulkapps_option_" + $(this).attr("data-field-num") + ".button_selected").data("conditional-value");
                        else if (!0 == $("." + hulkapps_parents).find(".option_type_id_" + $(this).attr("data-field-num")).hasClass("dp_render")) {
                            if (void 0 != (field_value = $("." + hulkapps_parents).find(".hulkapps_option_" + $(this).attr("data-field-num") + ".datepicker_selected").val())) {
                                var splitedValues = field_value.split("-");
                                field_value = splitedValues[1] + "/" + splitedValues[2] + "/" + splitedValues[0]
                            }
                        } else field_value = !0 == $("." + hulkapps_parents).find(".option_type_id_" + $(this).attr("data-field-num")).hasClass("dt_render") ? $("." + hulkapps_parents).find(".hulkapps_option_" + $(this).attr("data-field-num") + ".datetimepicker_selected").val() : $("." + hulkapps_parents).find("#" + $(this).attr("data-field-num")).val();
                        if ((condition_rule = condition_rule.replace("**value11**", field_value)).indexOf("==") >= 0) {
                            var condition_rule = condition_rule.split("==");
                            pass = condition_rule[0] == condition_rule[1]
                        } else {
                            var condition_rule = condition_rule.split("!=");
                            pass = condition_rule[0] != condition_rule[1]
                        }
                        pass_array.push(pass)
                    }
                });
                var type_rule = $(this).attr("data-verify-all"),
                    condition_id = $(this).attr("name");
                if ("0" == type_rule) var res = pass_array.join(" || ");
                else if (pass_array.length == conditional_count) var res = pass_array.join(" && ");
                (res = eval(res)) && ($("." + hulkapps_parents).find("." + condition_id + "_show").removeClass("conditional"), $("." + hulkapps_parents).find("." + condition_id + "_show .formula_selected").removeAttr("disabled"), $("." + hulkapps_parents).find("." + condition_id + "_hide").addClass("conditional"), $("." + hulkapps_parents).find(".conditional").removeClass("validation_error"))
            }), $("." + hulkapps_parents + " #conditional_rules").children().each(function() {
                var t = $(this).attr("name"),
                    e = $("." + hulkapps_parents).find("." + t + "_hide.conditional"),
                    i = $("." + hulkapps_parents).find("." + t + "_show.conditional");
                e.each(function() {
                    var t = $(this).hasClass("price-change"),
                        e = $(this);
                    t ? $(this).parent(".hulkapps_option_child").each(function() {
                        "UL" == $(this).prop("tagName") ? $(this).children(".dropdown_selected").data("value") == e.data("value") && conditional_change($(this), hulkapps_parents, prod_id) : $(this).val().includes(e.val()) && conditional_change($(this), hulkapps_parents, prod_id)
                    }) : $(this).find(".hulkapps_option_child").each(function() {
                        conditional_change($(this), hulkapps_parents, prod_id)
                    })
                }), i.each(function() {
                    var t = $(this).hasClass("price-change"),
                        e = $(this);
                    t ? $(this).parent(".hulkapps_option_child").each(function() {
                        "SELECT" == $(this).prop("tagName") ? $(this).val() == e.val() && conditional_change($(this), hulkapps_parents, prod_id) : $(this).val().includes(e.val()) && conditional_change($(this), hulkapps_parents, prod_id)
                    }) : $(this).find(".hulkapps_option_child").each(function() {
                        conditional_change($(this), hulkapps_parents, prod_id)
                    })
                })
            }), $("option.condition_hide").each(function() {
                $(this).hasClass("conditional") ? $(this).prop("disabled", !0) : $(this).removeAttr("disabled")
            }), $("option.condition_show").each(function() {
                $(this).hasClass("conditional") ? $(this).prop("disabled", !0) : $(this).removeAttr("disabled")
            }), calc_options_total(prod_id, hulkapps_parents), calc_options_total(prod_id, hulkapps_parents)
        }, window.conditional_change = function(t, e, i) {
            if ("select-one" == t.prop("type")) t.val() && (t.val("").change(), t.parent().find(".hulk_unique_sku").prop("disabled", "true"), t.parent().removeClass("selected"));
            else if ("select-multiple" == t.prop("type")) t.val() && (t.parent().find(".hulk_unique_sku").prop("disabled", "true"), t.val(""), t.parent(".hulkapps_option_value").find("input[type=hidden]").val(""), t.parent().removeClass("selected"));
            else if ("radio" == t.prop("type")) t.prop("checked") && (t.parents(".hulkapps_option_value").find(".hulk_radiobutton_hidden_prop").val(""), t.parents(".hulkapps_option_value").find(".hulk_unique_prop").val(""), t.prop("checked", !1), t.parent().find(".radio_selected").removeClass("radio_selected"), t.parent("label").find(".hulk_unique_sku").prop("disabled", "true"), t.change());
            else if ("file" == t.prop("type")) t.val(""), t.parent(".hulkapps_option_value").find(".upload_h_cls").val("");
            else if ("text" == t.prop("type") && t.parents(".hulkapps_option").hasClass("gf_render")) t.val() && (t.parents(".hulkapps_option_value").find(".gf_property_val").val(""), t.parents(".hulkapps_option_value").find("#valid-msg").remove());
            else if ("hidden" == t.prop("type") && t.parents(".hulkapps_option").hasClass("fm_render")) t.parents(".hulkapps_option").hasClass("conditional") ? t.attr("disabled", "disabled") : t.removeAttr("disabled");
            else if ("textarea" == t.prop("type") || "number" == t.prop("type") || "text" == t.prop("type") || "hidden" == t.prop("type") || "file" == t.prop("type") || "email" == t.prop("type")) t.val() && (t.val("").change(), t.parents(".hulkapps_option_value").find(".tb_property_val").val(""), t.parents(".hulkapps_option_value").find("#valid-msg").remove());
            else if ("color" == t.prop("type") || "color_picker" == t.prop("type")) t.val() && (t.parents(".hulkapps_option_value").find(".cp_property_val").val(""), t.parents(".hulkapps_option_value").find("#valid-msg").remove());
            else if ("date" == t.prop("type") || "date_picker" == t.prop("type")) t.val() && (t.val("").change(), t.parents(".hulkapps_option_value").find(".dp_property_val").val(""), t.parents(".hulkapps_option_value").find("#valid-msg").remove());
            else if ("time" == t.prop("type") || "date_picker" == t.prop("type")) t.val() && (t.val("").change(), t.parents(".hulkapps_option_value").find(".dp_property_val").val(""), t.parents(".hulkapps_option_value").find("#valid-msg").remove());
            else if ("checkbox" == t.prop("type")) t.prop("checked") && (t.prop("checked", !1).change(), t.parent().removeClass("swatch_selected"));
            else if ("DIV" == t.prop("tagName")) {
                if (t.find(".swatch_radio").prop("checked") && (t.find(".swatch_radio").prop("checked", !1), t.find(".swatch_radio").removeAttr("checked"), t.parents(".hulkapps_option_value").find(".hulk_swatch_hidden_prop").val(""), t.parents(".hulkapps_option_value").find(".hulk_unique_prop").val(""), t.removeClass("swatch_selected"), t.parents("label").find(".hulk_unique_sku").prop("disabled", "true"), conditional_rules(i, e)), t.find(".button_radio").prop("checked") && (t.parents(".hulkapps_option_value").find(".hulk_button_hidden_prop").val(""), t.parents(".hulkapps_option_value").find(".hulk_unique_prop").val(""), t.find(".button_radio").removeAttr("checked"), t.removeClass("button_selected"), t.parents("label").find(".hulk_unique_sku").prop("disabled", "true")), t.find(".swatch_checkbox").prop("checked")) {
                    t.find(".swatch_checkbox").prop("checked", !1), conditional_rules(i, e);
                    var a = t.parent().parent().parent().parent(".hulkapps_option_value"),
                        o = [];
                    a.find("input[type=checkbox]:checked").each(function() {
                        o.push($(this).val())
                    }), a.find("input[type=hidden]").not(".hulk_unique_sku").val(o.join(",")), t.removeClass("swatch_selected"), t.parents("label").find(".hulk_unique_sku").prop("disabled", "true")
                }
            } else if ("UL" == t.prop("tagName")) {
                if (t.find(".hulk_unique_sku").prop("disabled", "true"), t.find(".dropdown_selected").length > 0) {
                    var n = t.parents(".ci_render").find(".hulkapps_option_name").attr("data-option-name");
                    t.find(".init").html("").html("Choose " + n), t.find(".dropdown_selected").removeClass("dropdown_selected"), t.parent(".hulkapps_option_value").find(".hulk_opt_prop").val(""), t.parent(".hulkapps_option_value").find(".hulk_unique_prop").val(""), t.find(".hulk_unique_sku").prop("disabled", "false"), conditional_rules(t.attr("data-pid"), t.attr("data-parent"))
                }
            } else if ("LABEL" == t.prop("tagName")) {
                if (t.find(".swatch_radio").prop("checked") && (t.find(".swatch_radio").prop("checked", !1).change(), t.find(".swatch_radio").removeAttr("checked"), t.removeClass("swatch_selected"), t.parents("label").find(".hulk_unique_sku").prop("disabled", "true")), t.find(".button_radio").prop("checked") && (t.find(".button_radio").prop("checked", !1).change(), t.find(".button_radio").removeAttr("checked"), t.removeClass("button_selected"), t.parents("label").find(".hulk_unique_sku").prop("disabled", "true")), t.find(".swatch_checkbox").prop("checked")) {
                    t.find(".swatch_checkbox").prop("checked", !1);
                    var a = t.parent(".hulkapps_option_value"),
                        o = [];
                    a.find("input[type=checkbox]:checked").each(function() {
                        o.push($(this).val())
                    }), a.find("input[type=hidden]").val(o.join(",")), t.removeClass("swatch_selected")
                }
            } else "button" == t.prop("type") && t.parent().find(".hulk_quantity_amount").attr("data-qval") && (t.parent().find(".hulk_quantity_amount").attr("data-qval", "0"), t.parent().find(".hulk_quantity_amount").text("0"), t.parents(".muti-qty-div").parent(".hulk_multi_qty_main").find(".hulk_unique_prop").removeClass("mqty_selected"), t.parents(".muti-qty-div").parent(".hulk_multi_qty_main").find(".hulk_unique_prop").val(""), t.parents(".muti-qty-div").parent(".hulk_multi_qty_main").find(".hulk_unique_prop").removeAttr("data-inventory-record"), t.parents(".muti-qty-div").parent(".hulk_multi_qty_main").find(".hulk_unique_prop").removeAttr("data-price"), t.parents(".muti-qty-div").parent(".hulk_multi_qty_main").find(".hulk_mutli_qty").val(""), t.parents(".muti-qty-div").parent(".hulk_multi_qty_main").parents(".mq_render").find(".inventory_error").remove(), t.parents(".muti-qty-div").parent(".hulk_multi_qty_main").parents(".mq_render").removeClass("validation_error"))
        }, window.calc_options_total = function(t, e = "") {
            if ("price_addtional_charge" == (price_setting = display_price_setting.price_setting) || "price_total_charge" == price_setting || "price_append" == price_setting || "price_addtional_charge_beside_price" == price_setting || 1 == display_price_setting.amount_note_display && void 0 == price_setting) {
                var i, e = e;
                "" == e && (e = "hulkapps_product_options");
                var a = 0;
                for (window.hulkapps.money_format, checked_variant = $("." + e + " #hulkapps_option_list_" + t + ":visible .price-change:checked, ." + e + " #hulkapps_option_list_" + t + ":visible .price-change:selected, ." + e + " .hulkapps_swatch_option .swatch_selected,." + e + " .textarea_selected,." + e + " .textbox_selected,." + e + " .emailbox_selected,." + e + " .datepicker_selected,." + e + " .numberfield_selected,." + e + " .colorpicker_selected,." + e + " .button_selected,." + e + " .googlefont_selected, ." + e + " .datetimepicker_selected,." + e + " .ci_render .hulkapps_option_value .hulkapps_option_child .dropdown_selected, ." + e + " .formula_selected,." + e + " .stg_selected, ." + e + " .mqty_selected"), i = 0; i < checked_variant.length; i++)
                    if (!$(checked_variant[i]).parents(".hulkapps_option").hasClass("conditional")) {
                        var o = 1;
                        if ($(checked_variant[i]).parents(".hulkapps_option_value").find(".hulk_options_quantity").length > 0) var o = parseInt($(checked_variant[i]).parents(".hulkapps_option").find(".hulk_options_quantity").val());
                        a = Number($(checked_variant[i]).attr("data-price") * o) + Number(a)
                    }
                if ("price_total_charge" == price_setting && (a = Number(product_price / 100) + Number(a)), "price_append" == price_setting && (n = display_price_setting.price_class, a = currency_conversion(Number(product_price / 100) + Number(a)), n.length > 0 && n.split(",").forEach(t => {
                        t = $.trim(t), $("#" + t).length > 0 ? $("#" + t).html("<span class='money'>" + a + "</span>") : $("." + t).length > 0 && $("." + t).html("<span class='money'>" + a + "</span>")
                    }), a = 0), "price_addtional_charge_beside_price" == price_setting) {
                    if (a > 0) {
                        a = currency_conversion(Number(a));
                        var n = display_price_setting.price_class,
                            l = "1" == display_price_setting.price_display_brackets ? "" : "(",
                            s = "1" == display_price_setting.price_plus_sign ? "" : "+",
                            p = "1" == display_price_setting.price_display_brackets ? "" : ")",
                            d = ".hulk_price_addtional_charge_beside_price{";
                        d += void 0 != display_price_setting.addition_price_font_color ? "color: " + display_price_setting.addition_price_font_color + ";" : "", d += void 0 != display_price_setting.addition_price_font_size ? "font-size: " + display_price_setting.addition_price_font_size + "px;" : "";
                        var u = "<style>" + (d += "}") + "</style>";
                        $("." + e).append(u), n.length > 0 && n.split(",").forEach(t => {
                            t = $.trim(t), $("#" + t).length > 0 ? $("#" + t).html("<span class='money hulk_price_addtional_charge_beside_price'>" + l + s + a + p + "</span>") : $("." + t).length > 0 && $("." + t).html("<span class='money hulk_price_addtional_charge_beside_price'>" + l + s + a + p + "</span>")
                        })
                    } else {
                        var n = display_price_setting.price_class;
                        n.length > 0 && n.split(",").forEach(t => {
                            t = $.trim(t), $("#" + t).html(""), $("." + t).html("")
                        })
                    }
                    a = 0
                }
                $("." + e + " #raw_option_total").val(a), $("." + e + " #calculated_option_total").html(a.toFixed(2)), $("." + e + " #option_display_total_format").attr("aria-label", $("." + e + " #option_display_total_format").text()), a > 0 ? $("." + e + " #option_total").slideDown() : $("." + e + " #option_total").slideUp()
            }
        }, window.currency_conversion = function(t) {
            let e = window.hulkapps.money_format;
            if (t = Number(t), e.includes("{{ amount }}") || e.includes("{{amount}}")) return (t = t.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","), e.includes("{{ amount }}")) ? e.replace("{{ amount }}", t) : e.replace("{{amount}}", t);
            if (e.includes("{{ amount_no_decimals }}") || e.includes("{{amount_no_decimals}}")) return (t = Math.round(Number(t)).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","), e.includes("{{ amount_no_decimals }}")) ? e.replace("{{ amount_no_decimals }}", t) : e.replace("{{amount_no_decimals}}", t);
            if (e.includes("{{ amount_with_comma_separator }}") || e.includes("{{amount_with_comma_separator}}")) {
                if ((t = t.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ".")).includes(".")) {
                    let i = t.lastIndexOf(".");
                    t = t.slice(0, i) + "," + t.slice(i + 1)
                } else t = t.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                return e.includes("{{ amount_with_comma_separator }}") ? e.replace("{{ amount_with_comma_separator }}", t) : e.replace("{{amount_with_comma_separator}}", t)
            }
            if (e.includes("{{ amount_no_decimals_with_comma_separator }}") || e.includes("{{amount_no_decimals_with_comma_separator}}")) return (t = Math.round(Number(t)).toString().replace(/\B(?=(\d{3})+(?!\d))/g, "."), e.includes("{{ amount_no_decimals_with_comma_separator }}")) ? e.replace("{{ amount_no_decimals_with_comma_separator }}", t) : e.replace("{{amount_no_decimals_with_comma_separator}}", t);
            if (!(e.includes("{{ amount_with_apostrophe_separator }}") || e.includes("{{amount_with_apostrophe_separator}}"))) return t;
            else return (t = t.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, "'"), e.includes("{{ amount_with_apostrophe_separator }}")) ? e.replace("{{ amount_with_apostrophe_separator }}", t) : e.replace("{{amount_with_apostrophe_separator}}", t)
        }, window.checkPlan = function(t, e) {
            var i = !0,
                a = window.hulk_po_plan_id,
                o = window.hulk_po_plans_features,
                n = window.hulk_po_is_on_trial_period;
            return t && e && o && a && o[a] ? ("string" == $.type(o) && (o = JSON.parse(o)), !1 == o[a][t] && "boolean" == e && (i = !1), !0 == n && !0 == o[a][t] && (i = !0)) : i = !1, i
        }, window.oldStore = function() {
            var t = !1;
            return Date.parse(window.store_created_date) < Date.parse("08/27/2023") && (t = !0), t
        }, $(document).on("click", ".hulkappsGetOptions", function(t) {
            window.hulkapps.store_id && (window.hulkapps.product_id = $(this).attr("data-product-id"), window.hulkapps.product = {}, $(this).attr("data-product-tags") && (window.hulkapps.product.tags = $(this).attr("data-product-tags").split(",")), window.hulkapps.product.vendor = $(this).attr("data-product-vendor"), window.hulkapps.product.type = $(this).attr("data-product-type"), window.hulkapps.product_collections = $(this).attr("data-product-collections"), productPageAjax($, "is_collection_page"))
        }), window.check_character_limit = function(t, e, i, a = "") {
            var a = a;
            "" == a && (a = "hulkapps_product_options");
            var o = $("." + a + " .hulkapps_option_value .hulkapps_option_" + e).val().length,
                n = t - o;
            $("." + a + " #char_count_" + e).html(n + " " + i)
        }, window.requireInventory = async function(t, e) {
            $("." + e).find("#hulkapps_option_list_" + t + ":visible .dd_render.required:visible,.dd_multi_render.required:visible,.swatch_render.required:visible,.cb_render.required:visible,.multiswatch_render.required:visible,.ci_render.required:visible,.rb_render.required:visible,.button_render.required:visible").each(function() {
                if ($(this).hasClass("ci_render")) {
                    var t = $(this).find("li[value !='']").length,
                        e = $(this).find("li[value !=''].is_hulk_disabled").length;
                    t == e && ($(this).removeClass("required"), $(this).find(".hulkapps-required").remove())
                } else if (($(this).hasClass("dd_render") || $(this).hasClass("dd_multi_render")) && !$(this).hasClass("ci_render")) {
                    var t = $(this).find("option[value !='']").length,
                        e = $(this).find("option[value !='']:disabled").length;
                    t == e && ($(this).removeClass("required"), $(this).find(".hulkapps-required").remove())
                } else if ($(this).hasClass("multiswatch_render")) {
                    var t = $(this).find(".hulkapps_mswatch_option").length,
                        e = $(this).find(".hulkapps_mswatch_option input[type='checkbox']:disabled").length;
                    t == e && ($(this).removeClass("required"), $(this).find(".hulkapps-required").remove())
                } else if ($(this).hasClass("swatch_render")) {
                    var t = $(this).find(".hulkapps_swatch_option").length,
                        e = $(this).find(".hulkapps_swatch_option input[type='radio']:disabled").length;
                    t == e && ($(this).removeClass("required"), $(this).find(".hulkapps-required").remove())
                } else if ($(this).hasClass("rb_render")) {
                    var t = $(this).find(".hulkapps_radio_option").length,
                        e = $(this).find(".hulkapps_radio_option input[type='radio']:disabled").length;
                    t == e && ($(this).removeClass("required"), $(this).find(".hulkapps-required").remove())
                } else if ($(this).hasClass("cb_render")) {
                    var t = $(this).find(".hulkapps_check_option").length,
                        e = $(this).find(".hulkapps_check_option input[type='checkbox']:disabled").length;
                    t == e && ($(this).removeClass("required"), $(this).find(".hulkapps-required").remove())
                } else if ($(this).hasClass("button_render")) {
                    var t = $(this).find(".hulkapps_buton_option").length,
                        e = $(this).find(".hulkapps_buton_option input[type='radio']:disabled").length;
                    t == e && ($(this).removeClass("required"), $(this).find(".hulkapps-required").remove())
                }
            })
        }, window.validate_options = async function(t, e, i = "") {
            if (!window.is_hulkpo_installed) return !0;
            var a, i = i,
                e = e;
            ("" == e || void 0 == e) && (e = "hulkapps_product_options");
            var o = !0;
            $("." + e + " #error_text").html("");
            var n = $("." + e).find("#hulkapps_option_list_" + t + ":visible .required:visible");
            for (a = 0; a < n.length; a++) $(n[a]).hasClass("ci_render") && $(n[a]).find(".hulk_opt_prop").length && !$(n[a]).find(".hulk_opt_prop").val() ? ($(n[a]).addClass("validation_error"), o = !1) : $(n[a]).hasClass("dd_render") && $(n[a]).find(".hulk_dropdown_hidden_prop").length && !$(n[a]).find(".hulk_dropdown_hidden_prop").val() ? ($(n[a]).addClass("validation_error"), o = !1) : 1 != hulkapps_jQuery(n[a]).find("select[name^='properties']").length || hulkapps_jQuery(n[a]).find("select[name^='properties']").val() ? hulkapps_jQuery(n[a]).find(".hulkapps_option_value").find("input[name^='properties']").length >= 1 && !hulkapps_jQuery(n[a]).find(".hulkapps_option_value").find("input[name^='properties']:not(.hulk_unique_prop)").val() ? (hulkapps_jQuery(n[a]).addClass("validation_error"), o = !1) : $(n[a]).find(".hulkapps_radio_option").length && !$(n[a]).find(".hulk_radiobutton_hidden_prop").val() ? ($(n[a]).addClass("validation_error"), o = !1) : $(n[a]).find(".hulkapps_buton_option").length && !$(n[a]).find(".hulk_button_hidden_prop").val() ? ($(n[a]).addClass("validation_error"), o = !1) : $(n[a]).find(".hulkapps_swatch_option").length && !$(n[a]).find(".hulk_swatch_hidden_prop").val() ? ($(n[a]).addClass("validation_error"), o = !1) : $(n[a]).find(".hulkapps_short_option_value").length ? $(n[a]).find("input[type='text']").each(function() {
                "" != $(this).val() || $(this).parents(".hulkapps_short_option_value").hasClass("conditional") || ($(n[a]).addClass("validation_error"), o = !1)
            }) : $(n[a]).find("input[type='text']").length > 1 ? $(n[a]).find("input[type='text']").each(function() {
                "" == $(this).val() && ($(n[a]).addClass("validation_error"), o = !1)
            }) : $(n[a]).find("input[type='text']").length && !$(n[a]).find("input[name^='properties']").val() ? ($(n[a]).addClass("validation_error"), o = !1) : $(n[a]).find("input[type='email']").length && !$(n[a]).find("input[name^='properties']").val() ? ($(n[a]).addClass("validation_error"), o = !1) : $(n[a]).find("input[type='color']").length && !$(n[a]).find("input[name^='properties']").val() ? ($(n[a]).addClass("validation_error"), o = !1) : $(n[a]).find(".hulkapps_check_option").length && !$(n[a]).find("input[name^='properties']:not(.hulk_unique_sku)").val() ? ($(n[a]).addClass("validation_error"), o = !1) : $(n[a]).find("input[type='file']").length && !$(n[a]).find("input[name^='properties']").val() ? ($(n[a]).addClass("validation_error"), o = !1) : $(n[a]).hasClass("cb_render") && $(n[a]).find("input[type='checkbox']:checked").length && !$(n[a]).find("input[name^='properties']:not(.hulk_unique_sku,.hulk_unique_prop)").length ? ($(n[a]).addClass("validation_error"), o = !1) : $(n[a]).hasClass("multiswatch_render") && $(n[a]).find("input[type='checkbox']:checked").length && !$(n[a]).find("input[name^='properties']:not(.hulk_unique_sku)").length ? ($(n[a]).addClass("validation_error"), o = !1) : $(n[a]).find("textarea").length && !$(n[a]).find("input[name^='properties']").val() ? ($(n[a]).addClass("validation_error"), o = !1) : $(n[a]).find("select[multiple]").length >= 1 && !$(n[a]).find("input[name^='properties']:not(.hulk_unique_sku)").val() ? ($(n[a]).addClass("validation_error"), o = !1) : !$(n[a]).find("input[type='number']:not(.hulk_options_quantity)").length || $(n[a]).find("input[name^='properties']").val() || $(n[a]).hasClass("mq_render") ? $(n[a]).hasClass("dp_render") && $(n[a]).find("input[type='date']").length && !$(n[a]).find("input[name^='properties']").val() ? ($(n[a]).addClass("validation_error"), o = !1) : $(n[a]).hasClass("dt_render") && $(n[a]).find("input[type='time']").length && !$(n[a]).find("input[name^='properties']").val() ? ($(n[a]).addClass("validation_error"), o = !1) : hulkapps_jQuery(n[a]).find(".hulkapps_option_value").find("input[name^='properties']").length >= 1 && !hulkapps_jQuery(n[a]).find(".hulkapps_option_value").find("input[name^='properties']:not(.hulk_unique_prop)").val() ? (hulkapps_jQuery(n[a]).addClass("validation_error"), o = !1) : ($(n[a]).removeClass("validation_error"), $(n[a]).find(".validation_error.error_span").remove(), $(n[a]).removeAttr("aria-label tabindex")) : ($(n[a]).addClass("validation_error"), o = !1) : (hulkapps_jQuery(n[a]).addClass("validation_error"), o = !1);
            return $("." + e).find("#hulkapps_option_list_" + t + " .cb_render:visible").each(function() {
                var t = parseInt($(this).attr("data-min")),
                    e = parseInt($(this).attr("data-max")),
                    i = $(this).find("input[type='checkbox']:checked").length,
                    a = '<span class="validation_error error_span" tabindex="0" >';
                $(this).hasClass("required") && 0 == i && $(this).append(a), 0 != t && 0 != e ? i < t ? ($(this).removeClass("validation_error").find(".error_span").remove(), $(this).append(`${a} Choose from ${t} to ${e} values</span>`), $(this).find(".validation_error").attr("aria-label", `Choose from ${t} to ${e} values`), 0 == i && $(this).hasClass("required") ? $(this).addClass("validation_error") : 0 == i && $(this).removeClass("validation_error").find(".error_span").remove()) : i > e ? ($(this).removeClass("validation_error").find(".error_span").remove(), $(this).append(`${a} Choose from ${t} to ${e} values</span>`), $(this).find(".validation_error").attr("aria-label", `Choose from ${t} to ${e} values`)) : $(this).removeClass("validation_error").find(".error_span").remove() : 0 != t ? i < t ? ($(this).removeClass("validation_error").find(".error_span").remove(), $(this).append(`${a} Choose at least  ${t} values</span>`), $(this).find(".validation_error").attr("aria-label", `Choose at least  ${t} values`)) : $(this).removeClass("validation_error").find(".error_span").remove() : 0 != e && (e >= i ? e == i ? $(this).removeClass("validation_error").find(".error_span").remove() : ($(this).removeClass("validation_error").find(".error_span").remove(), $(this).append(`${a} Choose upto ${e} values</span>`), $(this).find(".validation_error").attr("aria-label", `Choose upto ${e} values`)) : $(this).removeClass("validation_error").find(".error_span").remove()), $(this).find(".error_span").length > 0 ? ($(this).addClass("validation_error"), o = !1) : ($(this).removeClass("validation_error"), $(this).removeAttr("aria-label tabindex")), $(this).hasClass("required") || 0 != i || ($(this).removeClass("validation_error"), $(this).removeAttr("aria-label tabindex"), $(this).find(".validation_error.error_span").remove(), o = !0)
            }), $("." + e).find("#hulkapps_option_list_" + t + " .multiswatch_render:visible").each(function() {
                $(this).hasClass("required") && $(this).find("input[type='checkbox']").length ? $(this).find("input[name^='properties']:not(.hulk_unique_sku)").val() ? $(this).find(".error_span").length > 0 ? ($(this).addClass("validation_error"), o = !1) : ($(this).removeClass("validation_error"), $(this).removeAttr("aria-label tabindex")) : ($(this).addClass("validation_error"), o = !1) : $(this).find(".error_span").length > 0 ? ($(this).addClass("validation_error"), o = !1) : ($(this).removeClass("validation_error"), $(this).removeAttr("aria-label tabindex"))
            }), $("#hulkapps_option_list_" + t + " .dd_multi_render:visible").each(function() {
                var t = parseInt($(this).find(".hulk_po_dropdown_multiple").attr("data-min")),
                    e = parseInt($(this).find(".hulk_po_dropdown_multiple").attr("data-max")),
                    i = $(this).find("select[multiple] option:selected").length,
                    a = '<span class="validation_error error_span" tabindex="0" >';
                $(this).hasClass("required") && (0 == i || 0 == $(this).find("input[name^='properties']:not(.hulk_unique_sku)").val()) && $(this).append(a), 0 != t && 0 != e ? i < t ? ($(this).removeClass("validation_error").find(".error_span").remove(), $(this).append(`${a} Choose from ${t} to ${e} values</span>`), $(this).find(".validation_error").attr("aria-label", `Choose from ${t} to ${e} values`), 0 == i && $(this).hasClass("required") ? $(this).addClass("validation_error") : 0 == i && $(this).removeClass("validation_error").find(".error_span").remove()) : i > e ? ($(this).removeClass("validation_error").find(".error_span").remove(), $(this).append(`${a} Choose from ${t} to ${e} values</span>`), $(this).find(".validation_error").attr("aria-label", `Choose from ${t} to ${e} values`)) : $(this).removeClass("validation_error").find(".error_span").remove() : 0 != t ? i < t ? ($(this).removeClass("validation_error").find(".error_span").remove(), $(this).append(`${a} Choose at least  ${t} values</span>`), $(this).find(".validation_error").attr("aria-label", `Choose at least  ${t} values`)) : $(this).removeClass("validation_error").find(".error_span").remove() : 0 != e && (e >= i ? e == i ? $(this).removeClass("validation_error").find(".error_span").remove() : ($(this).removeClass("validation_error").find(".error_span").remove(), $(this).append(`${a} Choose upto ${e} values</span>`), $(this).find(".validation_error").attr("aria-label", `Choose upto ${e} values`)) : $(this).removeClass("validation_error").find(".error_span").remove()), $(this).find(".error_span").length > 0 ? ($(this).addClass("validation_error"), o = !1) : ($(this).removeClass("validation_error"), $(this).removeAttr("aria-label tabindex")), $(this).hasClass("required") || 0 != i || ($(this).removeClass("validation_error"), $(this).removeAttr("aria-label tabindex"), $(this).find(".validation_error.error_span").remove(), o = !0)
            }), $("." + e).find("#hulkapps_option_list_" + t + " .et_render.required:visible").each(function() {
                if ($(this).find("input[type='email']").length && (!$(this).find("input[name^='properties']").val() && $(this).hasClass("required") || "" != $(this).find("input[type='email']").val())) {
                    var t = $(this).find("input[type='email']").val();
                    /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,5}|[0-9]{1,3})(\]?)$/.test(t) ? ($(this).removeClass("validation_error"), $(this).removeAttr("aria-label tabindex"), $(this).find(".error_span").remove()) : ($(this).addClass("validation_error"), "" != $(this).find("input[type='email']").val() && !$(this).find(".error_span").length > 0 && ($(this).find("input[type='email']").after('<span class="validation_error error_span" tabindex="0" aria-label="Invalid email format">Invalid email format</span>'), $(this).attr("aria-label", "Invalid email format")), o = !1)
                }
            }), $("." + e).find("#hulkapps_option_list_" + t + " .pn_render.required:visible").each(function() {
                $(this).find("input[type='textbox']").length && !$(this).find("input[name^='properties']").val() && $(this).hasClass("required") ? ($(this).addClass("validation_error"), o = !1) : $(this).find(".phone_number").hasClass("error") ? ($(this).addClass("validation_error"), o = !1) : ($(this).removeClass("validation_error"), $(this).removeAttr("aria-label tabindex"))
            }), $("." + e).find("#hulkapps_option_list_" + t + " .dp_render:visible").each(function() {
                $(this).find(".error_span").length > 0 ? ($(this).addClass("validation_error"), o = !1) : ($(this).removeClass("validation_error"), $(this).removeAttr("aria-label tabindex"))
            }), $("." + e).find("#hulkapps_option_list_" + t + " .dt_render:visible").each(function() {
                $(this).find(".error_span").length > 0 ? ($(this).addClass("validation_error"), o = !1) : ($(this).removeClass("validation_error"), $(this).removeAttr("aria-label tabindex"))
            }), $("." + e).find("#hulkapps_option_list_" + t + " .dp_render.required:visible").each(function() {
                $(this).find("input[type='date']").length && !$(this).find("input[name^='properties']").val() && $(this).hasClass("required") ? ($(this).addClass("validation_error"), o = !1) : $(this).find(".error_span").length > 0 ? ($(this).addClass("validation_error"), o = !1) : ($(this).removeClass("validation_error"), $(this).removeAttr("aria-label tabindex"))
            }), $("." + e).find("#hulkapps_option_list_" + t + " .dt_render.required:visible").each(function() {
                $(this).find("input[type='time']").length && !$(this).find("input[name^='properties']").val() && $(this).hasClass("required") ? ($(this).addClass("validation_error"), o = !1) : $(this).find(".error_span").length > 0 ? ($(this).addClass("validation_error"), o = !1) : ($(this).removeClass("validation_error"), $(this).removeAttr("aria-label tabindex"))
            }), o = !$("." + e).find(".fm_option_val").hasClass("validation_error"), $("." + e).find("#hulkapps_option_list_" + t + " .mq_render:visible").each(function() {
                var t = parseInt($(this).attr("data-min")),
                    e = parseInt($(this).attr("data-max")),
                    i = Math.max(t, e),
                    a = 0,
                    n = $(this).find(".hulkapps_option_name").attr("aria-label"),
                    l = document.querySelector(`input[name*="properties[${n}]"]`),
                    s = '<span class="validation_error error_span" tabindex="0" >',
                    p = $(this).find(".hulk_multi_qty_main .muti-qty-div").length;
                "" !== l.value.trim() && (a = l.value.split(",").length), $(this).hasClass("required") && 0 == a && $(this).append(s), (p >= i && !window.ignore_min_max_validation || p >= i && window.ignore_min_max_validation || p <= i && !window.ignore_min_max_validation) && (0 != t && 0 != e ? a < t ? ($(this).removeClass("validation_error").find(".error_span").remove(), $(this).append(`${s} Choose from ${t} to ${e} values</span>`), $(this).find(".validation_error").attr("aria-label", `Choose from ${t} to ${e} values`), 0 == a && $(this).hasClass("required") ? $(this).addClass("validation_error") : 0 == a && $(this).removeClass("validation_error").find(".error_span").remove()) : a > e ? ($(this).removeClass("validation_error").find(".error_span").remove(), $(this).append(`${s} Choose from ${t} to ${e} values</span>`), $(this).find(".validation_error").attr("aria-label", `Choose from ${t} to ${e} values`)) : $(this).removeClass("validation_error").find(".error_span").remove() : 0 != t ? a < t ? ($(this).removeClass("validation_error").find(".error_span").remove(), $(this).append(`${s} Choose at least  ${t} values</span>`), $(this).find(".validation_error").attr("aria-label", `Choose at least  ${t} values`)) : $(this).removeClass("validation_error").find(".error_span").remove() : 0 != e && (e >= a ? e == a ? $(this).removeClass("validation_error").find(".error_span").remove() : ($(this).removeClass("validation_error").find(".error_span").remove(), $(this).append(`${s} Choose upto ${e} values</span>`), $(this).find(".validation_error").attr("aria-label", `Choose upto ${e} values`)) : $(this).removeClass("validation_error").find(".error_span").remove()), $(this).find(".error_span").length > 0 ? ($(this).addClass("validation_error"), o = !1) : ($(this).removeClass("validation_error"), $(this).removeAttr("aria-label tabindex"))), $(this).hasClass("required") || 0 != a || ($(this).removeClass("validation_error"), $(this).removeAttr("aria-label tabindex"), $(this).find(".validation_error.error_span").remove(), o = !0)
            }), o = await resolveInventory(e, o, i), $("." + e).find(".hulkapps_option:visible").each(function() {
                if ($(this).hasClass("validation_error")) {
                    o = !1;
                    var t = $(this).find(".hulkapps_option_name").attr("aria-label");
                    void 0 == $(this).attr("aria-label") && $(this).attr({
                        "aria-label": `${t} is required`,
                        tabindex: 0
                    }), $(".validation_error:first").focus()
                }
            }), !1 == o && $(".inventory_error,.validation_error").first().focus(), o
        }, window.validate_single_option = function(t, e, i = "") {
            var i = i;
            if ("" == i && (i = "hulkapps_product_options"), "dd_render" == e) 1 == $("." + i).find("." + t).find("select[name^='properties']").length && !$("." + i).find("." + t).find("select[name^='properties']:not(.hulk_unique_sku)").val() && $("." + i).find("." + t).hasClass("required") ? $("." + i).find("." + t).addClass("validation_error") : ($("." + i).find("." + t).removeAttr("aria-label tabindex"), $("." + i).find("." + t).removeClass("validation_error"));
            else if ("ci_render" == e) 1 == $("." + i).find("." + t).find("input[name^='properties']").length && !$("." + i).find("." + t).find("input[name^='properties']:not(.hulk_unique_sku)").val() && $("." + i).find("." + t).hasClass("required") ? $("." + i).find("." + t).addClass("validation_error") : ($("." + i).find("." + t).removeAttr("aria-label tabindex"), $("." + i).find("." + t).removeClass("validation_error"));
            else if ("dd_multi_render" == e) $("." + i).find("." + t).find("select[multiple]").length && !$("." + i).find("." + t).find("input[name^='properties']:not(.hulk_unique_sku)").val() && $("." + i).find("." + t).hasClass("required") ? $("." + i).find("." + t).addClass("validation_error") : ($("." + i).find("." + t).removeAttr("aria-label tabindex"), $("." + i).find("." + t).removeClass("validation_error"));
            else if ("swatch_render" == e) $("." + i).find("." + t).removeClass("validation_error"), $("." + i).find("." + t).removeAttr("aria-label tabindex");
            else if ("multiswatch_render" == e) $("." + i).find("." + t).find(".hulkapps_swatch_option").length && !$("." + i).find("." + t).find("input[name^='properties']:not(.hulk_unique_sku)").val() && $("." + i).find("." + t).hasClass("required") ? $("." + i).find("." + t).addClass("validation_error") : ($("." + i).find("." + t).removeClass("validation_error"), $("." + i).find("." + t).removeAttr("aria-label tabindex"));
            else if ("button_render" == e) $("." + i).find("." + t).find(".hulkapps_buton_option").length && !$("." + i).find("." + t).find("input[name^='properties']:not(.hulk_unique_sku,.hulk_unique_prop)").val() && $("." + i).find("." + t).hasClass("required") ? $("." + i).find("." + t).addClass("validation_error") : ($("." + i).find("." + t).removeAttr("aria-label tabindex"), $("." + i).find("." + t).removeClass("validation_error"), $("." + i).find("." + t).removeAttr("aria-label tabindex"));
            else if ("cp_render" == e) $("." + i).find("." + t).find("input[type='text']").length && !$("." + i).find("." + t).find("input[name^='properties']").val() && $("." + i).find("." + t).hasClass("required") ? $("." + i).find("." + t).addClass("validation_error") : ($("." + i).find("." + t).removeClass("validation_error"), $("." + i).find("." + t).removeAttr("aria-label tabindex"));
            else if ("cb_render" == e) $("." + i).find("." + t).find(".hulkapps_check_option").length && !$("." + i).find("." + t).find("input[name^='properties']:not(.hulk_unique_sku,.hulk_unique_prop)").val() && $("." + i).find("." + t).hasClass("required") ? $("." + i).find("." + t).addClass("validation_error") : ($("." + i).find("." + t).removeClass("validation_error"), $("." + i).find("." + t).removeAttr("aria-label tabindex"));
            else if ("tb_render" == e) $("." + i).find("." + t).find("input[type='text']").length && !$("." + i).find("." + t).find("input[name^='properties']").val() && $("." + i).find("." + t).hasClass("required") ? $("." + i).find("." + t).addClass("validation_error") : ($("." + i).find("." + t).removeClass("validation_error"), $("." + i).find("." + t).removeAttr("aria-label tabindex"));
            else if ("dt_render" == e) $("." + i).find("." + t).find("input[type='time']").length && !$("." + i).find("." + t).find("input[name^='properties']").val() && $("." + i).find("." + t).hasClass("required") ? $("." + i).find("." + t).addClass("validation_error") : ($("." + i).find("." + t).removeClass("validation_error"), $("." + i).find("." + t).removeAttr("aria-label tabindex"));
            else if ("stg_render" == e) $("." + i).find("." + t).removeClass("validation_error"), $("." + i).find("." + t).removeAttr("aria-label tabindex"), $("." + i).find("." + t).hasClass("required") && $("." + i).find("." + t).find("input[type='text']").each(function() {
                "" != $(this).val() || $(this).parents(".hulkapps_short_option_value").hasClass("conditional") || $("." + i).find("." + t).addClass("validation_error")
            });
            else if ("gf_render" == e) $("." + i).find("." + t).find("input[type='text']").length && !$("." + i).find("." + t).find("input[type='text']").val() && $("." + i).find("." + t).hasClass("required") ? $("." + i).find("." + t).addClass("validation_error") : ($("." + i).find("." + t).removeClass("validation_error"), $("." + i).find("." + t).removeAttr("aria-label tabindex"));
            else if ("nf_render" == e) $("." + i).find("." + t).find("input[type='number']").length && !$("." + i).find("." + t).find("input[name^='properties']").val() && $("." + i).find("." + t).hasClass("required") ? $("." + i).find("." + t).addClass("validation_error") : ($("." + i).find("." + t).removeClass("validation_error"), $("." + i).find("." + t).removeAttr("aria-label tabindex"));
            else if ("dp_render" == e) {
                if ($("." + i).find("." + t).find("input[type='date']").length && $("." + i).find("." + t).find("input[name^='properties']").val()) {
                    var a = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/,
                        o = $("." + i).find("." + t).find("input[type='date']").val();
                    if (o.includes("-")) {
                        var n = o.split("-");
                        o = n[1] + "/" + n[2] + "/" + n[0]
                    }
                    var l = o.match(a);
                    if (null == l) $("." + i).find("." + t).addClass("validation_error"), $("." + i).find("." + t).find(".validation_error").remove(), $("." + i).find("." + t).find("input[type='date']").after('<span class="validation_error error_span">Enter valid date format mm/dd/yyyy</span>');
                    else if (dtMonth = l[1], dtDay = l[3], dtYear = l[5], dtMonth < 1 || dtMonth > 12) $("." + i).find("." + t).addClass("validation_error"), $("." + i).find("." + t).find(".validation_error").remove(), $("." + i).find("." + t).find("input[type='date']").after('<span class="validation_error error_span">Enter valid date format mm/dd/yyyy</span>');
                    else if (dtDay < 1 || dtDay > 31) $("." + i).find("." + t).addClass("validation_error"), $("." + i).find("." + t).find(".validation_error").remove(), $("." + i).find("." + t).find("input[type='date']").after('<span class="validation_error error_span">Enter valid date format mm/dd/yyyy</span>');
                    else if ((4 == dtMonth || 6 == dtMonth || 9 == dtMonth || 11 == dtMonth) && 31 == dtDay) $("." + i).find("." + t).addClass("validation_error"), $("." + i).find("." + t).find(".validation_error").remove(), $("." + i).find("." + t).find("input[type='date']").after('<span class="validation_error error_span">Enter valid date format mm/dd/yyyy</span>');
                    else if (2 == dtMonth) {
                        var s = dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0);
                        dtDay > 29 || 29 == dtDay && !s ? ($("." + i).find("." + t).addClass("validation_error"), $("." + i).find("." + t).find(".validation_error").remove(), $("." + i).find("." + t).find("input[type='date']").after('<span class="validation_error error_span">Enter valid date format mm/dd/yyyy</span>')) : ($("." + i).find("." + t).removeClass("validation_error"), $("." + i).find("." + t).find(".validation_error").remove(), $("." + i).find("." + t).removeAttr("aria-label tabindex"))
                    } else "/" !== l[2] || "/" !== l[4] ? ($("." + i).find("." + t).addClass("validation_error"), $("." + i).find("." + t).find(".validation_error").remove(), $("." + i).find("." + t).find("input[type='date']").after('<span class="validation_error error_span" tabindex="0" aria-labe="Enter valid date format mm/dd/yyyy">Enter valid date format mm/dd/yyyy</span>')) : ($("." + i).find("." + t).removeClass("validation_error"), $("." + i).find("." + t).find(".validation_error").remove(), $("." + i).find("." + t).removeAttr("aria-label tabindex"))
                } else $("." + i).find("." + t).find("input[type='date']").length && !$("." + i).find("." + t).find("input[name^='properties']").val() && $("." + i).find("." + t).hasClass("required") ? $("." + i).find("." + t).addClass("validation_error") : ($("." + i).find("." + t).removeClass("validation_error"), $("." + i).find("." + t).removeAttr("aria-label tabindex"))
            } else if ("ta_render" == e) $("." + i).find("." + t).find("textarea").length && !$("." + i).find("." + t).find("input[name^='properties']").val() && $("." + i).find("." + t).hasClass("required") ? $("." + i).find("." + t).addClass("validation_error") : ($("." + i).find("." + t).removeClass("validation_error"), $("." + i).find("." + t).removeAttr("aria-label tabindex"));
            else if ("rb_render" == e) $("." + i).find("." + t).removeClass("validation_error"), $("." + i).find("." + t).removeAttr("aria-label tabindex");
            else if ("fu_render" == e) $("." + i).find("." + t).find("input[type='file']").length && !$("." + i).find("." + t).find("input[name^='properties']").val() && $("." + i).find("." + t).hasClass("required") ? $("." + i).find("." + t).addClass("validation_error") : ($("." + i).find("." + t).removeClass("validation_error"), $("." + i).find("." + t).removeAttr("aria-label tabindex"));
            else if ("pn_render" == e) $("." + i).find("." + t).find("input[type='textbox']").length && !$("." + i).find("." + t).find("input[name^='properties']").val() && $("." + i).find("." + t).hasClass("required") ? ($("." + i).find("." + t).addClass("validation_error"), good = !1) : $("." + i).find("." + t).find(".phone_number").hasClass("error") ? ($("." + i).find("." + t).addClass("validation_error"), good = !1) : ($("." + i).find("." + t).removeClass("validation_error"), $("." + i).find("." + t).removeAttr("aria-label tabindex"));
            else if ("et_render" == e) {
                if ($("." + i).find("." + t).find("input[type='email']").length && ($("." + i).find("." + t).find("input[name^='properties']").val() && $("." + i).find("." + t).hasClass("required") || "" != $("." + i).find("." + t).find("input[type='email']").val().length)) {
                    var p = $("." + i).find("." + t).find("input[type='email']").val();
                    /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,5}|[0-9]{1,3})(\]?)$/.test(p) ? ($("." + i).find("." + t).removeClass("validation_error"), $("." + i).find("." + t).find(".error_span").remove(), $("." + i).find("." + t).removeAttr("aria-label tabindex")) : ($("." + i).find("." + t).addClass("validation_error"), !$("." + i).find("." + t).find(".error_span").length > 0 && ($("." + i).find("." + t).attr("aria-label", "Invalid email format"), $("." + i).find("." + t).find("input[type='email']").after('<span class="validation_error error_span" tabindex="0" aria-label="Invalid email format">Invalid email format</span>')))
                } else $("." + i).find("." + t).removeClass("validation_error"), $("." + i).find("." + t).find(".error_span").remove(), $("." + i).find("." + t).removeAttr("aria-label tabindex")
            }
        }, $(document).on("change", ".hulk_file_upload", function() {
            var t = $(this).val(),
                e = $(this)[0].files;
            /^\s*$/.test(t) ? ($(this).parents(".file-upload").removeClass("hulk-active"), $(this).parents(".file-upload").find(".noFile").text("No file chosen...")) : ($(this).parents(".file-upload").addClass("hulk-active"), e.length > 1 ? $(this).parents(".file-upload").find(".noFile").text(`${e.length} Files selected`) : $(this).parents(".file-upload").find(".noFile").text(t.replace("C:\\fakepath\\", "")))
        });
        var allOptions = "";

        function changeImage(t) {
            var e = "",
                t = $(t);
            if ($(".image_change_with_multiple").each(function() {
                    (first_element = $(this).find(".hulkapps_option_child:first")).attr("data-single_valid-class");
                    var t = first_element.attr("data-val-selected-class");
                    if ("radio" == $(first_element).prop("type")) 1 == $(this).find(`.${t}`).length && $.trim($(this).find(`.${t}`).parents(".hulkapps_radio_option").find(".hulkapps_option_child").attr("data-conditional-value")) != $.trim(e) && (e += $.trim($(this).find(`.${t}`).parents(".hulkapps_radio_option").find(".hulkapps_option_child").attr("data-conditional-value")) + " ");
                    else if ("select-one" == $(first_element).prop("type")) {
                        var i = $(first_element).find(":selected").data("conditional-value");
                        $.trim(i) != $.trim(e) && (e += $.trim(i) + " ")
                    } else 1 == $(this).find(`.${t}`).length && $.trim($(this).find(`.${t}`).attr("data-conditional-value")) != $.trim(e) && (e += $.trim($(this).find(`.${t}`).attr("data-conditional-value")) + " ")
                }), "" != $.trim(e)) {
                var i = $.trim(e.toLowerCase());
                $(window.image_parent).each(function() {
                    $.trim($(this).attr("alt").toLowerCase().replaceAll("_", " ")) == i && $(this).click()
                })
            }
        }
        $(document).on("click", "ul.hulkapps_product_options_ul .init", function() {
            $(this).parent(".hulkapps_option_child").children("li:not(.init)").toggleClass("hulk-flex")
        }), $(document).on("click", "ul.hulkapps_product_options_ul li:not(.init)", function() {
            var t = $(this).parent("ul").attr("data-parent"),
                e = $(this).parent("ul").attr("data-pid"),
                i = $(this).attr("data-uid"),
                a = $(this).attr("data-display-val"),
                o = $(this).attr("data-hinventory");
            $(this).parents(".hulkapps_option_value").find(".hulk_options_quantity").show(), $(this).parents(".ci_render").find(".inventory_error").html(""), $(this).parents(".ci_render").find(".hulk_unique_sku").prop("disabled", !0);
            var n = $(this).closest("ul").attr("id");
            (allOptions = $("#" + n).children("li:not(.init)")).removeClass("dropdown_selected"), $(this).addClass("dropdown_selected"), $(this).closest("ul").children(".init").html($(this).html()), $(this).closest("ul").children("li:not(.init)").toggleClass("hulk-flex"), $(this).closest("ul").children(".init").attr("data-uid", i), $(this).closest("ul").children(".init").attr("data-display-val", a), $(this).closest("ul").children(".init").attr("data-hinventory", o);
            var l = "";
            $(this).parents(".hulkapps_option_value").find(".hulk_options_quantity").val() && (l = ` | ${$(this).parents(".hulkapps_option_value").find(".hulk_options_quantity").val()}`), $(this).parents(".hulkapps_option_value").find(".hulk_unique_prop").length > 0 && ("" != $(this).data("hinventory") ? $(this).parents(".hulkapps_option_value").find(".hulk_unique_prop").val($(this).attr("data-value") + "_hin_" + $(this).data("hinventory") + l) : $(this).parents(".hulkapps_option_value").find(".hulk_unique_prop").val("")), $(this).parents(".hulkapps_option_value").find(".hulk_opt_prop").val($(this).attr("data-value") + l), $(this).find(".hulk_unique_sku").prop("disabled", !1), conditional_rules(parseInt(e), t), "1" == $("#hulk_amount_dis").val() && calc_options_total(parseInt(e), t), validate_single_option("option_type_id_" + n, "ci_render", t), changeImage(this)
        }), $(document).on("click", ".hulkapps_product_options_ul_parent .hulk_options_quantity", function() {
            $(this).parents(".hulkapps_option_value").find(".hulk_opt_prop").val($(this).parents(".hulkapps_option_value").find("li.dropdown_selected").attr("data-value") + " | " + $(this).val()), $(this).parents(".hulkapps_option_value").find(".hulk_unique_prop") && $(this).parents(".hulkapps_option_value").find(".hulk_unique_prop").length > 0 && $(this).parents(".hulkapps_option_value").find("li.dropdown_selected").data("hinventory") && $(this).parents(".hulkapps_option_value").find(".hulk_unique_prop").val($(this).parents(".hulkapps_option_value").find("li.dropdown_selected").attr("data-value") + "_hin_" + $(this).parents(".hulkapps_option_value").find("li.dropdown_selected").data("hinventory") + " | " + $(this).val()), "1" == $("#hulk_amount_dis").val() && calc_options_total(parseInt(window.hulkapps.product_id), "hulkapps_product_options")
        }), $(document).on("click keyup", ".multi-qty-option", function(t) {
            $(this).parents(".muti-qty-div").parents(".hulkapps_option_value").parent(".mq_render").removeClass("validation_error"), $(this).parents(".muti-qty-div").parents(".hulkapps_option_value").parent(".mq_render").find(".inventory_error").remove();
            var e = [],
                i = [],
                a = [],
                o = $(this).parent(".quantity_selector").find(".hulk_quantity_amount").attr("data-parent"),
                n = $(this).parent(".quantity_selector").find(".hulk_quantity_amount").attr("data-pid"),
                l = 0,
                s = $(this).parent(".quantity_selector").find(".hulk_quantity_amount").attr("data-qval"),
                p = '<span class="validation_error error_span" tabindex="0" >',
                d = $(this).parents(".muti-qty-div").parents(".hulkapps_option_value").parent(".mq_render");
            if ("number_input" == $(this).data("htype")) {
                var s = $(this).val();
                $(this).text(s), $(this).attr("data-qval", s)
            } else "increment" == $(this).data("htype") ? (s++, $(this).parent(".quantity_selector").find(".hulk_quantity_amount").val(s), $(this).parent(".quantity_selector").find(".hulk_quantity_amount").attr("data-qval", s)) : s > 0 && (s--, $(this).parent(".quantity_selector").find(".hulk_quantity_amount").val(s), $(this).parent(".quantity_selector").find(".hulk_quantity_amount").attr("data-qval", s));
            if (0 != $(".hulk_quantity_popup").length) var u = parseInt($(this).siblings(".hulk_quantity_amount").attr("data-min")),
                c = parseInt($(this).siblings(".hulk_quantity_amount").attr("data-max")),
                d = $(this).parents(".muti-qty-div").parent(".hulk_multi_qty_main");
            else var u = parseInt($(this).parents(".mq_render").attr("data-min")),
                c = parseInt($(this).parents(".mq_render").attr("data-max")),
                d = $(this).parents(".muti-qty-div").parents(".hulkapps_option_value").parent(".mq_render");
            var f = 0;
            !window.ignore_min_max_validation && checkPlan("validation_for_min_max_option_selection", "boolean") ? ($(this).parents(".muti-qty-div").parents(".hulkapps_option_value").find(".hulk_quantity_amount").each(function() {
                parseInt($(this).attr("data-qval")) > 0 && f++
            }), 0 != u && 0 != c ? f < u ? (d.removeClass("validation_error").find(".error_span").remove(), d.append(`${p} Choose from ${u} to ${c} values</span>`), d.find(".validation_error").attr("aria-label", `Choose from ${u} to ${c} values`), 0 == f && d.removeClass("validation_error").find(".error_span").remove()) : f > c ? (d.removeClass("validation_error").find(".error_span").remove(), d.append(`${p} Choose from ${u} to ${c} values</span>`), d.find(".validation_error").attr("aria-label", `Choose from ${u} to ${c} values`), f != c && d.removeClass("validation_error").find(".error_span").remove(), s--, "number_input" == $(this).data("htype") ? ($(this).val(0), $(this).attr("data-qval", 0)) : ($(this).parent(".quantity_selector").find(".hulk_quantity_amount").text(s), $(this).parent(".quantity_selector").find(".hulk_quantity_amount").attr("data-qval", s))) : d.removeClass("validation_error").find(".error_span").remove() : 0 != u ? f < u ? (d.removeClass("validation_error").find(".error_span").remove(), d.append(`${p} Choose at least  ${u} values</span>`), d.find(".validation_error").attr("aria-label", `Choose at least  ${u} values`)) : d.removeClass("validation_error").find(".error_span").remove() : 0 != c && (c >= f ? c == f ? d.removeClass("validation_error").find(".error_span").remove() : (d.removeClass("validation_error").find(".error_span").remove(), d.append(`${p} Choose upto ${c} values</span>`), d.find(".validation_error").attr("aria-label", `Choose upto ${c} values`)) : (d.removeClass("validation_error").find(".error_span").remove(), s--, "number_input" == $(this).data("htype") ? ($(this).val(0), $(this).attr("data-qval", 0)) : ($(this).parent(".quantity_selector").find(".hulk_quantity_amount").text(s), $(this).parent(".quantity_selector").find(".hulk_quantity_amount").attr("data-qval", s))))) : d.removeClass("validation_error").find(".error_span").remove(), $(this).parents(".muti-qty-div").parents(".hulkapps_option_value").find(".hulk_quantity_amount").each(function(t) {
                if (parseInt($(this).attr("data-qval")) > 0) {
                    $(this).parents(".hulk_quantity_div").parent(".muti-qty-div").find(".hulk_quantity_left").find(".hulk_unique_sku").removeAttr("disabled"), $(this).attr("id");
                    var o = "",
                        n = "";
                    o = ` | ${$(this).attr("data-qval")}`, n = $(this).attr("data-qval");
                    var s = $(this).attr("data-hinventory");
                    l += parseFloat($(this).attr("data-price")) * parseInt(n);
                    var p = $(this).attr("data-value");
                    s && e.push(`${p}_hin_${s}${o}`), i.push(`${p}${o}`), a.push(`${p}_hin_${n}`)
                } else $(this).parents(".muti-qty-div").find(".hulk_quantity_left").find(".hulk_unique_sku").attr("disabled", !0)
            }), $(this).parents(".muti-qty-div").parent(".hulk_multi_qty_main").find(".hulk_unique_prop").val(e.join(" , ")), i.length > 0 ? ($(this).parents(".muti-qty-div").parent(".hulk_multi_qty_main").find(".hulk_unique_prop").addClass("mqty_selected"), $(this).parents(".muti-qty-div").parent(".hulk_multi_qty_main").find(".hulk_unique_prop").attr("data-inventory-record", a), $(this).parents(".muti-qty-div").parent(".hulk_multi_qty_main").find(".hulk_unique_prop").attr("data-price", l)) : ($(this).parents(".muti-qty-div").parent(".hulk_multi_qty_main").find(".hulk_unique_prop").removeClass("mqty_selected"), $(this).parents(".muti-qty-div").parent(".hulk_multi_qty_main").find(".hulk_unique_prop").attr("data-price", "")), $(this).parents(".muti-qty-div").parent(".hulk_multi_qty_main").find(".hulk_mutli_qty").val(i.join(" , ")), calc_options_total(parseInt(n), o), conditional_rules(parseInt(n), o)
        }), $(document).on("change", ".hulk_po_dropdown", function() {
            var t = $(this).attr("id"),
                e = $(this).attr("data-parent"),
                i = $(this).attr("data-pid");
            $(this).val() ? $(this).parent(".hulkapps_option_value").find(".hulk_options_quantity").show() : $(this).parent(".hulkapps_option_value").find(".hulk_options_quantity").hide(), $(this).parents(".dd_render").find(".hulk_unique_sku").prop("disabled", !0), $(this).parents(".dd_render").find(".inventory_error").html("");
            var a = "";
            $(this).parent(".hulkapps_option_value").find(".hulk_options_quantity").val() && (a = ` | ${$(this).parent(".hulkapps_option_value").find(".hulk_options_quantity").val()}`), $(this).parent(".hulkapps_option_value").find(".hulk_unique_prop") && $(this).parent(".hulkapps_option_value").find(".hulk_unique_prop").length > 0 && ($(this).val() && $(this).children("option:selected").data("hinventory") ? $(this).parent(".hulkapps_option_value").find(".hulk_unique_prop").val(`${$(this).val()}_hin_${$(this).children("option:selected").data("hinventory")}${a}`) : $(this).parent(".hulkapps_option_value").find(".hulk_unique_prop").val("")), $(this).val() ? $(this).parent(".hulkapps_option_value").find(".hulk_dropdown_hidden_prop").val($(this).val() + a) : $(this).parent(".hulkapps_option_value").find(".hulk_dropdown_hidden_prop").val("");
            var o = $(this).find("option:selected").data("conditional-value");
            o && $(this).parents(".dd_render").find(`[data-sku-identifier='${o}']`).removeAttr("disabled"), conditional_rules(parseInt(i), e), "1" == $("#hulk_amount_dis").val() && calc_options_total(parseInt(i), e), validate_single_option(`option_type_id_${t}`, "dd_render", e), changeImage(this)
        }), $(document).on("change", ".hulk_po_dropdown_quantity", function() {
            var t = $(this).attr("data-parent"),
                e = $(this).attr("data-pid");
            $(this).parent(".hulkapps_option_value").find(".hulk_dropdown_hidden_prop").val(`${$(this).parent(".hulkapps_option_value").find(".hulkapps_option_child").val()} | ${$(this).val()}`), $(this).parent(".hulkapps_option_value").find(".hulk_unique_prop") && $(this).parent(".hulkapps_option_value").find(".hulk_unique_prop").length > 0 && ($(this).parent(".hulkapps_option_value").find(".hulkapps_option_child").children("option:selected").data("hinventory") ? $(this).parent(".hulkapps_option_value").find(".hulk_unique_prop").val(`${$(this).parent(".hulkapps_option_value").find(".hulkapps_option_child").val()}_hin_${$(this).parent(".hulkapps_option_value").find(".hulkapps_option_child").children("option:selected").data("hinventory")} | ${$(this).val()}`) : $(this).parent(".hulkapps_option_value").find(".hulk_unique_prop").val("")), "1" == $("#hulk_amount_dis").val() && calc_options_total(parseInt(e), t)
        }), $(document).on("change", ".hulk_po_dropdown_multiple", function() {
            var t = $(this).attr("id"),
                e = parseInt($(this).attr("data-min")),
                i = parseInt($(this).attr("data-max")),
                a = '<span class="validation_error error_span" tabindex="0">',
                o = $(this).attr("data-parent"),
                n = $(this).attr("data-pid");
            $(this).parents(".dd_multi_render").find(".hulk_unique_sku").prop("disabled", !0), $(this).parents(".dd_multi_render").find(".inventory_error").html(""), 0 != e && 0 != i && checkPlan("validation_for_min_max_option_selection", "boolean") ? $(this).find("option:selected").length < e ? ($(this).parents(".hulkapps_option").removeClass("validation_error").find(".error_span").remove(), $(this).after(`${a} Choose from ${e} to ${i} values</span>`), $(this).parents(".hulkapps_option").find(".validation_error").attr("aria-label", `Choose from ${e} to ${i} values`), 0 == $(this).find("option:selected").length && $(this).parents(".hulkapps_option").removeClass("validation_error").find(".error_span").remove()) : $(this).find("option:selected").length > i ? ($(this).find("option:selected:last").prop("selected", !1), $(this).parents(".hulkapps_option").removeClass("validation_error").find(".error_span").remove(), $(this).after(`${a} Choose from ${e} to ${i} values</span>`), $(this).parents(".hulkapps_option").find(".validation_error").attr("aria-label", `Choose from ${e} to ${i} values`), $(this).find("option:selected").length == i && $(this).parents(".hulkapps_option").removeClass("validation_error").find(".error_span").remove()) : $(this).parents(".hulkapps_option").removeClass("validation_error").find(".error_span").remove() : checkPlan("validation_for_min_max_option_selection", "boolean") ? $(this).find("option:selected").length < e ? ($(this).parents(".hulkapps_option").removeClass("validation_error").find(".error_span").remove(), $(this).after(`${a} Choose at least  ${e} values</span>`), $(this).parents(".hulkapps_option").find(".validation_error").attr("aria-label", `Choose at least  ${e} values`)) : $(this).parents(".hulkapps_option").removeClass("validation_error").find(".error_span").remove() : checkPlan("validation_for_min_max_option_selection", "boolean") ? i >= $(this).find("option:selected").length ? i == $(this).find("option:selected").length ? $(this).parents(".hulkapps_option").removeClass("validation_error").find(".error_span").remove() : ($(this).parents(".hulkapps_option").removeClass("validation_error").find(".error_span").remove(), $(this).after(`${a} Choose upto ${i} values</span>`), $(this).parents(".hulkapps_option").find(".validation_error").attr("aria-label", `Choose upto ${i} values`)) : ($(this).parents(".hulkapps_option").removeClass("validation_error").find(".error_span").remove(), $(this).find("option:selected:last").prop("selected", !1)) : $(this).parents(".hulkapps_option").removeClass("validation_error");
            var l = $.map($(`.${o}`).find(`.hulkapps_option_${t}_visible:not([disabled])  :selected`), function(t, e) {
                return $(t).val()
            });
            $(`.${o}`).find(`#hulkapps_option_${t}_hidden`).val(l.join(", "));
            var s = $.map($(`.${o}`).find(`.hulkapps_option_${t}_visible:not([disabled]) :selected`), function(t, e) {
                if ("" != $(t).data("hinventory")) return $(t).val() + "_hin_" + $(t).data("hinventory")
            });
            $(this).parent(".hulkapps_option_value").find(".hulk_unique_prop").length > 0 && $(this).parent(".hulkapps_option_value").find(".hulk_unique_prop").val(s.join(", ")), $(`.${o}`).find(`.hulkapps_option_${t}_visible:not([disabled]) :selected`).each(function(t) {
                var e = $(this).data("conditional-value");
                e && $(this).parents(".dd_multi_render").find(`[data-sku-identifier='${e}']`).removeAttr("disabled")
            }), conditional_rules(parseInt(n), o), "1" == $("#hulk_amount_dis").val() && calc_options_total(parseInt(n), o), validate_single_option(`option_type_id_${t}`, "dd_multi_render", o)
        }), $(document).on("click", ".hulk_po_radio", function() {
            var t = $(this).attr("data-oid"),
                e = $(this).attr("data-parent"),
                i = $(this).attr("data-pid"),
                a = $(this).attr("data-radio-class"),
                o = $(this).attr("data-single_valid-class"),
                n = $(this).attr("data-val-selected-class"),
                l = $(this).attr("data-hidden-class");
            $(this).parents(`.${o}`).find(".hulk_unique_sku").prop("disabled", !0), $(this).parents(".hulkapps_option_value").find(".hulk_options_quantity").show();
            var s = "";
            $(this).parents(".hulkapps_option_value").find(".hulk_options_quantity").val() && (s = ` | ${$(this).parents(".hulkapps_option_value").find(".hulk_options_quantity").val()}`), $(this).parents(".hulkapps_option_value").find(".hulk_unique_prop") && $(this).parents(".hulkapps_option_value").find(".hulk_unique_prop").length > 0 && ($(this).find(`.${a}`).data("hinventory") ? $(this).parents(".hulkapps_option_value").find(".hulk_unique_prop").val(`${$(this).find(`.${a}`).val()}_hin_${$(this).find(`.${a}`).data("hinventory")}${s}`) : $(this).parents(".hulkapps_option_value").find(".hulk_unique_prop").val("")), $(this).find(`.${a}`).prop("checked", !0), $(this).parents(`.${o}`).find(`.${n}`).removeClass(n), $(this).parents(".hulkapps_option_value").find(`.${l}`).val(`${$(this).find(`.${a}`).val()}${s}`), $(this).parents(`.${o}`).find(".inventory_error").html(""), $(this).addClass(n), $(this).parents("label").find(".hulk_unique_sku").prop("disabled", !1), conditional_rules(parseInt(i), e), "1" == $("#hulk_amount_dis").val() && calc_options_total(parseInt(i), e), validate_single_option(`option_type_id_${t}`, o, e), changeImage(this)
        }), $(document).on("change", ".hulk_po_swatch_quantity", function() {
            var t = $(this).attr("data-parent"),
                e = $(this).attr("data-pid");
            $(this).parent(".hulkapps_option_value").find(".hulk_swatch_hidden_prop").val(`${$(this).parents(".hulkapps_option_value").find(".swatch_radio:checked").val()} | ${$(this).val()}`), $(this).parents(".hulkapps_option_value").find(".hulk_unique_prop") && $(this).parents(".hulkapps_option_value").find(".hulk_unique_prop").length > 0 && $(this).parent(".hulkapps_option_value").find(".swatch_radio:checked").data("hinventory") ? $(this).parents(".hulkapps_option_value").find(".hulk_unique_prop").val(`${$(this).parent(".hulkapps_option_value").find(".swatch_radio:checked").val()}_hin_${$(this).parent(".hulkapps_option_value").find(".swatch_radio:checked").data("hinventory")} | ${$(this).val()}`) : $(this).parents(".hulkapps_option_value").find(".hulk_unique_prop").val(""), "1" == $("#hulk_amount_dis").val() && calc_options_total(parseInt(e), t)
        }), $(document).on("change", ".hulk_po_button_quantity", function() {
            var t = $(this).attr("data-parent"),
                e = $(this).attr("data-pid");
            $(this).parents(".hulkapps_option_value").find(".hulk_button_hidden_prop").val(`${$(this).parents(".hulkapps_option_value").find(".button_selected").find(".button_radio").val()} | ${$(this).val()}`), $(this).parents(".hulkapps_option_value").find(".hulk_unique_prop") && $(this).parents(".hulkapps_option_value").find(".hulk_unique_prop").length > 0 && $(this).parent(".hulkapps_option_value").find(".button_selected").find(".button_radio").data("hinventory") && $(this).parents(".hulkapps_option_value").find(".hulk_unique_prop").val(`${$(this).parents(".hulkapps_option_value").find(".button_selected").find(".button_radio").val()}_hin_${$(this).parent(".hulkapps_option_value").find(".button_selected").find(".button_radio").data("hinventory")} | ${$(this).val()}`), "1" == $("#hulk_amount_dis").val() && calc_options_total(parseInt(e), t)
        }), window.keybordAccess = function() {
            let t = document.querySelectorAll(".hulkapps_buton_option,.hulkapps_check_option,.hulkapps_radio_option,.hulkapps_swatch_option,.hulkapps_mswatch_option,ul.hulkapps_product_options_ul .init,ul.hulkapps_product_options_ul li:not(.init),.hulk_po_other_options,.font-select span,.fs-results li,.hulk_file_upload,.popup_open_link,.file-upload,.popup_close_link");
            t.forEach(t => {
                t.addEventListener("keydown", e => {
                    ("Enter" === e.key || " " === e.key) && (t.classList.contains("file-upload") ? t.querySelector(".hulk_file_upload").click() : t.click())
                })
            });
            var e = document.getElementsByClassName("hulkapps_option_value"),
                i = 0,
                a = 0;
            document.addEventListener("keydown", function(t) {
                var o = t.keyCode;
                if (37 === o || 38 === o) a = a > 0 ? a - 1 : 0;
                else {
                    if (39 !== o && 40 !== o) return;
                    var n = document.activeElement.closest(".hulkapps_option_value");
                    n || (n = e[i]);
                    var l = n.querySelectorAll("label, li").length - 1;
                    a === l ? n && (Array.prototype.indexOf.call(e, n) === i || (i = i < e.length - 1 ? i + 1 : 0), a = 0) : a = a < l ? a + 1 : l
                }
                var s = document.activeElement.closest(".hulkapps_option_value");
                s && (i = Array.prototype.indexOf.call(e, s));
                var p = e[i].querySelectorAll("label, li")[a];
                void 0 != p && (p.focus(), t.preventDefault())
            })
        }, $(document).on("click", ".hulk_po_checkbox", function() {
            var t = $(this).attr("data-oid"),
                e = $(this).attr("data-single_valid-class"),
                i = parseInt($(this).attr("data-min")),
                a = parseInt($(this).attr("data-max")),
                o = '<span class="validation_error error_span" tabindex="0" >',
                n = $(this).attr("data-parent"),
                l = $(this).attr("data-pid");
            $(this).parents(`.${e}`).find(".hulk_unique_sku").prop("disabled", !0), "multiswatch_render" == e ? $(this).addClass("swatch_selected") : $(this).parents(".cb_render").find(".inventory_error").html(""), 0 != i && 0 != a && checkPlan("validation_for_min_max_option_selection", "boolean") ? $(`.hulkapps_option_${t}_visible:checkbox:checked`).length < i ? ($(this).parents(".hulkapps_option").removeClass("validation_error").find(".error_span").remove(), $(this).parents(".hulkapps_option").append(`${o} Choose from ${i} to ${a} values</span>`), $(this).parents(".hulkapps_option").find(".validation_error").attr("aria-label", `Choose from ${i} to ${a} values`), 0 == $(`.hulkapps_option_${t}_visible:checkbox:checked`).length && $(this).parents(".hulkapps_option").removeClass("validation_error").find(".error_span").remove()) : $(`.${n}`).find(`.hulkapps_option_${t}_visible:checkbox:checked`).length > a ? ($(this).parents(".hulkapps_option").removeClass("validation_error").find(".error_span").remove(), $(this).parents(".hulkapps_option").append(`${o} Choose from ${i} to ${a} values</span>`), $(this).parents(".hulkapps_option").find(".validation_error").attr("aria-label", `Choose from ${i} to ${a} values`), $(`.${n}`).find(`.hulkapps_option_${t}_visible:checkbox:checked`).length != a && $(this).parents(".hulkapps_option").removeClass("validation_error").find(".error_span").remove(), "multiswatch_render" == e ? $(this).find(":checkbox").prop("checked", !1) : this.checked = !1) : $(this).parents(".hulkapps_option").removeClass("validation_error").find(".error_span").remove() : 0 != i && checkPlan("validation_for_min_max_option_selection", "boolean") ? $(`.${n}`).find(`.hulkapps_option_${t}_visible:checkbox:checked`).length < i ? ($(this).parents(".hulkapps_option").removeClass("validation_error").find(".error_span").remove(), $(this).parents(".hulkapps_option").append(`${o} Choose at least  ${i} values</span>`), $(this).parents(".hulkapps_option").find(".validation_error").attr("aria-label", `Choose at least  ${i} values`)) : $(this).parents(".hulkapps_option").removeClass("validation_error").find(".error_span").remove() : 0 != a && checkPlan("validation_for_min_max_option_selection", "boolean") && (a >= $(`.${n}`).find(`.hulkapps_option_${t}_visible:checkbox:checked`).length ? a == $(`.${n}`).find(`.hulkapps_option_${t}_visible:checkbox:checked`).length ? $(this).parents(".hulkapps_option").removeClass("validation_error").find(".error_span").remove() : ($(this).parents(".hulkapps_option").removeClass("validation_error").find(".error_span").remove(), $(this).parents(".hulkapps_option").append(`${o} Choose upto ${a} values</span>`), $(this).parents(".hulkapps_option").find(".validation_error").attr("aria-label", `Choose upto ${a} values`)) : ($(this).parents(".hulkapps_option").removeClass("validation_error").find(".error_span").remove(), "multiswatch_render" == e ? $(this).find(":checkbox").prop("checked", !1) : this.checked = !1)), conditional_rules(parseInt(l), n);
            var s = $.map($(`.${n}`).find(`.hulkapps_option_${t}_visible:not([disabled]):checked`), function(t, e) {
                return $(t).val()
            });
            $(`.${n}`).find(`.hulkapps_option_${t}_visible:not([disabled]):checked`).each(function(t) {
                $(this).parents("label").find(".hulk_unique_sku").removeAttr("disabled")
            }), $(`.${n}`).find(`#hulkapps_option_${t}_hidden`).val(s.join(",  "));
            var p = $.map($(`.${n}`).find(`.hulkapps_option_${t}_visible:not([disabled]):checked`), function(t, e) {
                if ("" != $(t).data("hinventory")) return $(t).val() + "_hin_" + $(t).data("hinventory")
            });
            $(this).parents(".hulkapps_option_value").find(".hulk_unique_prop").length > 0 && ($(this).parents(".hulkapps_option_value").find(".hulk_unique_prop").val(p.join(", ")), "multiswatch_render" == e && $(this).parents(".hulkapps_option_value").find(".swatch_checkbox:disabled").parent(".hulkapps_option_child").removeClass("swatch_selected")), "1" == $("#hulk_amount_dis").val() && calc_options_total(parseInt(l), n), validate_single_option(`option_type_id_${t}`, e, n)
        }), $(document).on("change", ".hulk_po_swatch_multiple_checkbox", function(t) {
            $(this).is(":checked") ? $(this).parent().addClass("swatch_selected") : $(this).parent().removeClass("swatch_selected"), $(this).parents(".multiswatch_render").find(".inventory_error").html("")
        }), $(document).on("change", ".hulk_po_radiobutton", function() {
            var t = $(this).attr("data-oid"),
                e = $(this).attr("data-parent"),
                i = $(this).attr("data-pid");
            if ($(this).is(":checked")) {
                $(this).parents(".hulkapps_option_value").find(".hulk_options_quantity").show(), $(this).parents(".rb_render").find(".hulk_unique_sku").prop("disabled", !0);
                var a = "";
                $(this).parents(".hulkapps_option_value").find(".hulk_options_quantity").val() && (a = ` | ${$(this).parents(".hulkapps_option_value").find(".hulk_options_quantity").val()}`), $(this).parents(".hulkapps_option_value").find(".hulk_unique_prop") && $(this).parents(".hulkapps_option_value").find(".hulk_unique_prop").length > 0 && ($(this).data("hinventory") ? $(this).parents(".hulkapps_option_value").find(".hulk_unique_prop").val(`${$(this).val()}_hin_${$(this).data("hinventory")}${a}`) : $(this).parents(".hulkapps_option_value").find(".hulk_unique_prop").val("")), $(this).parents(".hulkapps_option_value").find(".hulk_radiobutton_hidden_prop").val($(this).val() + a), $(this).parent().siblings().find(".radio_div").removeClass("radio_selected"), $(this).parent().find(".radio_div").addClass("radio_selected"), $(this).parent().find(".radio_div").addClass("radio_selected"), $(this).parents("label").find(".hulk_unique_sku").prop("disabled", !1), changeImage(this)
            }
            conditional_rules(parseInt(i), e), "1" == $("#hulk_amount_dis").val() && calc_options_total(parseInt(i), e), validate_single_option(`option_type_id_${t}`, "rb_render", e)
        }), $(document).on("change", ".hulk_po_radiobutton_quanity", function() {
            var t = $(this).attr("data-parent"),
                e = $(this).attr("data-pid");
            $(this).parent(".hulkapps_option_value").find(".hulk_radiobutton_hidden_prop").val(`${$(this).parent(".hulkapps_option_value").find(".radio_selected").parent(".hulkapps_radio_option").find(".hulkapps_option_child").val()} | ${$(this).val()}`), $(this).parent(".hulkapps_option_value").find(".hulk_unique_prop") && $(this).parent(".hulkapps_option_value").find(".hulk_unique_prop").length > 0 && $(this).parent(".hulkapps_option_value").find(".radio_selected").parent(".hulkapps_radio_option").find(".hulkapps_option_child").data("hinventory") && $(this).parent(".hulkapps_option_value").find(".hulk_unique_prop").val(`${$(this).parent(".hulkapps_option_value").find(".radio_selected").parent(".hulkapps_radio_option").find(".hulkapps_option_child").val()}_hin_${$(this).parent(".hulkapps_option_value").find(".radio_selected").parent(".hulkapps_radio_option").find(".hulkapps_option_child").data("hinventory")} | ${$(this).val()}`), "1" == $("#hulk_amount_dis").val() && calc_options_total(parseInt(e), t)
        }), $(document).on("change input", ".hulk_po_other_options", function() {
            var t = $(this).attr("id"),
                e = $(this).attr("data-parent"),
                i = $(this).attr("data-pid"),
                a = $(this).attr("data-single_valid-class"),
                o = $(this).attr("data-val-selected-class"),
                n = $(this).attr("data-is-charge"),
                l = $(this).data("price");
            if ("character_charge" == n) {
                $(this).attr("data-is-charge");
                var s = $(this).attr("data-main-price");
                l = parseFloat(s) * $.trim($(this).val()).length, $(this).attr("data-price", l)
            }
            var p = $(this).val();
            if ("" != p) {
                if ("0.00" != l) var d = `${p} [ ${window.hulk_po_currency_symbol}${l} ]`;
                else var d = p;
                $(this).parent().find(".other_options_prop_val").val(d), $(this).addClass(o)
            } else $(this).parent().find(".other_options_prop_val").val(""), $(this).removeClass(o);
            conditional_rules(parseInt(i), e), "1" == $("#hulk_amount_dis").val() && calc_options_total(parseInt(i), e), validate_single_option(`option_type_id_${t}`, a, e)
        }), $(document).on("change", ".po_changed_formula", function() {
            var po_final_price = "",
                final_prop = "",
                hulk_parent_div = $(this).parents(".fm_option_val").attr("data-parent"),
                hulk_pid = $(this).parents(".fm_option_val").attr("data-pid"),
                min_selection = 0,
                max_selection = 0,
                opt_name = $(this).attr("data-name");
            $(this).attr("min") && (min_selection = parseInt($(this).attr("min"))), $(this).attr("max") && (max_selection = parseInt($(this).attr("max")));
            var is_validated = !0;
            $(this).parent(".hulkapps_option_value").find(".error_span").remove(), 0 != min_selection && 0 != max_selection ? parseFloat($(this).val()) < min_selection || parseFloat($(this).val()) > max_selection ? ($(this).parent(".hulkapps_option_value").append(`<span class='validation_error error_span' tabindex='0' aria-label='Choose values from ${min_selection} - ${max_selection} for option ${opt_name}'>  Choose values from ${min_selection} - ${max_selection}. </span>`), is_validated = !1) : ($(this).parent(".hulkapps_option_value").find(".error_span").remove(), is_validated = !0) : 0 != min_selection ? parseFloat($(this).val()) < min_selection ? ($(this).parent(".hulkapps_option_value").append(`<span class='validation_error error_span' tabindex='0' aria-label=' Choose values higher than  ${min_selection} for option ${opt_name}'>  Choose values higher than  ${min_selection}. </span>`), is_validated = !1) : ($(this).parent(".hulkapps_option_value").find(".error_span").remove(), is_validated = !0) : 0 != max_selection && (parseFloat($(this).val()) > max_selection ? ($(this).parent(".hulkapps_option_value").append(`<span class='validation_error error_span' tabindex='0' aria-label='Choose values up to ${max_selection} for option ${opt_name}'> Choose values up to ${max_selection}. </span>`), is_validated = !1) : ($(this).parent(".hulkapps_option_value").find(".error_span").remove(), is_validated = !0));
            var error_span_length = $(this).parents(".fm_option_val").find(".error_span").length;
            is_validated && 0 == error_span_length ? ($(this).parents(".fm_option_val").find(".po_changed_formula").each(function() {
                po_final_price += parseFloat($(this).val()) + $(this).attr("data-arithmatic"), final_prop += `${$(this).attr("data-name")}:${$(this).val()} | `
            }), po_final_price = po_final_price.slice(0, -1), final_prop = final_prop.slice(0, -1), po_final_price = eval(po_final_price).toFixed(2), $(this).parents(".fm_option_val").removeClass("validation_error"), $(this).parents(".fm_render").find(".error_span").remove(), isNaN(po_final_price) ? (0 >= parseFloat($(this).val()) && $(this).val(""), $(this).parents(".fm_option_val").find(".hulk_formula_hidden_prop").removeClass("formula_selected"), $(this).parents(".fm_option_val").find(".hulk_formula_hidden_prop").val(""), $(this).parents(".fm_option_val").find(".hulk_formula_hidden_prop").attr("data-price", ""), calc_options_total(parseInt(hulk_pid), hulk_parent_div)) : po_final_price <= 0 || "Infinity" == po_final_price || 0 >= parseFloat($(this).val()) ? (0 >= parseFloat($(this).val()) && $(this).val(""), $(this).parents(".fm_option_val").addClass("validation_error"), $(this).parents(".fm_render").append("<span class='validation_error error_span' tabindex='0' aria-label='Please change your value(s)'> Please change your value(s). </span>"), $(this).parents(".fm_option_val").find(".hulk_formula_hidden_prop").removeClass("formula_selected"), $(this).parents(".fm_option_val").find(".hulk_formula_hidden_prop").val(""), $(this).parents(".fm_option_val").find(".hulk_formula_hidden_prop").attr("data-price", ""), calc_options_total(parseInt(hulk_pid), hulk_parent_div)) : ($(this).parents(".fm_option_val").find(".hulk_formula_hidden_prop").val(`${final_prop}[${po_final_price}]`), $(this).parents(".fm_option_val").find(".hulk_formula_hidden_prop").attr("data-price", po_final_price), $(this).parents(".fm_option_val").find(".hulk_formula_hidden_prop").addClass("formula_selected"), calc_options_total(parseInt(hulk_pid), hulk_parent_div))) : (0 >= parseFloat($(this).val()) && $(this).val(""), $(this).parents(".fm_option_val").find(".hulk_formula_hidden_prop").removeClass("formula_selected"), $(this).parents(".fm_option_val").find(".hulk_formula_hidden_prop").val(""), $(this).parents(".fm_option_val").find(".hulk_formula_hidden_prop").attr("data-price", ""), calc_options_total(parseInt(hulk_pid), hulk_parent_div)), conditional_rules(parseInt(hulk_pid), hulk_parent_div)
        }), $(document).on("change", '.stg_render input[type="text"]', function() {
            opt_val = $(this).parents(".stg_render").find("input[type='text']").map(function() {
                if ("" != $(this).val()) return $(this).attr("data-key-name") + " : " + $(this).val()
            }).get().join(" | ");
            var t = $(this).parents(".stg_render").find(".stg_hidden").attr("data-pid"),
                e = $(this).parents(".stg_render").find(".stg_hidden").attr("data-oid"),
                i = $(this).attr("data-parent"),
                a = $(this).attr("data-single_valid-class"),
                o = $(this).attr("data-val-selected-class");
            if ("" != opt_val) {
                if (opt_price = $(this).parents(".stg_render").find(".stg_hidden").data("price"), opt_currency = window.hulk_po_currency_symbol, "0:00" != opt_price) {
                    var n = opt_val + " [ " + opt_currency + " " + opt_price + " ]";
                    $(this).parents(".stg_render").find(".stg_property_val").val(n), $(this).parents(".stg_render").find(".stg_hidden").addClass(o)
                } else {
                    var n = opt_val;
                    $(this).parents(".stg_render").find(".stg_property_val").val(n), $(this).parents(".stg_render").find(".stg_hidden").addClass(o)
                }
            } else $(this).parents(".stg_render").find(".stg_property_val").val(""), $(this).parents(".stg_render").find(".stg_hidden").removeClass(o);
            conditional_rules(parseInt(t), i), "1" == $("#hulk_amount_dis").val() && calc_options_total(parseInt(t), i), validate_single_option(`option_type_id_${e}`, a, i)
        }), $(document).on("keyup", ".hulkapps_discount_code", function(t) {
            "" != $.trim($(this).val()) ? ($(".hulkapps_product_discount_button").removeAttr("disabled"), $(".hulkapps_product_discount_button").removeClass("hulkapps_product_discount_disabled_button")) : ($(".hulkapps_product_discount_button").attr("disabled", "disabled"), $(".hulkapps_product_discount_button").addClass("hulkapps_product_discount_disabled_button"))
        }), hulkapps_jQuery(document).on("blur", ".hulkapps_option_value [type='time']", function(t) {
            var e = $(this).attr("id"),
                i = $(this).attr("data-parent"),
                a = $(this).attr("data-pid"),
                o = $(this).attr("data-single_valid-class"),
                n = $(this).attr("data-val-selected-class"),
                l = $(this).data("price"),
                s = hulkapps_jQuery(this).val(),
                p = hulkapps_jQuery(this).attr("min"),
                d = hulkapps_jQuery(this).attr("max"),
                u = new Date("1970-01-01T" + s + ":00");
            if ("" != p) var c = new Date("1970-01-01T" + p + ":00");
            if ("" != d) var f = new Date("1970-01-01T" + d + ":00");
            if ("" != s) {
                if (u < c || u > f) {
                    hulkapps_jQuery(this).val("");
                    var v = "";
                    $(this).parent().find(".other_options_prop_val").val(""), $(this).removeClass(n), v = c && f ? "Please select a time between " + c.toLocaleTimeString([], {
                        timeStyle: "short"
                    }) + " and " + f.toLocaleTimeString([], {
                        timeStyle: "short"
                    }) + "." : c ? "Please select a time from " + c.toLocaleTimeString([], {
                        timeStyle: "short"
                    }) + "." : "Please select a time earlier than " + f.toLocaleTimeString([], {
                        timeStyle: "short"
                    }) + ".", hulkapps_jQuery(this).parent(".hulkapps_option_value").append("<span class='validation_error error_span' tabindex='0' aria-label='" + v + "'>" + v + "</span>");
                    var m = hulkapps_jQuery(this);
                    setTimeout(function() {
                        m.parent(".hulkapps_option_value").find(".validation_error").remove()
                    }, 3e3)
                } else {
                    if ("0.00" != l) var k = `${s} [ ${window.hulk_po_currency_symbol}${l} ]`;
                    else var k = s;
                    $(this).parent().find(".other_options_prop_val").val(k), $(this).addClass(n)
                }
            } else $(this).parent().find(".other_options_prop_val").val(""), $(this).removeClass(n);
            conditional_rules(parseInt(a), i), "1" == $("#hulk_amount_dis").val() && calc_options_total(parseInt(a), i), validate_single_option(`option_type_id_${e}`, o, i)
        }), hulkapps_jQuery(document).on("blur", ".hulkapps_option_value [type='date']", function(t) {
            var e = $(this).attr("id"),
                i = $(this).attr("data-parent"),
                a = $(this).attr("data-pid"),
                o = $(this).attr("data-single_valid-class"),
                n = $(this).attr("data-val-selected-class"),
                l = $(this).data("price"),
                s = hulkapps_jQuery(this).val(),
                p = hulkapps_jQuery(this).attr("min"),
                d = hulkapps_jQuery(this).attr("max"),
                u = new Date(s);
            if ("" != p) {
                var c = new Date(p).toISOString().split("T")[0];
                c = new Date(c)
            }
            if ("" != d) {
                var f = new Date(d).toISOString().split("T")[0];
                f = new Date(d)
            }
            if ("" != s) {
                if (u < c || u > f) {
                    hulkapps_jQuery(this).val("");
                    var v = "";
                    $(this).parent().find(".other_options_prop_val").val(""), $(this).removeClass(n), v = c && f ? "Please select a date between " + c.toISOString().split("T")[0] + " and " + f.toISOString().split("T")[0] + "." : c ? "Please select a time from " + c.toISOString().split("T")[0] + "." : "Please select a time earlier than " + f.toISOString().split("T")[0] + ".", hulkapps_jQuery(this).parent(".hulkapps_option_value").append("<span class='validation_error error_span' tabindex='0' aria-label='" + v + "'>" + v + "</span>");
                    var m = hulkapps_jQuery(this);
                    setTimeout(function() {
                        m.parent(".hulkapps_option_value").find(".validation_error").remove()
                    }, 3e3)
                } else {
                    if ("0.00" != l) var k = `${s} [ ${window.hulk_po_currency_symbol}${l} ]`;
                    else var k = s;
                    $(this).parent().find(".other_options_prop_val").val(k), $(this).addClass(n)
                }
            } else $(this).parent().find(".other_options_prop_val").val(""), $(this).removeClass(n);
            conditional_rules(parseInt(a), i), "1" == $("#hulk_amount_dis").val() && calc_options_total(parseInt(a), i), validate_single_option(`option_type_id_${e}`, o, i)
        }), $(document).on("click", ".hulkapps_product_discount_button", function(t) {
            $(".hulkapps_product_discount_button").attr("disabled", "disabled"), $(".hulkapps_product_discount_button").addClass("hulkapps_product_discount_disabled_button"), new Promise((t, e) => {
                var i = validate_options(window.hulkapps.product_id, "hulkapps_product_options");
                t(i)
            }).then(function(t) {
                if (t) {
                    var e = Shopify.locale,
                        i = {};
                    i[window.hulkapps.product.selected_variant] = window.hulkapps.product_collection, $.ajax({
                        type: "POST",
                        url: window.hulkapps.po_url + "/store/get_cart_details",
                        data: {
                            cart_data: window.hulk_cjson,
                            store_id: window.hulkapps.store_id,
                            cart_collections: JSON.stringify(i),
                            customer_tags: null != window.hulkapps.customer ? window.hulkapps.customer.tags.split(",") : "",
                            draft_order_language: void 0 != e ? e : "",
                            discount_code: $("input[name=checkout_discount]").val()
                        },
                        crossDomain: !0,
                        success: function(t) {
                            var e = t.discounts,
                                i = parseFloat(e.discount_cut_price);
                            e.discount_code && 1 == e.discount_error ? (hulkapps_jQuery(".hulkapps_summary_product").remove(), $(".discount_code_box_product .hulkapps_discount_hide").after("<span class='hulkapps_summary_product'>Discount code does not match</span>"), $(".hulkapps-summary-product-line-discount-code").html(""), $(".product_after_discount_price").html("")) : e.is_free_shipping ? ($(".hulkapps_summary_product").remove(), $(".hulkapps-summary-product-line-discount-code").html(""), $(".product_after_discount_price").html(""), $(".discount_code_box_product .hulkapps_discount_hide").after("<span class='hulkapps-summary-product-line-discount-code'><span class='discount-tag'>" + e.discount_code + "<span class='product-close-tag close-tag'></span></span>Free Shipping")) : e.discount_code && i <= 0 ? ($(".discount_code_box_product .hulkapps_discount_hide").after("<span class='hulkapps_summary_product'>" + e.discount_code + " discount code isn’t valid for the items in your cart</span>"), $(".hulkapps_discount_code").val(""), $(".hulkapps-summary-product-line-discount-code").html(""), $(".product_after_discount_price").html("")) : e.discount_code ? ($(".discount_code_box_product").find(".hulkapps_summary_product").html(""), $(".hulkapps-summary-product-line-discount-code,.product_after_discount_price").remove(), $(".discount_code_box_product .hulkapps_discount_hide").after("<span class='hulkapps-summary-product-line-discount-code'><span class='discount-tag'>" + e.discount_code + "<span class='product-close-tag close-tag'></span></span><span class='hulkapps_with_discount'> -" + e.with_discount + "</span></span><span class='product_after_discount_price'><span class='final-total'>Total</span>" + e.final_with_discounted_price + "</span>"), $(".hulkapps-cart-total").remove()) : ($(".hulkapps-summary-product-line-discount-code").html(""), $(".product_after_discount_price").html(""), $(".discount_code_box_product").find(".hulkapps_summary_product").html("")), $(".hulkapps_product_discount_button").removeAttr("disabled"), $(".hulkapps_product_discount_button").removeClass("hulkapps_product_discount_disabled_button")
                        }
                    })
                }
            }).catch(function(t) {})
        }), $(document).on("click", ".hulkapps_product_discount_modal .modal_close_btn", function(t) {
            $(".hulkapps_product_discount_modal").hide()
        });
        var hulk_flag = 0,
            hulk_flag = 0;
        $(document).on("click", ".hulkapps_submit_cart", function(t) {
            0 == hulk_flag && (t.preventDefault(), new Promise((t, e) => {
                var i = validate_options(window.hulkapps.product_id, "hulkapps_product_options");
                t(i)
            }).then(function(t) {
                t && ($("[name^='properties']").each(function() {
                    ("" == $(this).val() || $(this).hasClass("hf_property_val") && $(this).hasClass("conditional")) && $(this).attr("disabled", !0)
                }), hulk_flag = 1, $(".hulkapps_submit_cart").click(), 1 == hulk_flag && ($("[name^='properties']").each(function() {
                    ("" == $(this).val() || $(this).hasClass("hf_property_val") && $(this).hasClass("conditional")) && $(this).attr("disabled", !1)
                }), window.hulk_multi_qty_selector && setTimeout(function() {
                    window.hulkUpdateStockStatus($)
                }, 700), hulk_flag = 0))
            }).catch(function(t) {
                hulk_flag = 1, $(".hulkapps_submit_cart").click(), 1 == hulk_flag && ($("[name^='properties']").each(function() {
                    ("" == $(this).val() || $(this).hasClass("hf_property_val") && $(this).hasClass("conditional")) && $(this).attr("disabled", !1)
                }), hulk_flag = 0)
            }))
        })
    }, window.productPage_functionJS = function(t) {
        function e(t, e, i) {
            Shopify.queue.push({
                variantId: t,
                quantity: e,
                properties: i
            })
        }
        Shopify.queue = [], Shopify.successCount = 0, Shopify.failedIds = [], Shopify.failedDescriptions = [], Shopify.moveAlong = function(e) {
            if (Shopify.queue.length) {
                let i = Shopify.queue.shift();
                Shopify.addItem1(i.variantId, i.quantity, i.properties, function() {
                    Shopify.moveAlong(e)
                })
            }
            "" != Shopify.failedDescriptions && (t(document).find(".hulk_sold_out_error").remove(), t(document).find(".hulkapps-volumes").after('<div class="hulk_sold_out_error" style="color: red;">' + Shopify.failedDescriptions.join(", ") + "</div>"), t(document).find(".hulk_sold_out_error").fadeIn().delay(5e3).fadeOut(), t(document).find(".hulkapps-volumes button.offer-option-btn").prop("disabled", !1)), Shopify.queue.length || t(document).find(".hulkapps-volumes").find(".offer-option-item").length !== Shopify.successCount || 0 !== Shopify.failedIds.length || (e ? document.location.href = "/checkout" : document.location.href = "/cart")
        }, Shopify.addItem1 = function(e, i, a, o) {
            let n = {
                quantity: i,
                id: e
            };
            !1 != a && (n.properties = a), t.ajax({
                type: "POST",
                url: "/cart/add.js",
                dataType: "json",
                data: n,
                success: function() {
                    Shopify.successCount++, "function" == typeof o && o()
                },
                error: function(t, i, a) {
                    console.log("AJAX Error:", a), console.log("Error details:", t.responseJSON), t.responseJSON && t.responseJSON.description && Shopify.failedDescriptions.push(t.responseJSON.description), Shopify.failedIds.push(e), Shopify.successCount++, "function" == typeof o && o()
                }
            })
        }, window.bundle_bxgy_variant_logic = function() {
            let e = 0,
                i = 0,
                a = 0,
                o = 0,
                n = 0,
                l = 0,
                s;
            t(document).find(".hulkapps-volumes .offer-option-btn").prop("disabled", !0), t(".hulkapps-volumes").find(".offer-option-item").each(function() {
                let p = [];
                s = t(this);
                let d = t(this).attr("id");
                t(this).find("select.grid_name").length > 0 ? (t(this).find("select.grid_name").each(function() {
                    let e = t(this).children("option:selected").val();
                    p.push(e)
                }), p = p.join(" / ")) : p = "Default Title";
                let u = t(s).find(".hulk-variant-selection-dropdown option").filter(function() {
                        return t(this).text() === p
                    }).val(),
                    c = t(s).find(".hulk-variant-selection-dropdown option").filter(function() {
                        return t(this).text() === p
                    }).attr("data-variant");
                if (null != u) {
                    let f = JSON.parse(c);
                    if (f) {
                        let v = JSON.parse(t(s).attr("data-image")),
                            m = f ? f.image_id : v[0].id,
                            k = v.find(t => t.id === m),
                            g = k ? k.src : v[0] ? .src;
                        (null == g || void 0 == g) && (g = `${window.hulkapps.vd_url}/images/no_image.jpg`), t(s).find("img").attr("src", g);
                        let $ = f.price,
                            b = currency_conversion($);
                        t(s).find(".item-compare_price span").text(b);
                        let y = t(s).attr("id").split("_")[1];
                        t(s).find(".item-compare_price").text(b);
                        let x = 1;
                        if ("bxgy" == window.main_offer_type) {
                            let _ = "div[class^='" + y + "_qty_box']";
                            x = t(s).find(_).text().replace("X", "");
                            let w = t(s).attr("data-discount_type"),
                                q = t(s).attr("data-discount_val");
                            if ("Y" == y) {
                                if ("% Off" == w) {
                                    let C = parseFloat($) * (q / 100);
                                    n = parseFloat($) - C, a += C * parseInt(x);
                                    let S = currency_conversion(n);
                                    t(s).find(".item-regular_price").text(S)
                                } else if ("price_discount" == w) {
                                    let j = (l += parseFloat(t(s).find(".item-compare_price").text().trim().match(/[0-9,]+(?:\.[0-9]{1,2})?/)[0].replace(/,/g, "")) * x) / Shopify.currency.rate;
                                    a = j >= q ? q : j, a *= Shopify.currency.rate
                                } else "free_gift" == w && (a += parseFloat($) * parseInt(x), o += parseFloat($))
                            }
                            let A = `${"Y"==y&&("free_gift"===w||"% Off"===w)?"text-decoration:line-through":"text-decoration:unset"}`;
                            t(s).find(".item-compare_price").attr("style", A), e += parseFloat($) * parseInt(x)
                        } else if ("bundle" == window.main_offer_type) {
                            let z = t(s).attr("data-offer_type"),
                                O = t(s).attr("data-discount_type"),
                                E = t(s).attr("data-discount_val"),
                                L = t(s).attr("data-free_products");
                            if ("discount" == z) {
                                if ("% Off" == O) {
                                    n = parseFloat($) - parseFloat($) * E / 100, i += n;
                                    let F = currency_conversion(n);
                                    t(s).find(".item-regular_price").text(F)
                                } else "price_discount" == O && (i += parseFloat($))
                            } else L.includes(d) || (i += parseFloat($));
                            e += parseFloat($)
                        }
                        t(s).attr("data-add", JSON.stringify({
                            variant_id: f.id,
                            quantity: x
                        }))
                    }
                }
            }), window.prefix_symbol, e.toFixed(2), window.suffix_symbol;
            let p = currency_conversion(e);
            if ("bundle" == window.main_offer_type) {
                let d = t(s).attr("data-offer_type"),
                    u = t(s).attr("data-discount_type"),
                    c = t(s).attr("data-discount_val");
                "discount" == d && "price_discount" == u && (i -= c * Shopify.currency.rate);
                let f = currency_conversion(i);
                t(document).find(".bundle_offer_layout .bundle_total").find(".item-compare_price span.money").text(p), t(document).find(".bundle_offer_layout .bundle_total").find(".item-regular_price span.money").text(f)
            } else if ("bxgy" == window.main_offer_type) {
                let v = currency_conversion(e.toFixed(2) - a);
                t(document).find(".bxgy_offer_layout .bxgy_total").find(".item-compare_price span.money").text(p), t(document).find(".bxgy_offer_layout .bxgy_total").find(".item-regular_price span.money").text(v)
            }
            t(document).find(".hulkapps-volumes .offer-option-btn").prop("disabled", !1)
        }, t(document).on("change", ".offer-option-item .offer-option select", function(t) {
            bundle_bxgy_variant_logic()
        }), t(document).on("click", ".hulkapps-volumes button.offer-option-btn", function(i) {
            if (!t(this).attr("onclick")) {
                i.preventDefault();
                let a = t(this).hasClass("buynow");
                t(".hulkapps-volumes").find(".hulk_sold_out_error").remove(), t(".hulkapps-volumes button.offer-option-btn").prop("disabled", !0), t(".hulkapps-volumes").find(".offer-option-item").each(function() {
                    let i = JSON.parse(t(this).attr("data-add")),
                        a = i.variant_id,
                        o;
                    e(a, i.quantity, {})
                }), Shopify.successCount = 0, Shopify.failedIds = [], Shopify.failedDescriptions = [], a ? t.ajax({
                    type: "POST",
                    url: "/cart/clear.js",
                    data: "",
                    dataType: "json",
                    success: function() {
                        Shopify.moveAlong(a)
                    },
                    error: function(t, e) {
                        Shopify.moveAlong(a)
                    }
                }) : Shopify.moveAlong(a), t(document).find(".hulk_sold_out_error").remove()
            }
        })
    }, window.pixelTracking = function(t) {
        t && null != t && (t.facebook_pixel && null != t.facebook_pixel && fb_script(t.facebook_pixel), t.pinterest_pixel && null != t.pinterest_pixel && pinterest_script(t.pinterest_pixel), t.snapchat_pixel && null != t.snapchat_pixel && snapchat_script(t.snapchat_pixel), t.google_analaytics_pixel && null != t.google_analaytics_pixel && ga_script(t.google_analaytics_pixel))
    }, window.fb_script = function(t) {
        try {
            var e, i, a, o, n, l = "script",
                s = "https://connect.facebook.net/en_US/fbevents.js";
            e = window, i = document, e.fbq || (a = e.fbq = function() {
                a.callMethod ? a.callMethod.apply(a, arguments) : a.queue.push(arguments)
            }, e._fbq || (e._fbq = a), a.push = a, a.loaded = !0, a.version = "2.0", a.queue = [], (o = i.createElement(l)).async = !0, o.src = s, (n = i.getElementsByTagName(l)[0]).parentNode.insertBefore(o, n)), fbq("init", t), fbq("track", "PageView")
        } catch (p) {
            console.log(p.message)
        }
    }, window.pinterest_script = function(t) {
        try {
            (function(t) {
                if (!window.pintrk) {
                    window.pintrk = function() {
                        window.pintrk.queue.push(Array.prototype.slice.call(arguments))
                    };
                    var e = window.pintrk;
                    e.queue = [], e.version = "3.0";
                    var i = document.createElement("script");
                    i.async = !0, i.src = t;
                    var a = document.getElementsByTagName("script")[0];
                    a.parentNode.insertBefore(i, a)
                }
            })("https://s.pinimg.com/ct/core.js"), pintrk("load", t), pintrk("page")
        } catch (e) {
            console.log(e.message)
        }
    }, window.snapchat_script = function(t) {
        try {
            (function(t, e, i) {
                if (!t.snaptr) {
                    var a = t.snaptr = function() {
                        a.handleRequest ? a.handleRequest.apply(a, arguments) : a.queue.push(arguments)
                    };
                    a.queue = [];
                    var o = "script";
                    (r = e.createElement(o)).async = !0, r.src = i;
                    var n = e.getElementsByTagName(o)[0];
                    n.parentNode.insertBefore(r, n)
                }
            })(window, document, "https://sc-static.net/scevent.min.js"), c_email = window.hulkapps.customer ? window.hulkapps.customer.email : "", snaptr("init", t, {
                user_email: c_email
            }), snaptr("track", "PAGE_VIEW")
        } catch (e) {
            console.log(e.message)
        }
    }, window.ga_script = function(t) {
        try {
            var e = document.createElement("script");

            function i() {
                dataLayer.push(arguments)
            }
            e.type = "text/javascript", e.setAttribute("async", "true"), e.setAttribute("src", "https://www.googletagmanager.com/gtag/js?id=" + t), document.documentElement.firstChild.appendChild(e), window.dataLayer = window.dataLayer || [], i("js", new Date), i("config", t)
        } catch (a) {
            console.log(a.message)
        }
    }, window.tiktok_script = function(t) {
        try {
            ! function(e, i, a) {
                e.TiktokAnalyticsObject = a;
                var o = e[a] = e[a] || [];
                o.methods = ["page", "track", "identify", "instances", "debug", "on", "off", "once", "ready", "alias", "group", "enableCookie", "disableCookie"], o.setAndDefer = function(t, e) {
                    t[e] = function() {
                        t.push([e].concat(Array.prototype.slice.call(arguments, 0)))
                    }
                };
                for (var n = 0; n < o.methods.length; n++) o.setAndDefer(o, o.methods[n]);
                o.instance = function(t) {
                    for (var e = o._i[t] || [], i = 0; i < o.methods.length; i++) o.setAndDefer(e, o.methods[i]);
                    return e
                }, o.load = function(t, e) {
                    var i = "https://analytics.tiktok.com/i18n/pixel/events.js";
                    o._i = o._i || {}, o._i[t] = [], o._i[t]._u = i, o._t = o._t || {}, o._t[t] = +new Date, o._o = o._o || {}, o._o[t] = e || {};
                    var n = document.createElement("script");
                    n.type = "text/javascript", n.async = !0, n.src = i + "?sdkid=" + t + "&lib=" + a;
                    var l = document.getElementsByTagName("script")[0];
                    l.parentNode.insertBefore(n, l)
                }, o.load(t), o.page()
            }(window, document, "ttq")
        } catch (e) {
            console.log(e.message)
        }
    }, void 0 !== window.hulkapps && ("undefined" == typeof jQuery || 3 == parseInt(jQuery.fn.jquery) && 2.1 > parseFloat(jQuery.fn.jquery.replace(/^1\./, "")) ? hulkLoadScript("//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js", function() {
        checkAppInstalled(hulkapps_jQuery = jQuery.noConflict(!0))
    }) : checkAppInstalled(hulkapps_jQuery = jQuery)), window.add_to_cart = function(t) {
        hulkapps_jQuery("[name='quantity']").val(t), buy_now_wrap(), null != window.$first_add_to_cart_el && hulkapps_jQuery(window.$first_add_to_cart_el[0]).click()
    }, grab_deal = function(t) {
        t.preventDefault();
        let e = hulkapps_jQuery('input[name="card_group"]:checked').val();
        hulkapps_jQuery("[name='quantity']").val(e), buy_now_wrap(), null != window.$first_add_to_cart_el && hulkapps_jQuery(window.$first_add_to_cart_el[0]).click()
    }
}